package xyz.quaver.pupil.source

import xyz.quaver.pupil.hitomi.SortMode
import xyz.quaver.pupil.hitomi.getGallery
import xyz.quaver.pupil.hitomi.getGalleryIDsForQuery
import xyz.quaver.pupil.hitomi.getGalleryInfo
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.hitomi.urlFromUrlFromHash

class HitomiSource : ContentSource {
    override val id = "hitomi"
    override val displayName = "Hitomi"
    override val maturity = SourceMaturity.ADULT
    override val availability = SourceAvailability.READY

    override suspend fun search(query: String, page: Int): SourcePage {
        val pageSize = 30
        val ids = hitomiClient.getGalleryIDsForQuery(query, SortMode.DATE_ADDED)
        val from = (page * pageSize).coerceAtMost(ids.size)
        val to = (from + pageSize).coerceAtMost(ids.size)
        val items = ids.sliceArray(from until to).mapNotNull { id ->
            runCatching {
                val gallery = hitomiClient.getGallery(id)
                SourceItem(
                    sourceId = this.id,
                    remoteId = id.toString(),
                    title = gallery.title,
                    thumbnailUrl = gallery.cover,
                    pageUrl = null,
                    tags = gallery.tags,
                )
            }.getOrNull()
        }
        return SourcePage(items, if (to < ids.size) page + 1 else null)
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        val galleryId = remoteId.toInt()
        val gallery = hitomiClient.getGallery(galleryId)
        val info = hitomiClient.getGalleryInfo(galleryId)
        val images = info.files.map { file ->
            hitomiClient.urlFromUrlFromHash(galleryId, file, "webp", "webp")
        }
        return SourceDetail(
            item = SourceItem(id, remoteId, gallery.title, gallery.cover, null, gallery.tags),
            imageUrls = images,
            creators = gallery.artists,
        )
    }
}
