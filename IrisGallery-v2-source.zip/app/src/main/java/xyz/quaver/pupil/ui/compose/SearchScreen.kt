/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.drop
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.SortMode
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel
import xyz.quaver.pupil.util.DefaultQuery

private val sortModeLabels = listOf(
    SortMode.DATE_ADDED to R.string.main_menu_sort_date_added,
    SortMode.DATE_PUBLISHED to R.string.main_menu_sort_date_published,
    SortMode.POPULAR_TODAY to R.string.main_menu_sort_popular_today,
    SortMode.POPULAR_WEEK to R.string.main_menu_sort_popular_week,
    SortMode.POPULAR_MONTH to R.string.main_menu_sort_popular_month,
    SortMode.POPULAR_YEAR to R.string.main_menu_sort_popular_year,
    SortMode.RANDOM to R.string.main_menu_sort_random,
)

@Composable
fun SearchScreen(
    modifier: Modifier = Modifier,
    onGalleryClick: (Int) -> Unit = {},
    onShowDetail: (Int) -> Unit = {},
    viewModel: SearchViewModel = viewModel(),
) {
    // Kick off the first page once, rather than on every recomposition.
    LaunchedEffect(Unit) {
        if (viewModel.galleries.isEmpty() && viewModel.exception == null) viewModel.load()
    }

    LaunchedEffect(Unit) {
        snapshotFlow { DefaultQuery.signature }
            .drop(1)
            .collect { viewModel.onDefaultQueryChange() }
    }

    GalleryList(
        viewModel = viewModel,
        modifier = modifier,
        onGalleryClick = onGalleryClick,
        onShowDetail = onShowDetail,
        menuActions = { onDismissRequest ->
            WatchQueryMenuItem(
                query = viewModel.query,
                onDismissRequest = onDismissRequest,
            )

            HorizontalDivider()
        },
    ) {
        SortModeMenu(
            sortMode = viewModel.sortMode,
            onSortModeChange = viewModel::onSortModeChange,
        )
    }
}

@Composable
fun SortModeMenu(sortMode: SortMode, onSortModeChange: (SortMode) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(
                painterResource(R.drawable.sort_variant),
                contentDescription = stringResource(R.string.main_menu_sort),
            )
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            sortModeLabels.forEachIndexed { index, (mode, labelRes) ->
                DropdownMenuItem(
                    text = { Text(stringResource(labelRes)) },
                    trailingIcon = {
                        RadioButton(
                            selected = sortMode == mode,
                            onClick = {
                                expanded = false
                                onSortModeChange(mode)
                            },
                        )
                    },
                    onClick = {
                        expanded = false
                        onSortModeChange(mode)
                    },
                )
                if (index != sortModeLabels.lastIndex) HorizontalDivider()
            }
        }
    }
}
