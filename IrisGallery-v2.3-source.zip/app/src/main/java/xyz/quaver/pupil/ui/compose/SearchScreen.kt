/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.unit.dp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.drop
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.SortMode
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel
import xyz.quaver.pupil.util.DefaultQuery
import xyz.quaver.pupil.source.GgoorrSource
import xyz.quaver.pupil.source.SourceItem
import xyz.quaver.pupil.source.SourceDetail

private val sortModeLabels = listOf(
    SortMode.DATE_ADDED to R.string.main_menu_sort_date_added,
    SortMode.DATE_PUBLISHED to R.string.main_menu_sort_date_published,
    SortMode.POPULAR_TODAY to R.string.main_menu_sort_popular_today,
    SortMode.POPULAR_WEEK to R.string.main_menu_sort_popular_week,
    SortMode.POPULAR_MONTH to R.string.main_menu_sort_popular_month,
    SortMode.POPULAR_YEAR to R.string.main_menu_sort_popular_year,
    SortMode.RANDOM to R.string.main_menu_sort_random,
)

@Composable
fun SearchScreen(
    modifier: Modifier = Modifier,
    onGalleryClick: (Int) -> Unit = {},
    onShowDetail: (Int) -> Unit = {},
    viewModel: SearchViewModel = viewModel(),
) {
    var showGgoorr by remember { mutableStateOf(false) }

    // Kick off the first page once, rather than on every recomposition.
    LaunchedEffect(Unit) {
        if (viewModel.galleries.isEmpty() && viewModel.exception == null) viewModel.load()
    }

    LaunchedEffect(Unit) {
        snapshotFlow { DefaultQuery.signature }
            .drop(1)
            .collect { viewModel.onDefaultQueryChange() }
    }

    GalleryList(
        viewModel = viewModel,
        modifier = modifier,
        onGalleryClick = onGalleryClick,
        onShowDetail = onShowDetail,
        menuActions = { onDismissRequest ->
            DropdownMenuItem(
                text = { Text("Ggoorr source") },
                onClick = { onDismissRequest(); showGgoorr = true },
            )

            WatchQueryMenuItem(
                query = viewModel.query,
                onDismissRequest = onDismissRequest,
            )

            HorizontalDivider()
        },
    ) {
        SortModeMenu(
            sortMode = viewModel.sortMode,
            onSortModeChange = viewModel::onSortModeChange,
        )
    }

    if (showGgoorr) GgoorrBrowserDialog(onDismiss = { showGgoorr = false })
}

@Composable
private fun GgoorrBrowserDialog(onDismiss: () -> Unit) {
    val source = remember { GgoorrSource() }
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var detail by remember { mutableStateOf<SourceDetail?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        scope.launch {
            loading = true; error = null
            try { results = source.search(query).items }
            catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
            finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { load() }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { Button(onClick = onDismiss) { Text("Close") } },
        title = { Text(detail?.item?.title ?: "Ggoorr") },
        text = {
            Column {
                if (detail == null) {
                    Row(Modifier.fillMaxWidth()) {
                        OutlinedTextField(query, { query = it }, label = { Text("Search") }, modifier = Modifier.weight(1f), singleLine = true)
                        Button(onClick = { load() }, modifier = Modifier.padding(start = 8.dp)) { Text("Go") }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (loading) CircularProgressIndicator()
                    error?.let { Text("Error: $it") }
                    LazyColumn {
                        items(results, key = { it.remoteId }) { item ->
                            Row(Modifier.fillMaxWidth().clickable {
                                scope.launch {
                                    loading = true; error = null
                                    try { detail = source.detail(item.remoteId) }
                                    catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
                                    finally { loading = false }
                                }
                            }.padding(vertical = 8.dp)) {
                                RemoteImage(item.thumbnailUrl, Modifier.size(72.dp), item.title)
                                Text(item.title, Modifier.padding(start = 12.dp))
                            }
                        }
                    }
                } else {
                    Button(onClick = { detail = null }) { Text("Back") }
                    Spacer(Modifier.height(8.dp))
                    if (detail!!.imageUrls.isEmpty()) Text("No images found")
                    LazyColumn {
                        items(detail!!.imageUrls) { url ->
                            RemoteImage(url, Modifier.fillMaxWidth().height(420.dp), contentScale = ContentScale.Fit)
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        },
    )
}

@Composable
fun SortModeMenu(sortMode: SortMode, onSortModeChange: (SortMode) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(
                painterResource(R.drawable.sort_variant),
                contentDescription = stringResource(R.string.main_menu_sort),
            )
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            sortModeLabels.forEachIndexed { index, (mode, labelRes) ->
                DropdownMenuItem(
                    text = { Text(stringResource(labelRes)) },
                    trailingIcon = {
                        RadioButton(
                            selected = sortMode == mode,
                            onClick = {
                                expanded = false
                                onSortModeChange(mode)
                            },
                        )
                    },
                    onClick = {
                        expanded = false
                        onSortModeChange(mode)
                    },
                )
                if (index != sortModeLabels.lastIndex) HorizontalDivider()
            }
        }
    }
}
