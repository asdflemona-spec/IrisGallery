package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI

/** Public HTML adapter for the ggoorr /ao board. */
class GgoorrSource : ContentSource {
    override val id = "ggoorr"
    override val displayName = "Ggoorr"
    override val maturity = SourceMaturity.ADULT
    override val availability = SourceAvailability.READY

    private val baseUrl = "https://ggoorr.net"
    private val boardUrl = "$baseUrl/ao"

    private suspend fun document(url: String): Document {
        val response = client.get(url) {
            header(HttpHeaders.Referrer, boardUrl)
            header(HttpHeaders.UserAgent, "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        }
        if (!response.status.isSuccess()) throw IOException("Ggoorr HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }

    override suspend fun search(query: String, page: Int): SourcePage {
        val pageNumber = page + 1
        val url = buildString {
            append(boardUrl)
            append("?page=").append(pageNumber)
            if (query.isNotBlank()) {
                append("&search_target=title_content&search_keyword=")
                append(java.net.URLEncoder.encode(query, "UTF-8"))
            }
        }
        val doc = document(url)
        val seen = hashSetOf<String>()
        val items = doc.select("a[href]").mapNotNull { a ->
            val href = a.absUrl("href").ifBlank { a.attr("href") }
            val remoteId = remoteIdFrom(href) ?: return@mapNotNull null
            val title = a.text().trim()
            if (title.isBlank() || !seen.add(remoteId)) return@mapNotNull null
            val row = a.closest("tr, li, .document, .list_unit, .item")
            val thumb = row?.selectFirst("img[src], img[data-src], img[data-original]")?.let(::imageUrl)
            SourceItem(id, remoteId, title, thumb, "$boardUrl/$remoteId")
        }
        return SourcePage(items, if (items.isNotEmpty()) page + 1 else null)
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        val url = "$boardUrl/$remoteId"
        val doc = document(url)
        val title = doc.selectFirst("h1, h2, .document_title, .title")?.text()?.trim()
            ?.takeIf { it.isNotBlank() } ?: doc.title()

        val roots = listOf(
            ".xe_content", ".document_content", ".rd_body", ".read_body",
            "article", ".content", "#content"
        ).flatMap { doc.select(it) }.distinct()
        val scope = roots.firstOrNull { it.select("img").isNotEmpty() } ?: doc.body()
        val images = scope.select("img").mapNotNull(::imageUrl)
            .filter { it.startsWith("http://") || it.startsWith("https://") }
            .filterNot { u -> listOf("logo", "icon", "avatar", "emoji").any { u.contains(it, true) } }
            .distinct()

        return SourceDetail(
            item = SourceItem(id, remoteId, title, images.firstOrNull(), url),
            imageUrls = images,
        )
    }

    private fun imageUrl(img: org.jsoup.nodes.Element): String? {
        val raw = sequenceOf("data-original", "data-src", "data-lazy-src", "src")
            .map { img.attr(it).trim() }.firstOrNull { it.isNotBlank() } ?: return null
        if (raw.startsWith("data:")) return null
        return try { URI(boardUrl).resolve(raw).toString() } catch (_: Exception) { raw }
    }

    private fun remoteIdFrom(url: String): String? {
        val path = try { URI(url).path ?: return null } catch (_: Exception) { return null }
        val match = Regex("/ao/(\\d+)(?:/|$)").find(path) ?: return null
        return match.groupValues[1]
    }
}
