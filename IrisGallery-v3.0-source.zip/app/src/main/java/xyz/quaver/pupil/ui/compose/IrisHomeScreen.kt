/*
 * Iris Gallery fork of Pupil.
 * Pupil portions remain licensed under GPLv3; see app/LICENSE and FORK_NOTICE_KO.md.
 */
package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import xyz.quaver.pupil.source.GgoorrSource
import xyz.quaver.pupil.source.SourceDetail
import xyz.quaver.pupil.source.SourceItem
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel

enum class IrisHomeSource(val label: String) { HITOMI("Hitomi"), GGOORR("Ggoorr") }

@Composable
fun IrisHomeScreen(
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
    searchViewModel: SearchViewModel,
) {
    var selected by remember { mutableStateOf(IrisHomeSource.HITOMI) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("IRIS", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Discover across sources. Keep what matters in one visual library.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))
            Row {
                FilterChip(
                    selected = selected == IrisHomeSource.HITOMI,
                    onClick = { selected = IrisHomeSource.HITOMI },
                    label = { Text("Hitomi") },
                )
                Spacer(Modifier.size(8.dp))
                FilterChip(
                    selected = selected == IrisHomeSource.GGOORR,
                    onClick = { selected = IrisHomeSource.GGOORR },
                    label = { Text("Ggoorr") },
                )
            }
        }

        when (selected) {
            IrisHomeSource.HITOMI -> SearchScreen(
                modifier = Modifier.weight(1f),
                onGalleryClick = onGalleryClick,
                onShowDetail = onShowDetail,
                viewModel = searchViewModel,
            )
            IrisHomeSource.GGOORR -> GgoorrSourceScreen(Modifier.weight(1f))
        }
    }
}

@Composable
private fun GgoorrSourceScreen(modifier: Modifier = Modifier) {
    val source = remember { GgoorrSource() }
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var detail by remember { mutableStateOf<SourceDetail?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun search() {
        scope.launch {
            loading = true
            error = null
            detail = null
            try { items = source.search(query).items }
            catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
            finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { search() }

    Column(modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                label = { Text("Search Ggoorr") },
                singleLine = true,
            )
            Button(onClick = { search() }, modifier = Modifier.padding(start = 8.dp)) { Text("Go") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text("Source error: $it", modifier = Modifier.padding(vertical = 8.dp)) }

        val current = detail
        if (current == null) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.remoteId }) { item ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            scope.launch {
                                loading = true
                                error = null
                                try { detail = source.detail(item.remoteId) }
                                catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
                                finally { loading = false }
                            }
                        }.padding(vertical = 8.dp)
                    ) {
                        RemoteImage(item.thumbnailUrl, Modifier.size(84.dp), item.title)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium)
                            Text("Ggoorr", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        } else {
            Button(onClick = { detail = null }) { Text("Back to results") }
            Text(current.item.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(current.imageUrls) { url ->
                    RemoteImage(url, Modifier.fillMaxWidth().height(420.dp), contentScale = ContentScale.Fit)
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}
