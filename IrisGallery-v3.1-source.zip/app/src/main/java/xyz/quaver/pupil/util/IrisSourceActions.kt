package xyz.quaver.pupil.util

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import xyz.quaver.pupil.source.SourceDetail

object IrisSourceActions {
    private const val PREFS = "iris_library"

    fun download(context: Context, detail: SourceDetail, headers: Map<String, String>) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        var queued = 0
        detail.imageUrls.forEachIndexed { index, url ->
            if (url.substringBefore('?').lowercase().endsWith(".mp4") || url.substringBefore('?').lowercase().endsWith(".webm")) return@forEachIndexed
            runCatching {
                val ext = url.substringBefore('?').substringAfterLast('.', "jpg").take(5).ifBlank { "jpg" }
                val safeId = detail.item.remoteId.replace(Regex("[^A-Za-z0-9_-]"), "_")
                val req = DownloadManager.Request(Uri.parse(url))
                    .setTitle("Iris · ${detail.item.title}")
                    .setDescription("${index + 1}/${detail.imageUrls.size}")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_PICTURES, "Iris/Ggoorr/${safeId}_${index + 1}.$ext")
                headers.forEach { (k, v) -> req.addRequestHeader(k, v) }
                dm.enqueue(req); queued++
            }
        }
        Toast.makeText(context, if (queued > 0) "$queued files queued" else "No downloadable images", Toast.LENGTH_SHORT).show()
    }

    fun toggleSaved(context: Context, detail: SourceDetail): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = "saved:${detail.item.sourceId}:${detail.item.remoteId}"
        val next = !p.getBoolean(key, false)
        p.edit().putBoolean(key, next).apply()
        return next
    }

    fun isSaved(context: Context, detail: SourceDetail): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean("saved:${detail.item.sourceId}:${detail.item.remoteId}", false)

    fun recordHistory(context: Context, detail: SourceDetail) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong("history:${detail.item.sourceId}:${detail.item.remoteId}", System.currentTimeMillis()).apply()
    }

    fun openOriginal(context: Context, url: String?) {
        if (url == null) return
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    fun share(context: Context, detail: SourceDetail) {
        val text = detail.item.pageUrl ?: detail.imageUrls.firstOrNull() ?: return
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
        }, "Share from Iris"))
    }
}
