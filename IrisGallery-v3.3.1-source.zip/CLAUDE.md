# Working in this repo

## Comments

Do not add unnecessary comments. The code documents itself; a comment that
restates what the next line already says is noise that goes stale.

Rationale belongs in the commit message and the PR description, not in the
source. If a change needs explaining — why a set difference instead of a
complement, why a version is pinned, why a call site is ordered the way it is —
write it there, where it stays attached to the change without cluttering the
file for everyone who reads it later.

Leave a comment only when the code genuinely cannot carry the meaning: a
non-obvious external constraint, a workaround for a bug in a dependency, a
deliberate deviation that will look like a mistake to the next reader. Prefer
fixing the naming or the structure first.
