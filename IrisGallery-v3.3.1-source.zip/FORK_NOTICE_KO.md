# Iris Gallery

Iris Gallery는 업로드된 Pupil 소스 코드를 기반으로 만든 Android 포크 프로젝트입니다.

## 변경 사항
- 앱 표시 이름: `Iris Gallery`
- Android applicationId: `app.iris.gallery`
- Gradle 프로젝트 이름: `IrisGallery`
- 원본 Pupil 릴리스 APK를 설치하는 자동 업데이트 동작 비활성화
- 검색, 갤러리 상세, 이미지 리더, 즐겨찾기, 기록, 다운로드, 잠금, 설정 등 기존 핵심 기능 유지

## 빌드
Android Studio에서 프로젝트 루트를 열거나 다음 명령을 실행합니다.

```bash
./gradlew assembleDebug
```

디버그 APK는 일반적으로 `app/build/outputs/apk/debug/app-debug.apk`에 생성됩니다.

## 라이선스
원본 앱 모듈은 GNU GPL v3 라이선스입니다. 배포 시 원본 저작권 고지와 GPL 조건을 유지하고, 수정된 소스 코드 제공 의무 등 GPLv3 요구사항을 준수해야 합니다. 자세한 내용은 `app/LICENSE`를 확인하세요.

## 추가 커스터마이징 포인트
앱 이름은 `app/src/main/res/values/strings.xml`의 `app_name`, 앱 ID는 `app/build.gradle.kts`의 `applicationId`에서 변경할 수 있습니다.
