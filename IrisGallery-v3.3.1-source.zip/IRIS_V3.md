# Iris Gallery v3

Iris is moving from a Pupil UI fork to a source-oriented visual library.

## v3.0 foundation
- Visible IRIS home identity.
- First-class source switcher: Hitomi / Ggoorr.
- Existing Pupil/Hitomi search and reader preserved behind Hitomi.
- Ggoorr gets its own source screen instead of a hidden overflow/dialog entry.
- Source adapters remain separated from UI through the source package.

## Direction
Discover -> Collect -> Organize.
Future source adapters: Pixiv, Pinterest, X, subject to their authorized/public access methods.
