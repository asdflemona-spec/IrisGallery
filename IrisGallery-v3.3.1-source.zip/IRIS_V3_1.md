# Iris Gallery v3.1

Focus: make source-independent actions real before adding more providers.

- Ggoorr media extraction now checks lazy-load attributes, srcset, image links, video/source tags and OpenGraph images.
- Relative/protocol-relative URLs are normalized.
- Ggoorr detail records Iris history.
- Ggoorr detail exposes Download, Save, Original and Share actions.
- Downloads preserve Ggoorr Referer/User-Agent headers through Android DownloadManager.
- Save/history storage is intentionally small/local in this milestone; a full Iris Library database is a later migration.
- Hitomi remains on the proven Pupil engine.
