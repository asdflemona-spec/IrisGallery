# Iris v3.2

Foundation release for source-neutral Iris actions.

- Ggoorr viewer requests now reuse the source HTTP headers (Referer/User-Agent).
- Android 10+ downloads are written through MediaStore to Pictures/Iris/<source>, so gallery apps can index them.
- Save/history/download state is stored in a common IrisLibraryEntry keyed by sourceId + remoteId rather than one-off button booleans.
- Hitomi remains on its proven Pupil path for this release; migration to the common Iris library comes after this foundation is validated.
