# Iris Gallery v3.3

Focus: begin moving the app from source-specific Pupil state toward a source-neutral Iris Library.

- Ggoorr Save, History, and Download records are surfaced from the same bottom navigation destinations used by Hitomi.
- Iris library identity remains `sourceId + remoteId`, so future Pixiv/Pinterest/X adapters can use the same model.
- Existing Hitomi/Pupil databases remain intact in this migration build to avoid breaking proven Hitomi behavior.
- This is a bridge release: later releases can migrate Hitomi records into the Iris repository and replace the legacy split rendering with one unified list.
