# Iris Gallery v3.3.1

Compile-fix release for v3.3.

- Removed the invalid direct import of `androidx.compose.foundation.layout.weight` from DownloadsScreen, FavoritesScreen, and HistoryScreen.
- `Modifier.weight()` now resolves through the `ColumnScope` receiver, matching the Compose usage already present elsewhere in the project.
- Iris Library bridge behavior from v3.3 is otherwise unchanged.
