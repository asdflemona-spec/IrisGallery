# Iris Gallery multi-source v2

This fork now contains a provider-independent source layer under:
`app/src/main/java/xyz/quaver/pupil/source/`.

## Current state
- Hitomi: wired to the existing Pupil/Hitomi implementation through `HitomiSource`.
- Ggoorr, Pinterest, pixiv, X, Rule34: registered as providers but intentionally marked
  `REQUIRES_CONFIGURATION` until each provider's current public/authorized access method is
  configured and tested.
- Adult providers are marked `SourceMaturity.ADULT` so the UI can keep them opt-in/disabled by default.

## Next integration point
Migrate the existing search/detail Compose screens to consume `ContentSource` and `SourceItem`
instead of directly calling `hitomiClient`. After that, each provider can be added without
rewriting the reader/history/download layers.
