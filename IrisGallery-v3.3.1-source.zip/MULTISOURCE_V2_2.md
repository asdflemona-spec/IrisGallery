# Iris Gallery v2.2

- Ggoorr `/ao` public HTML source adapter enabled.
- Board list/search parsing into `SourceItem`.
- Article detail parsing extracts public body image URLs for the common Iris reader model.
- Hitomi remains enabled.
- Pinterest, pixiv, X and Rule34 remain configuration placeholders for later adapters.

The Ggoorr adapter does not bypass login/access controls. HTML selectors include fallbacks because the site's markup can change.
