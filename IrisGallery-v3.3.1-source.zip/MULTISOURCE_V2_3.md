# Iris Gallery v2.3

- Adds a user-visible **Ggoorr source** entry to the Home screen overflow menu.
- Opens a native Compose browser dialog for Ggoorr `/ao`.
- Supports public board loading, title/content search, post opening, and inline image viewing.
- Hitomi remains the default/home source, so existing Pupil flows are preserved.
- Ggoorr is classified as an adult source in the source registry.
