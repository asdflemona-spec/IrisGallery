# Iris Gallery v2.4

- Ggoorr entry is now a permanently visible action in the main Hitomi search bar instead of being hidden inside the overflow menu.
- Tapping `Ggoorr` opens the Ggoorr browser/search UI backed by `GgoorrSource`.
- Hitomi remains the default/main source and existing Pupil navigation remains intact.
