![Banner](https://github.com/tom5079/Pupil/blob/gh-pages/assets/images/pupil-banner.png?raw=true)
*Pupil, Hitomi.la viewer for Android*

[Download App](https://codeberg.org/pupil/Pupil/releases/download/6.1.0/Pupil-v6.1.0.apk)  
[![](https://discordapp.com/api/guilds/610452916612104194/embed.png?style=banner2)](https://discord.gg/Stj4b5v)

# Features

![Main Screen](https://github.com/tom5079/Pupil/blob/gh-pages/assets/images/main-screenshot.jpg?raw=true)

# Installation

Go [Releases page](https://codeberg.org/pupil/Pupil/releases) and get latest version
or Build app yourself

# Contribution

Any kind of contribution is appreciated. Feel free to leave PR!

## Tag Translation

Head over to [tags branch](https://codeberg.org/pupil/Pupil/src/branch/tags)
