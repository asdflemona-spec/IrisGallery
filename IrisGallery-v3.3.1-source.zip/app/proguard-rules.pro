# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

-dontobfuscate

-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.SerializationKt
-keep,includedescriptorclasses class xyz.quaver.**$$serializer { *; } # <-- change package name to your app's
-keepclassmembers class xyz.quaver.pupil.** { # <-- change package name to your app's
    *** Companion;
}
-keepclasseswithmembers class xyz.quaver.pupil.** { # <-- change package name to your app's
    kotlinx.serialization.KSerializer serializer(...);
}
-keep class xyz.quaver.pupil.ui.fragment.ManageFavoritesFragment
-keep class xyz.quaver.pupil.ui.fragment.ManageStorageFragment
-keep class xyz.quaver.pupil.** { *; }
-keep class app.cash.zipline.** { *; }
# Ktor's JVM logging looks for an slf4j binding that Android never provides.
-dontwarn org.slf4j.impl.StaticLoggerBinder

# Room 2.6.1 ships "-keep class * extends androidx.room.RoomDatabase", which
# holds the class but says nothing about its constructors. R8 from AGP 9 drops
# the no-arg constructor as unused, and WorkManager builds WorkDatabase_Impl
# reflectively through getDeclaredConstructor() — so the app died in
# androidx.startup before reaching any of our code. Room 2.7 adds the member to
# its own rule; until the upgrade, it lives here.
-keep class * extends androidx.room.RoomDatabase { <init>(); }

# Same shape as the Room rule above. firebase-components ships
# "-keep class * implements ...ComponentRegistrar" with no member spec, so R8
# from AGP 9 drops the no-arg constructor that ComponentDiscovery reflects on.
# Every Firebase component then goes missing, and FirebaseCrashlytics
# .getInstance() throws "component is not present" out of Application.onCreate.
-keep class * implements com.google.firebase.components.ComponentRegistrar { <init>(); }
