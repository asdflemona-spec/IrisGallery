/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.Manifest
import android.app.DownloadManager
import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.RootMatchers.isDialog
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import okio.Buffer
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Assume.assumeTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import xyz.quaver.pupil.BuildConfig
import xyz.quaver.pupil.R
import xyz.quaver.pupil.receiver.UpdateBroadcastReceiver
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.ui.MainComposeActivity
import java.io.File
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL

/**
 * Pupil is distributed outside any app store, so this pipeline is the only way a
 * user ever gets a new build. Every step of it is covered here: the release feed
 * as it is actually served, the asset the feed points at, the DownloadManager
 * handoff, the broadcast that comes back, and the notification that hands the apk
 * to the package installer.
 */
@RunWith(AndroidJUnit4::class)
class UpdateEndToEndTest {

    private val context: Context = InstrumentationRegistry.getInstrumentation().targetContext

    private val downloadManager
        get() = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    private val notificationManager
        get() = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private val apk = ByteArray(256 * 1024) { (it * 31 % 251).toByte() }

    private lateinit var server: MockWebServer
    private var feed = "[]"
    private var beta = false
    private var ignoreUpdateUntil = -1L

    private val releasesUrl get() = "http://127.0.0.1:${server.port}/releases"

    private val downloadTarget get() = File(context.getExternalFilesDir(null), "Pupil.apk")

    @Before
    fun setUp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            InstrumentationRegistry.getInstrumentation().uiAutomation.grantRuntimePermission(
                context.packageName,
                Manifest.permission.POST_NOTIFICATIONS
            )

        beta = settings.value.beta
        ignoreUpdateUntil = Preferences["ignore_update_until"]

        server = MockWebServer().apply {
            dispatcher = object : Dispatcher() {
                override fun dispatch(request: RecordedRequest): MockResponse {
                    val path = request.path.orEmpty()

                    return when {
                        path == "/releases" -> MockResponse()
                            .setHeader("Content-Type", "application/json")
                            .setBody(feed)
                        path.startsWith("/download/") -> MockResponse()
                            .setHeader("Content-Type", "application/vnd.android.package-archive")
                            .setBody(Buffer().write(apk))
                        else -> MockResponse().setResponseCode(500)
                    }
                }
            }
            start(InetAddress.getByName("127.0.0.1"), 0)
        }
    }

    @After
    fun tearDown() {
        settings.update { it.copy(beta = beta) }
        Preferences["ignore_update_until"] = ignoreUpdateUntil

        val id: Long = Preferences[UPDATE_DOWNLOAD_ID]
        if (id != -1L) downloadManager.remove(id)
        Preferences.remove(UPDATE_DOWNLOAD_ID)
        Preferences.remove(UPDATE_DOWNLOAD_VERSION)

        downloadTarget.delete()
        notificationManager.cancel(R.id.notification_id_update)
        server.shutdown()
    }

    @Test
    fun theLiveReleaseFeedStillOffersAnApkWeCanDownload(): Unit = runBlocking {
        val releaseUrl = context.getString(R.string.release_url)
        val releases = getReleases(releaseUrl)

        assertTrue("$releaseUrl served no releases", releases.isNotEmpty())

        val latest = releases.firstOrNull {
            it.jsonObject["prerelease"]?.jsonPrimitive?.booleanOrNull == false
        }?.jsonObject

        assertNotNull("$releaseUrl has no stable release to offer", latest)
        assertNotNull(
            "the newest stable release has no tag_name to compare against BuildConfig.VERSION_NAME",
            latest!!["tag_name"]?.jsonPrimitive?.contentOrNull
        )
        assertNotNull(
            "the newest stable release has no body, so the update dialog would crash",
            latest["body"]?.jsonPrimitive?.contentOrNull
        )

        val apkUrl = getApkUrl(latest)
        assertNotNull("the newest stable release has no asset matching Pupil-v*.apk", apkUrl)

        val connection = (URL(apkUrl!!).openConnection() as HttpURLConnection).apply { requestMethod = "HEAD" }
        try {
            assertEquals("$apkUrl is not downloadable", 200, connection.responseCode)
        } finally {
            connection.disconnect()
        }
    }

    @Test
    fun theUpdateCheckPicksTheNewestReleaseTheUserOptedInTo(): Unit = runBlocking {
        feed = feed(
            release("99.99.99", prerelease = true),
            release("99.99.98", prerelease = false)
        )

        settings.update { it.copy(beta = false) }
        assertEquals(
            "a stable user was offered a prerelease",
            "99.99.98",
            checkUpdate(releasesUrl)?.get("tag_name")?.jsonPrimitive?.contentOrNull
        )

        settings.update { it.copy(beta = true) }
        assertEquals(
            "a beta user was not offered the prerelease",
            "99.99.99",
            checkUpdate(releasesUrl)?.get("tag_name")?.jsonPrimitive?.contentOrNull
        )
    }

    @Test
    fun theUpdateCheckIgnoresTheReleaseWeAreAlreadyRunning(): Unit = runBlocking {
        feed = feed(release(BuildConfig.VERSION_NAME, prerelease = false))

        assertNull(
            "the build we are already running was offered as an update",
            checkUpdate(releasesUrl)
        )
    }

    @Test
    fun aBrokenFeedIsNeverAnUpdate(): Unit = runBlocking {
        assertNull("an http error was read as an update", checkUpdate("http://127.0.0.1:${server.port}/gone"))

        feed = "<html>we are down for maintenance</html>"
        assertNull("a non-json body was read as an update", checkUpdate(releasesUrl))

        feed = feed(release("99.99.99", prerelease = false, assetName = "Pupil.zip"))
        assertNull(
            "a release without an apk asset must not produce a download url",
            getApkUrl(checkUpdate(releasesUrl)!!)
        )

        assertNull(
            "an unreachable feed was read as an update",
            checkUpdate("http://127.0.0.1:1/releases")
        )
    }

    @Test
    fun theInstallHandoffIsStillWiredUpInTheManifest() {
        val receivers = context.packageManager.queryBroadcastReceivers(
            Intent(DownloadManager.ACTION_DOWNLOAD_COMPLETE).setPackage(context.packageName), 0
        )

        assertTrue(
            "nothing is listening for DownloadManager.ACTION_DOWNLOAD_COMPLETE",
            receivers.any { it.activityInfo.name == UpdateBroadcastReceiver::class.java.name }
        )

        val requested = context.packageManager
            .getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS)
            .requestedPermissions
            .orEmpty()

        assertTrue(
            "REQUEST_INSTALL_PACKAGES is not requested, so the apk can never be installed",
            requested.contains(Manifest.permission.REQUEST_INSTALL_PACKAGES)
        )
    }

    @Test
    fun anAvailableUpdateEndsUpAsAnInstallableNotification(): Unit = runBlocking {
        assumeTrue(
            "reading back posted notifications needs API 23+",
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
        )

        feed = feed(release("99.99.99", prerelease = false))

        val update = checkUpdate(releasesUrl)
        assertNotNull("the fixture release was not offered as an update", update)

        val apkUrl = getApkUrl(update!!)
        assertNotNull("the fixture release yielded no apk url", apkUrl)

        notificationManager.cancel(R.id.notification_id_update)

        val target = downloadTarget.also { it.delete() }
        val id = downloadManager.enqueue(
            DownloadManager.Request(Uri.parse(apkUrl))
                .setTitle(context.getText(R.string.update_notification_description))
                .setDestinationUri(Uri.fromFile(target))
        )
        Preferences[UPDATE_DOWNLOAD_ID] = id

        assertEquals(
            "DownloadManager could not write the update to ${target.absolutePath}",
            DownloadManager.STATUS_SUCCESSFUL,
            awaitDownload(id)
        )
        assertArrayEquals("the downloaded apk is not what the server served", apk, target.readBytes())

        val notification = awaitUpdateNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            assertEquals(
                "the update notification is not on the update channel",
                "update",
                notification.channelId
            )

        assertNotNull(
            "the update notification does nothing when tapped",
            notification.contentIntent
        )

        val localUri = Uri.parse(stringColumnOf(id, DownloadManager.COLUMN_LOCAL_URI))
        assertEquals("DownloadManager no longer reports a file:// destination", "file", localUri.scheme)

        val shared = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            File(localUri.path!!)
        )
        val install = Intent(Intent.ACTION_VIEW)
            .setDataAndType(shared, MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk"))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

        assertNotNull(
            "nothing on this device can install ${install.data} as ${install.type}",
            context.packageManager.resolveActivity(install, 0)
        )
    }

    /**
     * The completion broadcast never reaches a package the system considers
     * stopped, which leaves a finished apk on disk with nothing to open it. The
     * apk has to be offered again without a broadcast to lean on, and with
     * nobody in the app to show a dialog to, that offer is a notification.
     */
    @Test
    fun aDownloadThatFinishedUnheardIsStillHandedToTheInstaller(): Unit = runBlocking {
        assumeTrue(
            "reading back posted notifications needs API 23+",
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
        )

        feed = feed(release("99.99.99", prerelease = false))

        val apkUrl = getApkUrl(checkUpdate(releasesUrl)!!)
        assertNotNull("the fixture release yielded no apk url", apkUrl)

        notificationManager.cancel(R.id.notification_id_update)
        Preferences.remove(UPDATE_DOWNLOAD_ID)

        val target = downloadTarget.also { it.delete() }
        val id = downloadManager.enqueue(
            DownloadManager.Request(Uri.parse(apkUrl))
                .setTitle(context.getText(R.string.update_notification_description))
                .setDestinationUri(Uri.fromFile(target))
        )

        assertEquals(
            "DownloadManager could not write the update to ${target.absolutePath}",
            DownloadManager.STATUS_SUCCESSFUL,
            awaitDownload(id)
        )

        Thread.sleep(2_000)
        assertNull(
            "the receiver answered a download it was not tracking, so nothing was proven",
            activeUpdateNotification()
        )

        InstrumentationRegistry.getInstrumentation().runOnMainSync { offerUpdateInstall(context, id) }
        Preferences[UPDATE_DOWNLOAD_ID] = id

        assertNotNull(
            "a download that finished unheard was never handed to the installer",
            awaitUpdateNotification().contentIntent
        )
    }

    @Test
    fun openingTheAppOffersAnAvailableUpdateWithoutBeingAsked(): Unit = runBlocking {
        val update = checkUpdate(context.getString(R.string.release_url))
        assumeTrue("we are already running the newest release", update != null)

        Preferences.remove("ignore_update_until")

        ActivityScenario.launch(MainComposeActivity::class.java).use {
            awaitUpdateDialog()
        }
    }

    private fun feed(vararg releases: String) = releases.joinToString(",", "[", "]")

    private fun release(
        tag: String,
        prerelease: Boolean,
        assetName: String = "Pupil-v$tag.apk"
    ) = """
        {
          "tag_name": "$tag",
          "name": "Pupil v$tag released",
          "body": "# Pupil\n\n# Release Note(v$tag)\n## English\n- nothing to see here\n",
          "draft": false,
          "prerelease": $prerelease,
          "assets": [
            {
              "name": "checksums.txt",
              "browser_download_url": "http://127.0.0.1:${server.port}/download/$tag/checksums.txt"
            },
            {
              "name": "$assetName",
              "browser_download_url": "http://127.0.0.1:${server.port}/download/$tag/$assetName"
            }
          ]
        }
    """

    private fun awaitUpdateDialog() {
        val title = context.getString(R.string.update_title)
        val deadline = System.currentTimeMillis() + 30_000

        while (true) {
            try {
                onView(withText(title)).inRoot(isDialog()).check(matches(isDisplayed()))
                return
            } catch (e: Throwable) {
                if (System.currentTimeMillis() > deadline)
                    throw AssertionError("the launcher never offered the available update", e)
            }

            Thread.sleep(200)
        }
    }

    private fun awaitDownload(id: Long): Int {
        val deadline = System.currentTimeMillis() + 60_000

        while (System.currentTimeMillis() < deadline) {
            when (val status = intColumnOf(id, DownloadManager.COLUMN_STATUS)) {
                DownloadManager.STATUS_SUCCESSFUL -> return status
                DownloadManager.STATUS_FAILED ->
                    fail("download failed with reason ${intColumnOf(id, DownloadManager.COLUMN_REASON)}")
                null -> fail("DownloadManager forgot about download $id")
            }

            Thread.sleep(100)
        }

        fail(
            "download $id did not finish within 60s " +
                "(status=${intColumnOf(id, DownloadManager.COLUMN_STATUS)}, " +
                "bytes=${intColumnOf(id, DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)})"
        )
        error("unreachable")
    }

    private fun activeUpdateNotification(): Notification? =
        notificationManager.activeNotifications
            .firstOrNull { it.id == R.id.notification_id_update }
            ?.notification

    private fun awaitUpdateNotification(): Notification {
        val deadline = System.currentTimeMillis() + 30_000

        while (System.currentTimeMillis() < deadline) {
            activeUpdateNotification()?.let { return it }

            Thread.sleep(100)
        }

        fail("the completed download never produced an update notification")
        error("unreachable")
    }

    /**
     * DownloadManager only translates its internal status and reason columns in
     * [android.database.Cursor.getInt], so those two have to be read as ints.
     */
    private fun intColumnOf(id: Long, column: String): Int? =
        downloadManager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
            if (!cursor.moveToFirst()) return@use null

            val index = cursor.getColumnIndex(column)
            if (index < 0) null else cursor.getInt(index)
        }

    private fun stringColumnOf(id: Long, column: String): String? =
        downloadManager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
            if (!cursor.moveToFirst()) return@use null

            val index = cursor.getColumnIndex(column)
            if (index < 0) null else cursor.getString(index)
        }
}
