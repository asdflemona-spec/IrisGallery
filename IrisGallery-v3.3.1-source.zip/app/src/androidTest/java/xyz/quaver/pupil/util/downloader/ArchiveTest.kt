/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util.downloader

import androidx.core.net.toUri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import xyz.quaver.io.FileX
import xyz.quaver.io.util.getChild
import xyz.quaver.io.util.readBytes
import xyz.quaver.io.util.writeBytes
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.util.Preferences
import java.io.File

private const val GALLERY_ID = 999999999

@RunWith(AndroidJUnit4::class)
class ArchiveTest {

    private val context = InstrumentationRegistry.getInstrumentation().targetContext

    private lateinit var workingFolder: File
    private var previousDownloadFolder = ""

    @Before
    fun setUp() {
        previousDownloadFolder = settings.value.downloadFolder

        workingFolder = File(context.cacheDir, "archiveTest").apply {
            deleteRecursively()
            mkdirs()
        }

        settings.update { it.copy(downloadFolder = workingFolder.toUri().toString()) }

        Cache.delete(context, GALLERY_ID)
    }

    @After
    fun tearDown() {
        Cache.delete(context, GALLERY_ID)
        DownloadManager.getInstance(context).replaceDownloadFolders(emptyMap())

        settings.update { it.copy(downloadFolder = previousDownloadFolder) }

        workingFolder.deleteRecursively()
    }

    @Test
    fun packsAndUnpacksEveryEntry() {
        val source = folder("source")
        val destination = folder("destination")

        val files = mapOf(
            ".metadata" to """{"galleryBlock":null}""".toByteArray(),
            "00.webp" to ByteArray(4096) { it.toByte() },
            "01.avif" to byteArrayOf(7, 8, 9),
        )

        files.forEach { (name, content) ->
            source.getChild(name).apply { createNewFile() }.writeBytes(content)
        }

        val archive = FileX(context, workingFolder, "gallery.zip")

        packArchive(archive, files.keys.map { source.getChild(it) })

        assertEquals(files.keys, unpackArchive(archive, destination))

        files.forEach { (name, content) ->
            assertArrayEquals(name, content, destination.getChild(name).readBytes())
        }
    }

    @Test
    fun readsASingleEntryWithoutUnpacking() {
        val source = folder("source")

        val metadata = """{"galleryBlock":null}""".toByteArray()

        source.getChild(".metadata").apply { createNewFile() }.writeBytes(metadata)
        source.getChild("00.webp").apply { createNewFile() }.writeBytes(byteArrayOf(1, 2))

        val archive = FileX(context, workingFolder, "gallery.zip")

        packArchive(archive, listOf(source.getChild(".metadata"), source.getChild("00.webp")))

        assertArrayEquals(metadata, readArchiveEntry(archive, ".metadata"))
        assertNull(readArchiveEntry(archive, ".nothing"))
    }

    /**
     * The round trip a gallery saved as an archive makes: packed once it is
     * complete, and read back out of the zip the next time it is opened.
     */
    @Test
    fun packsAGalleryAndRestoresItIntoTheCache(): Unit = runBlocking {
        val downloadManager = DownloadManager.getInstance(context)
        downloadManager.replaceDownloadFolders(mapOf(GALLERY_ID to "gallery.zip"))

        val pages = listOf(
            "00.webp" to ByteArray(2048) { it.toByte() },
            "01.webp" to byteArrayOf(4, 5, 6),
        )

        val cache = Cache.getInstance(context, GALLERY_ID)
        cache.setMetadata { it.imageList = MutableList(pages.size) { null } }
        pages.forEachIndexed { index, (name, content) -> cache.putImage(index, name, content) }

        assertTrue(cache.saveToArchive(keepImages = false))

        val archive = downloadManager.getDownloadArchive(GALLERY_ID)
        assertTrue(archive != null && archive.exists())

        // The cover is what the downloads list draws, so it stays behind.
        assertTrue(cache.cacheFolder.getChild("00.webp").exists())
        assertFalse(cache.cacheFolder.getChild("01.webp").exists())

        Cache.delete(context, GALLERY_ID)

        val reopened = Cache.getInstance(context, GALLERY_ID)

        assertTrue(reopened.restoreFromArchive())
        assertEquals(pages.map { it.first }, reopened.metadata.imageList)

        pages.forEachIndexed { index, (name, content) ->
            assertArrayEquals(name, content, reopened.getImage(index)?.readBytes())
        }
    }

    @Test
    fun leavesAGallerySavedAsAFolderAlone(): Unit = runBlocking {
        DownloadManager.getInstance(context).replaceDownloadFolders(mapOf(GALLERY_ID to "gallery"))

        val cache = Cache.getInstance(context, GALLERY_ID)

        assertFalse(cache.restoreFromArchive())
        assertFalse(cache.saveToArchive(keepImages = false))
    }

    private fun folder(name: String) =
        FileX(context, workingFolder, name).also { it.mkdirs() }
}
