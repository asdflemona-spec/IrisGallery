/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util.downloader

import androidx.core.net.toUri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import xyz.quaver.io.util.readBytes
import xyz.quaver.pupil.settings
import java.io.File

private const val GALLERY_ID = 999999998

@RunWith(AndroidJUnit4::class)
class DownloadManagerTest {

    private val context = InstrumentationRegistry.getInstrumentation().targetContext

    private lateinit var workingFolder: File
    private var previousDownloadFolder = ""

    @Before
    fun setUp() {
        previousDownloadFolder = settings.value.downloadFolder

        workingFolder = File(context.cacheDir, "downloadManagerTest").apply {
            deleteRecursively()
            mkdirs()
        }

        settings.update { it.copy(downloadFolder = workingFolder.toUri().toString()) }

        Cache.delete(context, GALLERY_ID)
    }

    @After
    fun tearDown() {
        Cache.delete(context, GALLERY_ID)
        DownloadManager.getInstance(context).replaceDownloadFolders(emptyMap())

        settings.update { it.copy(downloadFolder = previousDownloadFolder) }

        workingFolder.deleteRecursively()
    }

    @Test
    fun savesIntoAFolderWhoseNameHasAPercentSign() = savesInto("[3060250] Fuyuko-chan to 120% Icha Love")

    @Test
    fun savesIntoAFolderWhoseNameLooksPercentEncoded() = savesInto("[1] 100%41")

    private fun savesInto(name: String): Unit = runBlocking {
        DownloadManager.getInstance(context).replaceDownloadFolders(mapOf(GALLERY_ID to name))

        val content = byteArrayOf(1, 2, 3)

        val cache = Cache.getInstance(context, GALLERY_ID)
        cache.setMetadata { it.imageList = MutableList(1) { null } }
        cache.putImage(0, "0.webp", content)

        val written = File(File(workingFolder, name), "0.webp")
        assertTrue(written.path, written.exists())
        assertArrayEquals(content, cache.getImage(0)?.readBytes())
    }
}
