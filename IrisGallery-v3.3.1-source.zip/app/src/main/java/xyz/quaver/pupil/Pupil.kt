/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil

import android.app.Activity
import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.gif.AnimatedImageDecoder
import coil3.gif.GifDecoder
import coil3.network.ktor3.KtorNetworkFetcherFactory
import com.google.android.gms.common.GooglePlayServicesNotAvailableException
import com.google.android.gms.common.GooglePlayServicesRepairableException
import com.google.android.gms.security.ProviderInstaller
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.request.HttpRequestPipeline
import io.ktor.http.HttpHeaders
import kotlinx.coroutines.*
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import okhttp3.Credentials
import okhttp3.OkHttpClient
import xyz.quaver.io.FileX
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.evaluationContext
import xyz.quaver.pupil.hitomi.parseQueryLine
import xyz.quaver.pupil.services.WatchlistWorker
import xyz.quaver.pupil.types.Tag
import xyz.quaver.pupil.util.*
import xyz.quaver.pupil.util.downloader.DownloadManager
import java.io.File
import java.io.IOException
import java.net.Proxy
import java.net.ProxySelector
import java.net.SocketAddress
import java.net.URI
import java.net.URL
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.util.*
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager
import kotlin.concurrent.thread

val histories = SetStore(
    fileName = "histories.json",
    elementSerializer = Int.serializer(),
    legacyFileName = "histories.json",
)
val favorites = SetStore(
    fileName = "favorites.json",
    elementSerializer = Int.serializer(),
    legacyFileName = "favorites.json",
)
val favoriteTags = SetStore(
    fileName = "favorite_tags.json",
    elementSerializer = Tag.serializer(),
    legacyFileName = "favorites_tags.json",
)
val readLater = SetStore(
    fileName = "read_later.json",
    elementSerializer = Int.serializer(),
)
val searchHistory = SetStore(
    fileName = "search_history.json",
    elementSerializer = SearchQuery.serializer(),
    legacyFileName = "search_histories.json",
    readLegacy = { text ->
        Json.decodeFromString(ListSerializer(String.serializer()), text)
            .mapNotNull(::parseQueryLine)
    },
)
val watchlist = WatchlistStore(
    fileName = "watchlist.json",
    onWatchesChanged = { WatchlistWorker.sync(Pupil.instance) },
)
val readProgress = ReadProgressStore(fileName = "read_progress.json")
val nightMode = NightModeStore(fileName = "night_mode")
val searchState = GalleryListStateStore(fileName = "search_state.json")
val historyState = GalleryListStateStore(fileName = "history_state.json")
val favoritesState = GalleryListStateStore(fileName = "favorites_state.json")
val downloadsState = GalleryListStateStore(fileName = "downloads_state.json")
val listStyle = ListStyleStore(fileName = "list_style")
val settings = SettingsStore(fileName = "settings.json")

private const val BROWSER_USER_AGENT =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36"

/** okhttp's own default, restored whenever the preference is cleared. */
private const val DEFAULT_MAX_REQUESTS = 64

private const val HTTP_CACHE_SIZE = 50L * 1024 * 1024

/**
 * Backs [client], and through it Coil. Private on purpose: the client makes the
 * requests, and the settings okhttp still owns are reachable as [setProxy] and
 * [setMaxConcurrentRequests].
 */
private lateinit var okHttp: OkHttpClient

lateinit var client: HttpClient

lateinit var cachedClient: HttpClient

/**
 * okhttp bakes the proxy into the client, but the proxy preference changes at
 * runtime. Routing it through a selector keeps [client] and the hitomi client
 * derived from it on one engine instead of leaving stale copies behind on every
 * change.
 */
private object PupilProxySelector : ProxySelector() {
    @Volatile
    var proxyInfo: ProxyInfo = ProxyInfo(Proxy.Type.DIRECT)

    override fun select(uri: URI?): List<Proxy> = listOf(proxyInfo.proxy())

    override fun connectFailed(uri: URI?, address: SocketAddress?, failure: IOException?) = Unit
}

fun setProxy(proxyInfo: ProxyInfo) {
    PupilProxySelector.proxyInfo = proxyInfo
    okHttp.connectionPool.evictAll()
}

/**
 * Caps in-flight requests across [client]. Applied to the shared
 * okhttp dispatcher, so it takes effect without rebuilding anything.
 */
fun setMaxConcurrentRequests(max: Int) {
    okHttp.dispatcher.maxRequests = if (max <= 0) DEFAULT_MAX_REQUESTS else max
}

private fun buildEngine(context: Context): OkHttpClient = OkHttpClient.Builder()
    .sslSocketFactory(getSSLContext(context).socketFactory, trustManagerFor(context))
    .readTimeout(0, TimeUnit.SECONDS)
    .proxySelector(PupilProxySelector)
    .proxyAuthenticator { _, response ->
        PupilProxySelector.proxyInfo.credentials?.let { (username, password) ->
            response.request.newBuilder()
                .header("Proxy-Authorization", Credentials.basic(username, password))
                .build()
        }
    }
    .build()

private fun buildClient(okHttpEngine: OkHttpClient): HttpClient = HttpClient(OkHttp) {
    expectSuccess = false

    engine { preconfigured = okHttpEngine }

    install("PupilDefaultHeaders") {
        requestPipeline.intercept(HttpRequestPipeline.State) {
            context.headers.apply {
                if (!contains("Referer"))
                    append("Referer", "https://hitomi.la/")

                // Only impose the browser User-Agent when the request hasn't set its
                // own. Codeberg (release feed) rejects browser-like UAs with 403,
                // so those requests supply a non-browser UA of their own.
                if (!contains(HttpHeaders.UserAgent))
                    append(HttpHeaders.UserAgent, BROWSER_USER_AGENT)
            }
        }
    }
}

fun trustManagerFor(context: Context): X509TrustManager =
    TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        .apply { init(keyStoreWithISRGRoot(context)) }
        .trustManagers
        .filterIsInstance<X509TrustManager>()
        .first()

private fun keyStoreWithISRGRoot(context: Context): KeyStore {
    val keyStore = KeyStore.getInstance(KeyStore.getDefaultType())
    keyStore.load(null, null)

    val certificateFactory = CertificateFactory.getInstance("X.509")

    val certificate = context.resources.openRawResource(R.raw.isrgrootx1).use {
        certificateFactory.generateCertificate(it)
    }

    keyStore.setCertificateEntry("isrgrootx1", certificate)

    TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        .apply { init(null as KeyStore?) }
        .trustManagers
        .filterIsInstance<X509TrustManager>()
        .forEach { trustManager ->
            trustManager.acceptedIssuers.forEach { acceptedIssuer ->
                keyStore.setCertificateEntry(acceptedIssuer.subjectDN.name, acceptedIssuer)
            }
        }

    return keyStore
}

fun getSSLContext(context: Context): SSLContext {
    val keyStore = KeyStore.getInstance(KeyStore.getDefaultType())
    keyStore.load(null, null)

    val certificateFactory = CertificateFactory.getInstance("X.509")

    val certificate = context.resources.openRawResource(R.raw.isrgrootx1).use {
        certificateFactory.generateCertificate(it)
    }

    keyStore.setCertificateEntry("isrgrootx1", certificate)

    val defaultTrustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
    defaultTrustManagerFactory.init(null as KeyStore?)

    defaultTrustManagerFactory.trustManagers.filterIsInstance(X509TrustManager::class.java).forEach { trustManager ->
        trustManager.acceptedIssuers.forEach { acceptedIssuer ->
            keyStore.setCertificateEntry(acceptedIssuer.subjectDN.name, acceptedIssuer)
        }
    }

    val trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
    trustManagerFactory.init(keyStore)

    val sslContext = SSLContext.getInstance("TLS")
    sslContext.init(null, trustManagerFactory.trustManagers, SecureRandom())

    return sslContext
}

class Pupil : Application(), SingletonImageLoader.Factory {
    companion object {
        lateinit var instance: Pupil
            private set
    }

    /**
     * Whoever is on screen right now, so code with nothing but an application
     * context — a broadcast receiver, say — can tell whether the user is looking
     * at the app and put something in front of them instead of in the shade.
     */
    var resumedActivity: Activity? = null
        private set

    /**
     * Coil fetches over [client], which carries the Referer and User-Agent the
     * image hosts require along with the proxy and the trust store. Asked for
     * lazily, since the client is only built in [onCreate].
     */
    override fun newImageLoader(context: PlatformContext): ImageLoader =
        ImageLoader.Builder(context)
            .components {
                add(KtorNetworkFetcherFactory(httpClient = { client }))

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) add(AnimatedImageDecoder.Factory())
                else add(GifDecoder.Factory())
            }
            .build()

    override fun onCreate() {
        instance = this

        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                resumedActivity = activity
            }

            override fun onActivityPaused(activity: Activity) {
                if (resumedActivity === activity) resumedActivity = null
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityStarted(activity: Activity) = Unit
            override fun onActivityStopped(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })

        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)

        preferences = getSharedPreferences("${packageName}_preferences", MODE_PRIVATE)

        settings.init(this)

        DefaultQuery.init()

        val userID = Preferences["user_id", ""].let {  userID ->
            if (userID.isEmpty()) UUID.randomUUID().toString().also { Preferences["user_id"] = it }
            else userID
        }

        Crashlytics.init(this, userID)

        // Ahead of the client: the SSLContext below binds whichever security provider
        // is current, so the upgraded one has to be in place first.
        try {
            ProviderInstaller.installIfNeeded(this)
        } catch (e: GooglePlayServicesRepairableException) {
            e.printStackTrace()
        } catch (e: GooglePlayServicesNotAvailableException) {
            e.printStackTrace()
        }

        okHttp = buildEngine(this)
        setProxy(settings.value.proxy)
        setMaxConcurrentRequests(settings.value.maxConcurrentDownload)
        client = buildClient(okHttp)
        cachedClient = buildClient(
            okHttp.newBuilder()
                .cache(okhttp3.Cache(File(cacheDir, "http"), HTTP_CACHE_SIZE))
                .build()
        )
        thread { File(cacheDir, "hitomi-http").deleteRecursively() }

        try {
            settings.value.downloadFolder.also {
                if (it.startsWith("content://"))
                    contentResolver.takePersistableUriPermission(
                        Uri.parse(it),
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )

                if (!FileX(this, it).canWrite())
                    throw Exception()
            }
        } catch (e: Exception) {
            settings.update { it.copy(downloadFolder = "") }
        }

        if (!Preferences["reset_secure", false]) {
            settings.update { it.copy(securityMode = false) }
            Preferences["reset_secure"] = true
        }

        AppLock.observeProcessLifecycle()

        histories.init(this)
        favorites.init(this)
        favoriteTags.init(this)
        readLater.init(this)
        searchHistory.init(this)
        watchlist.init(this)
        readProgress.init(this)
        nightMode.init(this)
        searchState.init(this)
        historyState.init(this)
        favoritesState.init(this)
        downloadsState.init(this)
        listStyle.init(this)

        // Here rather than wherever the downloads are first wanted: the manager
        // holds snapshot state, and building it inside the read-only snapshot a
        // snapshotFlow reads it in leaves that snapshot unable to see it.
        DownloadManager.getInstance(this)

        WatchlistWorker.sync(this)

        favoriteTags.removeAll(favoriteTags.items.filter { it.tag.contains('_') })

        /*
        if (BuildConfig.DEBUG)
            FirebaseAnalytics.getInstance(this).setAnalyticsCollectionEnabled(false)*/

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            manager.createNotificationChannel(NotificationChannel("download", getString(R.string.channel_download), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.channel_download_description)
                enableLights(false)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            })

            manager.createNotificationChannel(NotificationChannel("downloader", getString(R.string.channel_downloader), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.channel_downloader_description)
                enableLights(false)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            })

            manager.createNotificationChannel(NotificationChannel("update", getString(R.string.channel_update), NotificationManager.IMPORTANCE_HIGH).apply {
                description = getString(R.string.channel_update_description)
                enableLights(true)
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            })

            manager.createNotificationChannel(NotificationChannel("watchlist", getString(R.string.channel_watchlist), NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = getString(R.string.channel_watchlist_description)
                enableLights(true)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            })

            manager.createNotificationChannel(NotificationChannel("import", getString(R.string.channel_update), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.channel_update_description)
                enableLights(false)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            })
        }

        AppCompatDelegate.setDefaultNightMode(nightMode.mode.delegateMode)

        super.onCreate()
    }

}