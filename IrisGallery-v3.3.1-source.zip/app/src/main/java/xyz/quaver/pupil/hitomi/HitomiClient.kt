/*
 *    Copyright 2019 tom5079
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package xyz.quaver.pupil.hitomi

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.onDownload
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess
import kotlinx.coroutines.delay
import xyz.quaver.pupil.cachedClient
import xyz.quaver.pupil.client
import java.io.IOException
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.coroutineContext

class HitomiResponseException(val statusCode: Int) : IOException("CODE $statusCode")

private const val MAX_ATTEMPTS = 3
private const val FIRST_RETRY_DELAY_MS = 200L

/**
 * Replays a read whose response body ended mid-stream, which hitomi's edge
 * hands back often enough that a search reading a dozen files fails on one
 * that succeeds the moment it is asked again.
 *
 * A status code is the server's answer rather than a cut connection, so
 * [HitomiResponseException] goes straight to the caller: asking again for a
 * tag that has no nozomi file would only be told so again.
 */
internal suspend fun <T> retryingCutReads(read: suspend () -> T): T {
    repeat(MAX_ATTEMPTS - 1) { attempt ->
        try {
            return read()
        } catch (e: HitomiResponseException) {
            throw e
        } catch (e: IOException) {
            delay(FIRST_RETRY_DELAY_MS shl attempt)
        }
    }

    return read()
}

/**
 * Marks a scope whose reads may not be answered out of the response cache.
 * hitomi serves the index files with an hour of freshness, so a reload within
 * that hour would otherwise hand back the very list it is reloading.
 *
 * Every refresh makes its own, so that what is resolved once per scope -- the
 * b-tree index version -- is resolved again for the next one.
 */
class Revalidate : CoroutineContext.Element {
    override val key: CoroutineContext.Key<Revalidate> = Key

    companion object Key : CoroutineContext.Key<Revalidate>
}

class HitomiClient(private val http: HttpClient, private val uncachedHttp: HttpClient) {
    internal val gg = Gg(this)
    internal val tagIndexVersion = IndexVersion(this, index_dir)
    internal val galleriesIndexVersion = IndexVersion(this, galleries_index_dir)

    // The HTTP cache keys entries by URL alone, so it hands the first range
    // fetched from a file back for every later range of that same file. Ranged
    // reads have to skip the cache entirely.
    internal suspend fun get(url: String, range: LongRange? = null): HttpResponse {
        val revalidate = coroutineContext[Revalidate.Key] != null

        return when (range) {
            null -> http.get(url) {
                if (revalidate) header(HttpHeaders.CacheControl, "no-cache")
            }
            else -> uncachedHttp.get(url) {
                header(HttpHeaders.Range, "bytes=${range.first}-${range.last}")
            }
        }.also {
            if (!it.status.isSuccess()) throw HitomiResponseException(it.status.value)
        }
    }

    internal suspend fun getText(url: String): String = retryingCutReads { get(url).bodyAsText() }

    internal suspend fun getBytes(url: String, range: LongRange? = null): ByteArray =
        retryingCutReads { get(url, range).body() }

    /**
     * A gallery image. Separate from [getBytes] because callers want progress, and
     * because the image hosts fail differently: [HitomiHttpException] carries the
     * code so the downloader can tell a 503 worth retrying from a real failure.
     */
    suspend fun getImage(
        url: String,
        onProgress: ((bytesRead: Long, contentLength: Long?) -> Unit)? = null,
    ): ByteArray =
        uncachedHttp.get(url) {
            onProgress?.let { listener -> onDownload { read, total -> listener(read, total) } }
        }.also {
            if (!it.status.isSuccess()) throw HitomiHttpException(it.status.value)
        }.body()
}

class HitomiHttpException(val status: Int) : IOException("CODE $status")

val hitomiClient: HitomiClient by lazy {
    HitomiClient(
        http = cachedClient,
        uncachedHttp = client,
    )
}
