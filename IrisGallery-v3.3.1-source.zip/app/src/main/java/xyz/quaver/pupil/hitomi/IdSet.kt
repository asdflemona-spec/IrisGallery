/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

import androidx.collection.IntSet
import androidx.collection.MutableIntSet

internal fun IntArray.toIntSet(): MutableIntSet =
    MutableIntSet(size).also { set -> for (id in this) set.add(id) }

internal fun IntArray.intersectIds(other: IntArray): IntArray {
    if (isEmpty() || other.isEmpty()) return IntArray(0)

    val keep = other.toIntSet()
    val out = IntArray(size)
    var n = 0

    for (id in this) if (keep.contains(id)) out[n++] = id

    return if (n == size) out else out.copyOf(n)
}

internal fun IntArray.retainIds(keep: IntSet): IntArray {
    var n = 0
    for (id in this) if (keep.contains(id)) n++

    val out = IntArray(n)
    var i = 0

    for (id in this) if (keep.contains(id)) out[i++] = id

    return out
}

internal fun IntArray.subtractIds(other: IntArray): IntArray {
    if (isEmpty() || other.isEmpty()) return this

    val drop = other.toIntSet()
    val out = IntArray(size)
    var n = 0

    for (id in this) if (!drop.contains(id)) out[n++] = id

    return if (n == size) out else out.copyOf(n)
}

internal fun List<IntArray>.unionIds(): IntArray {
    if (size == 1) return single()

    val total = sumOf { it.size }
    val seen = MutableIntSet(total)
    val out = IntArray(total)
    var n = 0

    for (branch in this) for (id in branch) if (seen.add(id)) out[n++] = id

    return if (n == total) out else out.copyOf(n)
}

internal fun IntArray.rankedBy(order: IntArray): IntArray {
    val pending = toIntSet()
    val out = IntArray(size)
    var n = 0

    for (id in order) if (pending.remove(id)) out[n++] = id

    if (pending.isNotEmpty()) for (id in this) if (pending.remove(id)) out[n++] = id

    return if (n == size) out else out.copyOf(n)
}
