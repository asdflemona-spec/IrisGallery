/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** What emptied a search, with the one thing to do about it. */
sealed interface NoResultReason {

    /** [term] matches no gallery at all. */
    data class EmptyTerm(val term: SearchQuery) : NoResultReason

    /** [term] leaves out every gallery the rest of the search finds. */
    data class ExcludingTerm(val term: SearchQuery) : NoResultReason

    /** Every term finds something on its own; no gallery answers all of them. */
    data object NoOverlap : NoResultReason

    /** Nothing the search finds is in [languages]. */
    data class UnavailableLanguage(val languages: SearchQuery) : NoResultReason

    /** The filter requires [tag], which nothing the search finds carries. */
    data class MissingRequiredTag(val tag: SearchQuery.Tag) : NoResultReason

    /** The filter bans [tag], which everything the search finds carries. */
    data class BannedTag(val tag: SearchQuery.Tag) : NoResultReason

    /** The filter hides everything the search finds, with no one term to blame. */
    data object Filtered : NoResultReason
}

/**
 * The first term of [query] that matches no gallery at all, which is the one
 * thing a list can say about an empty result without knowing what it searched.
 */
suspend fun HitomiClient.emptyTerm(
    query: SearchQuery,
    sortMode: SortMode = SortMode.DATE_ADDED,
): SearchQuery? = emptyTerm(query, { allGalleryIDs(sortMode) }, tagLookup(sortMode))

/**
 * Why a search for [query] narrowed by the default filter came back empty.
 *
 * The search is run again a term at a time, and the term that empties it is
 * the one to report -- so what comes back is the one term to take away, not
 * the whole query to give up on. Null where nothing on its own is to blame.
 */
suspend fun HitomiClient.diagnoseNoResult(
    query: SearchQuery?,
    languages: SearchQuery?,
    requiredTags: List<SearchQuery.Tag>,
    bannedTags: List<SearchQuery.Tag>,
    sortMode: SortMode,
): NoResultReason? = diagnoseNoResult(
    query = query,
    languages = languages,
    requiredTags = requiredTags,
    bannedTags = bannedTags,
    all = { allGalleryIDs(sortMode) },
    lookup = tagLookup(sortMode),
)

internal suspend fun emptyTerm(
    query: SearchQuery,
    all: suspend () -> IntArray,
    lookup: suspend (SearchQuery.Tag) -> IntArray,
): SearchQuery? = coroutineScope {
    query.terms()
        .filterNot { it is SearchQuery.Not }
        .map { it to async { evaluateEverywhere(it, all, lookup) } }
        .firstOrNull { (_, matched) -> matched.await().isEmpty() }
        ?.first
}

internal suspend fun diagnoseNoResult(
    query: SearchQuery?,
    languages: SearchQuery?,
    requiredTags: List<SearchQuery.Tag>,
    bannedTags: List<SearchQuery.Tag>,
    all: suspend () -> IntArray,
    lookup: suspend (SearchQuery.Tag) -> IntArray,
): NoResultReason? = coroutineScope {
    val (excluding, including) = query.terms().partition { it is SearchQuery.Not }

    val matched = including
        .map { it to async { evaluateEverywhere(it, all, lookup) } }
        .map { (term, matched) -> term to matched.await() }

    matched.firstOrNull { (_, ids) -> ids.isEmpty() }?.let { (term, _) ->
        return@coroutineScope NoResultReason.EmptyTerm(term)
    }

    // Without a term saying what to include, the search starts from everything,
    // the way the search itself does.
    val found = matched.map { (_, ids) -> ids }.reduceOrNull(IntArray::intersectIds) ?: all()

    if (found.isEmpty()) return@coroutineScope NoResultReason.NoOverlap

    // Every term is answered against what the query's own positive terms found,
    // rather than against what the terms before it left, so a term is only
    // blamed for emptying the result where it empties it on its own.
    var remaining = found

    for (term in excluding) {
        val excluded = evaluateWithin((term as SearchQuery.Not).query, found, lookup)

        if (excluded.size == found.size) return@coroutineScope NoResultReason.ExcludingTerm(term)

        remaining = remaining.subtractIds(excluded)
    }

    if (remaining.isEmpty()) return@coroutineScope NoResultReason.NoOverlap

    languages?.let { term ->
        val inLanguage = evaluateWithin(term, found, lookup)

        if (inLanguage.isEmpty()) return@coroutineScope NoResultReason.UnavailableLanguage(term)

        remaining = remaining.intersectIds(inLanguage)
    }

    for (tag in requiredTags) {
        val carrying = evaluateWithin(tag, found, lookup)

        if (carrying.isEmpty()) return@coroutineScope NoResultReason.MissingRequiredTag(tag)

        remaining = remaining.intersectIds(carrying)
    }

    for (tag in bannedTags) {
        val carrying = evaluateWithin(tag, found, lookup)

        if (carrying.size == found.size) return@coroutineScope NoResultReason.BannedTag(tag)

        remaining = remaining.subtractIds(carrying)
    }

    if (remaining.isEmpty()) NoResultReason.Filtered else null
}
