/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import xyz.quaver.pupil.favoriteTags
import xyz.quaver.pupil.readLater
import xyz.quaver.pupil.types.Tag

val validNamespace = listOf(
    "female",
    "male",
    "artist",
    "group",
    "character",
    "series",
    "type",
    "language",
    "tag",
)

/**
 * Structured search query.
 *
 * [doSearch] only understands a flat "positive terms, minus `-` terms" string,
 * so it cannot express OR at all. This tree can, and [evaluate] resolves it
 * against the same [getGalleryIDsForQuery] primitive.
 *
 * The [SerialName]s end up in stored queries, so they are spelled out rather
 * than derived from the class names, which are free to move.
 */
@Serializable
sealed interface SearchQuery {
    @Serializable
    @SerialName("tag")
    data class Tag(
        val namespace: String? = null,
        val tag: String,
    ) : SearchQuery {
        override fun toString() = if (namespace == null) tag else "$namespace:$tag"
    }

    @Serializable
    @SerialName("and")
    data class And(val queries: List<SearchQuery>) : SearchQuery {
        init {
            require(queries.isNotEmpty()) { "queries cannot be empty" }
        }
    }

    @Serializable
    @SerialName("or")
    data class Or(val queries: List<SearchQuery>) : SearchQuery {
        init {
            require(queries.isNotEmpty()) { "queries cannot be empty" }
        }
    }

    @Serializable
    @SerialName("not")
    data class Not(val query: SearchQuery) : SearchQuery

    /**
     * Every favourited `artist:` and `group:` tag, ORed together -- a work is
     * often credited to the circle rather than the person, so following one
     * without the other misses half of what you are looking for.
     *
     * Resolved when the query runs, so favouriting an artist widens searches
     * already built around it.
     */
    @Serializable
    @SerialName("favoriteArtists")
    data object FavoriteArtists : SearchQuery

    /**
     * Every gallery put aside to read later, newest first.
     *
     * Resolved when the query runs, so a gallery marked while a search is built
     * around this is in the next set of results.
     */
    @Serializable
    @SerialName("readLater")
    data object ReadLater : SearchQuery
}

/**
 * The query line 5.x kept its search history as: tags separated by spaces, each
 * optionally negated with a leading `-`, namespaced with `namespace:`, and
 * written with its own spaces as underscores.
 *
 * Null for a line no tag survives, which is not a search worth offering back.
 */
fun parseQueryLine(line: String): SearchQuery? {
    val queries = line.split(' ').mapNotNull { token ->
        if (token.isBlank()) return@mapNotNull null

        val parsed = Tag.parse(token)
        val tag = parsed.tag.replace('_', ' ').trim()

        if (tag.isEmpty()) return@mapNotNull null

        SearchQuery.Tag(parsed.area, tag).let { if (parsed.isNegative) SearchQuery.Not(it) else it }
    }

    return when (queries.size) {
        0 -> null
        1 -> queries.single()
        else -> SearchQuery.And(queries)
    }
}

private val favoriteArtistNamespaces = setOf("artist", "group")

private fun favoriteArtistTags(): List<SearchQuery.Tag> =
    favoriteTags.items
        .filter { it.area in favoriteArtistNamespaces }
        .map { SearchQuery.Tag(it.area, it.tag) }

internal suspend fun HitomiClient.allGalleryIDs(sortMode: SortMode): IntArray =
    getGalleryIDsFromNozomi(SearchArgs("all", "index", "all"), sortMode)

/**
 * Whether the result comes back in no order at all: a union takes the order of
 * whichever branch reached an ID first, which is an artifact of the request
 * rather than anything to show a reader.
 *
 * [SearchQuery.ReadLater] is not such a case. Its order is the order the
 * galleries were put aside in, which is worth keeping -- and keeping it also
 * spares a query built only from local state the whole index it would be
 * ranked against.
 */
private fun SearchQuery.needsRanking(): Boolean = when (this) {
    is SearchQuery.Tag, is SearchQuery.ReadLater -> false
    is SearchQuery.FavoriteArtists -> true
    is SearchQuery.Or -> true
    is SearchQuery.And -> queries.any { it.needsRanking() }
    is SearchQuery.Not -> query.needsRanking()
}

/** The query with its tag names left out, for a crash report. */
fun SearchQuery.shape(): String = when (this) {
    is SearchQuery.Tag -> namespace ?: "text"
    is SearchQuery.And -> queries.joinToString(" ", "(", ")") { it.shape() }
    is SearchQuery.Or -> queries.joinToString(" | ", "(", ")") { it.shape() }
    is SearchQuery.Not -> "-${query.shape()}"
    is SearchQuery.FavoriteArtists -> "favoriteArtists[${favoriteArtistTags().size}]"
    is SearchQuery.ReadLater -> "readLater[${readLater.size}]"
}

/** Whether [readLater] decides part of the result, so a change to it changes the list. */
fun SearchQuery.usesReadLater(): Boolean = when (this) {
    is SearchQuery.ReadLater -> true
    is SearchQuery.Tag, is SearchQuery.FavoriteArtists -> false
    is SearchQuery.And -> queries.any { it.usesReadLater() }
    is SearchQuery.Or -> queries.any { it.usesReadLater() }
    is SearchQuery.Not -> query.usesReadLater()
}

suspend fun HitomiClient.evaluate(query: SearchQuery, sortMode: SortMode): IntArray {
    val ids = evaluateNode(query, sortMode)

    return when {
        ids.isEmpty() -> ids

        sortMode == SortMode.RANDOM -> ids.also { it.shuffle() }

        !query.needsRanking() -> ids

        else -> ids.rankedBy(allGalleryIDs(sortMode))
    }
}

/**
 * The [candidates] [query] matches, in no particular order.
 *
 * Every step stays within [candidates], so neither a NOT nor an OR needs the
 * whole index to complement or rank against.
 */
suspend fun HitomiClient.evaluateWithin(
    query: SearchQuery,
    candidates: IntArray,
    sortMode: SortMode = SortMode.DATE_ADDED,
): IntArray = evaluateWithin(query, candidates, tagLookup(sortMode))

internal suspend fun evaluateWithin(
    query: SearchQuery,
    candidates: IntArray,
    lookup: suspend (SearchQuery.Tag) -> IntArray,
): IntArray {
    val pool = candidates.toIntSet()

    suspend fun match(query: SearchQuery): IntArray = coroutineScope {
        when (query) {
            is SearchQuery.Tag -> lookup(query).retainIds(pool)

            is SearchQuery.FavoriteArtists ->
                favoriteArtistTags().let { artists ->
                    if (artists.isEmpty()) IntArray(0)
                    else match(SearchQuery.Or(artists))
                }

            is SearchQuery.ReadLater -> readLater.items.toIntArray().retainIds(pool)

            is SearchQuery.And -> {
                val (negative, positive) = query.queries.partition { it is SearchQuery.Not }

                val excluded = negative.map { async { match((it as SearchQuery.Not).query) } }
                val included = positive.map { async { match(it) } }

                excluded.awaitAll().fold(
                    included.awaitAll().reduceOrNull { acc, ids -> acc.intersectIds(ids) }
                        ?: candidates,
                ) { acc, ids -> acc.subtractIds(ids) }
            }

            is SearchQuery.Or ->
                query.queries.map { async { match(it) } }.awaitAll().unionIds()

            is SearchQuery.Not -> candidates.subtractIds(match(query.query))
        }
    }

    return match(query)
}

/** How a tag is resolved against hitomi, for an evaluator that takes it apart. */
internal fun HitomiClient.tagLookup(sortMode: SortMode): suspend (SearchQuery.Tag) -> IntArray =
    { getGalleryIDsForQuery(it.toString().lowercase(), sortMode) }

private suspend fun HitomiClient.evaluateNode(query: SearchQuery, sortMode: SortMode): IntArray =
    evaluateEverywhere(query, { allGalleryIDs(sortMode) }, tagLookup(sortMode))

/**
 * Everything [query] matches, in no particular order.
 *
 * [all] is only asked for where a query says nothing about what to include --
 * a lone negation, or a conjunction of them -- since that is the only time the
 * whole index is what the terms narrow.
 */
internal suspend fun evaluateEverywhere(
    query: SearchQuery,
    all: suspend () -> IntArray,
    lookup: suspend (SearchQuery.Tag) -> IntArray,
): IntArray {
    suspend fun match(query: SearchQuery): IntArray = coroutineScope {
        when (query) {
            is SearchQuery.Tag -> lookup(query)

            is SearchQuery.FavoriteArtists ->
                favoriteArtistTags().let { artists ->
                    if (artists.isEmpty()) IntArray(0)
                    else match(SearchQuery.Or(artists))
                }

            is SearchQuery.ReadLater -> readLater.items.asReversed().toIntArray()

            is SearchQuery.And -> {
                val (negative, positive) = query.queries.partition { it is SearchQuery.Not }

                val excluded = negative.map { async { match((it as SearchQuery.Not).query) } }

                val included = if (positive.isEmpty())
                    listOf(async { all() })
                else
                    positive.map { async { match(it) } }

                excluded.awaitAll().fold(
                    included.awaitAll().reduce { acc, ids -> acc.intersectIds(ids) },
                ) { acc, ids -> acc.subtractIds(ids) }
            }

            is SearchQuery.Or ->
                query.queries.map { async { match(it) } }.awaitAll().unionIds()

            // Complement, not intersection.
            is SearchQuery.Not -> {
                val index = async { all() }
                val excluded = match(query.query)
                index.await().subtractIds(excluded)
            }
        }
    }

    return match(query)
}

/**
 * The terms of the query's top level conjunction, which are the ones that can
 * be taken out of it on their own.
 */
fun SearchQuery?.terms(): List<SearchQuery> = when (this) {
    null -> emptyList()
    is SearchQuery.And -> queries
    else -> listOf(this)
}

/** The query with [term] taken out of its top level conjunction. */
fun SearchQuery.without(term: SearchQuery): SearchQuery? = when {
    this == term -> null
    this !is SearchQuery.And -> this
    else -> queries.filterNot { it == term }.let { rest ->
        when (rest.size) {
            0 -> null
            1 -> rest.single()
            else -> SearchQuery.And(rest)
        }
    }
}
