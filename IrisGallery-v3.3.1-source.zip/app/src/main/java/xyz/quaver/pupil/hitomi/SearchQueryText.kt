/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

/**
 * The plain text spelling of a query: whitespace-separated terms, `-` in front
 * of one to exclude it, `namespace:tag`, and `_` wherever a tag has a space.
 *
 * It is what hitomi's own search box takes, so it can only say AND and NOT.
 * Everything the tree can express beyond that -- an OR group, the favourite
 * artists, the read later list -- has no spelling, which [toQueryText] reports
 * by returning null.
 */
fun parseQueryText(text: String): SearchQuery? {
    val terms = text.split(' ', '\t', '\n').mapNotNull(::parseTerm)

    return when (terms.size) {
        0 -> null
        1 -> terms.single()
        else -> SearchQuery.And(terms)
    }
}

fun SearchQuery.toQueryText(): String? {
    return when (this) {
        is SearchQuery.Tag -> toTermText()

        is SearchQuery.Not -> (query as? SearchQuery.Tag)?.let { "-${it.toTermText()}" }

        is SearchQuery.And ->
            queries.map { it.toQueryText() ?: return null }.joinToString(" ")

        is SearchQuery.Or, is SearchQuery.FavoriteArtists, is SearchQuery.ReadLater -> null
    }
}

data class QueryTerm(val start: Int, val end: Int, val text: String)

/** The one term of [text] the cursor at [cursor] is inside of, or touching. */
fun termAt(text: String, cursor: Int): QueryTerm {
    var start = cursor.coerceIn(0, text.length)
    var end = start

    while (start > 0 && !text[start - 1].isWhitespace()) start--
    while (end < text.length && !text[end].isWhitespace()) end++

    return QueryTerm(start, end, text.substring(start, end))
}

fun parseQueryTerm(term: String): SearchQuery.Tag {
    val separator = term.indexOf(':')
    val namespace = term.take(separator.coerceAtLeast(0)).lowercase()

    return if (separator != -1 && namespace in validNamespace)
        SearchQuery.Tag(namespace, term.drop(separator + 1).normalizeTag())
    else
        SearchQuery.Tag(null, term.normalizeTag())
}

private fun parseTerm(term: String): SearchQuery? {
    val negated = term.startsWith('-')
    val body = if (negated) term.drop(1) else term

    val tag = parseQueryTerm(body)

    if (tag.tag.isBlank()) return null

    return if (negated) SearchQuery.Not(tag) else tag
}

private fun SearchQuery.Tag.toTermText() = toString().replace(' ', '_')

private fun String.normalizeTag() = replace('_', ' ').lowercase().trim()
