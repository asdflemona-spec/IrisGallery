/*
 *    Copyright 2019 tom5079
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package xyz.quaver.pupil.hitomi

import io.ktor.client.call.body
import kotlinx.serialization.Serializable
import java.nio.ByteBuffer
import java.nio.ByteOrder

//galleryblock.js
suspend fun HitomiClient.fetchNozomi(area: String? = null, tag: String = "index", language: String = "all", start: Int = -1, count: Int = -1) : Pair<List<Int>, Int> {
    val url = when(area) {
        null -> "$protocol//$domain/$tag-$language$nozomiextension"
        else -> "$protocol//$domain/$area/$tag-$language$nozomiextension"
    }

    val range = if (start != -1 && count != -1)
        (start.toLong() * 4)..((start + count).toLong() * 4 - 1)
    else
        null

    val response = get(url, range)

    val totalItems = response.headers["Content-Range"]
        ?.replace(Regex("^[Bb]ytes \\d+-\\d+/"), "")?.toInt()?.div(4) ?: 0

    val nozomi = ArrayList<Int>()

    val arrayBuffer = ByteBuffer
        .wrap(response.body<ByteArray>())
        .order(ByteOrder.BIG_ENDIAN)

    while (arrayBuffer.hasRemaining())
        nozomi.add(arrayBuffer.int)

    return Pair(nozomi, totalItems)
}

@Serializable
data class GalleryBlock(
    val id: Int,
    val galleryUrl: String,
    val thumbnails: List<String>,
    val title: String,
    val artists: List<String>,
    val series: List<String>,
    val type: String,
    val language: String,
    val relatedTags: List<String>,
    val groups: List<String> = emptyList()
)

suspend fun HitomiClient.getGalleryBlock(galleryID: Int) : GalleryBlock {
    val info = getGalleryInfo(galleryID)

    return GalleryBlock(
        galleryID,
        "",
        listOf(urlFromUrlFromHash(galleryID, info.files.first(), "webpbigtn", "webp", "tn")),
        info.title,
        info.artists?.map { it.artist }.orEmpty(),
        info.parodys?.map { it.parody }.orEmpty(),
        info.type,
        info.language.orEmpty(),
        info.tags?.map { "${if (it.female.isNullOrEmpty()) "" else "female:"}${if (it.male.isNullOrEmpty()) "" else "male:"}${it.tag}" }.orEmpty(),
        info.groups?.map { it.group }.orEmpty()
    )
}