/*
 *    Copyright 2019 tom5079
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package xyz.quaver.pupil.hitomi

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.util.LinkedList

suspend fun HitomiClient.doSearch(query: String, sortMode: SortMode): IntArray = coroutineScope {
    val terms = query
        .trim()
        .replace(Regex("""^\?"""), "")
        .lowercase()
        .split(Regex("\\s+"))
        .map {
            it.replace('_', ' ')
        }

    val positiveTerms = LinkedList<String>()
    val negativeTerms = LinkedList<String>()

    for (term in terms) {
        if (term.startsWith("-"))
            negativeTerms.push(term.substring(1))
        else if (term.isNotBlank())
            positiveTerms.push(term)
    }

    val positiveResults = positiveTerms.map {
        async {
            runCatching {
                getGalleryIDsForQuery(it, sortMode)
            }.getOrElse { IntArray(0) }
        }
    }

    val negativeResults = negativeTerms.map {
        async {
            runCatching {
                getGalleryIDsForQuery(it, sortMode)
            }.getOrElse { IntArray(0) }
        }
    }

    var results = if (positiveTerms.isEmpty())
        getGalleryIDsFromNozomi(SearchArgs("all", "index", "all"), sortMode)
    else
        null

    positiveResults.forEach { deferred ->
        val ids = deferred.await()
        results = results?.intersectIds(ids) ?: ids
    }

    negativeResults.forEach { deferred ->
        results = results?.subtractIds(deferred.await())
    }

    return@coroutineScope (results ?: IntArray(0)).also {
        if (sortMode == SortMode.RANDOM) it.shuffle()
    }
}
