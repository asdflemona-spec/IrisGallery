/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.network

import io.ktor.client.HttpClient
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonArray
import xyz.quaver.pupil.client
import java.io.IOException

/**
 * Everything the app fetches that is not a hitomi resource. URLs live here rather
 * than at the call sites, which ask for what they want and never build a request.
 */
class PupilClient(private val http: HttpClient) {

    /**
     * Codeberg answers 403 to browser-like User-Agents, so these requests set one of
     * their own over the default the engine applies.
     */
    private suspend fun getText(url: String): String =
        http.get(url) {
            header(HttpHeaders.UserAgent, "Pupil")
        }.also {
            if (!it.status.isSuccess()) throw IOException("CODE ${it.status.value}")
        }.bodyAsText()

    /** The release feed, whose URL is a string resource so forks can point elsewhere. */
    suspend fun getReleases(url: String): JsonArray =
        Json.parseToJsonElement(getText(url)).jsonArray

    /** A favourites backup, from wherever the user says it lives. */
    suspend fun getBackup(url: String): JsonElement =
        Json.parseToJsonElement(getText(url).ifEmpty { "[]" })
}

val pupilClient: PupilClient by lazy { PupilClient(client) }
