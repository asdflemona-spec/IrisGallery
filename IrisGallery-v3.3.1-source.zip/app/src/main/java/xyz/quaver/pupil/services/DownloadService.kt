/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.services

import android.annotation.SuppressLint
import android.app.ForegroundServiceStartNotAllowedException
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.system.ErrnoException
import android.system.OsConstants
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.TaskStackBuilder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import xyz.quaver.pupil.*
import xyz.quaver.pupil.hitomi.HitomiHttpException
import xyz.quaver.pupil.hitomi.HitomiResponseException
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.ui.ReaderActivity
import xyz.quaver.pupil.util.*
import xyz.quaver.pupil.util.downloader.Cache
import xyz.quaver.pupil.util.downloader.DownloadFailure
import xyz.quaver.pupil.util.downloader.DownloadManager
import xyz.quaver.pupil.util.downloader.DownloadState
import xyz.quaver.pupil.util.downloader.Downloads
import xyz.quaver.pupil.util.downloader.ImageProgress
import xyz.quaver.pupil.util.downloader.message
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil
import kotlin.math.log10

class DownloadService : Service() {

    //region Notification
    private val notificationManager by lazy {
        NotificationManagerCompat.from(this)
    }

    private val serviceNotification by lazy {
        NotificationCompat.Builder(this, "downloader")
            .setContentTitle(getString(R.string.downloader_running))
            .setProgress(0, 0, false)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
    }

    private val notification = ConcurrentHashMap<Int, NotificationCompat.Builder?>()

    private fun initNotification(galleryID: Int) {
        val intent = Intent(this, ReaderActivity::class.java)
            .putExtra("galleryID", galleryID)

        val pendingIntent = TaskStackBuilder.create(this).run {
            addNextIntentWithParentStack(intent)
            getPendingIntent(galleryID, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
        }
        val action =
            NotificationCompat.Action.Builder(0, getText(android.R.string.cancel),
                PendingIntent.getService(
                    this,
                    R.id.notification_download_cancel_action.normalizeID(),
                    Intent(this, DownloadService::class.java)
                        .putExtra(KEY_COMMAND, COMMAND_CANCEL)
                        .putExtra(KEY_ID, galleryID),
                    PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0),
            ).build()

        notification[galleryID] = NotificationCompat.Builder(this, "download").apply {
            setContentTitle(getString(R.string.reader_loading))
            setContentText(getString(R.string.reader_notification_text))
            setSmallIcon(R.drawable.ic_notification)
            setContentIntent(pendingIntent)
            addAction(action)
            setProgress(0, 0, true)
            setOngoing(true)
        }

        notify(galleryID)
    }

    @SuppressLint("RestrictedApi", "MissingPermission")
    private fun notify(galleryID: Int) {
        val notification = notification[galleryID] ?: return

        if (!checkNotificationEnabled(this)) return

        // Preparing keeps the indeterminate bar initNotification set: there is no
        // image count to put on it yet.
        when (val state = Downloads.state(galleryID)) {
            is DownloadState.Complete -> {
                notification
                    .setContentText(getString(R.string.reader_notification_complete))
                    .setProgress(0, 0, false)
                    .setOngoing(false)
                    .mActions.clear()

                notificationManager.cancel(galleryID)
            }
            is DownloadState.Downloading ->
                notification
                    .setProgress(state.total, state.completed, false)
                    .setContentText("${state.completed}/${state.total}")

            is DownloadState.Failed ->
                notification
                    .setContentText(getString(state.reason.message()))
                    .setProgress(0, 0, false)
                    .setOngoing(false)
                    .mActions.clear()

            else -> Unit
        }

        if (DownloadManager.getInstance(this).isSaved(galleryID) || galleryID == Downloads.priority)
            notification.let { notificationManager.notify(galleryID, it.build()) }
        else
            notificationManager.cancel(galleryID)
    }
    //endregion

    //region Image fetching
    /**
     * Hitomi answers 503 while it brings a subdomain up, so a retry there is expected
     * rather than exceptional and is not counted. Anything else gets [MAX_RETRY]
     * attempts before the image is given up on.
     */
    private suspend fun fetchImage(galleryID: Int, index: Int, url: String): ByteArray {
        var limit = MAX_RETRY

        while (true) {
            val attempt = kotlin.runCatching {
                hitomiClient.getImage(url) { bytesRead, contentLength ->
                    if (contentLength != null && contentLength > 0L)
                        Downloads.advance(galleryID, index, bytesRead.toFloat() / contentLength)
                }
            }

            attempt.getOrNull()?.let { return it }

            val failure = attempt.exceptionOrNull()

            if ((failure as? HitomiHttpException)?.status == SERVICE_UNAVAILABLE)
                delay(RETRY_DELAY)
            else if (--limit < 0)
                throw IOException("$galleryID $index $url", failure)
        }
    }

    /** An image that did not land, and what to tell the user about it. */
    private class ImageFailure(val reason: DownloadFailure, cause: Throwable) : IOException(cause)

    /**
     * A disk with no room reports it as the errno behind the write, or as a plain
     * message from `createNewFile`, depending on which of the two runs out first.
     */
    private fun Throwable.isOutOfSpace(): Boolean =
        generateSequence(this) { it.cause }.take(CAUSE_DEPTH).any { failure ->
            (failure as? ErrnoException)?.errno == OsConstants.ENOSPC ||
                failure.message?.contains("ENOSPC") == true ||
                failure.message?.contains("No space left on device") == true
        }

    private suspend fun downloadImage(galleryID: Int, index: Int, url: String, total: Int) {
        val image = try {
            fetchImage(galleryID, index, url)
        } catch (e: Exception) {
            throw ImageFailure(DownloadFailure.NETWORK, e)
        }

        val padding = ceil(log10(total.toFloat())).toInt()
        val ext = url.substringBefore('?').substringAfterLast('.')

        try {
            Cache.getInstance(this, galleryID)
                .putImage(index, "${index.toString().padStart(padding, '0')}.$ext", image)
        } catch (e: Exception) {
            throw ImageFailure(
                if (e.isOutOfSpace()) DownloadFailure.OUT_OF_SPACE else DownloadFailure.STORAGE,
                e,
            )
        }

        Downloads.complete(galleryID, index)
        notify(galleryID)
    }
    //endregion

    //region Downloader
    private val downloadScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /** Stops the service only once nothing else is still downloading. */
    private fun stopIfIdle(startId: Int?) {
        if (startId != null && downloadJobs.values.none { it.isActive })
            stopSelf(startId)
    }

    fun cancel(startId: Int? = null) {
        downloadJobs.keys.toList().forEach { cancel(it) }

        Downloads.forgetAll()
        notification.clear()
        notificationManager.cancelAll()

        stopIfIdle(startId)
    }

    fun cancel(galleryID: Int, startId: Int? = null) {
        downloadJobs.remove(galleryID)?.cancel()

        Downloads.forget(galleryID)
        notification.remove(galleryID)
        notificationManager.cancel(galleryID)

        stopIfIdle(startId)
    }

    /** The job goes first: the folder is deleted out from under it otherwise. */
    private fun stopSaving(galleryID: Int) {
        cancel(galleryID)
        DownloadManager.getInstance(this).deleteDownloadFolder(galleryID)
    }

    /**
     * Stops saving [galleryID] to the download folder, leaving what is cached alone.
     *
     * A download still running carries on into the cache, which is where a reader
     * showing the gallery expects to keep finding it.
     */
    fun unsave(galleryID: Int, startId: Int? = null) = downloadScope.launch {
        val wasDownloading = isDownloading(galleryID)

        stopSaving(galleryID)

        if (wasDownloading) download(galleryID)

        stopIfIdle(startId)
    }

    fun delete(galleryID: Int, startId: Int? = null) = downloadScope.launch {
        stopSaving(galleryID)
        Cache.delete(this@DownloadService, galleryID)

        stopIfIdle(startId)
    }

    @Synchronized
    fun download(galleryID: Int, priority: Boolean = false, save: Boolean = false, startId: Int? = null): Job {
        // A gallery already on its way into the cache has to start again to be
        // saved, since where a job writes is settled before it fetches anything.
        if (save && !DownloadManager.getInstance(this).isSaved(galleryID))
            cancel(galleryID)

        downloadJobs[galleryID]?.let { if (it.isActive) return it }

        val job = downloadScope.launch(start = CoroutineStart.LAZY) {
            downloadGallery(galleryID, priority, save)
        }

        downloadJobs[galleryID] = job
        job.invokeOnCompletion {
            downloadJobs.remove(galleryID, job)
            stopIfIdle(startId)
        }
        job.start()

        return job
    }

    private suspend fun downloadGallery(galleryID: Int, priority: Boolean, save: Boolean) {
        cleanCache(this)

        if (save) DownloadManager.getInstance(this).addDownloadFolder(galleryID)

        val cache = Cache.getInstance(this, galleryID)

        Downloads.preparing(galleryID)
        initNotification(galleryID)

        // A gallery saved as an archive is read out of the cache like any other, so
        // it is unpacked back into it before anything asks what is on disk.
        val archived = cache.restoreFromArchive()

        val galleryInfo = kotlin.runCatching { cache.getGalleryInfo() }.getOrElse { failure ->
            // Hitomi answering that it has no such gallery is the gallery being gone.
            // Hitomi not answering is not, so nothing is deleted over it.
            if ((failure as? HitomiResponseException)?.statusCode != NOT_FOUND) {
                Downloads.failed(galleryID, DownloadFailure.NETWORK)
                notify(galleryID)
                return
            }

            // Torn down inline rather than through delete(), which would cancel this
            // very job and leave the state unset.
            notification.remove(galleryID)
            notificationManager.cancel(galleryID)

            DownloadManager.getInstance(this).deleteDownloadFolder(galleryID)
            Cache.delete(this, galleryID)

            Downloads.notFound(galleryID)
            return
        }

        // Brings over anything cached before the gallery became a download, and
        // answers which images are in the folder this job writes to.
        val present = cache.reconcile()

        Downloads.begin(galleryID, galleryInfo.files.size)
        present.forEach { index -> Downloads.complete(galleryID, index) }

        if (Downloads.state(galleryID) is DownloadState.Complete) {
            if (!archived) cache.saveToArchive(keepImages = galleryID == Downloads.reading)

            notificationManager.cancel(galleryID)
            return
        }

        notification[galleryID]?.setContentTitle(galleryInfo.title.ellipsize(32))
        notify(galleryID)

        // A priority gallery jumps the queue: everything else is parked and resumed after.
        val preempted = if (priority)
            downloadJobs.keys.filterNot { it == galleryID }.onEach { cancel(it) }
        else
            emptyList()

        downloadImages(galleryID, galleryInfo.getImageUrls())

        if (!archived) cache.saveToArchive(keepImages = galleryID == Downloads.reading)

        preempted.forEach { download(it) }
    }

    /**
     * Fetches what [galleryID] is still missing, [concurrentImages] at a time, each
     * worker taking the image nearest the page being read.
     *
     * A queue of its own rather than every image at once: requests beyond the few
     * okhttp runs concurrently wait in its dispatcher in the order they were made,
     * where a reader that has turned to a later page can no longer overtake them.
     */
    private suspend fun downloadImages(galleryID: Int, urls: List<String>) = coroutineScope {
        // Already on disk, or past the image count the gallery info gave.
        val pending = urls.indices.filter {
            Downloads.imageProgress(galleryID, it) is ImageProgress.Downloading
        }

        val queue = ImageQueue(pending, urls.size)

        // A device that has run out of room has none for the next image either, so
        // the rest of the gallery is given up rather than fetched to be thrown away.
        val outOfSpace = AtomicBoolean(false)

        repeat(minOf(concurrentImages(), pending.size)) {
            launch {
                while (true) {
                    val index = queue.take(Downloads.focusOf(galleryID)) ?: break

                    if (outOfSpace.get()) {
                        Downloads.fail(galleryID, index, DownloadFailure.OUT_OF_SPACE)
                        continue
                    }

                    kotlin.runCatching {
                        downloadImage(galleryID, index, urls[index], urls.size)
                    }.onFailure { failure ->
                        val reason =
                            (failure as? ImageFailure)?.reason ?: DownloadFailure.STORAGE

                        if (reason == DownloadFailure.OUT_OF_SPACE) outOfSpace.set(true)

                        Log.d("PUPILD", "DOWNLOAD FAILED $galleryID $index, $failure")
                        Crashlytics.recordException(failure)

                        Downloads.fail(galleryID, index, reason)
                        notify(galleryID)
                    }
                }
            }
        }
    }

    /**
     * How many images of one gallery to have in flight, from the preference that caps
     * every request the app makes. Unlimited is a cap all the same here: filling
     * okhttp's queue is what settles the order before the reader can ask for another
     * page.
     */
    private fun concurrentImages(): Int =
        settings.value.maxConcurrentDownload.takeIf { it > 0 }
            ?: DEFAULT_CONCURRENT_IMAGES
    //endregion

    companion object {
        const val KEY_COMMAND = "COMMAND"   // String
        const val KEY_ID = "ID"             // Int
        const val KEY_PRIORITY = "PRIORITY" // Boolean
        const val KEY_SAVE = "SAVE"         // Boolean

        const val COMMAND_DOWNLOAD = "DOWNLOAD"
        const val COMMAND_CANCEL = "CANCEL"
        const val COMMAND_UNSAVE = "UNSAVE"
        const val COMMAND_DELETE = "DELETE"

        private const val MAX_RETRY = 10
        private const val RETRY_DELAY = 200L
        private const val SERVICE_UNAVAILABLE = 503
        private const val NOT_FOUND = 404
        private const val CAUSE_DEPTH = 8
        private const val DEFAULT_CONCURRENT_IMAGES = 4

        /**
         * In-flight gallery downloads, keyed by gallery ID. Process-wide because
         * [DownloadManager] has to answer "is this downloading?" without the service.
         */
        private val downloadJobs = ConcurrentHashMap<Int, Job>()

        fun isDownloading(galleryID: Int) = downloadJobs[galleryID]?.isActive == true

        private fun command(context: Context, extras: Intent.() -> Unit) {
            ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java).apply(extras))
        }

        /** [save] registers the download folder before anything is fetched. */
        fun download(context: Context, galleryID: Int, priority: Boolean = false, save: Boolean = false) {
            command(context) {
                putExtra(KEY_COMMAND, COMMAND_DOWNLOAD)
                putExtra(KEY_PRIORITY, priority)
                putExtra(KEY_SAVE, save)
                putExtra(KEY_ID, galleryID)
            }
        }

        fun unsave(context: Context, galleryID: Int) {
            command(context) {
                putExtra(KEY_COMMAND, COMMAND_UNSAVE)
                putExtra(KEY_ID, galleryID)
            }
        }

        fun cancel(context: Context, galleryID: Int? = null) {
            command(context) {
                putExtra(KEY_COMMAND, COMMAND_CANCEL)
                galleryID?.let { putExtra(KEY_ID, it) }
            }
        }

        fun delete(context: Context, galleryID: Int) {
            command(context) {
                putExtra(KEY_COMMAND, COMMAND_DELETE)
                putExtra(KEY_ID, galleryID)
            }
        }
    }

    /**
     * Android refuses the promotion for a start that reached here from the
     * background, which a download notification outliving its process does: it
     * keeps its cancel action long after the app was last open. Stopping is what
     * clears the start's obligation to become foreground within five seconds.
     */
    private fun promoteToForeground(): Boolean = runCatching {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.TIRAMISU) {
            startForeground(R.id.downloader_notification_id, serviceNotification.build())
        } else {
            startForeground(R.id.downloader_notification_id, serviceNotification.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        }
    }.onFailure { failure ->
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || failure !is ForegroundServiceStartNotAllowedException)
            throw failure

        Crashlytics.recordException(failure)
    }.isSuccess

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent?.getStringExtra(KEY_COMMAND)
        val galleryID = intent?.getIntExtra(KEY_ID, -1) ?: -1

        // Cancelling is the one command left worth honouring: it asks for work to
        // stop rather than start, and it is what takes the stale notification down.
        if (!promoteToForeground()) {
            if (command == COMMAND_CANCEL) if (galleryID > 0) cancel(galleryID) else cancel()

            stopSelf(startId)
            return START_NOT_STICKY
        }

        when (command) {
            COMMAND_DOWNLOAD -> if (galleryID > 0)
                download(
                    galleryID,
                    intent?.getBooleanExtra(KEY_PRIORITY, false) == true,
                    intent?.getBooleanExtra(KEY_SAVE, false) == true,
                    startId,
                )
            COMMAND_CANCEL -> if (galleryID > 0) cancel(galleryID, startId) else cancel(startId = startId)
            COMMAND_UNSAVE -> if (galleryID > 0) unsave(galleryID, startId)
            COMMAND_DELETE -> if (galleryID > 0) delete(galleryID, startId)
        }

        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        downloadScope.cancel()
    }
}
