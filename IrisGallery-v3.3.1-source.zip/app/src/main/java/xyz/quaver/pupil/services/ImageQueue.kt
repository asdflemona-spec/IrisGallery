/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.services

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * The images of one gallery still to fetch, out of [total], handed out nearest first
 * to the page being read: that page and everything past it in order, then what was
 * left behind it, nearest first.
 */
internal class ImageQueue(pending: List<Int>, private val total: Int) {

    private val mutex = Mutex()
    private val remaining = pending.toMutableList()

    suspend fun take(focus: Int): Int? = mutex.withLock {
        remaining.indices
            .minByOrNull { distanceFrom(focus, remaining[it]) }
            ?.let { remaining.removeAt(it) }
    }

    private fun distanceFrom(focus: Int, index: Int) =
        if (index >= focus) index - focus else total + focus - index
}
