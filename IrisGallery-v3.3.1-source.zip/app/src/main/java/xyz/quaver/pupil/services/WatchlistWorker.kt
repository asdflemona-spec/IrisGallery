/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.services

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.Revalidate
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.SortMode
import xyz.quaver.pupil.hitomi.evaluate
import xyz.quaver.pupil.hitomi.getGalleryBlock
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.hitomi.shape
import xyz.quaver.pupil.ui.MainComposeActivity
import xyz.quaver.pupil.util.Crashlytics
import xyz.quaver.pupil.util.DefaultQuery
import xyz.quaver.pupil.util.Watch
import xyz.quaver.pupil.util.afterCheck
import xyz.quaver.pupil.util.checkNotificationEnabled
import xyz.quaver.pupil.util.translations
import xyz.quaver.pupil.util.wordCapitalize
import xyz.quaver.pupil.watchlist
import java.util.concurrent.TimeUnit

private const val WORK_NAME = "watchlist"
private const val CHECK_NOW_WORK_NAME = "watchlist-check-now"

/** Keeps a watch's notification apart from the download sharing its ID. */
private const val NOTIFICATION_TAG = "watchlist"

private const val CHECK_INTERVAL_HOURS = 6L

/** Titles to put in a notification before it only counts what is left. */
private const val NOTIFICATION_TITLE_LIMIT = 5

private const val EXTRA_QUERY = "watchlist_query"

/**
 * Runs every watched query and tells the reader what turned up since the last
 * time it ran.
 *
 * The work is unique and periodic; [sync] keeps it scheduled only while there
 * is something to watch.
 */
class WatchlistWorker(
    context: Context,
    parameters: WorkerParameters,
) : CoroutineWorker(context, parameters) {

    override suspend fun doWork(): Result {
        var failed = false

        watchlist.items.forEach { watch ->
            runCatching { check(watch) }.onFailure {
                if (it is CancellationException) throw it

                failed = true
                Crashlytics.recordException(it)
            }
        }

        return if (failed) Result.retry() else Result.success()
    }

    private suspend fun check(watch: Watch) {
        val query = DefaultQuery.apply(watch.query) ?: watch.query

        Crashlytics.log("Watchlist: checking ${query.shape()}")

        // hitomi serves its index with an hour of freshness, and a check that
        // read it out of the cache would report the same galleries again.
        val ids = withContext(Revalidate()) { hitomiClient.evaluate(query, SortMode.DATE_ADDED) }

        val (checked, new) = watch.afterCheck(ids, System.currentTimeMillis())

        watchlist.set(checked)

        if (new.isNotEmpty()) notify(watch.query, new)
    }

    @SuppressLint("MissingPermission")
    private suspend fun notify(query: SearchQuery, new: List<Int>) {
        val context = applicationContext

        if (!checkNotificationEnabled(context)) return

        val titles = new.take(NOTIFICATION_TITLE_LIMIT).map { galleryID ->
            runCatching { hitomiClient.getGalleryBlock(galleryID).title }
                .getOrDefault(galleryID.toString())
        }

        val label = context.queryLabel(query)

        val style = NotificationCompat.InboxStyle().setSummaryText(label)
        titles.forEach(style::addLine)
        if (new.size > titles.size)
            style.addLine(context.getString(R.string.watchlist_notification_more, new.size - titles.size))

        val notification = NotificationCompat.Builder(context, "watchlist")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(
                context.resources.getQuantityString(
                    R.plurals.watchlist_notification_title,
                    new.size,
                    new.size,
                ),
            )
            .setContentText(label)
            .setStyle(style)
            .setContentIntent(
                PendingIntent.getActivity(
                    context,
                    query.hashCode(),
                    watchlistIntent(context, query),
                    PendingIntent.FLAG_UPDATE_CURRENT or
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                            PendingIntent.FLAG_IMMUTABLE
                        else 0,
                ),
            )
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context)
            .notify(NOTIFICATION_TAG, query.hashCode(), notification)
    }

    companion object {
        private val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        /** Schedules the periodic check, or drops it once nothing is watched. */
        fun sync(context: Context) {
            val workManager = WorkManager.getInstance(context)

            if (watchlist.items.isEmpty()) {
                workManager.cancelUniqueWork(WORK_NAME)
                return
            }

            workManager.enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<WatchlistWorker>(CHECK_INTERVAL_HOURS, TimeUnit.HOURS)
                    .setConstraints(constraints)
                    .build(),
            )
        }

        fun checkNow(context: Context) {
            WorkManager.getInstance(context).enqueueUniqueWork(
                CHECK_NOW_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                OneTimeWorkRequestBuilder<WatchlistWorker>()
                    .setConstraints(constraints)
                    .build(),
            )
        }
    }
}

/**
 * Opens the app on the watched query, closing whatever it had opened over the
 * list. SINGLE_TOP so the app it is already showing takes the query through
 * [android.app.Activity.onNewIntent] rather than being torn down and rebuilt
 * around it.
 */
fun watchlistIntent(context: Context, query: SearchQuery): Intent =
    Intent(context, MainComposeActivity::class.java)
        .setFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP,
        )
        .putExtra(EXTRA_QUERY, Json.encodeToString(SearchQuery.serializer(), query))

/** The query [watchlistIntent] was built for, if this is one of those intents. */
fun Intent.watchlistQuery(): SearchQuery? = getStringExtra(EXTRA_QUERY)?.let {
    runCatching { Json.decodeFromString(SearchQuery.serializer(), it) }.getOrNull()
}

private fun Context.queryLabel(query: SearchQuery): String = when (query) {
    is SearchQuery.Tag ->
        query.namespace?.let { "$it:" }.orEmpty() +
            (translations[query.tag] ?: query.tag).wordCapitalize()

    is SearchQuery.And -> query.queries.joinToString(" ") { queryLabel(it) }

    is SearchQuery.Or -> query.queries.joinToString(" + ", "(", ")") { queryLabel(it) }

    is SearchQuery.Not -> "-${queryLabel(query.query)}"

    is SearchQuery.FavoriteArtists -> getString(R.string.search_favorite_artists)

    is SearchQuery.ReadLater -> getString(R.string.search_read_later)
}
