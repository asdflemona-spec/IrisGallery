package xyz.quaver.pupil.source

/** Placeholder used until the user supplies/authorizes the provider's supported API configuration. */
class ConfiguredSource(
    override val id: String,
    override val displayName: String,
    override val maturity: SourceMaturity = SourceMaturity.GENERAL,
) : ContentSource {
    override val availability = SourceAvailability.REQUIRES_CONFIGURATION

    override suspend fun search(query: String, page: Int): SourcePage =
        error("$displayName source requires provider configuration")

    override suspend fun detail(remoteId: String): SourceDetail =
        error("$displayName source requires provider configuration")
}
