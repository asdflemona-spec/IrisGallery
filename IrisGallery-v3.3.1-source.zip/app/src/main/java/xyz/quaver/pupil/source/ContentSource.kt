package xyz.quaver.pupil.source

/** A site-independent item that Iris can show in unified search/results UI. */
data class SourceItem(
    val sourceId: String,
    val remoteId: String,
    val title: String,
    val thumbnailUrl: String?,
    val pageUrl: String?,
    val tags: List<String> = emptyList(),
)

data class SourceDetail(
    val item: SourceItem,
    val imageUrls: List<String>,
    val creators: List<String> = emptyList(),
    val description: String? = null,
)

data class SourcePage(
    val items: List<SourceItem>,
    val nextPage: Int? = null,
)

enum class SourceMaturity { GENERAL, ADULT }

enum class SourceAvailability { READY, REQUIRES_CONFIGURATION }

/**
 * Adapter boundary for remote image/gallery providers.
 * Implementations must use public/authorized endpoints and must not bypass
 * authentication, paywalls, access controls, or provider restrictions.
 */
interface ContentSource {
    val id: String
    val displayName: String
    val maturity: SourceMaturity
    val availability: SourceAvailability

    suspend fun search(query: String, page: Int = 0): SourcePage
    suspend fun detail(remoteId: String): SourceDetail
}
