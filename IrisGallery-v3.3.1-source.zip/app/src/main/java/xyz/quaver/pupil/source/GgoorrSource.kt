package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI

/** Public HTML adapter for the ggoorr /ao board. */
class GgoorrSource : ContentSource {
    override val id = "ggoorr"
    override val displayName = "Ggoorr"
    override val maturity = SourceMaturity.ADULT
    override val availability = SourceAvailability.READY

    val baseUrl = "https://ggoorr.net"
    val boardUrl = "$baseUrl/ao"
    val requestHeaders = mapOf(
        "Referer" to boardUrl,
        "User-Agent" to "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
    )

    private suspend fun document(url: String): Document {
        val response = client.get(url) { requestHeaders.forEach { (k, v) -> header(k, v) } }
        if (!response.status.isSuccess()) throw IOException("Ggoorr HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }

    override suspend fun search(query: String, page: Int): SourcePage {
        val url = buildString {
            append(boardUrl).append("?page=").append(page + 1)
            if (query.isNotBlank()) append("&search_target=title_content&search_keyword=")
                .append(java.net.URLEncoder.encode(query, "UTF-8"))
        }
        val doc = document(url)
        val seen = hashSetOf<String>()
        val items = doc.select("a[href]").mapNotNull { a ->
            val href = a.absUrl("href").ifBlank { a.attr("href") }
            val remoteId = remoteIdFrom(href) ?: return@mapNotNull null
            val title = a.text().trim()
            if (title.isBlank() || !seen.add(remoteId)) return@mapNotNull null
            val row = a.closest("tr, li, .document, .list_unit, .item")
            val thumb = row?.selectFirst("img")?.let(::imageUrl)
            SourceItem(id, remoteId, title, thumb, "$boardUrl/$remoteId")
        }
        return SourcePage(items, if (items.isNotEmpty()) page + 1 else null)
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        val url = "$boardUrl/$remoteId"
        val doc = document(url)
        val title = doc.selectFirst("h1, h2, .document_title, .title")?.text()?.trim()
            ?.takeIf(String::isNotBlank) ?: doc.title()
        val roots = listOf(".xe_content", ".document_content", ".rd_body", ".read_body", "article", ".content", "#content")
            .flatMap { doc.select(it) }.distinct()
        val scope = roots.firstOrNull { it.select("img, a[href], video, source").isNotEmpty() } ?: doc.body()

        // Ggoorr uses several generations of lazy loaders. Collect the original URL from
        // attributes, srcset, image links and media source tags instead of only <img src>.
        val media = linkedSetOf<String>()
        scope.select("img").forEach { imageCandidates(it).forEach(media::add) }
        scope.select("a[href]").forEach { a ->
            absolute(a.attr("href"))?.takeIf(::looksLikeMedia)?.let(media::add)
        }
        scope.select("video[src], source[src]").forEach { e ->
            absolute(e.attr("src"))?.let(media::add)
        }
        doc.select("meta[property=og:image], meta[name=twitter:image]").forEach { e ->
            absolute(e.attr("content"))?.let(media::add)
        }
        val filtered = media.filterNot { u ->
            listOf("logo", "icon", "avatar", "emoji", "favicon").any { u.contains(it, true) }
        }
        return SourceDetail(SourceItem(id, remoteId, title, filtered.firstOrNull(), url), filtered)
    }

    private fun imageCandidates(img: Element): List<String> {
        val out = linkedSetOf<String>()
        listOf("data-original", "data-origin", "data-src", "data-lazy-src", "data-url", "src").forEach { key ->
            absolute(img.attr(key))?.let(out::add)
        }
        listOf("data-srcset", "srcset").forEach { key ->
            img.attr(key).split(',').map { it.trim().substringBefore(' ') }
                .forEach { absolute(it)?.let(out::add) }
        }
        return out.filterNot { it.startsWith("data:") || it.startsWith("blob:") }
    }

    private fun imageUrl(img: Element): String? = imageCandidates(img).firstOrNull()

    private fun absolute(raw0: String): String? {
        val raw = raw0.trim().replace("&amp;", "&")
        if (raw.isBlank() || raw.startsWith("data:") || raw.startsWith("javascript:")) return null
        return try {
            if (raw.startsWith("//")) "https:$raw" else URI(boardUrl).resolve(raw).toString()
        } catch (_: Exception) { null }
    }

    private fun looksLikeMedia(url: String): Boolean {
        val clean = url.substringBefore('?').lowercase()
        return listOf(".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif", ".mp4", ".webm").any(clean::endsWith)
    }

    private fun remoteIdFrom(url: String): String? {
        val path = try { URI(url).path ?: return null } catch (_: Exception) { return null }
        return Regex("/ao/(\\d+)(?:/|$)").find(path)?.groupValues?.get(1)
    }
}
