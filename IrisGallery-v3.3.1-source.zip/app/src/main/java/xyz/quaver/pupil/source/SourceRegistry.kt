package xyz.quaver.pupil.source

object SourceRegistry {
    val sources: List<ContentSource> = listOf(
        HitomiSource(),
        GgoorrSource(),
        ConfiguredSource("pinterest", "Pinterest"),
        ConfiguredSource("pixiv", "pixiv"),
        ConfiguredSource("x", "X"),
        ConfiguredSource("rule34", "Rule34", SourceMaturity.ADULT),
    )

    fun byId(id: String): ContentSource? = sources.firstOrNull { it.id == id }
    val ready: List<ContentSource> get() = sources.filter { it.availability == SourceAvailability.READY }
}
