/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.services.watchlistQuery
import xyz.quaver.pupil.ui.compose.LocalVolumePageTurn
import xyz.quaver.pupil.ui.compose.PupilApp
import xyz.quaver.pupil.ui.compose.PupilTheme
import xyz.quaver.pupil.ui.compose.VolumePageTurnDispatcher
import xyz.quaver.pupil.util.checkUpdate

/**
 * Compose entry point for the app.
 *
 * Hosts search and the navigation shell. Opening a gallery hands off to
 * [ReaderActivity], and the settings live in [SettingsActivity].
 *
 * A [BaseActivity] — itself an [androidx.appcompat.app.AppCompatActivity] —
 * rather than a plain ComponentActivity: the base class gates the screen behind
 * the app lock and applies `security_mode`, and the `dark_mode` preference is
 * applied through [androidx.appcompat.app.AppCompatDelegate], the only thing
 * that overrides the configuration `isSystemInDarkTheme()` reads.
 */
class MainComposeActivity : BaseActivity() {

    private val volumePageTurn = VolumePageTurnDispatcher()

    /**
     * The query a watchlist notification was tapped for, until the search has
     * it. Only picked up on a first start: a rotation is handed the same intent
     * again, and would otherwise search it over wherever the reader has got to.
     */
    private var watchedQuery by mutableStateOf<SearchQuery?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        if (savedInstanceState == null) watchedQuery = intent.watchlistQuery()

        setContent {
            PupilTheme {
                CompositionLocalProvider(LocalVolumePageTurn provides volumePageTurn) {
                    PupilApp(
                        initialQuery = watchedQuery,
                        onInitialQueryConsumed = { watchedQuery = null },
                        onGalleryClick = { galleryID ->
                            startActivity(
                                Intent(this, ReaderActivity::class.java)
                                    .putExtra("galleryID", galleryID)
                            )
                        },
                        onGalleryPageClick = { galleryID, page ->
                            startActivity(
                                Intent(this, ReaderActivity::class.java)
                                    .putExtra("galleryID", galleryID)
                                    .putExtra("page", page)
                            )
                        },
                        onSettingsClick = {
                            startActivity(Intent(this, SettingsActivity::class.java))
                        },
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        setIntent(intent)
        intent.watchlistQuery()?.let { watchedQuery = it }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (!volumePageTurnEnabled) return super.onKeyDown(keyCode, event)

        val delta = when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> -1
            KeyEvent.KEYCODE_VOLUME_DOWN -> 1
            else -> return super.onKeyDown(keyCode, event)
        }

        if (!volumePageTurn.turn(delta)) return super.onKeyDown(keyCode, event)

        showVolumePageTurnNotice(findViewById(android.R.id.content))

        return true
    }

    override fun onResume() {
        super.onResume()

        // Fork build: upstream Pupil self-update disabled.
    }
}
