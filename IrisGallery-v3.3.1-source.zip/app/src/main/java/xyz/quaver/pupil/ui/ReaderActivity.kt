/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import xyz.quaver.pupil.histories
import xyz.quaver.pupil.services.DownloadService
import xyz.quaver.pupil.ui.compose.LocalVolumePageTurn
import xyz.quaver.pupil.ui.compose.PupilTheme
import xyz.quaver.pupil.ui.compose.VolumePageTurnDispatcher
import xyz.quaver.pupil.ui.compose.reader.ReaderScreen
import xyz.quaver.pupil.ui.viewmodel.ReaderViewModel
import xyz.quaver.pupil.util.Crashlytics
import xyz.quaver.pupil.util.downloader.DownloadManager
import xyz.quaver.pupil.util.downloader.Downloads

class ReaderActivity : BaseActivity() {

    private val volumePageTurn = VolumePageTurnDispatcher()

    private val galleryID by lazy {
        if (intent.action == Intent.ACTION_VIEW)
            intent.data?.lastPathSegment?.toIntOrNull() ?: 0
        else
            intent.getIntExtra("galleryID", 0)
    }

    private var startPage = 0

    private val model: ReaderViewModel by viewModels {
        viewModelFactory { initializer { ReaderViewModel(application, galleryID, startPage) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        if (galleryID == 0) {
            finish()
            return
        }

        if (savedInstanceState == null) startPage = intent.getIntExtra("page", 0)

        Downloads.reading = galleryID
        Crashlytics.setCustomKey("GalleryID", galleryID)

        setContent {
            PupilTheme {
                CompositionLocalProvider(LocalVolumePageTurn provides volumePageTurn) {
                    ReaderScreen(model)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (galleryID == 0) return

        Downloads.priority = 0

        // Every resume, not just the first: coming back to this gallery from
        // another one is the read that history is meant to be ordered by.
        histories.add(galleryID)

        model.focusPage()?.let { Downloads.focus(galleryID, it) }

        // A gallery saved as an archive is commanded again even when this process
        // already counted it complete: its images live in the zip, and the service
        // is what unpacks them back into the cache this reads from. One this process
        // knows nothing about is commanded by the reader itself.
        if (model.cache.downloadArchive != null)
            DownloadService.download(this, galleryID, true)
    }

    override fun onPause() {
        super.onPause()

        if (galleryID == 0) return

        model.recordProgress()

        Downloads.priority = galleryID
    }

    override fun onDestroy() {
        super.onDestroy()

        if (galleryID == 0) return

        // Only the fill this reader commanded is cancelled: a gallery the reader
        // asked to keep is the user's, however far its download has got.
        if (isFinishing && !DownloadManager.getInstance(this).isSaved(galleryID))
            DownloadService.cancel(this, galleryID)

        if (Downloads.reading == galleryID) Downloads.reading = 0

        Downloads.unfocus(galleryID)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (!volumePageTurnEnabled) return super.onKeyDown(keyCode, event)

        val delta = when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> -1
            KeyEvent.KEYCODE_VOLUME_DOWN -> 1
            else -> return super.onKeyDown(keyCode, event)
        }

        if (!volumePageTurn.turn(delta)) return super.onKeyDown(keyCode, event)

        showVolumePageTurnNotice(findViewById(android.R.id.content))

        return true
    }
}
