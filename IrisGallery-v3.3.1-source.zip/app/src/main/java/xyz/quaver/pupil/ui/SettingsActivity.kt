/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import xyz.quaver.pupil.ui.compose.PupilTheme
import xyz.quaver.pupil.ui.compose.settings.SettingsApp
import xyz.quaver.pupil.util.checkUpdate

class SettingsActivity : BaseActivity() {

    companion object {
        const val EXTRA_HIGHLIGHT_PREFERENCE = "highlight_preference"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val highlight = intent.getStringExtra(EXTRA_HIGHLIGHT_PREFERENCE)

        setContent {
            PupilTheme {
                SettingsApp(
                    highlight = highlight,
                    onClose = ::finish,
                    onCheckUpdate = { /* Fork build: upstream updater disabled. */ },
                )
            }
        }
    }
}
