/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.view.updatePaddingRelative
import com.google.android.material.snackbar.Snackbar
import xyz.quaver.pupil.R
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.util.Preferences
import kotlin.math.roundToInt

const val VOLUME_PAGE_TURN = "volume_page_turn"

private const val VOLUME_PAGE_TURN_NOTICE = "volume_page_turn_notice"

val volumePageTurnEnabled: Boolean
    get() = settings.value.volumePageTurn

/**
 * Says what the volume keys just did, the first time they do it — in the reader
 * or in the gallery list, whichever the reader meets first — and offers the way
 * out of it.
 */
fun Activity.showVolumePageTurnNotice(anchor: View) {
    if (Preferences[VOLUME_PAGE_TURN_NOTICE, false]) return

    Preferences[VOLUME_PAGE_TURN_NOTICE] = true

    val notice = Snackbar
        .make(anchor, R.string.volume_page_turn_notice, Snackbar.LENGTH_INDEFINITE)
        .setAction(R.string.settings_title) {
            startActivity(
                Intent(this, SettingsActivity::class.java)
                    .putExtra(SettingsActivity.EXTRA_HIGHLIGHT_PREFERENCE, VOLUME_PAGE_TURN)
            )
        }

    notice.addDismissButton()

    notice.show()
}

/**
 * Snackbars have room for one action, and this one spends it on the way to the
 * setting. An indefinite notice still needs a way out, so the close button is
 * added to the layout the action sits in.
 */
private fun Snackbar.addDismissButton() {
    val layout = view as ViewGroup
    val context = layout.context
    val message = layout.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
    val size = (48 * context.resources.displayMetrics.density).roundToInt()

    val dismiss = ImageButton(context).apply {
        setImageResource(R.drawable.close)
        imageTintList = ColorStateList.valueOf(message.currentTextColor)
        background = null
        contentDescription = context.getString(R.string.close)
        setOnClickListener { this@addDismissButton.dismiss() }
    }

    layout.addView(
        dismiss,
        FrameLayout.LayoutParams(size, size, Gravity.END or Gravity.CENTER_VERTICAL),
    )

    // The content fills the whole bar, so the message and the action would run
    // under the button without this.
    layout.getChildAt(0).updatePaddingRelative(end = size)
}
