/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import xyz.quaver.pupil.R

/**
 * Top level destinations, mirroring the View-based navigation drawer.
 */
enum class Destination(
    val route: String,
    @StringRes val labelRes: Int,
    @DrawableRes val iconRes: Int,
) {
    Home("home", R.string.main_drawer_home, R.drawable.ic_home),
    History("history", R.string.main_drawer_history, R.drawable.history),
    Downloads("downloads", R.string.main_drawer_downloads, R.drawable.ic_download),
    Favorites("favorites", R.string.main_drawer_favorite, R.drawable.ic_star_filled),
    Settings("settings", R.string.settings_title, R.drawable.ic_settings),
}
