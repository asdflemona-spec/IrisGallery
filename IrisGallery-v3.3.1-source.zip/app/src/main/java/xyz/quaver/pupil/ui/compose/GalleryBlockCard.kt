/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.BookmarkRemove
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HistoryToggleOff
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.SubcomposeLayout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.R
import xyz.quaver.pupil.favoriteTags
import xyz.quaver.pupil.favorites
import xyz.quaver.pupil.hitomi.GalleryBlock
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.getGalleryInfo
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.histories
import xyz.quaver.pupil.listStyle
import xyz.quaver.pupil.readLater
import xyz.quaver.pupil.readProgress
import xyz.quaver.pupil.services.DownloadService
import xyz.quaver.pupil.types.Tag
import xyz.quaver.pupil.util.ListStyle
import xyz.quaver.pupil.util.ReadProgress
import xyz.quaver.pupil.util.copyToClipboard
import xyz.quaver.pupil.util.translations
import xyz.quaver.pupil.util.wordCapitalize

/** Master caps the chip group and hides the rest behind a "..." chip. */
private const val MAX_CHIPS = 10

private val ReadProgressColor = Color(0xFFE53935)

/** Language code -> display name, straight from the `languages` string-array. */
@Composable
internal fun rememberLanguageNames(): Map<String, String> {
    val options = rememberLanguageOptions()

    return remember(options) { options.toMap() }
}

/**
 * A 150dp thumbnail stretched to the height of the detail column, then a divider
 * and a footer holding the gallery ID, page count and favourite toggle.
 *
 * The overflow button beside the title opens [GalleryBlockMenu], which holds
 * everything the card offers to do with the gallery.
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun GalleryBlockCard(
    galleryBlock: GalleryBlock,
    onClick: () -> Unit,
    onShowDetail: () -> Unit,
    onTagClick: (SearchQuery.Tag) -> Unit,
) {
    val languageNames = rememberLanguageNames()

    val isFavorite = favorites.contains(galleryBlock.id)

    val download = rememberGalleryDownload(galleryBlock.id)

    val progress = readProgress[galleryBlock.id]

    var menuExpanded by remember(galleryBlock.id) { mutableStateOf(false) }

    // Not part of GalleryBlock, so master shows "-" until the info request lands.
    val pageCount by produceState<Int?>(null, galleryBlock.id) {
        value = withContext(Dispatchers.IO) {
            runCatching { hitomiClient.getGalleryInfo(galleryBlock.id).files.size }.getOrNull()
        }
    }

    SwipeRevealBox(
        key = galleryBlock.id,
        shape = RoundedCornerShape(4.dp),
        actions = { close ->
            GallerySwipeActions(
                galleryBlock = galleryBlock,
                download = download,
                onActionClick = close,
            )
        },
    ) {
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = onClick, onLongClick = onShowDetail),
            shape = RoundedCornerShape(4.dp),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = colorResource(R.color.gallery_card),
            ),
        ) {
            Row(Modifier.readProgressBar(progress, MaterialTheme.colorScheme.outlineVariant)) {
                // Keeps its own aspect ratio and sits centred beside the details,
                // the way adjustViewBounds leaves it in the ConstraintLayout.
                RemoteImage(
                    url = galleryBlock.thumbnails.firstOrNull(),
                    modifier = Modifier
                        .align(Alignment.CenterVertically)
                        .width(150.dp)
                        .heightIn(min = 200.dp),
                    contentScale = ContentScale.Fit,
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp, end = 8.dp, top = 8.dp),
                ) {
                    TextWrappingTrailing(
                        text = galleryBlock.title,
                        style = MaterialTheme.typography.headlineSmall,
                    ) {
                        Box {
                            IconButton(onClick = { menuExpanded = true }) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = stringResource(R.string.galleryblock_menu),
                                )
                            }

                            GalleryBlockMenu(
                                galleryBlock = galleryBlock,
                                download = download,
                                expanded = menuExpanded,
                                onDismissRequest = { menuExpanded = false },
                                onShowDetail = onShowDetail,
                                onTagClick = onTagClick,
                            )
                        }
                    }

                    if (galleryBlock.artists.isNotEmpty()) {
                        val artists = galleryBlock.artists.joinToString { it.wordCapitalize() }

                        Text(
                            text = if (galleryBlock.groups.isEmpty())
                                artists
                            else
                                stringResource(
                                    R.string.galleryblock_artist_with_group,
                                    artists,
                                    galleryBlock.groups.joinToString { it.wordCapitalize() },
                                ),
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }

                    if (galleryBlock.series.isNotEmpty()) {
                        Text(
                            stringResource(
                                R.string.galleryblock_series,
                                galleryBlock.series.joinToString { it.wordCapitalize() },
                            )
                        )
                    }

                    Text(
                        stringResource(R.string.galleryblock_type, galleryBlock.type).wordCapitalize()
                    )

                    if (galleryBlock.language.isNotEmpty()) {
                        Text(
                            stringResource(
                                R.string.galleryblock_language,
                                languageNames[galleryBlock.language] ?: galleryBlock.language,
                            )
                        )
                    }

                    if (listStyle.style == ListStyle.THIN || galleryBlock.relatedTags.isEmpty()) {
                        Spacer(Modifier.height(8.dp))
                    } else {
                        // Favourites first, then female / male / everything else.
                        val tags = remember(galleryBlock.id) {
                            galleryBlock.relatedTags
                                .map { Tag.parseNamespaced(it) }
                                .sortedBy { tag ->
                                    when {
                                        favoriteTags.contains(tag) -> -1
                                        tag.area == "female" -> 0
                                        tag.area == "male" -> 1
                                        else -> 2
                                    }
                                }
                        }

                        var expanded by remember(galleryBlock.id) { mutableStateOf(false) }

                        FlowRow(
                            modifier = Modifier.padding(vertical = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            val shown = if (expanded) tags else tags.take(MAX_CHIPS)

                            shown.forEach { tag ->
                                FavoritableTagChip(
                                    tag = tag.toString(),
                                    onClick = { onTagClick(SearchQuery.Tag(tag.area, tag.tag)) },
                                    content = { _, label ->
                                        Text((translations[label] ?: label).wordCapitalize())
                                    },
                                )
                            }

                            if (shown.size != tags.size)
                                TagChip(tag = "\u2026", onClick = { expanded = true })
                        }
                    }
                }
            }

            HorizontalDivider(Modifier.padding(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.align(Alignment.CenterStart)) {
                    var idMenuExpanded by remember(galleryBlock.id) { mutableStateOf(false) }

                    Text(
                        text = galleryBlock.id.toString(),
                        modifier = Modifier.combinedClickable(
                            onClick = onClick,
                            onLongClick = { idMenuExpanded = true },
                        ),
                    )

                    GalleryIdMenu(
                        galleryID = galleryBlock.id,
                        expanded = idMenuExpanded,
                        onDismissRequest = { idMenuExpanded = false },
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    when (download) {
                        GalleryDownload.Saved -> Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = stringResource(R.string.gallery_saved),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp),
                        )

                        // The text beside it spells the state out, so the icon adds
                        // nothing for a screen reader.
                        GalleryDownload.Missing -> Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp),
                        )

                        else -> Unit
                    }

                    Text(
                        text = when (download) {
                            is GalleryDownload.Running -> stringResource(
                                R.string.galleryblock_pagecount_progress,
                                download.completed,
                                download.total,
                            )

                            GalleryDownload.Missing ->
                                stringResource(R.string.gallery_download_missing)

                            else -> pageCount
                                ?.let { stringResource(R.string.galleryblock_pagecount, it) }
                                ?: "-"
                        },
                        color = when (download) {
                            is GalleryDownload.Running -> MaterialTheme.colorScheme.primary
                            GalleryDownload.Missing -> MaterialTheme.colorScheme.error
                            else -> Color.Unspecified
                        },
                    )
                }

                // The star drawables carry the colour themselves, which Icon's tint
                // would flatten to the content colour.
                Icon(
                    painter = painterResource(
                        if (isFavorite) R.drawable.ic_star_filled else R.drawable.ic_star_empty
                    ),
                    contentDescription = null,
                    tint = TagColors.Favorite,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(32.dp)
                        .clickable { favorites.toggle(galleryBlock.id) },
                )
            }

            DownloadProgressBar(download)
        }
    }
}

/**
 * What a swipe pulls out from behind the card: the download's next step, and
 * dropping the gallery from the history once it has been read. A saved gallery
 * that is also in the history gets a third action beneath the two, dropping both.
 */
@Composable
private fun GallerySwipeActions(
    galleryBlock: GalleryBlock,
    download: GalleryDownload,
    onActionClick: () -> Unit,
) {
    val context = LocalContext.current

    val save = rememberSaveAction(galleryBlock.id)

    val inHistory = histories.contains(galleryBlock.id)

    var confirmRemove by remember(galleryBlock.id) { mutableStateOf(false) }
    var confirmRemoveBoth by remember(galleryBlock.id) { mutableStateOf(false) }

    val removeHistoryAction = @Composable {
        SwipeAction(
            text = stringResource(R.string.gallery_remove_history),
            icon = rememberVectorPainter(Icons.Default.HistoryToggleOff),
            color = MaterialTheme.colorScheme.error,
            onClick = {
                onActionClick()
                removeFromHistory(galleryBlock.id)
            },
        )
    }

    when (download) {
        GalleryDownload.None -> SwipeAction(
            text = stringResource(R.string.gallery_download),
            icon = painterResource(R.drawable.ic_download),
            color = MaterialTheme.colorScheme.primary,
            onClick = {
                onActionClick()
                save()
            },
        )

        is GalleryDownload.Running -> SwipeAction(
            text = stringResource(R.string.gallery_cancel_download),
            icon = painterResource(R.drawable.cancel),
            color = MaterialTheme.colorScheme.primary,
            onClick = {
                onActionClick()
                DownloadService.unsave(context, galleryBlock.id)
            },
        )

        GalleryDownload.Saved -> Column(Modifier.fillMaxHeight()) {
            Row(Modifier.weight(1f)) {
                SwipeAction(
                    text = stringResource(R.string.gallery_remove_download),
                    icon = painterResource(R.drawable.delete),
                    color = MaterialTheme.colorScheme.primary,
                    onClick = {
                        onActionClick()
                        confirmRemove = true
                    },
                )

                if (inHistory) removeHistoryAction()
            }

            if (inHistory)
                SwipeAction(
                    text = stringResource(R.string.gallery_remove_both),
                    icon = painterResource(R.drawable.delete),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier
                        .weight(1f)
                        .width(176.dp),
                    onClick = {
                        onActionClick()
                        confirmRemoveBoth = true
                    },
                )
        }

        GalleryDownload.Missing -> SwipeAction(
            text = stringResource(R.string.gallery_download_again),
            icon = painterResource(R.drawable.ic_download),
            color = MaterialTheme.colorScheme.primary,
            onClick = {
                onActionClick()
                save()
            },
        )
    }

    if (inHistory && download != GalleryDownload.Saved) removeHistoryAction()

    if (confirmRemove)
        RemoveDownloadDialog(
            galleryID = galleryBlock.id,
            title = galleryBlock.title,
            onDismiss = { confirmRemove = false },
        )

    if (confirmRemoveBoth)
        RemoveDownloadDialog(
            galleryID = galleryBlock.id,
            title = galleryBlock.title,
            onDismiss = { confirmRemoveBoth = false },
            removeHistory = true,
        )
}

@Composable
private fun SwipeAction(
    text: String,
    icon: Painter,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(88.dp)
            .background(color)
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
    ) {
        val contentColor = contentColorFor(color)

        Icon(painter = icon, contentDescription = null, tint = contentColor)

        Text(
            text = text,
            color = contentColor,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * What the gallery ID in the footer offers on a long press: the ID itself, or
 * the pupil-app.com link that opens the gallery on a device with Pupil.
 */
@Composable
private fun GalleryIdMenu(galleryID: Int, expanded: Boolean, onDismissRequest: () -> Unit) {
    val context = LocalContext.current

    DropdownMenu(expanded = expanded, onDismissRequest = onDismissRequest) {
        MenuItem(
            text = stringResource(R.string.gallery_copy_id),
            icon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
            onClick = {
                onDismissRequest()
                context.copyToClipboard("gallery id", galleryID.toString())
            },
        )

        MenuItem(
            text = stringResource(R.string.gallery_copy_link),
            icon = { Icon(Icons.Default.Link, contentDescription = null) },
            onClick = {
                onDismissRequest()
                context.copyToClipboard("gallery link", "https://pupil-app.com/redirect/$galleryID")
            },
        )
    }
}

/** The share of the gallery's pages that have landed, across the foot of the card. */
@Composable
internal fun DownloadProgressBar(download: GalleryDownload) {
    if (download !is GalleryDownload.Running || download.total <= 0) return

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(3.dp)
            .background(MaterialTheme.colorScheme.outlineVariant)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(download.completed / download.total.toFloat())
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.primary)
        )
    }
}

internal fun Modifier.readProgressBar(progress: ReadProgress?, trackColor: Color) =
    drawWithContent {
        drawContent()

        if (progress == null)
            return@drawWithContent

        val height = 3.dp.toPx()
        val width = size.width * progress.fraction

        drawRect(trackColor, size = Size(size.width, height))
        drawRect(
            ReadProgressColor,
            topLeft = Offset(if (layoutDirection == LayoutDirection.Rtl) size.width - width else 0f, 0f),
            size = Size(width, height),
        )
    }

/**
 * What the card offers to do with its gallery: open its detail page, put it
 * aside to read later, save it or give it back, drop it from the history once
 * it has been read, and search for whoever it is credited to.
 */
@Composable
internal fun GalleryBlockMenu(
    galleryBlock: GalleryBlock,
    download: GalleryDownload,
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    onShowDetail: () -> Unit,
    onTagClick: (SearchQuery.Tag) -> Unit,
) {
    val context = LocalContext.current

    val save = rememberSaveAction(galleryBlock.id)

    val isReadLater = readLater.contains(galleryBlock.id)

    var confirmRemove by remember(galleryBlock.id) { mutableStateOf(false) }

    DropdownMenu(expanded = expanded, onDismissRequest = onDismissRequest) {
        MenuItem(
            text = stringResource(R.string.gallery_details),
            icon = { Icon(Icons.Default.Info, contentDescription = null) },
            onClick = {
                onDismissRequest()
                onShowDetail()
            },
        )

        MenuItem(
            text = stringResource(
                if (isReadLater) R.string.gallery_unmark_read_later
                else R.string.gallery_read_later
            ),
            icon = {
                Icon(
                    imageVector = if (isReadLater) Icons.Default.BookmarkRemove
                    else Icons.Default.BookmarkAdd,
                    contentDescription = null,
                )
            },
            onClick = {
                onDismissRequest()
                readLater.toggle(galleryBlock.id)
            },
        )

        when (download) {
            GalleryDownload.None -> MenuItem(
                text = stringResource(R.string.gallery_download),
                icon = { Icon(painterResource(R.drawable.ic_download), contentDescription = null) },
                onClick = {
                    onDismissRequest()
                    save()
                },
            )

            // Nothing is finished to lose yet, so this goes without asking, the
            // same as the detail page's running button.
            is GalleryDownload.Running -> MenuItem(
                text = stringResource(R.string.gallery_cancel_download),
                icon = { Icon(painterResource(R.drawable.cancel), contentDescription = null) },
                onClick = {
                    onDismissRequest()
                    DownloadService.unsave(context, galleryBlock.id)
                },
            )

            GalleryDownload.Saved -> MenuItem(
                text = stringResource(R.string.gallery_remove_download),
                icon = { Icon(painterResource(R.drawable.delete), contentDescription = null) },
                onClick = {
                    onDismissRequest()
                    confirmRemove = true
                },
            )

            GalleryDownload.Missing -> {
                MenuItem(
                    text = stringResource(R.string.gallery_download_again),
                    icon = {
                        Icon(painterResource(R.drawable.ic_download), contentDescription = null)
                    },
                    onClick = {
                        onDismissRequest()
                        save()
                    },
                )

                // Nothing is left on the device to lose, so this goes without asking.
                MenuItem(
                    text = stringResource(R.string.gallery_remove_download),
                    icon = { Icon(painterResource(R.drawable.delete), contentDescription = null) },
                    onClick = {
                        onDismissRequest()
                        DownloadService.unsave(context, galleryBlock.id)
                    },
                )
            }
        }

        if (histories.contains(galleryBlock.id))
            MenuItem(
                text = stringResource(R.string.gallery_remove_history),
                icon = {
                    Icon(Icons.Default.HistoryToggleOff, contentDescription = null)
                },
                onClick = {
                    onDismissRequest()
                    removeFromHistory(galleryBlock.id)
                },
            )

        if (galleryBlock.artists.isNotEmpty() || galleryBlock.groups.isNotEmpty())
            HorizontalDivider()

        galleryBlock.artists.forEach { artist ->
            MenuItem(
                text = stringResource(R.string.galleryblock_menu_artist, artist.wordCapitalize()),
                icon = {
                    Icon(painterResource(R.drawable.account_star), contentDescription = null)
                },
                onClick = {
                    onDismissRequest()
                    onTagClick(SearchQuery.Tag("artist", artist))
                },
            )
        }

        galleryBlock.groups.forEach { group ->
            MenuItem(
                text = stringResource(R.string.galleryblock_menu_group, group.wordCapitalize()),
                icon = {
                    Icon(painterResource(R.drawable.account_group), contentDescription = null)
                },
                onClick = {
                    onDismissRequest()
                    onTagClick(SearchQuery.Tag("group", group))
                },
            )
        }
    }

    if (confirmRemove)
        RemoveDownloadDialog(
            galleryID = galleryBlock.id,
            title = galleryBlock.title,
            onDismiss = { confirmRemove = false },
        )
}

@Composable
private fun MenuItem(text: String, icon: @Composable () -> Unit, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        onClick = onClick,
        leadingIcon = icon,
    )
}

/**
 * [text] beside [trailing] for as many lines as sit level with it, then the rest
 * across the full width underneath, the way text floats around an inline box.
 */
@Composable
private fun TextWrappingTrailing(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    trailing: @Composable () -> Unit,
) {
    val textMeasurer = rememberTextMeasurer()
    val mergedStyle = LocalTextStyle.current.merge(style)

    SubcomposeLayout(modifier) { constraints ->
        val looseConstraints = constraints.copy(minWidth = 0, minHeight = 0)

        val trailingPlaceable = subcompose("trailing", trailing).single().measure(looseConstraints)

        val besideWidth = (constraints.maxWidth - trailingPlaceable.width).coerceAtLeast(0)
        val besideLayout = textMeasurer.measure(
            text = text,
            style = mergedStyle,
            constraints = Constraints(maxWidth = besideWidth),
        )
        val besideLineCount = (0 until besideLayout.lineCount)
            .count { besideLayout.getLineTop(it) < trailingPlaceable.height }
            .coerceAtLeast(1)
        val splitAt = besideLayout.getLineEnd(besideLineCount - 1)

        val besidePlaceable = subcompose("beside") {
            Text(text.substring(0, splitAt).trimEnd(), style = style)
        }.single().measure(Constraints(maxWidth = besideWidth))

        val below = text.substring(splitAt).trimStart()
        val belowPlaceable = if (below.isEmpty()) null else subcompose("below") {
            Text(below, style = style)
        }.single().measure(looseConstraints)

        val height = maxOf(besidePlaceable.height, trailingPlaceable.height) +
            (belowPlaceable?.height ?: 0)

        layout(constraints.maxWidth, height) {
            besidePlaceable.placeRelative(0, 0)
            trailingPlaceable.placeRelative(constraints.maxWidth - trailingPlaceable.width, 0)
            belowPlaceable?.placeRelative(0, besidePlaceable.height)
        }
    }
}
