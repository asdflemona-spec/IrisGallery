/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.R
import xyz.quaver.pupil.favoriteTags
import xyz.quaver.pupil.hitomi.Gallery
import xyz.quaver.pupil.hitomi.GalleryBlock
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.getGallery
import xyz.quaver.pupil.hitomi.getGalleryBlock
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.services.DownloadService
import xyz.quaver.pupil.types.Tag
import xyz.quaver.pupil.util.wordCapitalize

/**
 * Full-screen port of the View `GalleryDialog`: the cover, the gallery's tags as
 * chips that search for themselves, the thumbnail pager and the related
 * galleries, over a button into the reader.
 *
 * Drawn as an overlay rather than a [androidx.compose.ui.window.Dialog] because a
 * dialog window is measured against the area between the system bars, which would
 * leave the page ending in a band of whatever is behind it.
 */
@Composable
fun GalleryDetailPage(
    galleryID: Int,
    onDismiss: () -> Unit,
    onOpen: (Int) -> Unit,
    onOpenPage: (Int) -> Unit,
    onTagClick: (SearchQuery.Tag) -> Unit,
    onShowRelatedDetail: (Int) -> Unit,
) {
    BackHandler(onBack = onDismiss)

    // Nothing to page through here, and the list underneath is not the reader's
    // to turn while it is covered.
    VolumePageTurnHandler(null)

    val gallery by produceState<Result<Gallery>?>(null, galleryID) {
        value = withContext(Dispatchers.IO) {
            runCatching { hitomiClient.getGallery(galleryID) }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            // Keeps gestures that miss the page's own controls off the screen
            // underneath it.
            .pointerInput(Unit) { },
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.windowInsetsPadding(
                    WindowInsets.safeDrawing
                        .only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
                ),
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.close),
                )
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            when (val result = gallery) {
                null -> CircularProgressIndicator(Modifier.align(Alignment.Center))

                else -> result.fold(
                    onSuccess = { galleryDetail ->
                        GalleryDetail(
                            galleryID = galleryID,
                            gallery = galleryDetail,
                            onOpen = onOpen,
                            onOpenPage = onOpenPage,
                            onTagClick = onTagClick,
                            onShowRelatedDetail = onShowRelatedDetail,
                        )
                    },
                    onFailure = {
                        ErrorMessage(
                            modifier = Modifier.align(Alignment.Center),
                            kaomoji = "(×_×)⌒☆",
                        ) { Text(stringResource(R.string.unable_to_connect)) }
                    },
                )
            }
        }
    }
}

@Composable
private fun GalleryDetail(
    galleryID: Int,
    gallery: Gallery,
    onOpen: (Int) -> Unit,
    onOpenPage: (Int) -> Unit,
    onTagClick: (SearchQuery.Tag) -> Unit,
    onShowRelatedDetail: (Int) -> Unit,
) {
    val related by produceState(emptyList<GalleryBlock>(), gallery.related) {
        value = withContext(Dispatchers.IO) {
            coroutineScope {
                gallery.related
                    .map { async { runCatching { hitomiClient.getGalleryBlock(it) }.getOrNull() } }
                    .awaitAll()
                    .filterNotNull()
            }
        }
    }

    // Sorted once per gallery rather than on every recomposition: unfavouriting
    // a tag leaves it where it is instead of moving it out from under the tap.
    val contentTags = remember(gallery) { gallery.contentTags() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { Header(gallery) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onOpen(galleryID) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        text = stringResource(R.string.gallery_open),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                DownloadButton(
                    galleryID = galleryID,
                    title = gallery.title,
                    modifier = Modifier.weight(1f),
                )
            }
        }

        item { GalleryTypeIndicator(gallery.type, onTagClick) }

        item { TagGroup(gallery.creditTags(), onTagClick) }

        if (contentTags.isNotEmpty()) item { TagGroup(contentTags, onTagClick) }

        if (gallery.thumbnails.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.gallery_thumbnails)) }
            item { ThumbnailPager(gallery.thumbnails, onOpenPage) }
        }

        if (gallery.related.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.gallery_related)) }

            if (related.isEmpty()) item { CircularProgressIndicator() }

            items(related, key = { it.id }) { block ->
                GalleryBlockCard(
                    galleryBlock = block,
                    onClick = { onOpen(block.id) },
                    onShowDetail = { onShowRelatedDetail(block.id) },
                    onTagClick = onTagClick,
                )
            }
        }
    }
}

/**
 * Saves the gallery, shows how far that has got, and gives it back.
 *
 * While it runs the button is its own progress bar -- the fill is the container of
 * a filled tonal button, drawn to the fraction that has landed -- rather than a
 * separate indicator under one.
 */
@Composable
private fun DownloadButton(galleryID: Int, title: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current

    val download = rememberGalleryDownload(galleryID)
    val save = rememberSaveAction(galleryID)

    var confirmRemove by remember { mutableStateOf(false) }

    // The service registers the download folder before it fetches anything, and
    // that can take a request of its own, so the button waits rather than looking
    // like the tap missed.
    var starting by remember(galleryID) { mutableStateOf(false) }

    LaunchedEffect(download) {
        if (download !is GalleryDownload.None) starting = false
    }

    when (download) {
        GalleryDownload.None -> FilledTonalButton(
            onClick = {
                starting = true
                save()
            },
            modifier = modifier,
            enabled = !starting,
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_download),
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.gallery_download), maxLines = 1)
        }

        is GalleryDownload.Running -> FilledTonalButton(
            onClick = { DownloadService.unsave(context, galleryID) },
            modifier = modifier,
            contentPadding = PaddingValues(0.dp),
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .fillMaxHeight()
                        .fillMaxWidth(
                            if (download.total > 0)
                                download.completed / download.total.toFloat()
                            else
                                0f
                        )
                        .background(MaterialTheme.colorScheme.primaryContainer)
                )

                Text(
                    text = stringResource(
                        R.string.gallery_download_progress,
                        download.completed,
                        download.total,
                    ),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    maxLines = 1,
                )
            }
        }

        GalleryDownload.Saved -> OutlinedButton(
            onClick = { confirmRemove = true },
            modifier = modifier,
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.gallery_saved), maxLines = 1)
        }

        GalleryDownload.Missing -> OutlinedButton(
            onClick = {
                starting = true
                save()
            },
            modifier = modifier,
            enabled = !starting,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.error,
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = stringResource(R.string.gallery_download_missing),
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.gallery_download_again), maxLines = 1)
        }
    }

    if (confirmRemove)
        RemoveDownloadDialog(
            galleryID = galleryID,
            title = title,
            onDismiss = { confirmRemove = false },
        )
}

/**
 * A landscape cover takes the full width and the title sits under it; a portrait
 * one stands beside the title, the way the reference implementation had it.
 */
@Composable
private fun Header(gallery: Gallery) {
    val cover = @Composable { modifier: Modifier ->
        RemoteImage(
            url = gallery.cover,
            modifier = modifier.clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Fit,
        )
    }

    if (gallery.coverAspectRatio > 1f)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            cover(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(gallery.coverAspectRatio)
            )
            Title(gallery)
        }
    else
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            cover(
                Modifier
                    .height(200.dp)
                    .aspectRatio(gallery.coverAspectRatio)
            )
            Column(Modifier.heightIn(min = 200.dp)) { Title(gallery) }
        }
}

@Composable
private fun Title(gallery: Gallery) {
    val flag = languageIcon(gallery.language)

    if (flag == null)
        Text(gallery.title, style = MaterialTheme.typography.headlineSmall)
    else
        Text(
            text = buildAnnotatedString {
                appendInlineContent("language", "<language>")
                append(' ')
                append(gallery.title)
            },
            style = MaterialTheme.typography.headlineSmall,
            inlineContent = mapOf(
                "language" to InlineTextContent(
                    Placeholder(
                        width = 20.sp,
                        height = 20.sp,
                        placeholderVerticalAlign = PlaceholderVerticalAlign.Center,
                    )
                ) {
                    Icon(
                        painterResource(flag),
                        contentDescription = null,
                        tint = Color.Unspecified,
                    )
                },
            ),
        )

    val credits = buildString {
        if (gallery.artists.isNotEmpty()) append(gallery.artists.joinToString { it.wordCapitalize() })

        if (gallery.groups.isNotEmpty()) {
            if (isNotEmpty()) append(' ')
            append('(')
            append(gallery.groups.joinToString { it.wordCapitalize() })
            append(')')
        }
    }

    if (credits.isNotEmpty()) Text(credits, style = MaterialTheme.typography.labelLarge)
}

private val galleryTypeStrings = mapOf(
    "doujinshi" to R.string.doujinshi,
    "manga" to R.string.manga,
    "artistcg" to R.string.artist_cg,
    "gamecg" to R.string.game_cg,
    "imageset" to R.string.image_set,
)

private val galleryTypeColors = mapOf(
    "doujinshi" to Color(0xFFEF4444),
    "manga" to Color(0xFFF59E0B),
    "artistcg" to Color(0xFF8B5CF6),
    "gamecg" to Color(0xFF10B981),
    "imageset" to Color(0xFF3B82F6),
)

@Composable
private fun GalleryTypeIndicator(type: String, onTagClick: (SearchQuery.Tag) -> Unit) {
    // Hitomi searches these two by a name that is not the one it displays.
    val searchName = when (type) {
        "artist CG" -> "artistcg"
        "game CG" -> "gamecg"
        else -> type
    }

    Surface(
        onClick = { onTagClick(SearchQuery.Tag("type", searchName)) },
        modifier = Modifier.height(32.dp),
        shape = RoundedCornerShape(16.dp),
        color = galleryTypeColors[searchName] ?: MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Box(Modifier.fillMaxHeight()) {
            Text(
                text = galleryTypeStrings[searchName]?.let { stringResource(it) }
                    ?: type.wordCapitalize(),
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .align(Alignment.Center),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
            )
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TagGroup(tags: List<Tag>, onTagClick: (SearchQuery.Tag) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        tags.forEach { tag ->
            FavoritableTagChip(
                tag = tag.toString(),
                onClick = { onTagClick(SearchQuery.Tag(tag.area, tag.tag)) },
            )
        }
    }
}

/** Who made it and where it came from: everything but the content tags. */
private fun Gallery.creditTags(): List<Tag> = buildList {
    artists.forEach { add(Tag("artist", it)) }
    groups.forEach { add(Tag("group", it)) }
    series.forEach { add(Tag("series", it)) }
    characters.forEach { add(Tag("character", it)) }
    if (language.isNotEmpty()) add(Tag("language", language))
}

/** Favourites first, then female / male / everything else. */
private fun Gallery.contentTags(): List<Tag> = tags
    .map { Tag.parseNamespaced(it) }
    .sortedBy { tag ->
        when {
            favoriteTags.contains(tag) -> -1
            tag.area == "female" -> 0
            tag.area == "male" -> 1
            else -> 2
        }
    }

private const val THUMBNAIL_COLUMNS = 3
private const val THUMBNAILS_PER_PAGE = THUMBNAIL_COLUMNS * 3
private const val THUMBNAIL_ASPECT_RATIO = 0.7f
private val thumbnailSpacing = 8.dp

@Composable
private fun ThumbnailPager(thumbnails: List<String>, onThumbnailClick: (page: Int) -> Unit) {
    val pages = remember(thumbnails) { thumbnails.chunked(THUMBNAILS_PER_PAGE) }
    val pagerState = rememberPagerState { pages.size }

    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val cellWidth =
                (maxWidth - thumbnailSpacing * (THUMBNAIL_COLUMNS - 1)) / THUMBNAIL_COLUMNS
            val rowHeight = cellWidth / THUMBNAIL_ASPECT_RATIO

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.height(rowHeight * 3 + thumbnailSpacing * 2),
                pageSpacing = thumbnailSpacing,
            ) { page ->
                ThumbnailGrid(pages[page], rowHeight) { index ->
                    onThumbnailClick(page * THUMBNAILS_PER_PAGE + index + 1)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(pages.size) { page ->
                val selected = page == pagerState.currentPage

                Box(
                    Modifier
                        .size(if (selected) 8.dp else 6.dp)
                        .clip(CircleShape)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }
    }
}

@Composable
private fun ThumbnailGrid(
    thumbnails: List<String>,
    rowHeight: Dp,
    onThumbnailClick: (index: Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(thumbnailSpacing)) {
        thumbnails.chunked(THUMBNAIL_COLUMNS).forEachIndexed { rowIndex, row ->
            Row(
                modifier = Modifier.height(rowHeight),
                horizontalArrangement = Arrangement.spacedBy(thumbnailSpacing),
            ) {
                row.forEachIndexed { columnIndex, thumbnail ->
                    RemoteImage(
                        url = thumbnail,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .clickable { onThumbnailClick(rowIndex * THUMBNAIL_COLUMNS + columnIndex) },
                        contentScale = ContentScale.Fit,
                    )
                }

                repeat(THUMBNAIL_COLUMNS - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/** Hitomi searches these two by a name that is not the one it displays. */
private fun Gallery.typeTag() = Tag(
    "type",
    when (type) {
        "artist CG" -> "artistcg"
        "game CG" -> "gamecg"
        else -> type
    },
)

/** The label -> chips rows of the details section, in the View dialog's order. */
private fun Gallery.detailRows(): List<Pair<Int, List<Tag>>> = listOf(
    R.string.gallery_artists to artists.map { Tag("artist", it) },
    R.string.gallery_groups to groups.map { Tag("group", it) },
    R.string.gallery_language to listOfNotNull(language.takeIf { it.isNotEmpty() })
        .map { Tag("language", it) },
    R.string.gallery_series to series.map { Tag("series", it) },
    R.string.gallery_characters to characters.map { Tag("character", it) },
    R.string.gallery_tags to tags
        .map { Tag.parseNamespaced(it) }
        .sortedBy { tag ->
            when {
                favoriteTags.contains(tag) -> -1
                tag.area == "female" -> 0
                tag.area == "male" -> 1
                else -> 2
            }
        },
).filter { (_, tags) -> tags.isNotEmpty() }
