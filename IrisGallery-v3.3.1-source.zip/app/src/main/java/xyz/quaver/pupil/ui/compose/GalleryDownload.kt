/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.R
import xyz.quaver.pupil.services.DownloadService
import xyz.quaver.pupil.util.downloader.Cache
import xyz.quaver.pupil.util.downloader.DownloadManager
import xyz.quaver.pupil.util.downloader.DownloadState
import xyz.quaver.pupil.util.downloader.Downloads
import xyz.quaver.pupil.util.requestNotificationPermission

/** A gallery's download, as the list and the detail page show it. */
sealed interface GalleryDownload {

    /** Not saved. A cache fill the reader started is not the list's business. */
    data object None : GalleryDownload

    data class Running(val completed: Int, val total: Int) : GalleryDownload

    data object Saved : GalleryDownload

    /** Saved, but nothing of it is left on the device. */
    data object Missing : GalleryDownload
}

/**
 * Follows [galleryID]'s download.
 *
 * [Downloads] knows nothing about a download this process didn't run, so what is
 * on disk answers for one that ended with an earlier process: it reads as the
 * count it reached rather than as finished, and as [GalleryDownload.Missing] once
 * a folder deleted from outside the app has taken the metadata naming its images
 * with it.
 */
@Composable
fun rememberGalleryDownload(galleryID: Int): GalleryDownload {
    val context = LocalContext.current.applicationContext

    val isDownload = DownloadManager.getInstance(context).downloadFolderMap.containsKey(galleryID)

    // Only a download has anything to read back, and touching the cache of every
    // gallery scrolled past would create a folder for each of them.
    val onDisk by produceState<GalleryDownload?>(null, galleryID, isDownload) {
        if (!isDownload) return@produceState

        value = withContext(Dispatchers.IO) {
            val images = Cache.getInstance(context, galleryID).metadata.imageList.orEmpty()

            val completed = images.count { it != null }

            when {
                completed == 0 -> GalleryDownload.Missing
                completed < images.size -> GalleryDownload.Running(completed, images.size)
                else -> GalleryDownload.Saved
            }
        }
    }

    if (!isDownload) return GalleryDownload.None

    val state = Downloads.state(galleryID)

    return when {
        state is DownloadState.Downloading -> GalleryDownload.Running(state.completed, state.total)
        state is DownloadState.Complete -> GalleryDownload.Saved

        // A download this process has started is on its way to the folder, so
        // nothing being there yet is not the same as nothing being left.
        state != null && onDisk is GalleryDownload.Missing -> GalleryDownload.Saved

        else -> onDisk ?: GalleryDownload.Saved
    }
}

/**
 * Saves [galleryID], asking for the notification permission first: the downloader
 * is a foreground service, and one that cannot post its notification leaves the
 * user nothing to watch or cancel.
 */
@Composable
fun rememberSaveAction(galleryID: Int, priority: Boolean = false): () -> Unit {
    val context = LocalContext.current
    val activity = context.findActivity()

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) DownloadService.download(context, galleryID, priority, save = true)
    }

    return {
        if (activity == null)
            DownloadService.download(context, galleryID, priority, save = true)
        else
            requestNotificationPermission(activity, launcher) {
                DownloadService.download(context, galleryID, priority, save = true)
            }
    }
}

/**
 * Asks before [galleryID]'s files go, and its history with them when
 * [removeHistory]: they are deleted the moment this is confirmed, and getting
 * them back costs the network again.
 */
@Composable
fun RemoveDownloadDialog(
    galleryID: Int,
    title: String,
    onDismiss: () -> Unit,
    removeHistory: Boolean = false,
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                stringResource(
                    if (removeHistory) R.string.gallery_remove_both_title
                    else R.string.gallery_remove_download_title
                )
            )
        },
        text = {
            Text(
                stringResource(
                    if (removeHistory) R.string.gallery_remove_both_message
                    else R.string.gallery_remove_download_message,
                    title,
                )
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    DownloadService.unsave(context, galleryID)
                    if (removeHistory) removeFromHistory(galleryID)
                    onDismiss()
                }
            ) {
                Text(stringResource(R.string.gallery_remove_download_confirm))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(android.R.string.cancel))
            }
        },
    )
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
