/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.GalleryBlock
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.readProgress

/**
 * As many columns as fit at [minWidth] plus [gap], each widened to share the row
 * but never past [maxWidth]. The cells always leave at least [gap] per column
 * unclaimed, for a spacing arrangement to put around them.
 */
class BoundedAdaptiveCells(
    private val minWidth: Dp,
    private val maxWidth: Dp,
    private val gap: Dp,
) : GridCells {
    override fun Density.calculateCrossAxisCellSizes(availableSize: Int, spacing: Int): List<Int> {
        val count = (availableSize / (minWidth + gap).roundToPx()).coerceAtLeast(1)
        val width = (availableSize / count - gap.roundToPx())
            .coerceIn(0, maxWidth.roundToPx())

        return List(count) { width }
    }

    override fun equals(other: Any?) = other is BoundedAdaptiveCells &&
        minWidth == other.minWidth && maxWidth == other.maxWidth && gap == other.gap

    override fun hashCode() = (minWidth.hashCode() * 31 + maxWidth.hashCode()) * 31 + gap.hashCode()
}

/**
 * The cover and the title, and the [GalleryBlockMenu] the detailed card carries,
 * from a button over the top corner of the cover. The card has no room for a row
 * of its own to hold it.
 *
 * The read and download bars keep the detailed card's places -- the top and the
 * foot of the card -- so a list reads the same whichever style it is drawn in.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryGridCard(
    galleryBlock: GalleryBlock,
    onClick: () -> Unit,
    onShowDetail: () -> Unit,
    onTagClick: (SearchQuery.Tag) -> Unit,
    modifier: Modifier = Modifier,
) {
    val download = rememberGalleryDownload(galleryBlock.id)

    val progress = readProgress[galleryBlock.id]

    var menuExpanded by remember(galleryBlock.id) { mutableStateOf(false) }

    ElevatedCard(
        modifier = modifier.combinedClickable(onClick = onClick, onLongClick = onShowDetail),
        shape = RoundedCornerShape(4.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = colorResource(R.color.gallery_card),
        ),
    ) {
        Box(Modifier.readProgressBar(progress, MaterialTheme.colorScheme.outlineVariant)) {
            RemoteImage(
                url = galleryBlock.thumbnails.firstOrNull(),
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(3f / 4f),
                contentScale = ContentScale.Crop,
            )

            Box(Modifier.align(Alignment.TopEnd)) {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier
                        .padding(4.dp)
                        .size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = stringResource(R.string.galleryblock_menu),
                        modifier = Modifier.size(20.dp),
                    )
                }

                GalleryBlockMenu(
                    galleryBlock = galleryBlock,
                    download = download,
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    onShowDetail = onShowDetail,
                    onTagClick = onTagClick,
                )
            }
        }

        Text(
            text = galleryBlock.title,
            modifier = Modifier.padding(8.dp),
            style = MaterialTheme.typography.titleSmall,
            minLines = 2,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )

        DownloadProgressBar(download)
    }
}
