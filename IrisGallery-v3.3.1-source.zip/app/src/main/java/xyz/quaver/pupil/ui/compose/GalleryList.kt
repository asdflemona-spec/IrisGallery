/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.pullToRefresh
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlin.math.roundToInt
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.NoResultReason
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.without
import xyz.quaver.pupil.listStyle
import xyz.quaver.pupil.ui.viewmodel.GalleryListViewModel
import xyz.quaver.pupil.util.ListStyle

private val GalleryGridCells = BoundedAdaptiveCells(minWidth = 150.dp, maxWidth = 200.dp, gap = 8.dp)

/**
 * The gallery list every top level destination is built from: a floating search
 * bar over a page of [GalleryBlockCard]s, or a grid of [GalleryGridCard]s, with
 * the pull-to-turn gesture around it.
 *
 * [actions] lead the collapsed search bar's trailing row, ahead of the overflow
 * menu every list has, and [menuActions] lead that menu.
 *
 * A list the app keeps itself says [emptyMessage] when nothing is in it at all
 * and [noMatchMessage] when a query narrowed everything away; the search, whose
 * empty result is always about the query, has neither.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryList(
    viewModel: GalleryListViewModel,
    modifier: Modifier = Modifier,
    onGalleryClick: (Int) -> Unit = {},
    onShowDetail: (Int) -> Unit = {},
    emptyMessage: String? = null,
    noMatchMessage: String? = null,
    menuActions: @Composable ColumnScope.(onDismissRequest: () -> Unit) -> Unit = {},
    actions: @Composable RowScope.() -> Unit = {},
) {
    val density = LocalDensity.current
    // The bar is 64dp tall including its margin and sits below the status bar,
    // which the list scrolls behind, so it has to cross that strip as well to
    // leave the screen.
    val searchBarSpace = 64.dp
    val statusBarHeight = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val searchBarTravelPx = with(density) { (statusBarHeight + searchBarSpace).roundToPx() }

    // Slides the search bar away as the list scrolls down, mirroring the
    // reference implementation's SearchLayout.
    val nestedScroll = remember(searchBarTravelPx, viewModel) {
        object : NestedScrollConnection {
            fun slide(delta: Float) {
                viewModel.searchBarOffset =
                    (viewModel.searchBarOffset + delta.roundToInt())
                        .coerceIn(-searchBarTravelPx, 0)
            }

            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f) slide(available.y)
                return Offset.Zero
            }

            // Hiding follows what the list actually moved, so a drag it could
            // not use -- a page shorter than the screen, a pull to turn the
            // page -- leaves the bar alone.
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource,
            ): Offset {
                if (consumed.y < 0f) slide(consumed.y)
                return Offset.Zero
            }
        }
    }

    var searchBarState by rememberSaveable { mutableStateOf(HitomiSearchBarState.NORMAL) }

    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()

    val grid = listStyle.style == ListStyle.GRID

    val swipeRevealGroup = remember { SwipeRevealGroup() }

    val pullToRefreshState = rememberPullToRefreshState()

    val listShown = viewModel.exception == null && viewModel.galleries.isNotEmpty()

    // A page still filling up measures as a list at the top, so the position
    // the view model keeps is only put back, and only followed, once a whole
    // page is on screen -- a refresh never stops showing one. A page turn
    // arrives here having already reset it.
    val pageSettled = listShown && (!viewModel.loading || viewModel.refreshing)

    LaunchedEffect(pageSettled, grid) {
        if (!pageSettled) return@LaunchedEffect

        if (grid)
            gridState.scrollToItem(
                viewModel.firstVisibleItemIndex,
                viewModel.firstVisibleItemScrollOffset,
            )
        else
            listState.scrollToItem(
                viewModel.firstVisibleItemIndex,
                viewModel.firstVisibleItemScrollOffset,
            )

        snapshotFlow {
            if (grid) gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset
            else listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset
        }.collect { (index, offset) -> viewModel.onScroll(index, offset) }
    }

    val listAtTop by remember(listState, gridState) {
        derivedStateOf {
            if (listStyle.style == ListStyle.GRID)
                gridState.firstVisibleItemIndex == 0 && gridState.firstVisibleItemScrollOffset == 0
            else
                listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0
        }
    }

    // Only a scrolling list brings the bar back, so it may only be away while
    // there is one under it that has left the top. Everything that puts the
    // list back at the top without scrolling it -- a page turn, an error, an
    // offset restored from the last session -- is covered without having to
    // remember to reset the offset itself.
    LaunchedEffect(listShown, listAtTop) {
        if (!listShown || listAtTop) viewModel.searchBarOffset = 0
    }

    HitomiSearchBar(
        query = viewModel.query,
        onQueryChange = viewModel::onQueryChange,
        topOffset = viewModel.searchBarOffset,
        onTopOffsetChange = { viewModel.searchBarOffset = it },
        state = searchBarState,
        onStateChange = { searchBarState = it },
        onOpenGallery = { galleryID ->
            searchBarState = HitomiSearchBarState.NORMAL
            onShowDetail(galleryID)
        },
        actions = {
            actions()

            GalleryListMenu(
                currentPage = viewModel.currentPage,
                maxPage = viewModel.maxPage,
                onPageChange = viewModel::goToPage,
                randomAvailable = !viewModel.loading && viewModel.totalItems > 0,
                onOpenRandom = { viewModel.randomGalleryID()?.let(onShowDetail) },
                menuActions = menuActions,
            )
        },
    ) {
        // Turning while a page is still loading would race the fetch.
        val canTurnPrev = viewModel.prevPageAvailable && !viewModel.loading
        val canTurnNext = viewModel.nextPageAvailable && !viewModel.loading

        // Composed under the search bar, so it is offered back before the bar's
        // own handler and has to leave the expanded bar the first thing back
        // closes.
        BackHandler(
            canTurnPrev &&
                searchBarState == HitomiSearchBarState.NORMAL &&
                !LocalScreenCovered.current,
        ) {
            viewModel.goToPage(1)
        }

        // The keys stay the list's while it is on screen, whether or not this
        // page is one it can leave: a volume key that turns nothing is better
        // than one that jumps the volume mid-list.
        VolumePageTurnHandler { delta ->
            if (if (delta < 0) canTurnPrev else canTurnNext)
                viewModel.goToPage(viewModel.currentPage + delta)
        }

        PageTurnBox(
            currentPage = viewModel.currentPage,
            canTurnPrev = canTurnPrev,
            canTurnNext = canTurnNext,
            onPageTurn = viewModel::goToPage,
            modifier = modifier.fillMaxSize(),
            topInset = statusBarHeight + searchBarSpace,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pullToRefresh(
                        isRefreshing = viewModel.refreshing,
                        state = pullToRefreshState,
                        // The first page is the one page a pull from the top is
                        // free on; anywhere else it turns back a page.
                        enabled = !viewModel.prevPageAvailable,
                        onRefresh = viewModel::refresh,
                    ),
            ) {
                val exception = viewModel.exception
                val empty = viewModel.galleries.isEmpty()

                when {
                    exception != null -> ErrorState(
                        modifier = Modifier.align(Alignment.Center),
                        throwable = exception,
                        onRetry = viewModel::load,
                    )

                    viewModel.loading && empty ->
                        CircularProgressIndicator(Modifier.align(Alignment.Center))

                    // The query found galleries and every one of their blocks
                    // failed to arrive: a page that could not be built, rather
                    // than a search with nothing to show.
                    empty && viewModel.totalItems > 0 -> PageLoadFailed(
                        modifier = Modifier.align(Alignment.Center),
                        onRetry = viewModel::load,
                    )

                    empty && viewModel.query == null && emptyMessage != null -> NothingYet(
                        modifier = Modifier.align(Alignment.Center),
                        message = emptyMessage,
                    )

                    empty -> NoResult(
                        modifier = Modifier.align(Alignment.Center),
                        reason = viewModel.noResultReason,
                        fallback = noMatchMessage,
                        onRemoveTerm = { term ->
                            viewModel.onQueryChange(viewModel.query?.without(term))
                        },
                        onEditLanguages = { searchBarState = HitomiSearchBarState.SEARCH },
                        onEditFilters = { searchBarState = HitomiSearchBarState.FILTERS },
                    )

                    grid -> {
                        LazyVerticalGrid(
                            columns = GalleryGridCells,
                            state = gridState,
                            modifier = Modifier
                                .fillMaxSize()
                                .nestedScroll(nestedScroll),
                            contentPadding = PaddingValues(
                                start = 4.dp,
                                end = 4.dp,
                                top = statusBarHeight + searchBarSpace + 8.dp,
                                bottom = 8.dp,
                            ),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            gridItems(viewModel.galleries, key = { it.id }) { galleryBlock ->
                                GalleryGridCard(
                                    galleryBlock = galleryBlock,
                                    onClick = { onGalleryClick(galleryBlock.id) },
                                    onShowDetail = { onShowDetail(galleryBlock.id) },
                                    onTagClick = viewModel::onQueryChange,
                                )
                            }
                        }

                        FastScroller(
                            state = gridState,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .fillMaxHeight()
                                .padding(top = statusBarHeight + searchBarSpace),
                        )
                    }

                    else -> {
                        CompositionLocalProvider(LocalSwipeRevealGroup provides swipeRevealGroup) {
                            LazyColumn(
                                state = listState,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .nestedScroll(nestedScroll),
                                // Leave room for the status bar and the floating search bar.
                                contentPadding = PaddingValues(
                                    start = 8.dp,
                                    end = 8.dp,
                                    top = statusBarHeight + searchBarSpace + 8.dp,
                                    bottom = 8.dp,
                                ),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                items(viewModel.galleries, key = { it.id }) { galleryBlock ->
                                    GalleryBlockCard(
                                        galleryBlock = galleryBlock,
                                        onClick = { onGalleryClick(galleryBlock.id) },
                                        onShowDetail = { onShowDetail(galleryBlock.id) },
                                        onTagClick = viewModel::onQueryChange,
                                    )
                                }
                            }
                        }

                        FastScroller(
                            state = listState,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .fillMaxHeight()
                                .padding(top = statusBarHeight + searchBarSpace),
                        )
                    }
                }

                PullToRefreshDefaults.Indicator(
                    state = pullToRefreshState,
                    isRefreshing = viewModel.refreshing,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = statusBarHeight + searchBarSpace),
                )
            }
        }
    }
}

/** A list nothing has been put in yet, which no search can explain. */
@Composable
private fun NothingYet(modifier: Modifier, message: String) {
    ErrorMessage(modifier = modifier, kaomoji = "(・_・)") {
        EmptyStateDetail(text = message)
    }
}

/** A page whose galleries were all found and none of them could be fetched. */
@Composable
private fun PageLoadFailed(modifier: Modifier, onRetry: () -> Unit) {
    ErrorMessage(modifier = modifier, kaomoji = "(×_×)⌒☆") {
        EmptyStateDetail(
            text = stringResource(R.string.main_page_load_failed),
            action = stringResource(R.string.reader_fab_retry),
            onAction = onRetry,
        )
    }
}

/**
 * The empty list, with whatever the view model worked out about why it is
 * empty and the one thing to do about it. [fallback] is what a list says where
 * the query is not enough to explain it.
 */
@Composable
private fun NoResult(
    modifier: Modifier,
    reason: NoResultReason?,
    fallback: String?,
    onRemoveTerm: (SearchQuery) -> Unit,
    onEditLanguages: () -> Unit,
    onEditFilters: () -> Unit,
) {
    ErrorMessage(modifier = modifier, kaomoji = "(ﾟoﾟ;;") {
        Text(stringResource(R.string.main_no_result))

        when (reason) {
            null -> if (fallback != null) EmptyStateDetail(text = fallback)

            is NoResultReason.EmptyTerm -> EmptyStateDetail(
                text = stringResource(R.string.search_no_result_empty_term),
                term = reason.term,
                action = stringResource(R.string.search_no_result_remove_term),
                onAction = { onRemoveTerm(reason.term) },
            )

            is NoResultReason.ExcludingTerm -> EmptyStateDetail(
                text = stringResource(R.string.search_no_result_excluding_term),
                term = reason.term,
                action = stringResource(R.string.search_no_result_remove_term),
                onAction = { onRemoveTerm(reason.term) },
            )

            NoResultReason.NoOverlap -> EmptyStateDetail(
                text = stringResource(R.string.search_no_result_no_overlap),
            )

            is NoResultReason.UnavailableLanguage -> EmptyStateDetail(
                text = stringResource(R.string.search_no_result_language),
                term = reason.languages,
                action = stringResource(R.string.search_no_result_edit_languages),
                onAction = onEditLanguages,
            )

            is NoResultReason.MissingRequiredTag -> EmptyStateDetail(
                text = stringResource(R.string.search_no_result_required_tag),
                term = reason.tag,
                action = stringResource(R.string.search_no_result_edit_filters),
                onAction = onEditFilters,
            )

            is NoResultReason.BannedTag -> EmptyStateDetail(
                text = stringResource(R.string.search_no_result_banned_tag),
                term = reason.tag,
                action = stringResource(R.string.search_no_result_edit_filters),
                onAction = onEditFilters,
            )

            NoResultReason.Filtered -> EmptyStateDetail(
                text = stringResource(R.string.search_no_result_filtered),
                action = stringResource(R.string.search_no_result_edit_filters),
                onAction = onEditFilters,
            )
        }
    }
}

@Composable
private fun EmptyStateDetail(
    text: String,
    term: SearchQuery? = null,
    action: String? = null,
    onAction: () -> Unit = {},
) {
    Column(
        modifier = Modifier.padding(horizontal = 32.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )

        if (term != null) QueryView(term)

        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun ErrorState(modifier: Modifier, throwable: Throwable, onRetry: () -> Unit) {
    var showDetail by remember { mutableStateOf(false) }

    ErrorMessage(modifier = modifier, kaomoji = "(×_×)⌒☆") {
        Text(stringResource(R.string.search_error_title))
        Row {
            TextButton(onClick = { showDetail = true }) {
                Text(stringResource(R.string.search_error_detail))
            }
            TextButton(onClick = onRetry) {
                Text(stringResource(R.string.reader_fab_retry))
            }
        }
    }

    if (showDetail) {
        Dialog(onDismissRequest = { showDetail = false }) {
            Card {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = throwable::class.simpleName ?: "Exception",
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        text = throwable.stackTraceToString(),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState()),
                    )
                    TextButton(
                        modifier = Modifier.align(Alignment.End),
                        onClick = { showDetail = false },
                    ) { Text(stringResource(android.R.string.ok)) }
                }
            }
        }
    }
}

/** Kaomoji + message, matching the reference implementation's empty/error states. */
@Composable
fun ErrorMessage(
    modifier: Modifier = Modifier,
    kaomoji: String,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = kaomoji,
            style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        content()
    }
}
