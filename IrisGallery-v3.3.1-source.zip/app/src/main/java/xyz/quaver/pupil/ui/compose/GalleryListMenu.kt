/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.R
import xyz.quaver.pupil.listStyle
import xyz.quaver.pupil.util.ListStyle

/**
 * The collapsed search bar's overflow: the actions every gallery list has, and
 * under them the style it is drawn in.
 *
 * [menuActions] leads with whatever the list on screen adds of its own, and
 * closes itself off from the shared actions with its own divider.
 */
@Composable
fun GalleryListMenu(
    currentPage: Int,
    maxPage: Int,
    onPageChange: (Int) -> Unit,
    randomAvailable: Boolean,
    onOpenRandom: () -> Unit,
    menuActions: @Composable ColumnScope.(onDismissRequest: () -> Unit) -> Unit = {},
) {
    var expanded by remember { mutableStateOf(false) }
    var showJumpDialog by remember { mutableStateOf(false) }

    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = stringResource(R.string.main_menu_more),
            )
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            menuActions { expanded = false }

            DropdownMenuItem(
                text = { Text(stringResource(R.string.main_fab_random)) },
                leadingIcon = {
                    Icon(painterResource(R.drawable.shuffle_variant), contentDescription = null)
                },
                enabled = randomAvailable,
                onClick = {
                    expanded = false
                    onOpenRandom()
                },
            )

            DropdownMenuItem(
                text = { Text(stringResource(R.string.main_jump_title)) },
                leadingIcon = {
                    Icon(painterResource(R.drawable.ic_jump), contentDescription = null)
                },
                enabled = maxPage > 1,
                onClick = {
                    expanded = false
                    showJumpDialog = true
                },
            )

            HorizontalDivider()

            ListStyle.entries.forEach { style ->
                DropdownMenuItem(
                    text = { Text(stringResource(style.label)) },
                    leadingIcon = { Icon(style.icon, contentDescription = null) },
                    trailingIcon = {
                        RadioButton(selected = listStyle.style == style, onClick = null)
                    },
                    onClick = {
                        expanded = false
                        listStyle.set(style)
                    },
                )
            }
        }
    }

    // Outside the menu, whose content leaves composition as it closes.
    if (showJumpDialog)
        JumpToPageDialog(
            currentPage = currentPage,
            maxPage = maxPage,
            onDismiss = { showJumpDialog = false },
            onConfirm = {
                showJumpDialog = false
                onPageChange(it)
            },
        )
}

@Composable
private fun JumpToPageDialog(
    currentPage: Int,
    maxPage: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit,
) {
    var input by remember { mutableStateOf("") }
    val page = input.toIntOrNull()?.takeIf { it in 1..maxPage }

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) { focusRequester.requestFocus() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.main_jump_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(stringResource(R.string.main_jump_message, currentPage, maxPage))

                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.filter(Char::isDigit) },
                    singleLine = true,
                    isError = input.isNotEmpty() && page == null,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Go,
                    ),
                    keyboardActions = KeyboardActions(onGo = { page?.let(onConfirm) }),
                    modifier = Modifier.focusRequester(focusRequester),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { page?.let(onConfirm) }, enabled = page != null) {
                Text(stringResource(android.R.string.ok))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(android.R.string.cancel))
            }
        },
    )
}

private val ListStyle.icon
    get() = when (this) {
        ListStyle.DETAILED -> Icons.Default.ViewAgenda
        ListStyle.THIN -> Icons.AutoMirrored.Filled.ViewList
        ListStyle.GRID -> Icons.Default.GridView
    }

private val ListStyle.label
    get() = when (this) {
        ListStyle.DETAILED -> R.string.main_menu_detailed
        ListStyle.THIN -> R.string.main_menu_thin
        ListStyle.GRID -> R.string.main_menu_grid
    }
