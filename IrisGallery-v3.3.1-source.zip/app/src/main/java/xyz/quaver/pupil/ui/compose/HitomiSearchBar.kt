/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateDp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateTo
import androidx.compose.animation.core.updateTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarOutline
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import kotlinx.coroutines.delay
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import xyz.quaver.pupil.R
import xyz.quaver.pupil.favoriteTags
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.toQueryText
import xyz.quaver.pupil.searchHistory
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.types.Tag
import xyz.quaver.pupil.util.DefaultQuery
import xyz.quaver.pupil.util.translations
import xyz.quaver.pupil.util.wordCapitalize

/** What the expanded search bar is editing, whichever editor is on screen. */
sealed interface SearchEditorController {
    /** The query the bar hands back when it collapses, text still being typed included. */
    fun commitQuery(): SearchQuery?

    val isEmpty: Boolean

    fun clear()

    fun replaceWith(query: SearchQuery?)
}

enum class HitomiSearchBarState {
    NORMAL,
    SEARCH,

    FILTERS,
    HISTORY,
    WATCHLIST,
}

private val iconMap: Map<String, ImageVector> = mapOf(
    "female" to Icons.Default.Female,
    "male" to Icons.Default.Male,
    "artist" to Icons.Default.Brush,
    "group" to Icons.Default.Group,
    "character" to Icons.Default.Face,
    "series" to Icons.Default.Book,
    "type" to Icons.Default.Folder,
    "language" to Icons.Default.Translate,
    "tag" to Icons.AutoMirrored.Filled.Label,
)

object TagColors {
    val Female = Color(0xFFD81B60)
    val Male = Color(0xFF1976D2)
    val Favorite = Color(0xFFFF9800)
    val ReadLater = Color(0xFF00897B)
}

/** Hitomi's language names to the flag that stands in for the Translate icon. */
private val languageIconMap: Map<String, Int> = mapOf(
    "albanian" to R.drawable.language_albanian,
    "catalan" to R.drawable.language_catalan,
    "cebuano" to R.drawable.language_philippines,
    "chinese" to R.drawable.language_chinese,
    "czech" to R.drawable.language_czech,
    "danish" to R.drawable.language_danish,
    "dutch" to R.drawable.language_dutch,
    "english" to R.drawable.language_english,
    "estonian" to R.drawable.language_estonian,
    "finnish" to R.drawable.language_finnish,
    "french" to R.drawable.language_french,
    "german" to R.drawable.language_german,
    "greek" to R.drawable.language_greek,
    "hebrew" to R.drawable.language_hebrew,
    "hungarian" to R.drawable.language_hungarian,
    "indonesian" to R.drawable.language_indonesian,
    "italian" to R.drawable.language_italian,
    "japanese" to R.drawable.language_japanese,
    "javanese" to R.drawable.language_javanese,
    "korean" to R.drawable.language_korean,
    "latin" to R.drawable.language_latin,
    "mongolian" to R.drawable.language_mongolian,
    "norwegian" to R.drawable.language_norwegian,
    "persian" to R.drawable.language_persian,
    "polish" to R.drawable.language_polish,
    "portuguese" to R.drawable.language_portuguese,
    "romanian" to R.drawable.language_romanian,
    "russian" to R.drawable.language_russian,
    "slovak" to R.drawable.language_slovak,
    "spanish" to R.drawable.language_spanish,
    "swedish" to R.drawable.language_swedish,
    "tagalog" to R.drawable.language_philippines,
    "thai" to R.drawable.language_thai,
    "turkish" to R.drawable.language_turkish,
    "ukrainian" to R.drawable.language_ukrainian,
    "vietnamese" to R.drawable.language_vietnamese,
)

@Composable
fun languageIcon(language: String): Int? = languageIconMap[language]

@Composable
fun tagLabel(area: String, tag: String): String {
    val languageNames = rememberLanguageNames()

    return if (area == "language") languageNames[tag] ?: tag
    else (translations[tag] ?: tag).wordCapitalize()
}

@Composable
fun TagChipIcon(area: String, tag: String = "") {
    val flag = if (area == "language") languageIconMap[tag] else null

    val icon = iconMap[area]

    when {
        flag != null -> Icon(
            painterResource(flag),
            contentDescription = null,
            modifier = Modifier
                .padding(4.dp)
                .size(24.dp),
            // Flags carry their own colours.
            tint = Color.Unspecified,
        )

        icon != null -> Icon(
            icon,
            contentDescription = null,
            modifier = Modifier
                .padding(4.dp)
                .size(24.dp),
        )

        else -> Spacer(Modifier.width(16.dp))
    }
}

/**
 * [TagChip] that paints itself as a favourite and toggles it from a trailing
 * star, and offers the tag to [TagBanMenu] on a long press. Drop the star with
 * [showFavoriteToggle] where the chip is only there to be picked.
 */
@Composable
fun FavoritableTagChip(
    tag: String,
    enabled: Boolean = true,
    showFavoriteToggle: Boolean = true,
    onClick: (String) -> Unit = { },
    content: @Composable (String, String) -> Unit = { area, tagPart -> Text(tagLabel(area, tagPart)) },
) {
    val parsed = remember(tag) { Tag.parseNamespaced(tag) }
    val isFavorite = favoriteTags.contains(parsed)

    var banMenuExpanded by remember(tag) { mutableStateOf(false) }

    Box {
        TagChip(
            tag = tag,
            isFavorite = isFavorite,
            enabled = enabled,
            onClick = onClick,
            onLongClick = { banMenuExpanded = true },
            content = content,
            rightIcon = { _, _ ->
                if (showFavoriteToggle) Icon(
                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarOutline,
                    contentDescription = stringResource(
                        if (isFavorite) R.string.tag_remove_favorite else R.string.tag_add_favorite,
                    ),
                    modifier = Modifier
                        .padding(start = 4.dp, end = 8.dp)
                        .size(20.dp)
                        .clickable { favoriteTags.toggle(parsed) },
                )
                else Spacer(Modifier.width(16.dp))
            },
        )

        TagBanMenu(
            tag = SearchQuery.Tag(parsed.area, parsed.tag),
            expanded = banMenuExpanded,
            onDismissRequest = { banMenuExpanded = false },
        )
    }
}

/**
 * A full-width row in a list of things to pick from, where a chip would only
 * hug its own label.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SuggestionRow(
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    icon: @Composable () -> Unit,
    trailing: @Composable () -> Unit = { Spacer(Modifier.width(8.dp)) },
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalTextStyle provides MaterialTheme.typography.bodyMedium) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            icon()

            Box(Modifier.weight(1f).padding(horizontal = 4.dp)) { content() }

            trailing()
        }
    }
}

/**
 * [FavoritableTagChip] as a [SuggestionRow]: the namespace icon, the label, and
 * a star that puts the tag on or off the favourites.
 */
@Composable
fun TagSuggestionRow(
    tag: String,
    onClick: () -> Unit = { },
    content: @Composable (String, String) -> Unit = { area, tagPart ->
        Text(tagLabel(area, tagPart), maxLines = 1, overflow = TextOverflow.Ellipsis)
    },
) {
    val parsed = remember(tag) { Tag.parseNamespaced(tag) }
    val isFavorite = favoriteTags.contains(parsed)

    var banMenuExpanded by remember(tag) { mutableStateOf(false) }

    val (area, tagPart) = tag.split(':', limit = 2).let {
        if (it.size == 1 || it[0] !in iconMap.keys) listOf("", tag) else it
    }

    Box {
        SuggestionRow(
            onClick = onClick,
            onLongClick = { banMenuExpanded = true },
            icon = {
                CompositionLocalProvider(
                    LocalContentColor provides when (area) {
                        "male" -> TagColors.Male
                        "female" -> TagColors.Female
                        else -> LocalContentColor.current
                    },
                ) {
                    TagChipIcon(area, tagPart)
                }
            },
            trailing = {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarOutline,
                    contentDescription = stringResource(
                        if (isFavorite) R.string.tag_remove_favorite else R.string.tag_add_favorite,
                    ),
                    tint = if (isFavorite) TagColors.Favorite else LocalContentColor.current,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { favoriteTags.toggle(parsed) }
                        .padding(8.dp)
                        .size(20.dp),
                )
            },
            content = { content(area, tagPart) },
        )

        TagBanMenu(
            tag = SearchQuery.Tag(parsed.area, parsed.tag),
            expanded = banMenuExpanded,
            onDismissRequest = { banMenuExpanded = false },
        )
    }
}

/** [FavoriteArtistsChip] as a [SuggestionRow]. */
@Composable
fun FavoriteArtistsSuggestionRow(onClick: () -> Unit) {
    SuggestionRow(
        onClick = onClick,
        icon = {
            Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = TagColors.Favorite,
                modifier = Modifier
                    .padding(4.dp)
                    .size(24.dp),
            )
        },
        content = { Text(stringResource(R.string.search_favorite_artists)) },
    )
}

/** [ReadLaterChip] as a [SuggestionRow]. */
@Composable
fun ReadLaterSuggestionRow(onClick: () -> Unit) {
    SuggestionRow(
        onClick = onClick,
        icon = {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                tint = TagColors.ReadLater,
                modifier = Modifier
                    .padding(4.dp)
                    .size(24.dp),
            )
        },
        content = { Text(stringResource(R.string.search_read_later)) },
    )
}

/** Puts a tag on, or takes it off, [DefaultQuery]'s ban list. */
@Composable
private fun TagBanMenu(
    tag: SearchQuery.Tag,
    expanded: Boolean,
    onDismissRequest: () -> Unit,
) {
    val isBanned = DefaultQuery.isBanned(tag)

    val label = tagLabel(tag.namespace.orEmpty(), tag.tag)

    DropdownMenu(expanded = expanded, onDismissRequest = onDismissRequest) {
        DropdownMenuItem(
            text = {
                Text(
                    text = stringResource(
                        if (isBanned) R.string.tag_unban else R.string.tag_ban,
                        label,
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            },
            onClick = {
                onDismissRequest()

                if (isBanned) DefaultQuery.unban(tag) else DefaultQuery.ban(tag)
            },
            leadingIcon = {
                Icon(
                    imageVector = if (isBanned)
                        Icons.Default.Visibility
                    else
                        Icons.Default.VisibilityOff,
                    contentDescription = null,
                )
            },
        )
    }
}

/** Chip standing for [SearchQuery.FavoriteArtists]. */
@Composable
fun FavoriteArtistsChip(
    onClick: (() -> Unit)? = null,
    rightIcon: @Composable (String, String) -> Unit = { _, _ -> Spacer(Modifier.width(16.dp)) },
) {
    TagChip(
        tag = stringResource(R.string.search_favorite_artists),
        isFavorite = true,
        enabled = onClick != null,
        onClick = { onClick?.invoke() },
        leftIcon = { _, _ ->
            Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                modifier = Modifier
                    .padding(4.dp)
                    .size(24.dp),
            )
        },
        rightIcon = rightIcon,
        content = { _, label -> Text(label) },
    )
}

/** Chip standing for [SearchQuery.ReadLater]. */
@Composable
fun ReadLaterChip(
    onClick: (() -> Unit)? = null,
    rightIcon: @Composable (String, String) -> Unit = { _, _ -> Spacer(Modifier.width(16.dp)) },
) {
    TagChip(
        tag = stringResource(R.string.search_read_later),
        containerColor = TagColors.ReadLater,
        enabled = onClick != null,
        onClick = { onClick?.invoke() },
        leftIcon = { _, _ ->
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                modifier = Modifier
                    .padding(4.dp)
                    .size(24.dp),
            )
        },
        rightIcon = rightIcon,
        content = { _, label -> Text(label) },
    )
}

/**
 * Namespace-coloured chip: male is blue, female is pink, a favourited tag is
 * orange, everything else takes the surface colour.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TagChip(
    tag: String,
    isFavorite: Boolean = false,
    containerColor: Color? = null,
    enabled: Boolean = true,
    onClick: (String) -> Unit = { },
    onLongClick: (() -> Unit)? = null,
    leftIcon: @Composable (String, String) -> Unit = { area, tagPart -> TagChipIcon(area, tagPart) },
    rightIcon: @Composable (String, String) -> Unit = { _, _ -> Spacer(Modifier.width(16.dp)) },
    content: @Composable (String, String) -> Unit = { area, tagPart -> Text(tagLabel(area, tagPart)) },
) {
    val (area, tagPart) = tag.split(':', limit = 2).let {
        if (it.size == 1 || it[0] !in iconMap.keys) listOf("", tag) else it
    }

    val surfaceColor = containerColor ?: if (isFavorite) TagColors.Favorite else when (area) {
        "male" -> TagColors.Male
        "female" -> TagColors.Female
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    val contentColor =
        if (surfaceColor == MaterialTheme.colorScheme.surfaceVariant)
            MaterialTheme.colorScheme.onSurfaceVariant
        else
            Color.White

    Surface(
        modifier = Modifier.height(32.dp),
        shape = RoundedCornerShape(16.dp),
        color = surfaceColor,
        shadowElevation = 8.dp,
    ) {
        CompositionLocalProvider(
            LocalContentColor provides contentColor,
            LocalTextStyle provides MaterialTheme.typography.bodyMedium,
        ) {
            Row(
                // Inside the Surface, so the ripple takes the chip's shape
                // instead of spilling out of the corners.
                modifier = if (enabled)
                    Modifier.combinedClickable(
                        onClick = { onClick(tag) },
                        onLongClick = onLongClick,
                    )
                else
                    Modifier,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                leftIcon(area, tagPart)
                content(area, tagPart)
                rightIcon(area, tagPart)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TagGroup(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    FlowRow(
        modifier = modifier.padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        content = { content() },
    )
}

/** Collapsed state: the active query as a horizontally scrolling chip row. */
@Composable
private fun Normal(
    query: SearchQuery?,
    simplified: Boolean,
    actions: @Composable RowScope.() -> Unit,
) {
    Row(
        modifier = Modifier.height(48.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Spacer(Modifier.width(8.dp))

            when (val text = query?.toQueryText().takeIf { simplified }) {
                null -> QueryView(query)
                else -> Text(text, style = MaterialTheme.typography.titleMedium)
            }

            Spacer(Modifier.width(8.dp))
        }

        Row(content = actions)
    }
}

/** Read-only render of the query tree, used by the collapsed bar. */
@Composable
fun QueryView(query: SearchQuery?, topLevel: Boolean = true) {
    val borderModifier = if (topLevel) Modifier else Modifier.border(
        width = 0.5.dp,
        color = LocalContentColor.current,
        shape = RoundedCornerShape(8.dp),
    )

    when (query) {
        null -> Text(
            stringResource(R.string.search_hint),
            style = MaterialTheme.typography.titleMedium,
        )

        is SearchQuery.Tag -> TagChip(query.toString(), enabled = false)

        is SearchQuery.FavoriteArtists -> FavoriteArtistsChip()

        is SearchQuery.ReadLater -> ReadLaterChip()

        is SearchQuery.And -> Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            query.queries.forEach { QueryView(it, topLevel = false) }
        }

        is SearchQuery.Or -> Row(
            modifier = borderModifier.padding(vertical = 2.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            query.queries.forEachIndexed { index, subQuery ->
                if (index != 0) Text("+")
                QueryView(subQuery, topLevel = false)
            }
        }

        is SearchQuery.Not -> Row(
            modifier = borderModifier.padding(vertical = 2.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("-")
            QueryView(query.query, topLevel = false)
        }
    }
}

@Composable
private fun Scrim(color: Color, onDismiss: () -> Unit, visible: Boolean) {
    val alpha by animateFloatAsState(if (visible) 1f else 0f, label = "scrimAlpha")

    if (alpha == 0f) return

    Canvas(
        Modifier
            .fillMaxSize()
            .then(if (visible) Modifier.clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            ) else Modifier)
    ) {
        drawRect(color = color, alpha = alpha)
    }
}

/**
 * Floating search bar that expands over [content].
 *
 * [topOffset] is driven by the result list's nested scroll so the bar slides
 * away as you scroll down.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HitomiSearchBar(
    query: SearchQuery?,
    onQueryChange: (SearchQuery?) -> Unit,
    topOffset: Int,
    onTopOffsetChange: (Int) -> Unit,
    state: HitomiSearchBarState,
    onStateChange: (HitomiSearchBarState) -> Unit,
    onOpenGallery: (Int) -> Unit,
    actions: @Composable RowScope.() -> Unit,
    content: @Composable () -> Unit,
) {
    val isFocused = state != HitomiSearchBarState.NORMAL

    val simplified = settings.value.simplifiedSearch

    val controller = remember(query, simplified) {
        if (simplified) SimpleQueryController(query)
        else QueryEditorController(query.toEditableState())
    }

    val focusManager = LocalFocusManager.current
    val imeVisible = WindowInsets.isImeVisible
    var imeWasVisible by remember { mutableStateOf(false) }

    LaunchedEffect(imeVisible) {
        if (imeVisible) imeWasVisible = true
        else if (imeWasVisible) {
            imeWasVisible = false
            focusManager.clearFocus()
        }
    }

    LaunchedEffect(state) {
        if (isFocused && topOffset != 0) {
            AnimationState(Int.VectorConverter, topOffset).animateTo(0) {
                onTopOffsetChange(value)
            }
        }

        // Collapsing commits whatever the editor currently holds.
        if (state == HitomiSearchBarState.NORMAL) {
            val committed = controller.commitQuery()

            // Entering composition commits the query already showing, which
            // is not a search anyone just ran.
            if (committed != null && committed != query) searchHistory.add(committed)

            onQueryChange(committed)
        }
    }

    BackHandler((isFocused || query != null) && !LocalScreenCovered.current) {
        when (state) {
            HitomiSearchBarState.FILTERS,
            HitomiSearchBarState.HISTORY,
            HitomiSearchBarState.WATCHLIST -> onStateChange(HitomiSearchBarState.SEARCH)

            HitomiSearchBarState.SEARCH -> onStateChange(HitomiSearchBarState.NORMAL)
            HitomiSearchBarState.NORMAL -> onQueryChange(null)
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // The card is placed below the status bar, which this box spans, so the
        // expanded height has to leave that strip out to stay on screen.
        val statusBarHeight = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

        val transition = updateTransition(isFocused, label = "searchBarFocused")
        val width by transition.animateDp(label = "searchBarWidth") { focused ->
            if (focused) min(maxWidth, 1000.dp) else maxWidth
        }
        val height by transition.animateDp(label = "searchBarHeight") { focused ->
            if (focused) maxHeight - statusBarHeight else 64.dp
        }

        content()

        Scrim(
            color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.32f),
            onDismiss = { onStateChange(HitomiSearchBarState.NORMAL) },
            visible = isFocused,
        )

        val interactionSource = remember { MutableInteractionSource() }

        ElevatedCard(
            modifier = Modifier
                .statusBarsPadding()
                .imePadding()
                .width(width)
                .height(height)
                .padding(8.dp)
                .align(Alignment.TopCenter)
                .absoluteOffset { IntOffset(0, topOffset) }
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                ) {
                    when (state) {
                        HitomiSearchBarState.NORMAL -> onStateChange(HitomiSearchBarState.SEARCH)
                        HitomiSearchBarState.SEARCH -> onStateChange(HitomiSearchBarState.NORMAL)
                        HitomiSearchBarState.FILTERS,
                        HitomiSearchBarState.HISTORY,
                        HitomiSearchBarState.WATCHLIST -> Unit
                    }
                },
            shape = RoundedCornerShape(4.dp),
            elevation = CardDefaults.elevatedCardElevation(if (isFocused) 16.dp else 8.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = colorResource(R.color.gallery_card),
            ),
        ) {
            when (state) {
                HitomiSearchBarState.NORMAL -> Normal(query, simplified, actions)

                HitomiSearchBarState.SEARCH -> Column(Modifier.fillMaxSize()) {
                    val editorModifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()

                    when (controller) {
                        is QueryEditorController -> QueryEditor(
                            controller = controller,
                            onOpenGallery = onOpenGallery,
                            onSubmit = { onStateChange(HitomiSearchBarState.NORMAL) },
                            modifier = editorModifier,
                        )

                        is SimpleQueryController -> SimpleQueryEditor(
                            controller = controller,
                            onOpenGallery = onOpenGallery,
                            onSubmit = { onStateChange(HitomiSearchBarState.NORMAL) },
                            modifier = editorModifier,
                        )
                    }

                    HorizontalDivider()

                    SearchCardFooter(
                        onHistoryClick = {
                            onStateChange(HitomiSearchBarState.HISTORY)
                        },
                        onWatchlistClick = {
                            onStateChange(HitomiSearchBarState.WATCHLIST)
                        },
                        onFiltersClick = {
                            onStateChange(HitomiSearchBarState.FILTERS)
                        },
                        onClearClick = controller::clear,
                        clearEnabled = !controller.isEmpty,
                    )
                }

                HitomiSearchBarState.FILTERS -> SearchFilterEditor(
                    onBack = { onStateChange(HitomiSearchBarState.SEARCH) },
                    modifier = Modifier.fillMaxSize(),
                )

                HitomiSearchBarState.HISTORY -> SearchHistoryList(
                    onBack = { onStateChange(HitomiSearchBarState.SEARCH) },
                    onPick = { picked ->
                        controller.replaceWith(picked)
                        onStateChange(HitomiSearchBarState.SEARCH)
                    },
                    modifier = Modifier.fillMaxSize(),
                )

                HitomiSearchBarState.WATCHLIST -> WatchlistEditor(
                    onBack = { onStateChange(HitomiSearchBarState.SEARCH) },
                    onPick = { picked ->
                        controller.replaceWith(picked)
                        onStateChange(HitomiSearchBarState.SEARCH)
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}
