package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.util.IrisLibraryEntry
import xyz.quaver.pupil.util.IrisSourceActions

enum class IrisLibraryFilter { SAVED, HISTORY, DOWNLOADED }

@Composable
fun IrisLibrarySection(
    filter: IrisLibraryFilter,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val entries = remember(filter) {
        IrisSourceActions.entries(context).filter {
            when (filter) {
                IrisLibraryFilter.SAVED -> it.saved
                IrisLibraryFilter.HISTORY -> it.lastViewedAt > 0
                IrisLibraryFilter.DOWNLOADED -> it.downloadedAt > 0
            }
        }.sortedByDescending {
            when (filter) {
                IrisLibraryFilter.SAVED -> maxOf(it.lastViewedAt, it.downloadedAt)
                IrisLibraryFilter.HISTORY -> it.lastViewedAt
                IrisLibraryFilter.DOWNLOADED -> it.downloadedAt
            }
        }
    }

    Column(modifier) {
        Text(
            "Iris · all sources",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        )
        if (entries.isEmpty()) {
            Text(
                "No Iris source items yet.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
        } else {
            LazyColumn(Modifier.fillMaxWidth()) {
                items(entries, key = { "${it.sourceId}:${it.remoteId}" }) { entry ->
                    IrisLibraryRow(entry)
                }
            }
        }
    }
}

@Composable
private fun IrisLibraryRow(entry: IrisLibraryEntry) {
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth()
            .clickable(enabled = entry.pageUrl != null) {
                IrisSourceActions.openOriginal(context, entry.pageUrl)
            }
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        RemoteImage(entry.thumbnailUrl, Modifier.size(76.dp), entry.title)
        Column(Modifier.padding(start = 12.dp)) {
            Text(entry.title, style = MaterialTheme.typography.titleSmall)
            Text(entry.sourceId, style = MaterialTheme.typography.labelSmall)
        }
    }
}
