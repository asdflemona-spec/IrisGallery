/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import xyz.quaver.pupil.R
import kotlin.math.abs
import kotlin.math.roundToInt

/** Pull distance that arms a page turn, and the height of the reveal band. */
private val PageTurnThreshold = 48.dp

/** The ripple band overshoots its label by this much, as in the View version. */
private val RippleGive = 4.dp

private const val PageTurnAnimDuration = 500

/**
 * Overscrolling past either end of [content] drags it aside to reveal a
 * "move to page N" label, ripples once the pull is far enough to commit, and
 * turns the page on release.
 *
 * [topInset] is how much of the box the content is inset by at the top -- the
 * status bar and the floating search bar -- so the prev label lands under them
 * rather than behind them.
 */
@Composable
fun PageTurnBox(
    currentPage: Int,
    canTurnPrev: Boolean,
    canTurnNext: Boolean,
    onPageTurn: (Int) -> Unit,
    modifier: Modifier = Modifier,
    topInset: Dp = 0.dp,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    val thresholdPx = with(density) { PageTurnThreshold.toPx() }

    // Raw pull, unclamped: the translation saturates but the commit threshold
    // is measured against the whole gesture, as in the original.
    var overscroll by remember { mutableFloatStateOf(0f) }
    var armed by remember { mutableStateOf(false) }
    var rippleTargetPx by remember { mutableFloatStateOf(0f) }

    val translation = remember { Animatable(0f) }
    val ripple = remember { Animatable(0f) }

    val page by rememberUpdatedState(currentPage)
    val canPrev by rememberUpdatedState(canTurnPrev)
    val canNext by rememberUpdatedState(canTurnNext)
    val onTurn by rememberUpdatedState(onPageTurn)

    fun applyOverscroll(value: Float) {
        overscroll = value
        scope.launch { translation.snapTo(value.coerceIn(-thresholdPx, thresholdPx)) }

        val shouldArm = abs(value) >= thresholdPx
        if (shouldArm == armed) return

        armed = shouldArm
        if (shouldArm) haptic.performHapticFeedback(HapticFeedbackType.LongPress)

        scope.launch {
            ripple.animateTo(
                targetValue = if (shouldArm) rippleTargetPx else 0f,
                animationSpec = tween(PageTurnAnimDuration),
            )
        }
    }

    val connection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput || overscroll == 0f) return Offset.Zero
                // Only unwind here; growing the pull is onPostScroll's job.
                if (available.y == 0f || (available.y > 0f) == (overscroll > 0f)) return Offset.Zero

                val consumed =
                    if (abs(available.y) > abs(overscroll)) -overscroll else available.y

                applyOverscroll(overscroll + consumed)

                return Offset(0f, consumed)
            }

            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource,
            ): Offset {
                if (source != NestedScrollSource.UserInput || available.y == 0f) return Offset.Zero

                // Once a pull is under way it keeps going; only its start is gated.
                if (overscroll == 0f &&
                    ((available.y > 0f && !canPrev) || (available.y < 0f && !canNext))
                ) return Offset.Zero

                applyOverscroll(overscroll + available.y)

                return Offset(0f, available.y)
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                val released = overscroll

                if (released == 0f) return Velocity.Zero

                overscroll = 0f
                armed = false

                scope.launch { ripple.animateTo(0f, tween(PageTurnAnimDuration)) }
                scope.launch {
                    translation.animateTo(
                        targetValue = 0f,
                        animationSpec = tween(PageTurnAnimDuration, easing = FastOutSlowInEasing),
                    )
                }

                if (abs(released) > thresholdPx)
                    onTurn(if (released > 0f) page - 1 else page + 1)

                // Swallow the fling: the list is already at its end.
                return available
            }
        }
    }

    val rippleColor =
        if (isSystemInDarkTheme()) colorResource(R.color.material_light_blue_700)
        else colorResource(R.color.material_light_blue_300)

    Box(modifier.onSizeChanged { rippleTargetPx = it.width.toFloat() }) {
        // Behind everything, the way the ViewGroup drew it before its children.
        if (ripple.value > 0f) {
            val pullingPrev = overscroll > 0f

            Canvas(Modifier.matchParentSize()) {
                val give = RippleGive.toPx()

                val centerY = if (pullingPrev)
                    topInset.toPx() + PageTurnThreshold.toPx() + give
                else
                    size.height - PageTurnThreshold.toPx() - give

                drawCircle(
                    color = rippleColor,
                    radius = ripple.value,
                    center = Offset(size.width / 2f, centerY),
                )
            }
        }

        if (overscroll > 0f)
            PageTurnLabel(
                page = currentPage - 1,
                prev = true,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = topInset),
            )

        if (overscroll < 0f)
            PageTurnLabel(
                page = currentPage + 1,
                prev = false,
                modifier = Modifier.align(Alignment.BottomCenter),
            )

        Box(
            Modifier
                .offset { IntOffset(0, translation.value.roundToInt()) }
                .nestedScroll(connection)
        ) {
            content()
        }
    }
}

@Composable
private fun PageTurnLabel(page: Int, prev: Boolean, modifier: Modifier = Modifier) {
    val tint = colorResource(R.color.colorAccent)

    Row(
        modifier = modifier.height(PageTurnThreshold),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (prev)
            Icon(painterResource(R.drawable.navigate_prev), contentDescription = null, tint = tint)

        Text(stringResource(R.string.main_move_to_page, page))

        if (!prev)
            Icon(painterResource(R.drawable.navigate_next), contentDescription = null, tint = tint)
    }
}
