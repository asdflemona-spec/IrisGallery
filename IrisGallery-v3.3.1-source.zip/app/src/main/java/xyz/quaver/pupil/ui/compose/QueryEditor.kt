/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.R
import xyz.quaver.pupil.favoriteTags
import xyz.quaver.pupil.hitomi.GalleryBlock
import xyz.quaver.pupil.hitomi.HitomiResponseException
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.Suggestion
import xyz.quaver.pupil.hitomi.getGalleryBlock
import xyz.quaver.pupil.hitomi.getSuggestionsForQuery
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.hitomi.validNamespace
import xyz.quaver.pupil.util.Crashlytics
import xyz.quaver.pupil.util.tagsMatchingTranslation
import xyz.quaver.pupil.util.translations

private val MinQueryHeight = 48.dp

private val Blue300 = Color(0xFF64B5F6)
private val Red300 = Color(0xFFE57373)

//region editable state

/** Mutable mirror of [SearchQuery] so the tree can be edited in place. */
sealed interface EditableSearchQueryState {
    class Tag(
        namespace: String? = null,
        tag: String = "",
        expanded: Boolean = false,
    ) : EditableSearchQueryState {
        val namespace = mutableStateOf(namespace)
        val tag = mutableStateOf(tag)
        val expanded = mutableStateOf(expanded)
    }

    class And(queries: List<EditableSearchQueryState> = emptyList()) : EditableSearchQueryState {
        val queries = queries.toMutableStateList()
    }

    class Or(queries: List<EditableSearchQueryState> = emptyList()) : EditableSearchQueryState {
        val queries = queries.toMutableStateList()
    }

    class Not(query: EditableSearchQueryState? = null) : EditableSearchQueryState {
        val query = mutableStateOf(query)
    }

    class FavoriteArtists : EditableSearchQueryState

    class ReadLater : EditableSearchQueryState

    class Root(query: EditableSearchQueryState? = null) {
        val query = mutableStateOf(query)
    }
}

private fun SearchQuery.toEditableStateInternal(): EditableSearchQueryState = when (this) {
    is SearchQuery.Tag -> EditableSearchQueryState.Tag(namespace, tag)
    is SearchQuery.And -> EditableSearchQueryState.And(queries.map { it.toEditableStateInternal() })
    is SearchQuery.Or -> EditableSearchQueryState.Or(queries.map { it.toEditableStateInternal() })
    is SearchQuery.Not -> EditableSearchQueryState.Not(query.toEditableStateInternal())
    is SearchQuery.FavoriteArtists -> EditableSearchQueryState.FavoriteArtists()
    is SearchQuery.ReadLater -> EditableSearchQueryState.ReadLater()
}

fun SearchQuery?.toEditableState(): EditableSearchQueryState.Root =
    EditableSearchQueryState.Root(this?.toEditableStateInternal())

private fun EditableSearchQueryState.toSearchQueryInternal(): SearchQuery? = when (this) {
    is EditableSearchQueryState.Tag ->
        if (namespace.value != null || tag.value.isNotBlank())
            SearchQuery.Tag(namespace.value, tag.value.lowercase().trim())
        else null

    is EditableSearchQueryState.And ->
        queries.mapNotNull { it.toSearchQueryInternal() }
            .let { if (it.isNotEmpty()) SearchQuery.And(it) else null }

    is EditableSearchQueryState.Or ->
        queries.mapNotNull { it.toSearchQueryInternal() }
            .let { if (it.isNotEmpty()) SearchQuery.Or(it) else null }

    is EditableSearchQueryState.Not ->
        query.value?.toSearchQueryInternal()?.let { SearchQuery.Not(it) }

    is EditableSearchQueryState.FavoriteArtists -> SearchQuery.FavoriteArtists

    is EditableSearchQueryState.ReadLater -> SearchQuery.ReadLater
}

fun EditableSearchQueryState.Root.toSearchQuery(): SearchQuery? =
    query.value?.toSearchQueryInternal()

//endregion

/** What [TagInputField] holds before it is committed. */
@Stable
class TagInputState {
    var namespace by mutableStateOf<String?>(null)
    var tag by mutableStateOf("")

    val pendingTag: SearchQuery.Tag?
        get() {
            val (area, name) = splitNamespace(tag, namespace)

            return name.lowercase().trim().takeIf { it.isNotBlank() }?.let { SearchQuery.Tag(area, it) }
        }

    fun clear() {
        namespace = null
        tag = ""
    }
}

@Stable
class QueryEditorController(
    val root: EditableSearchQueryState.Root,
) : SearchEditorController {

    val input = TagInputState()

    override fun commitQuery(): SearchQuery? {
        input.pendingTag?.let(::commit)
        input.clear()

        return root.toSearchQuery()
    }

    override val isEmpty: Boolean
        get() = root.query.value == null && input.tag.isEmpty() && input.namespace == null

    var orMode by mutableStateOf(false)
        private set

    var notMode by mutableStateOf(false)
        private set

    var openOrGroup by mutableStateOf<EditableSearchQueryState.Or?>(null)
        private set

    fun toggleOr() {
        orMode = !orMode

        if (!orMode) closeOrGroup()
    }

    fun toggleNot() {
        notMode = !notMode
    }

    fun commit(tag: SearchQuery.Tag) =
        commitLeaf(EditableSearchQueryState.Tag(tag.namespace, tag.tag))

    fun commitFavoriteArtists() = commitLeaf(EditableSearchQueryState.FavoriteArtists())

    fun commitReadLater() = commitLeaf(EditableSearchQueryState.ReadLater())

    private fun commitLeaf(leaf: EditableSearchQueryState) {
        val term: EditableSearchQueryState =
            if (notMode) EditableSearchQueryState.Not(leaf) else leaf

        if (!orMode) {
            and(term)
            return
        }

        val group = openOrGroup ?: EditableSearchQueryState.Or().also {
            openOrGroup = it
            and(it)
        }

        group.queries.add(term)
    }

    fun remove(term: EditableSearchQueryState) {
        if (term === openOrGroup) openOrGroup = null

        replace(term, null)
    }

    override fun clear() {
        openOrGroup = null
        root.query.value = null
        input.clear()
    }

    override fun replaceWith(query: SearchQuery?) {
        openOrGroup = null
        input.clear()
        orMode = false
        notMode = false
        root.query.value = query.toEditableState().query.value
    }

    private fun and(term: EditableSearchQueryState) {
        val current = root.query.value

        root.query.value = when (current) {
            null -> term
            is EditableSearchQueryState.And -> current.apply { queries.add(term) }
            else -> EditableSearchQueryState.And(listOf(current, term))
        }
    }

    private fun closeOrGroup() {
        val group = openOrGroup ?: return
        openOrGroup = null

        if (group.queries.size != 1) return

        replace(group, group.queries.single())
    }

    private fun replace(old: EditableSearchQueryState, new: EditableSearchQueryState?) {
        val current = root.query.value

        when {
            current === old -> root.query.value = new

            current is EditableSearchQueryState.And -> {
                val index = current.queries.indexOfFirst { it === old }
                if (index < 0) return

                if (new == null) current.queries.removeAt(index)
                else current.queries[index] = new

                when (current.queries.size) {
                    0 -> root.query.value = null
                    1 -> root.query.value = current.queries.single()
                }
            }
        }
    }
}

/**
 * What Hitomi's tag index offers for [query]. A 404 is the index answering that
 * it has nothing filed under that prefix; anything else is a failure to reach
 * it, which the reader is told about rather than shown an empty list.
 */
private suspend fun suggestionsFor(query: String): List<Suggestion> =
    try {
        hitomiClient.getSuggestionsForQuery(query)
    } catch (e: HitomiResponseException) {
        if (e.statusCode == HttpStatusCode.NotFound.value) emptyList() else throw e
    }

/**
 * Tags to offer for a partly typed [tag], from Hitomi's index and -- since that
 * index is in English only -- from every tag whose translation in the reader's
 * own language matches what they typed.
 */
private suspend fun suggestTags(namespace: String?, tag: String): List<SearchQuery.Tag> =
    coroutineScope {
        fun queryFor(term: String) = if (namespace == null) term else "$namespace:$term"

        val typed = async { suggestionsFor(queryFor(tag)) }

        val translated = translations.tagsMatchingTranslation(tag).map { englishTag ->
            async {
                suggestionsFor(queryFor(englishTag))
                    .filter { it.s.equals(englishTag, ignoreCase = true) }
                    .sortedByDescending { it.t }
            }
        }

        (listOf(typed) + translated)
            .awaitAll()
            .flatten()
            .map { SearchQuery.Tag(it.n.ifEmpty { null }, it.s) }
            .distinct()
            .filterNot { it.namespace == namespace && it.tag == tag }
    }

@Composable
internal fun TagSuggestionList(
    namespace: String?,
    tag: String,
    onPickFavoriteArtists: (() -> Unit)? = null,
    onPickReadLater: (() -> Unit)? = null,
    suggestFavorites: Boolean = true,
    onPick: (SearchQuery.Tag) -> Unit,
) {
    val showPresets = namespace == null && tag.isBlank()

    var suggestionList: Result<List<SearchQuery.Tag>>? by remember { mutableStateOf(null) }
    var lastReportedFailure: String? by remember { mutableStateOf(null) }

    LaunchedEffect(namespace, tag) {
        suggestionList = null

        if (showPresets) return@LaunchedEffect

        delay(200) // debounce keystrokes

        suggestionList = withContext(Dispatchers.IO) {
            try {
                Result.success(suggestTags(namespace, tag))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val field = namespace ?: "text"
                val failure = "$field ${e::class.qualifiedName} ${e.message}"

                if (failure != lastReportedFailure) {
                    lastReportedFailure = failure
                    Crashlytics.log("tag suggestions for $field failed")
                    Crashlytics.recordException(e)
                }

                Result.failure(e)
            }
        }
    }

    // Taken once per list rather than read live: unfavouriting a tag from here
    // leaves the row in place, so the tap can be taken back.
    val favorites = remember(showPresets, suggestFavorites) {
        if (suggestFavorites) favoriteTags.items.map { SearchQuery.Tag(it.area, it.tag) }
        else emptyList()
    }

    val result = if (showPresets) Result.success(favorites) else suggestionList

    when (result) {
        null -> LoadingRow()

        else -> result.fold(
            onSuccess = { suggestions ->
                val pickFavoriteArtists = onPickFavoriteArtists.takeIf { showPresets }
                val pickReadLater = onPickReadLater.takeIf { showPresets }

                val hasContent = suggestions.isNotEmpty() ||
                    pickFavoriteArtists != null ||
                    pickReadLater != null

                if (hasContent) Column(Modifier.padding(vertical = 4.dp)) {
                    if (pickFavoriteArtists != null)
                        FavoriteArtistsSuggestionRow(onClick = pickFavoriteArtists)

                    if (pickReadLater != null) ReadLaterSuggestionRow(onClick = pickReadLater)

                    suggestions.forEach { suggestion ->
                        TagSuggestionRow(
                            tag = suggestion.toString(),
                            onClick = { onPick(suggestion) },
                            content = { area, tagPart ->
                                val label = tagLabel(area, tagPart)

                                Text(
                                    text = if (label.equals(tagPart, ignoreCase = true)) label
                                    else "$label ($tagPart)",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                        )
                    }
                }
            },
            onFailure = { SuggestionErrorRow() },
        )
    }
}

@Composable
internal fun LoadingRow() {
    Row(
        Modifier.padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(Modifier.size(24.dp))
        Text(stringResource(R.string.reader_loading))
    }
}

@Composable
private fun SuggestionErrorRow() {
    Row(
        Modifier.padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.error) {
            Icon(
                imageVector = Icons.Default.CloudOff,
                contentDescription = null,
                modifier = Modifier.size(24.dp),
            )
            Text(stringResource(R.string.unable_to_connect))
        }
    }
}

/** What a gallery ID resolves to while the search field holds one. */
internal sealed interface GalleryLookup {
    data object Loading : GalleryLookup
    data class Found(val block: GalleryBlock) : GalleryLookup
    data object NotFound : GalleryLookup
}

/** The gallery a typed ID names, offered in place of the tag suggestions. */
@Composable
internal fun GalleryHit(block: GalleryBlock, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RemoteImage(
                url = block.thumbnails.firstOrNull(),
                modifier = Modifier.size(width = 48.dp, height = 64.dp),
            )

            Column(Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.main_open_gallery_by_id),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = block.title,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = block.id.toString(),
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

@Composable
internal fun rememberGalleryLookup(galleryID: Int?): GalleryLookup? {
    val lookup by produceState<GalleryLookup?>(null, galleryID) {
        value = null

        val id = galleryID ?: return@produceState

        value = GalleryLookup.Loading

        delay(200) // debounce keystrokes

        value = withContext(Dispatchers.IO) {
            runCatching { hitomiClient.getGalleryBlock(id) }
                .fold({ GalleryLookup.Found(it) }, { GalleryLookup.NotFound })
        }
    }

    return lookup
}

@Composable
private fun TagTextField(
    namespace: String?,
    tag: String,
    onNamespaceChange: (String?) -> Unit,
    onTagChange: (String) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() },
    onFocusChanged: (Boolean) -> Unit = { },
) {
    var textFieldValue by remember {
        mutableStateOf(TextFieldValue(tag, TextRange(tag.length)))
    }

    if (textFieldValue.text != tag) {
        textFieldValue = TextFieldValue(tag, TextRange(tag.length))
    }

    OutlinedTextField(
        value = textFieldValue,
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.None,
            autoCorrectEnabled = false,
            imeAction = ImeAction.Done,
        ),
        leadingIcon = { TagChipIcon(namespace.orEmpty(), tag) },
        modifier = modifier
            .onKeyEvent { event ->
                when {
                    // Backspace on an empty tag drops back into the namespace.
                    event.key == Key.Backspace && tag.isEmpty() -> {
                        onNamespaceChange(null)
                        onTagChange(namespace?.dropLast(1) ?: "")
                        true
                    }

                    // A hardware Enter never reaches the IME action, and both
                    // halves of the press have to be swallowed here: the search
                    // card's click activates on the key up and would collapse
                    // the bar out from under the commit.
                    event.key == Key.Enter || event.key == Key.NumPadEnter -> {
                        if (event.type == KeyEventType.KeyDown) onDone()
                        true
                    }

                    else -> false
                }
            }
            .focusRequester(focusRequester)
            .onFocusChanged { onFocusChanged(it.isFocused) },
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        onValueChange = { newValue ->
            val newTag = newValue.text
            val possibleNamespace = newTag.dropLast(1).lowercase().trim()

            // Typing "female:" promotes the text to a namespace. Only the colon
            // that has just been typed does so: emptying the field costs
            // whatever else is arriving in the same breath, and text that came
            // in carrying its own prefix is split by [commit] anyway.
            if (namespace == null && newTag.endsWith(':') && possibleNamespace in validNamespace) {
                onNamespaceChange(possibleNamespace)
                onTagChange("")
            } else onTagChange(newTag)

            textFieldValue = newValue
        },
    )
}

/**
 * The namespace and tag [text] carries, splitting off a `female:` prefix it
 * still has on it.
 *
 * Text arrives in whatever chunks the keyboard sends -- a word committed whole,
 * a paste, an autocompletion -- and a chunk carrying both halves at once never
 * ends on the colon that would have promoted its prefix to a namespace. Left
 * alone it was committed as one flat tag, `language:korean`, which hitomi reads
 * as the language `korean` but which nothing else in the app can take apart.
 */
internal fun splitNamespace(text: String, namespace: String?): Pair<String?, String> {
    val colon = text.indexOf(':')
    if (colon < 0) return namespace to text

    val prefix = text.take(colon).lowercase().trim()
    if (prefix !in validNamespace) return namespace to text

    return prefix to text.substring(colon + 1)
}

@Composable
fun TagInputField(
    onCommit: (SearchQuery.Tag) -> Unit,
    // Only the search bar opens galleries; the filter editor just collects tags.
    onOpenGallery: ((Int) -> Unit)? = null,
    modifier: Modifier = Modifier,
    state: TagInputState = remember { TagInputState() },
    onCommitFavoriteArtists: (() -> Unit)? = null,
    onCommitReadLater: (() -> Unit)? = null,
    onSubmitEmpty: (() -> Unit)? = null,
    suggestFavorites: Boolean = true,
    autoFocus: Boolean = true,
    suggestionsAbove: Boolean = false,
    leading: @Composable () -> Unit = { },
    trailing: (@Composable () -> Unit)? = null,
) {
    var namespace by state::namespace
    var tag by state::tag
    var focused by remember { mutableStateOf(false) }

    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(autoFocus) {
        if (autoFocus) runCatching { focusRequester.requestFocus() }
    }

    fun reset() {
        state.clear()

        runCatching { focusRequester.requestFocus() }
        keyboard?.show()
    }

    fun commit() {
        onCommit(state.pendingTag ?: return)
        reset()
    }

    val galleryID = tag.trim()
        .takeIf { onOpenGallery != null && namespace == null && it.isNotEmpty() && it.all(Char::isDigit) }
        ?.toIntOrNull()

    val lookup = rememberGalleryLookup(galleryID)

    val suggestFor = splitNamespace(tag, namespace)

    // Enter on a number opens the gallery it names, so a press that lands
    // before the lookup does waits for it rather than searching for the digits.
    var openRequested by remember { mutableStateOf(false) }

    fun open(id: Int) {
        openRequested = false
        state.clear()

        onOpenGallery?.invoke(id)
    }

    LaunchedEffect(openRequested, lookup) {
        if (!openRequested) return@LaunchedEffect

        when (val current = lookup) {
            is GalleryLookup.Found -> open(current.block.id)
            GalleryLookup.NotFound -> { openRequested = false; commit() }
            else -> Unit
        }
    }

    val suggestions: @Composable () -> Unit = {
        when (val current = lookup) {
            is GalleryLookup.Found -> GalleryHit(current.block) { open(current.block.id) }

            GalleryLookup.Loading -> LoadingRow()

            // A number nothing answers to is just another tag to search for.
            else -> TagSuggestionList(
                namespace = suggestFor.first,
                tag = suggestFor.second,
                onPickFavoriteArtists = onCommitFavoriteArtists?.let { commitFavorites ->
                    { commitFavorites(); reset() }
                },
                onPickReadLater = onCommitReadLater?.let { commitReadLater ->
                    { commitReadLater(); reset() }
                },
                suggestFavorites = suggestFavorites,
                onPick = { onCommit(it); reset() },
            )
        }
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 4.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
        ) {
            if (suggestionsAbove && focused) Box(
                Modifier
                    .weight(1f, fill = false)
                    .heightIn(max = 280.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                suggestions()
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                leading()

                TagTextField(
                    namespace = namespace,
                    tag = tag,
                    onNamespaceChange = { namespace = it },
                    onTagChange = { tag = it },
                    onDone = {
                        when {
                            tag.isBlank() -> onSubmitEmpty?.invoke()
                            galleryID == null -> commit()
                            else -> openRequested = true
                        }
                    },
                    modifier = Modifier.weight(1f),
                    focusRequester = focusRequester,
                    onFocusChanged = { focused = it },
                )

                trailing?.invoke()
            }

            if (!suggestionsAbove && focused) suggestions()
        }
    }
}

@Composable
private fun ModeToggle(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary
        else MaterialTheme.colorScheme.onSurfaceVariant,
    ) {
        Box(
            modifier = Modifier
                .height(32.dp)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

/** A tag chip that expands in place into a text field plus suggestions. */
@Composable
fun EditableTagChip(
    state: EditableSearchQueryState.Tag,
    autoFocus: Boolean = true,
    requestScrollTo: (Float) -> Unit,
    rightIcon: @Composable RowScope.() -> Unit = { Spacer(Modifier.width(16.dp)) },
) {
    val coroutineScope = rememberCoroutineScope()

    var namespace by state.namespace
    var tag by state.tag
    var expanded by state.expanded
    var wasFocused by remember { mutableStateOf(false) }
    var positionY by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(expanded) {
        if (!expanded) wasFocused = false
    }

    val surfaceColor by animateColorAsState(
        when {
            expanded -> MaterialTheme.colorScheme.surface
            namespace == "male" -> TagColors.Male
            namespace == "female" -> TagColors.Female
            else -> MaterialTheme.colorScheme.surfaceVariant
        },
        label = "tagSurfaceColor",
    )

    val contentColor by animateColorAsState(
        when {
            expanded -> MaterialTheme.colorScheme.onSurface
            namespace == "male" || namespace == "female" -> Color.White
            else -> MaterialTheme.colorScheme.onSurfaceVariant
        },
        label = "tagContentColor",
    )

    Surface(
        modifier = Modifier.onGloballyPositioned { positionY = it.positionInRoot().y },
        shape = RoundedCornerShape(16.dp),
        color = surfaceColor,
        shadowElevation = 4.dp,
    ) {
        AnimatedContent(targetState = expanded, label = "openTagEditor") { targetExpanded ->
            if (!targetExpanded) {
                CompositionLocalProvider(
                    LocalContentColor provides contentColor,
                    LocalTextStyle provides MaterialTheme.typography.bodyMedium,
                ) {
                    Row(
                        modifier = Modifier
                            .height(32.dp)
                            .clickable { expanded = true },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        TagChipIcon(namespace.orEmpty(), tag)
                        Text(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            text = if (tag.isBlank()) stringResource(R.string.search_bar_edit_tag)
                            else tagLabel(namespace.orEmpty(), tag),
                        )
                        rightIcon()
                    }
                }
            } else {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 8.dp, end = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { expanded = false }) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = stringResource(
                                    R.string.search_bar_close_tag_editor,
                                ),
                            )
                        }

                        val focusRequester = remember { FocusRequester() }

                        LaunchedEffect(expanded) {
                            if (autoFocus && expanded) {
                                runCatching { focusRequester.requestFocus() }
                            }
                        }

                        TagTextField(
                            namespace = namespace,
                            tag = tag,
                            onNamespaceChange = { namespace = it },
                            onTagChange = { tag = it },
                            onDone = { expanded = false },
                            modifier = Modifier.fillMaxWidth(),
                            focusRequester = focusRequester,
                            onFocusChanged = { focused ->
                                if (focused) {
                                    wasFocused = true
                                    coroutineScope.launch {
                                        delay(300)
                                        requestScrollTo(positionY)
                                    }
                                } else if (wasFocused) {
                                    expanded = false
                                }
                            },
                        )
                    }

                    TagSuggestionList(namespace, tag) { suggestion ->
                        namespace = suggestion.namespace
                        tag = suggestion.tag
                        expanded = false
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupCard(
    label: String,
    containerColor: Color,
    active: Boolean,
    onRemove: () -> Unit,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = if (active) Modifier.border(
            width = 2.dp,
            color = MaterialTheme.colorScheme.primary,
            shape = CardDefaults.shape,
        ) else Modifier,
        colors = CardDefaults.cardColors(
            containerColor = containerColor,
            contentColor = Color.Black,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.Start,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    label,
                    modifier = Modifier.padding(horizontal = 8.dp),
                    style = MaterialTheme.typography.labelMedium,
                )
                Icon(
                    modifier = Modifier
                        .size(16.dp)
                        .clickable(onClick = onRemove),
                    imageVector = Icons.Default.RemoveCircleOutline,
                    contentDescription = stringResource(R.string.search_remove_query_item_description),
                )
            }
            content()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TermRow(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        content = { content() },
    )
}

@Composable
fun QueryEditorQueryView(
    state: EditableSearchQueryState,
    activeOrGroup: EditableSearchQueryState.Or?,
    onQueryRemove: (EditableSearchQueryState) -> Unit,
    requestScrollTo: (Float) -> Unit,
) {
    when (state) {
        is EditableSearchQueryState.Tag -> EditableTagChip(
            state,
            requestScrollTo = requestScrollTo,
            rightIcon = {
                Icon(
                    modifier = Modifier
                        .padding(8.dp)
                        .size(16.dp)
                        .clickable { onQueryRemove(state) },
                    imageVector = Icons.Default.RemoveCircleOutline,
                    contentDescription = stringResource(R.string.search_remove_query_item_description),
                )
            },
        )

        is EditableSearchQueryState.FavoriteArtists -> FavoriteArtistsChip(
            rightIcon = { _, _ ->
                Icon(
                    modifier = Modifier
                        .padding(8.dp)
                        .size(16.dp)
                        .clickable { onQueryRemove(state) },
                    imageVector = Icons.Default.RemoveCircleOutline,
                    contentDescription = stringResource(R.string.search_remove_query_item_description),
                )
            },
        )

        is EditableSearchQueryState.ReadLater -> ReadLaterChip(
            rightIcon = { _, _ ->
                Icon(
                    modifier = Modifier
                        .padding(8.dp)
                        .size(16.dp)
                        .clickable { onQueryRemove(state) },
                    imageVector = Icons.Default.RemoveCircleOutline,
                    contentDescription = stringResource(R.string.search_remove_query_item_description),
                )
            },
        )

        is EditableSearchQueryState.Or -> GroupCard(
            label = "OR",
            containerColor = Blue300,
            active = state === activeOrGroup,
            onRemove = { onQueryRemove(state) },
        ) {
            TermRow {
                state.queries.forEachIndexed { index, subQuery ->
                    if (index != 0) Text("+", modifier = Modifier.padding(horizontal = 4.dp))
                    QueryEditorQueryView(
                        state = subQuery,
                        activeOrGroup = activeOrGroup,
                        onQueryRemove = {
                            state.queries.remove(it)
                            if (state.queries.isEmpty()) onQueryRemove(state)
                        },
                        requestScrollTo = requestScrollTo,
                    )
                }
            }
        }

        is EditableSearchQueryState.And -> TermRow {
            state.queries.forEach { subQuery ->
                QueryEditorQueryView(
                    state = subQuery,
                    activeOrGroup = activeOrGroup,
                    onQueryRemove = {
                        state.queries.remove(it)
                        if (state.queries.isEmpty()) onQueryRemove(state)
                    },
                    requestScrollTo = requestScrollTo,
                )
            }
        }

        is EditableSearchQueryState.Not -> Row(
            modifier = Modifier
                .border(1.dp, Red300, RoundedCornerShape(20.dp))
                .padding(start = 8.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("−", color = Red300, style = MaterialTheme.typography.titleMedium)

            state.query.value?.let { subQuery ->
                QueryEditorQueryView(
                    state = subQuery,
                    activeOrGroup = activeOrGroup,
                    onQueryRemove = { onQueryRemove(state) },
                    requestScrollTo = requestScrollTo,
                )
            }
        }
    }
}

@Composable
fun QueryEditor(
    controller: QueryEditorController,
    onOpenGallery: (Int) -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scrollState = rememberScrollState()
    var topY by remember { mutableFloatStateOf(0f) }

    val scrollOffset = with(LocalDensity.current) { 16.dp.toPx() }
    val coroutineScope = rememberCoroutineScope()

    val requestScrollTo: (Float) -> Unit = { target ->
        val topYSnapshot = topY
        coroutineScope.launch {
            scrollState.animateScrollBy(
                target - topYSnapshot - scrollOffset,
                spring(stiffness = Spring.StiffnessLow),
            )
        }
    }

    BoxWithConstraints(modifier) {
        val inputMaxHeight = if (controller.root.query.value != null)
            (maxHeight - MinQueryHeight).coerceAtLeast(0.dp)
        else
            maxHeight

        Column(Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .onGloballyPositioned { topY = it.positionInRoot().y }
                    .verticalScroll(scrollState)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                when (val root = controller.root.query.value) {
                    null -> Unit

                    is EditableSearchQueryState.And -> TermRow {
                        root.queries.forEach { term ->
                            QueryEditorQueryView(
                                state = term,
                                activeOrGroup = controller.openOrGroup,
                                onQueryRemove = controller::remove,
                                requestScrollTo = requestScrollTo,
                            )
                        }
                    }

                    else -> QueryEditorQueryView(
                        state = root,
                        activeOrGroup = controller.openOrGroup,
                        onQueryRemove = controller::remove,
                        requestScrollTo = requestScrollTo,
                    )
                }
            }

            TagInputField(
                onCommit = controller::commit,
                onOpenGallery = onOpenGallery,
                state = controller.input,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = inputMaxHeight)
                    .padding(8.dp),
                onCommitFavoriteArtists = controller::commitFavoriteArtists,
                onCommitReadLater = controller::commitReadLater,
                onSubmitEmpty = onSubmit,
                suggestionsAbove = true,
                leading = {
                    ModeToggle("−", selected = controller.notMode, onClick = controller::toggleNot)
                },
                trailing = {
                    ModeToggle("OR", selected = controller.orMode, onClick = controller::toggleOr)
                },
            )
        }
    }
}
