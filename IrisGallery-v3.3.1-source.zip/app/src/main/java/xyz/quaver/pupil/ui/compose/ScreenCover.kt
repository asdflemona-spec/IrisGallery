/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.runtime.compositionLocalOf

/**
 * Whether a page is drawn over the screens below, which then own neither the back
 * key nor the volume keys.
 *
 * Both key dispatchers offer a key to whatever registered last, which is the
 * covering page only for as long as nothing underneath it composes again. A
 * navigation rebuilds the screen it leaves behind, and that screen registers after
 * the page covering it and takes the keys from it. Screens ask this rather than
 * trusting that order.
 */
val LocalScreenCovered = compositionLocalOf { false }
