/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.R
import xyz.quaver.pupil.util.DefaultQuery
import xyz.quaver.pupil.watchlist

@Composable
fun rememberLanguageOptions(): List<Pair<String, String>> {
    val languages = stringArrayResource(R.array.languages)

    return remember(languages) {
        languages.mapNotNull { entry ->
            entry.split('|', limit = 2).takeIf { it.size == 2 }?.let { (code, name) -> code to name }
        }
    }
}

@Composable
fun SearchCardFooter(
    onHistoryClick: () -> Unit,
    onWatchlistClick: () -> Unit,
    onFiltersClick: () -> Unit,
    onClearClick: () -> Unit,
    clearEnabled: Boolean,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LanguageSelector(Modifier.weight(1f))

        IconButton(onClick = onHistoryClick) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = stringResource(R.string.search_history_title),
            )
        }

        IconButton(onClick = onWatchlistClick) {
            Icon(
                imageVector = if (watchlist.items.any { it.newCount > 0 })
                    Icons.Default.NotificationsActive
                else
                    Icons.Default.NotificationsNone,
                contentDescription = stringResource(R.string.search_watchlist_title),
            )
        }

        IconButton(onClick = onClearClick, enabled = clearEnabled) {
            Icon(
                imageVector = Icons.Default.DeleteSweep,
                contentDescription = stringResource(R.string.search_clear_query),
            )
        }

        val filterCount = DefaultQuery.bannedTags.size + DefaultQuery.requiredTags.size

        IconButton(onClick = onFiltersClick) {
            Icon(
                imageVector = Icons.Default.FilterAlt,
                contentDescription =
                    if (filterCount > 0)
                        stringResource(R.string.search_filters_action_count, filterCount)
                    else stringResource(R.string.search_filters_title),
            )
        }
    }
}

@Composable
private fun LanguageSelector(modifier: Modifier = Modifier) {
    val languages = rememberLanguageOptions()
    var expanded by remember { mutableStateOf(false) }

    val selected = DefaultQuery.languages
    val anyLanguage = stringResource(R.string.default_query_dialog_language_selector_none)

    val label = when (selected.size) {
        0 -> anyLanguage
        else -> languages.filter { it.first in selected }
            .let { picked ->
                val first = picked.firstOrNull()?.second ?: anyLanguage
                if (picked.size <= 1) first
                else stringResource(R.string.search_language_more, first, picked.size - 1)
            }
    }

    Box(modifier) {
        TextButton(onClick = { expanded = true }) {
            Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                text = label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.heightIn(max = 320.dp),
        ) {
            LanguageItem(
                label = anyLanguage,
                selected = selected.isEmpty(),
                onClick = DefaultQuery::clearLanguages,
            )

            HorizontalDivider()

            languages.forEach { (code, name) ->
                LanguageItem(
                    label = name,
                    selected = code in selected,
                    onClick = { DefaultQuery.toggleLanguage(code) },
                )
            }
        }
    }
}

@Composable
private fun LanguageItem(label: String, selected: Boolean, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label) },
        onClick = onClick,
        leadingIcon = {
            Checkbox(checked = selected, onCheckedChange = null)
        },
    )
}
