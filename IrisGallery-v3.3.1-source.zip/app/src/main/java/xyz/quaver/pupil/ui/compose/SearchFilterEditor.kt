/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.util.DefaultQuery

private class BannedTagPreset(val labelRes: Int, val tags: List<SearchQuery.Tag>)

private val bannedTagPresets = listOf(
    BannedTagPreset(
        R.string.default_query_dialog_filter_BL,
        listOf(SearchQuery.Tag("male", "yaoi")),
    ),
    BannedTagPreset(
        R.string.default_query_dialog_filter_guro,
        listOf(SearchQuery.Tag("female", "guro"), SearchQuery.Tag("male", "guro")),
    ),
    BannedTagPreset(
        R.string.default_query_dialog_filter_loli,
        listOf(SearchQuery.Tag("female", "loli"), SearchQuery.Tag("male", "shota")),
    ),
)

@Composable
fun SearchFilterEditor(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()

    Column(modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.search_filters_back),
                )
            }
            Text(
                text = stringResource(R.string.search_filters_title),
                style = MaterialTheme.typography.titleMedium,
            )
        }

        HorizontalDivider()

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            TagSection(
                title = stringResource(R.string.search_banned_tags_title),
                description = stringResource(R.string.search_banned_tags_description),
                tags = DefaultQuery.bannedTags,
                removeDescription = stringResource(R.string.search_banned_tags_remove),
                onRemove = DefaultQuery::unban,
                onAdd = DefaultQuery::ban,
            ) {
                bannedTagPresets.forEach { preset ->
                    val checked = preset.tags.all { DefaultQuery.isBanned(it) }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (checked) preset.tags.forEach(DefaultQuery::unban)
                                else preset.tags.forEach(DefaultQuery::ban)
                            },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked, onCheckedChange = null)
                        Spacer(Modifier.width(12.dp))
                        Text(stringResource(preset.labelRes))
                    }
                }
            }

            HorizontalDivider()

            TagSection(
                title = stringResource(R.string.search_required_tags_title),
                description = stringResource(R.string.search_required_tags_description),
                tags = DefaultQuery.requiredTags,
                removeDescription = stringResource(R.string.search_required_tags_remove),
                onRemove = DefaultQuery::removeRequired,
                onAdd = DefaultQuery::addRequired,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TagSection(
    title: String,
    description: String,
    tags: List<SearchQuery.Tag>,
    removeDescription: String,
    onRemove: (SearchQuery.Tag) -> Unit,
    onAdd: (SearchQuery.Tag) -> Unit,
    presets: @Composable () -> Unit = {},
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
        )

        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        presets()

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            tags.forEach { tag ->
                TagChip(
                    tag = tag.toString(),
                    enabled = false,
                    rightIcon = { _, _ ->
                        Icon(
                            modifier = Modifier
                                .padding(8.dp)
                                .size(16.dp)
                                .clickable { onRemove(tag) },
                            imageVector = Icons.Default.Cancel,
                            contentDescription = removeDescription,
                        )
                    },
                )
            }
        }

        TagInputField(
            onCommit = onAdd,
            modifier = Modifier.fillMaxWidth(),
            suggestFavorites = false,
            autoFocus = false,
        )
    }
}
