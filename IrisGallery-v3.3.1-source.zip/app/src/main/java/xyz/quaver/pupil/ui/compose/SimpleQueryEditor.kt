/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.parseQueryTerm
import xyz.quaver.pupil.hitomi.parseQueryText
import xyz.quaver.pupil.hitomi.termAt
import xyz.quaver.pupil.hitomi.toQueryText

@Stable
class SimpleQueryController(query: SearchQuery?) : SearchEditorController {

    /**
     * The query for as long as plain text cannot spell it. Held whole so that
     * opening the bar on one built elsewhere -- an OR group picked out of the
     * history, a search handed over from another list -- does not drop it, and
     * given up the moment something is typed over it.
     */
    var unspellableQuery by mutableStateOf(query?.takeIf { it.toQueryText() == null })
        private set

    var text by mutableStateOf(query?.toQueryText().orEmpty())
        private set

    override fun commitQuery(): SearchQuery? = unspellableQuery ?: parseQueryText(text)

    override val isEmpty: Boolean
        get() = unspellableQuery == null && text.isBlank()

    fun onTextChange(newText: String) {
        unspellableQuery = null
        text = newText
    }

    override fun clear() = onTextChange("")

    override fun replaceWith(query: SearchQuery?) {
        unspellableQuery = query?.takeIf { it.toQueryText() == null }
        text = query?.toQueryText().orEmpty()
    }
}

/**
 * The whole query as one line of text, with the favourite tags -- or whatever
 * the term under the cursor suggests -- to pick from underneath.
 */
@Composable
fun SimpleQueryEditor(
    controller: SimpleQueryController,
    onOpenGallery: (Int) -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val focusRequester = remember { FocusRequester() }

    var fieldValue by remember {
        mutableStateOf(TextFieldValue(controller.text, TextRange(controller.text.length)))
    }

    if (fieldValue.text != controller.text)
        fieldValue = TextFieldValue(controller.text, TextRange(controller.text.length))

    LaunchedEffect(Unit) { runCatching { focusRequester.requestFocus() } }

    val term = termAt(fieldValue.text, fieldValue.selection.min)
    val negated = term.text.startsWith('-')
    val tag = parseQueryTerm(term.text.removePrefix("-"))

    fun replaceTerm(replacement: String) {
        val text = fieldValue.text
        // Room to type the next term, but only where the picked one ends the
        // line: mid-line the space that separates it is already there.
        val trailingSpace = if (term.end == text.length) " " else ""

        val newText = text.take(term.start) + replacement + trailingSpace + text.drop(term.end)

        controller.onTextChange(newText)
        fieldValue = TextFieldValue(
            text = newText,
            selection = TextRange(term.start + replacement.length + trailingSpace.length),
        )
    }

    val galleryID = fieldValue.text.trim()
        .takeIf { it.isNotEmpty() && it.all(Char::isDigit) }
        ?.toIntOrNull()

    val lookup = rememberGalleryLookup(galleryID)

    Column(modifier) {
        controller.unspellableQuery?.let { query ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                QueryView(query)
            }
        }

        TextField(
            value = fieldValue,
            onValueChange = {
                fieldValue = it
                controller.onTextChange(it.text)
            },
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focusRequester)
                // A hardware Enter never reaches the IME action, and both halves
                // of the press have to be swallowed here: the search card's
                // click activates on the key up and would collapse the bar a
                // second time, reopening it.
                .onKeyEvent { event ->
                    when (event.key) {
                        Key.Enter, Key.NumPadEnter -> {
                            if (event.type == KeyEventType.KeyDown) onSubmit()
                            true
                        }

                        else -> false
                    }
                },
            placeholder = { Text(stringResource(R.string.search_hint)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                autoCorrectEnabled = false,
                imeAction = ImeAction.Search,
            ),
            keyboardActions = KeyboardActions(onSearch = { onSubmit() }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
            textStyle = MaterialTheme.typography.titleMedium,
        )

        HorizontalDivider()

        Box(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
        ) {
            when (lookup) {
                is GalleryLookup.Found -> GalleryHit(lookup.block) { onOpenGallery(lookup.block.id) }

                GalleryLookup.Loading -> LoadingRow()

                // A number nothing answers to is just another tag to search for.
                else -> TagSuggestionList(
                    namespace = tag.namespace,
                    tag = tag.tag,
                    onPick = { picked ->
                        replaceTerm(
                            (if (negated) "-" else "") + picked.toString().replace(' ', '_'),
                        )
                    },
                )
            }
        }
    }
}
