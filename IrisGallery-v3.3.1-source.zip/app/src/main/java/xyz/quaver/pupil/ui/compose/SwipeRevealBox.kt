/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.animation.core.tween
import androidx.compose.animation.rememberSplineBasedDecay
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.AnchoredDraggableState
import androidx.compose.foundation.gestures.DraggableAnchors
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.anchoredDraggable
import androidx.compose.foundation.gestures.animateTo
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

private enum class SwipeReveal { Closed, Open }

/** Which [SwipeRevealBox] in a list has its actions out, so opening one closes the rest. */
class SwipeRevealGroup {
    var openKey: Any? by mutableStateOf(null)
}

val LocalSwipeRevealGroup = staticCompositionLocalOf<SwipeRevealGroup?> { null }

/**
 * [content] that slides toward the start edge to pull [actions] out from behind
 * it. While they are out, a tap on [content] only slides it back.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SwipeRevealBox(
    key: Any,
    actions: @Composable RowScope.(close: () -> Unit) -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RectangleShape,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    val decay = rememberSplineBasedDecay<Float>()

    val state = remember(key) {
        AnchoredDraggableState(
            initialValue = SwipeReveal.Closed,
            positionalThreshold = { distance -> distance / 2 },
            velocityThreshold = { with(density) { 125.dp.toPx() } },
            snapAnimationSpec = tween(),
            decayAnimationSpec = decay,
        )
    }

    val scope = rememberCoroutineScope()
    val close: () -> Unit = { scope.launch { state.animateTo(SwipeReveal.Closed) } }

    val group = LocalSwipeRevealGroup.current

    LaunchedEffect(state, group) {
        if (group == null) return@LaunchedEffect

        launch {
            snapshotFlow { state.targetValue }.collect {
                if (it == SwipeReveal.Open) group.openKey = key
            }
        }

        snapshotFlow { group.openKey }.collect {
            if (it != key && state.targetValue == SwipeReveal.Open)
                state.animateTo(SwipeReveal.Closed)
        }
    }

    var actionsWidth by remember { mutableStateOf(0) }

    val offset = { state.offset.takeUnless(Float::isNaN)?.roundToInt() ?: 0 }

    Box(modifier) {
        Box(
            Modifier
                .matchParentSize()
                .clip(shape)
        ) {
            Row(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .onSizeChanged { size ->
                        actionsWidth = size.width
                        state.updateAnchors(
                            DraggableAnchors {
                                SwipeReveal.Closed at 0f
                                SwipeReveal.Open at -size.width.toFloat()
                            }
                        )
                    }
                    .offset { IntOffset(actionsWidth + offset(), 0) },
                content = { actions(close) },
            )
        }

        Box(
            Modifier
                .offset { IntOffset(offset(), 0) }
                .anchoredDraggable(state, Orientation.Horizontal)
        ) {
            content()

            if (state.targetValue == SwipeReveal.Open)
                Box(
                    Modifier
                        .matchParentSize()
                        .clickable(interactionSource = null, indication = null, onClick = close)
                )
        }
    }
}
