/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.google.android.material.color.DynamicColors

// Fallback palettes for devices without dynamic color. Material 3 palettes
// generated from the View theme's colorPrimary
// (@color/colorPrimary, light blue 300) as the seed, so the two UIs read as the
// same app while the port is only half done. Generated with the content variant
// rather than the default tonal spot, which caps the primary palette at chroma
// 36 and would wash the seed's 50 out to a grey-blue.
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF006688),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF4FC3F7),
    onPrimaryContainer = Color(0xFF004E69),
    inversePrimary = Color(0xFF75D1FF),
    secondary = Color(0xFF3E6377),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFBFE5FC),
    onSecondaryContainer = Color(0xFF42677B),
    tertiary = Color(0xFF7E4799),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFDDA0F9),
    onTertiaryContainer = Color(0xFF653080),
    background = Color(0xFFF6FAFE),
    onBackground = Color(0xFF171C1F),
    surface = Color(0xFFF6FAFE),
    onSurface = Color(0xFF171C1F),
    surfaceVariant = Color(0xFFD9E4EC),
    onSurfaceVariant = Color(0xFF3E484F),
    surfaceTint = Color(0xFF006688),
    inverseSurface = Color(0xFF2C3134),
    inverseOnSurface = Color(0xFFEDF1F5),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF93000A),
    outline = Color(0xFF6E7980),
    outlineVariant = Color(0xFFBDC8D0),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFFF6FAFE),
    surfaceDim = Color(0xFFD6DADF),
    surfaceContainer = Color(0xFFEAEEF3),
    surfaceContainerHigh = Color(0xFFE4E9ED),
    surfaceContainerHighest = Color(0xFFDFE3E7),
    surfaceContainerLow = Color(0xFFF0F4F8),
    surfaceContainerLowest = Color(0xFFFFFFFF),
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF9ADBFF),
    onPrimary = Color(0xFF003548),
    primaryContainer = Color(0xFF4FC3F7),
    onPrimaryContainer = Color(0xFF004E69),
    inversePrimary = Color(0xFF006688),
    secondary = Color(0xFFA6CCE2),
    onSecondary = Color(0xFF083446),
    secondaryContainer = Color(0xFF274D60),
    onSecondaryContainer = Color(0xFF98BED4),
    tertiary = Color(0xFFEEC4FF),
    onTertiary = Color(0xFF4B1567),
    tertiaryContainer = Color(0xFFDDA0F9),
    onTertiaryContainer = Color(0xFF653080),
    background = Color(0xFF0F1417),
    onBackground = Color(0xFFDFE3E7),
    surface = Color(0xFF0F1417),
    onSurface = Color(0xFFDFE3E7),
    surfaceVariant = Color(0xFF3E484F),
    onSurfaceVariant = Color(0xFFBDC8D0),
    surfaceTint = Color(0xFF75D1FF),
    inverseSurface = Color(0xFFDFE3E7),
    inverseOnSurface = Color(0xFF2C3134),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    outline = Color(0xFF889299),
    outlineVariant = Color(0xFF3E484F),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF353A3D),
    surfaceDim = Color(0xFF0F1417),
    surfaceContainer = Color(0xFF1B2023),
    surfaceContainerHigh = Color(0xFF262B2E),
    surfaceContainerHighest = Color(0xFF303539),
    surfaceContainerLow = Color(0xFF171C1F),
    surfaceContainerLowest = Color(0xFF0A0F12),
)

@Composable
fun PupilTheme(
    useDarkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current

    val colorScheme = when {
        DynamicColors.isDynamicColorAvailable() ->
            if (useDarkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        useDarkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content,
    )
}
