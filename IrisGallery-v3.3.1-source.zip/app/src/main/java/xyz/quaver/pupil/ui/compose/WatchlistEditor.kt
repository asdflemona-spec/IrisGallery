/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.services.WatchlistWorker
import xyz.quaver.pupil.util.Watch
import xyz.quaver.pupil.util.checkNotificationEnabled
import xyz.quaver.pupil.watchlist

/** The watched queries, and what each of them has turned up since you last looked. */
@Composable
fun WatchlistEditor(
    onBack: () -> Unit,
    onPick: (SearchQuery) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val watches = watchlist.items

    Column(modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.search_watchlist_back),
                )
            }
            Text(
                text = stringResource(R.string.search_watchlist_title),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            if (watches.isNotEmpty()) IconButton(
                onClick = { WatchlistWorker.checkNow(context) },
            ) {
                Icon(
                    Icons.Default.Refresh,
                    contentDescription = stringResource(R.string.search_watchlist_check_now),
                )
            }
        }

        HorizontalDivider()

        if (watches.isEmpty()) Box(Modifier.fillMaxSize()) {
            Text(
                text = stringResource(R.string.search_watchlist_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp),
            )
        } else LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(watches) { watch ->
                WatchRow(
                    watch = watch,
                    onClick = {
                        watchlist.markSeen(watch.query)
                        onPick(watch.query)
                    },
                    onRemove = { watchlist.remove(watch.query) },
                )
            }
        }
    }
}

@Composable
private fun WatchRow(watch: Watch, onClick: () -> Unit, onRemove: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(start = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    QueryView(watch.query)
                }

                WatchStatus(watch)
            }

            Spacer(Modifier.width(4.dp))

            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = stringResource(R.string.search_watchlist_remove),
                modifier = Modifier
                    .clickable(onClick = onRemove)
                    .padding(12.dp)
                    .size(16.dp),
            )
        }
    }
}

@Composable
private fun WatchStatus(watch: Watch) {
    val hasNew = watch.newCount > 0

    Text(
        text = when {
            hasNew -> pluralStringResource(
                R.plurals.search_watchlist_new,
                watch.newCount,
                watch.newCount,
            )
            watch.lastCheckedAt == 0L -> stringResource(R.string.search_watchlist_unchecked)
            else -> stringResource(
                R.string.search_watchlist_checked,
                DateUtils.getRelativeTimeSpanString(
                    watch.lastCheckedAt,
                    System.currentTimeMillis(),
                    DateUtils.MINUTE_IN_MILLIS,
                ),
            )
        },
        style = MaterialTheme.typography.bodySmall,
        color = if (hasNew) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

/** Puts the query a list is showing on, or off, the watchlist. */
@Composable
fun WatchQueryMenuItem(query: SearchQuery?, onDismissRequest: () -> Unit) {
    val watching = query != null && watchlist.contains(query)
    val requestNotifications = rememberNotificationPermissionRequest()

    DropdownMenuItem(
        text = {
            Text(
                stringResource(
                    if (watching) R.string.search_unwatch_query else R.string.search_watch_query,
                ),
            )
        },
        leadingIcon = {
            Icon(
                imageVector = if (watching) Icons.Default.NotificationsActive
                else Icons.Default.NotificationsNone,
                contentDescription = null,
            )
        },
        enabled = query != null,
        onClick = {
            onDismissRequest()

            if (query == null) return@DropdownMenuItem

            watchlist.toggle(query)

            if (!watching) requestNotifications()
        },
    )
}

/** Asks for the notification permission, on the versions that have one. */
@Composable
private fun rememberNotificationPermissionRequest(): () -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }

    return {
        if (!checkNotificationEnabled(context))
            launcher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }
}
