/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.google.mlkit.vision.face.Face
import kotlinx.coroutines.delay
import xyz.quaver.pupil.R
import xyz.quaver.pupil.util.closeCamera
import xyz.quaver.pupil.util.startCamera

private const val EYE_OPEN_PROBABILITY = 0.4f
private const val WINK_DURATION = 100L
private const val WINK_COOLDOWN = 500L
private const val FRAME_DOT_DURATION = 50L

private enum class Eye { LEFT, RIGHT }

/**
 * Whether each eye the front camera sees is open, `null` while it does not see
 * exactly one face. The left eye is the one on the left of the screen, which is
 * the face's right.
 */
class EyeBlinkState {
    var leftOpen by mutableStateOf<Boolean?>(null)
        private set
    var rightOpen by mutableStateOf<Boolean?>(null)
        private set

    /** Counts the frames analyzed, so the card can flash once for each. */
    var frames by mutableIntStateOf(0)
        private set

    private var closedEye: Eye? = null
    private var closedSince = 0L

    /** Takes a frame, answering the direction to turn when a wink has been held long enough. */
    fun onFaces(faces: List<Face>): Int? {
        frames++

        val face = faces.singleOrNull()

        if (face == null) {
            leftOpen = null
            rightOpen = null
            return null
        }

        val left = (face.rightEyeOpenProbability ?: 0f) > EYE_OPEN_PROBABILITY
        val right = (face.leftEyeOpenProbability ?: 0f) > EYE_OPEN_PROBABILITY

        leftOpen = left
        rightOpen = right

        val closed = when {
            left == right -> null
            !left -> Eye.LEFT
            else -> Eye.RIGHT
        }

        if (closed != closedEye) {
            closedEye = closed
            closedSince = System.currentTimeMillis()
        }

        if (closed == null || System.currentTimeMillis() - closedSince <= WINK_DURATION)
            return null

        closedSince = System.currentTimeMillis() + WINK_COOLDOWN

        return if (closed == Eye.RIGHT) 1 else -1
    }
}

/**
 * Runs the front camera while the reader is resumed, turning the page toward the
 * eye held shut. [onTurn] is handed +1 for the right eye and -1 for the left.
 */
@Composable
fun EyeBlinkCamera(state: EyeBlinkState, onTurn: (Int) -> Unit) {
    val context = LocalContext.current
    val currentOnTurn by rememberUpdatedState(onTurn)

    LifecycleResumeEffect(state) {
        startCamera(context) { faces -> state.onFaces(faces)?.let(currentOnTurn) }

        onPauseOrDispose { closeCamera() }
    }
}

@Composable
fun EyeBlinkCard(state: EyeBlinkState, visible: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = slideInVertically(tween()) { -it * 2 } + fadeIn(),
        exit = slideOutVertically(tween()) { -it * 2 } + fadeOut(),
    ) {
        EyeBlinkCard(state)
    }
}

@Composable
private fun EyeBlinkCard(state: EyeBlinkState, modifier: Modifier = Modifier) {
    var dotVisible by remember { mutableStateOf(false) }

    LaunchedEffect(state.frames) {
        dotVisible = true
        delay(FRAME_DOT_DURATION)
        dotVisible = false
    }

    Card(modifier, shape = RoundedCornerShape(16.dp)) {
        Box {
            Row {
                EyeIcon(state.leftOpen)
                EyeIcon(state.rightOpen)
            }

            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .size(4.dp)
                    .alpha(if (dotVisible) 1f else 0f)
                    .background(colorResource(R.color.colorAccent), CircleShape),
            )
        }
    }
}

@Composable
private fun EyeIcon(open: Boolean?) {
    Image(
        painterResource(
            when (open) {
                null -> R.drawable.eye_off
                true -> R.drawable.eye
                false -> R.drawable.eye_closed
            }
        ),
        contentDescription = null,
        modifier = Modifier
            .padding(4.dp)
            .size(8.dp),
    )
}
