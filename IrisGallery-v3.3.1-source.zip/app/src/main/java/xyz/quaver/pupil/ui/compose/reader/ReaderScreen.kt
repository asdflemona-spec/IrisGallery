/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.reader

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.widget.Toast
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListLayoutInfo
import androidx.compose.foundation.lazy.LazyListPrefetchScope
import androidx.compose.foundation.lazy.LazyListPrefetchStrategy
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.layout.LazyLayoutPrefetchState
import androidx.compose.foundation.lazy.layout.NestedPrefetchScope
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.R
import xyz.quaver.pupil.favorites
import xyz.quaver.pupil.services.DownloadService
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.ui.compose.GalleryDownload
import xyz.quaver.pupil.ui.compose.RemoveDownloadDialog
import xyz.quaver.pupil.ui.compose.VolumePageTurnHandler
import xyz.quaver.pupil.ui.compose.rememberGalleryDownload
import xyz.quaver.pupil.ui.compose.rememberSaveAction
import xyz.quaver.pupil.ui.viewmodel.ReaderViewModel
import xyz.quaver.pupil.util.MultipageFit
import xyz.quaver.pupil.util.MultipageOrder
import xyz.quaver.pupil.util.PageImage
import xyz.quaver.pupil.util.Preferences
import xyz.quaver.pupil.util.ReaderLayout
import xyz.quaver.pupil.util.ReaderOrientation
import xyz.quaver.pupil.util.buildSpreads
import xyz.quaver.pupil.util.copyImage
import xyz.quaver.pupil.util.downloader.DownloadState
import xyz.quaver.pupil.util.downloader.Downloads
import xyz.quaver.pupil.util.downloader.ImageProgress
import xyz.quaver.pupil.util.downloader.message
import xyz.quaver.pupil.util.shareGallery
import xyz.quaver.pupil.util.shareImage
import kotlin.math.roundToInt

private const val PAGE_TURN_INTERVAL_KEY = "reader_timer_interval"
private const val MAX_PAGE_TURN_INTERVAL = 60
private const val DEFAULT_PAGE_TURN_INTERVAL = 5

private const val MULTIPAGE_PORTRAIT_MIN_WIDTH_DP = 600

private const val SAVED_PAGE_MIME_TYPE = "image/*"

private val CHROME_TAP_REGION = 1 / 3f..2 / 3f

/** How long the bars the reader opens itself stay, if they go unused. */
private const val CHROME_LINGER = 5000L

private val SpreadSpacing = 8.dp

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ReaderScreen(model: ReaderViewModel) {
    val context = LocalContext.current
    val activity = LocalActivity.current
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current
    val scope = rememberCoroutineScope()

    val settings = settings.value
    val galleryID = model.galleryID
    val galleryInfo = model.galleryInfo

    val multipage = when (settings.readerLayout) {
        ReaderLayout.SINGLE -> false
        ReaderLayout.DOUBLE -> true
        ReaderLayout.AUTO ->
            configuration.orientation == Configuration.ORIENTATION_LANDSCAPE ||
                settings.multipagePortrait && configuration.screenWidthDp >= MULTIPAGE_PORTRAIT_MIN_WIDTH_DP
    }

    val vertical = settings.readerOrientation == ReaderOrientation.VERTICAL
    val reverse = settings.readerReverse

    val spreadRtl = when (settings.multipageOrder) {
        MultipageOrder.LTR -> false
        MultipageOrder.RTL -> true
        MultipageOrder.AUTO -> reverse
    }

    val contentScale =
        if (multipage && settings.multipageFit == MultipageFit.FILL) ContentScale.Crop
        else ContentScale.Fit

    val spreads = remember(galleryInfo, multipage, settings.multipageCover) {
        galleryInfo?.files?.let { buildSpreads(it, multipage, settings.multipageCover) }.orEmpty()
    }

    val listState = rememberLazyListState(prefetchStrategy = remember { NeighbourPrefetchStrategy() })
    val reversed = !vertical && reverse

    val insetsController = remember(activity, view) {
        activity?.window?.let { window ->
            WindowCompat.getInsetsController(window, view).apply {
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    // Bars swiped in over a fullscreen window are never reported to it, so the
    // reader shows the system bars itself and the toolbar goes with them. The
    // gallery opens with both out, and a tap on a page puts them away.
    var chromeVisible by rememberSaveable { mutableStateOf(true) }

    // The bars the reader opened are only there to be seen, and go on their own.
    // Ones asked for, or used before they went, stay until they are dismissed.
    var chromeAwaitsUse by rememberSaveable { mutableStateOf(true) }

    fun keepChrome() {
        chromeAwaitsUse = false
    }

    // Only while the reader is being looked at: bars that went in the background
    // are gone when the gallery is come back to.
    LaunchedEffect(chromeVisible, chromeAwaitsUse) {
        if (!chromeVisible || !chromeAwaitsUse) return@LaunchedEffect

        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            delay(CHROME_LINGER)
            chromeVisible = false
        }
    }

    LifecycleResumeEffect(insetsController, chromeVisible) {
        insetsController?.run {
            if (chromeVisible) show(WindowInsetsCompat.Type.systemBars())
            else hide(WindowInsetsCompat.Type.systemBars())
        }

        onPauseOrDispose { }
    }

    fun spreadOf(page: Int) = spreads.indexOfFirst { page - 1 in it }

    // Where a turn still animating is headed, so a quick second turn goes on from
    // there rather than from the page the list has not left yet.
    var turnTarget by remember { mutableStateOf<Int?>(null) }

    fun showSpread(spread: Int) {
        turnTarget = spread

        scope.launch {
            try {
                if (settings.instantFlip) listState.scrollToItem(spread)
                else listState.animateScrollToItem(spread)
            } finally {
                if (turnTarget == spread) turnTarget = null
            }
        }
    }

    fun turn(delta: Int) {
        if (spreads.isEmpty()) return

        showSpread(((turnTarget ?: listState.firstVisibleItemIndex) + delta).coerceIn(0, spreads.lastIndex))
    }

    // Straight there rather than animated: this is a page picked out by hand,
    // not a turn, and the spreads in between are not worth scrolling past.
    fun jumpToPage(page: Int) {
        val spread = spreadOf(page)

        if (spread < 0 || spread == listState.firstVisibleItemIndex) return

        turnTarget = null
        scope.launch { listState.scrollToItem(spread) }
    }

    fun onTap(x: Float) {
        when {
            chromeVisible -> chromeVisible = false
            x in CHROME_TAP_REGION -> {
                chromeVisible = true
                keepChrome()
            }
            else -> turn(if (settings.tapSides && (x < 0.5f) != reversed) -1 else 1)
        }
    }

    val currentOnTap by rememberUpdatedState(::onTap)

    LaunchedEffect(spreads, vertical) {
        if (spreads.isEmpty()) return@LaunchedEffect

        val spread = spreadOf(model.pageToShow())
        if (spread >= 0) listState.scrollToItem(spread)

        snapshotFlow { listState.shownSpreads() }
            .filterNotNull()
            .distinctUntilChanged()
            .collect { (first, last) ->
                if (last < spreads.size)
                    model.onPagesShown(spreads[first].first() + 1, spreads[last].last() + 1)
            }
    }

    VolumePageTurnHandler { turn(it) }

    model.pageTurnInterval?.let { interval ->
        DisposableEffect(view) {
            view.keepScreenOn = true
            onDispose { view.keepScreenOn = false }
        }

        LaunchedEffect(interval) {
            lifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                while (true) {
                    delay(interval * 1000L)

                    if (listState.layoutInfo.totalItemsCount == 0) continue

                    if (!listState.canScrollForward) {
                        model.pageTurnInterval = null
                        return@repeatOnLifecycle
                    }

                    turn(1)
                }
            }
        }
    }

    val eyeBlink = remember { EyeBlinkState() }

    if (model.cameraEnabled)
        EyeBlinkCamera(eyeBlink) { turn(if (reversed) -it else it) }

    var cameraDialogTitle by remember { mutableStateOf<Int?>(null) }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) model.cameraEnabled = true
        else cameraDialogTitle = R.string.error
    }

    fun toggleCamera() {
        when {
            model.cameraEnabled -> model.cameraEnabled = false
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED ->
                model.cameraEnabled = true
            activity != null && ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.CAMERA) ->
                cameraDialogTitle = R.string.warning
            else -> cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val downloadState = Downloads.state(galleryID)
    val notFound = downloadState is DownloadState.NotFound

    val resumed = lifecycleOwner.lifecycle.currentStateAsState().value.isAtLeast(Lifecycle.State.RESUMED)

    // Unsaving a finished download deletes the pages along with the folder, so a
    // gallery the downloader has forgotten is fetched again, not only on resume.
    LaunchedEffect(resumed, downloadState == null) {
        if (resumed && downloadState == null)
            DownloadService.download(context, galleryID, priority = true)
    }
    val failure = (downloadState as? DownloadState.Failed)?.reason

    LaunchedEffect(notFound) {
        if (notFound)
            snackbarHostState.showSnackbar(
                context.getString(R.string.reader_failed_to_find_gallery),
                duration = SnackbarDuration.Indefinite,
            )
    }

    // The pages that did land are still worth reading, so the gallery stays on
    // screen with the reason and a way to ask for the rest again.
    LaunchedEffect(failure) {
        if (failure == null) return@LaunchedEffect

        val result = snackbarHostState.showSnackbar(
            context.getString(failure.message()),
            actionLabel = context.getString(R.string.reader_fab_retry),
            duration = SnackbarDuration.Indefinite,
        )

        if (result == SnackbarResult.ActionPerformed)
            DownloadService.download(context, galleryID)
    }

    var optionsOpen by remember { mutableStateOf(false) }
    var pageGridOpen by remember { mutableStateOf(false) }

    // Which page the sheet's buttons act on: the one long pressed, or the first
    // of the spread on screen when the sheet was opened from the bar.
    var targetPage by rememberSaveable { mutableIntStateOf(0) }
    val actedPage = targetPage.takeIf { it > 0 } ?: model.currentPage

    suspend fun pageImage(page: Int): PageImage? = withContext(Dispatchers.IO) {
        model.cache.getImage(page - 1)?.let { file ->
            PageImage(file.uri, "Pupil-$galleryID-$page.${file.name.substringAfterLast('.', "webp")}")
        }
    }

    // Which page the picker is being asked about, kept as the page itself: the
    // answer can outlive this process, and the page is looked up again for it.
    var pageToSave by rememberSaveable { mutableIntStateOf(0) }

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(SAVED_PAGE_MIME_TYPE)
    ) { target ->
        val page = pageToSave
        pageToSave = 0

        if (target == null || page <= 0) return@rememberLauncherForActivityResult

        scope.launch {
            val message = runCatching {
                val image = pageImage(page) ?: error("Page $page is not on the device")

                context.copyImage(image.source, target)
            }.fold(
                onSuccess = { R.string.reader_image_saved },
                onFailure = { R.string.reader_image_save_failed },
            )

            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    // A page still on its way has nothing to hand over, and saying so beats a
    // button that does nothing.
    fun savePage() = scope.launch {
        val image = pageImage(actedPage)

        if (image == null) {
            Toast.makeText(context, R.string.reader_image_save_failed, Toast.LENGTH_SHORT).show()
            return@launch
        }

        pageToSave = actedPage
        saveLauncher.launch(image.displayName)
    }

    fun sharePage() = scope.launch {
        val image = pageImage(actedPage)

        if (image == null) {
            Toast.makeText(context, R.string.reader_image_share_failed, Toast.LENGTH_SHORT).show()
            return@launch
        }

        runCatching { context.shareImage(image) }.onFailure {
            Toast.makeText(context, R.string.reader_image_share_failed, Toast.LENGTH_SHORT).show()
        }
    }

    // Saving or sharing a page is offered where a page was named: a long press
    // picks one out, while the bar is about the gallery as a whole.
    val quickActions = buildList {
        add(
            ReaderQuickAction(
                label = stringResource(R.string.reader_action_favorite),
                icon = {
                    painterResource(
                        if (favorites.contains(galleryID)) R.drawable.ic_star_filled
                        else R.drawable.ic_star_empty
                    )
                },
            ) {
                favorites.toggle(galleryID)
            }
        )

        if (targetPage > 0) {
            add(
                ReaderQuickAction(
                    label = stringResource(R.string.reader_save_page, actedPage),
                    icon = { painterResource(R.drawable.download) },
                ) {
                    optionsOpen = false
                    savePage()
                }
            )

            add(
                ReaderQuickAction(
                    label = stringResource(R.string.reader_share_page, actedPage),
                    icon = { rememberVectorPainter(Icons.Default.Share) },
                ) {
                    optionsOpen = false
                    sharePage()
                }
            )
        }

        add(
            ReaderQuickAction(
                label = stringResource(R.string.reader_action_share_gallery),
                icon = { rememberVectorPainter(Icons.Default.Link) },
            ) {
                optionsOpen = false
                context.shareGallery(galleryID, galleryInfo?.title.orEmpty())
            }
        )
    }

    var timerDialogShown by remember { mutableStateOf(false) }

    val download = rememberGalleryDownload(galleryID)
    val save = rememberSaveAction(galleryID, priority = true)
    var confirmRemove by remember { mutableStateOf(false) }

    val actions = listOf(
        ReaderAction(
            label = stringResource(
                when (download) {
                    is GalleryDownload.Running -> R.string.reader_fab_download_cancel
                    GalleryDownload.Saved -> R.string.gallery_remove_download
                    else -> R.string.reader_fab_download
                }
            ),
            icon = {
                when (download) {
                    is GalleryDownload.Running -> downloadingPainter()
                    GalleryDownload.Saved -> rememberVectorPainter(Icons.Default.Close)
                    else -> painterResource(R.drawable.ic_download)
                }
            },
            progress = when (download) {
                is GalleryDownload.Running -> if (download.total > 0) download.completed.toFloat() / download.total else 0f
                else -> null
            },
        ) {
            when (download) {
                is GalleryDownload.Running -> DownloadService.unsave(context, galleryID)
                GalleryDownload.Saved -> confirmRemove = true
                else -> save()
            }
        },
        ReaderAction(
            label = stringResource(if (model.cameraEnabled) R.string.reader_fab_auto_cancel else R.string.reader_fab_auto),
            icon = { painterResource(if (model.cameraEnabled) R.drawable.eye_off_white else R.drawable.eye_white) },
        ) {
            toggleCamera()
        },
        ReaderAction(
            label = stringResource(if (model.pageTurnInterval != null) R.string.reader_fab_timer_cancel else R.string.reader_fab_timer),
            icon = { painterResource(if (model.pageTurnInterval != null) R.drawable.timer_off_white else R.drawable.timer_white) },
        ) {
            if (model.pageTurnInterval != null) model.pageTurnInterval = null
            else timerDialogShown = true
        },
    )

    val background = MaterialTheme.colorScheme.background
    val downloadedPages = rememberDownloadedPages(galleryID, model.pageCount)

    Scaffold(
        bottomBar = {
            AnimatedVisibility(
                visible = chromeVisible,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
            ) {
                ReaderBottomBar(
                    currentPage = model.currentPage,
                    pageCount = model.pageCount,
                    reversed = reversed,
                    downloadedPages = downloadedPages,
                    onInteraction = ::keepChrome,
                    onPageGridClick = { pageGridOpen = true },
                    onOptionsClick = {
                        targetPage = 0
                        optionsOpen = true
                    },
                    onPageSelected = ::jumpToPage,
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = background,
        contentWindowInsets = WindowInsets.systemBars,
    ) { padding ->
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { currentOnTap(it.x / size.width.coerceAtLeast(1)) } }
        ) {
            val viewport = IntSize(constraints.maxWidth, constraints.maxHeight)

            val content: LazyListScope.() -> Unit = {
                items(spreads, key = { it.first() }) { spread ->
                    val files = galleryInfo!!.files
                    val width = spread.sumOf { files[it].width }
                    val height = spread.maxOf { files[it].height }
                    val ratio = if (width > 0 && height > 0) width.toFloat() / height else 1f

                    ReaderSpread(
                        galleryID = galleryID,
                        cache = model.cache,
                        pages = if (spreadRtl) spread.asReversed() else spread,
                        label = spread.joinToString("-") { (it + 1).toString() },
                        size = spreadSize(viewport, ratio, settings.readerPadding, vertical),
                        contentScale = contentScale,
                        onTap = ::onTap,
                        onLongPress = { page ->
                            keepChrome()
                            targetPage = page + 1
                            optionsOpen = true
                        },
                        modifier = when {
                            settings.readerPadding -> Modifier.fillParentMaxSize()
                            vertical -> Modifier
                                .fillMaxWidth()
                                .aspectRatio(ratio)
                            else -> Modifier
                                .widthIn(max = maxWidth)
                                .fillParentMaxHeight()
                                .aspectRatio(ratio, matchHeightConstraintsFirst = true)
                        },
                    )
                }
            }

            val flingBehavior =
                if (settings.readerSnap) rememberPageFlingBehavior(listState)
                else ScrollableDefaults.flingBehavior()

            if (vertical)
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize(),
                    reverseLayout = reverse,
                    verticalArrangement = Arrangement.spacedBy(SpreadSpacing),
                    flingBehavior = flingBehavior,
                    content = content,
                )
            else
                LazyRow(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize(),
                    reverseLayout = reverse,
                    horizontalArrangement = Arrangement.spacedBy(SpreadSpacing),
                    flingBehavior = flingBehavior,
                    content = content,
                )

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(bottom = padding.calculateBottomPadding())
            ) {
                AnimatedVisibility(
                    visible = chromeVisible,
                    enter = slideInVertically { -it } + fadeIn(),
                    exit = slideOutVertically { -it } + fadeOut(),
                ) {
                    ReaderTopBar(
                        title = galleryInfo?.title ?: stringResource(R.string.reader_loading),
                        onBack = { activity?.finish() },
                    )
                }

                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    EyeBlinkCard(
                        state = eyeBlink,
                        visible = model.cameraEnabled,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp),
                    )
                }
            }
        }
    }

    if (timerDialogShown)
        NumberPickerDialog(
            title = stringResource(R.string.reader_timer_interval),
            range = 1..MAX_PAGE_TURN_INTERVAL,
            initial = Preferences[PAGE_TURN_INTERVAL_KEY, DEFAULT_PAGE_TURN_INTERVAL],
            onConfirm = { interval ->
                timerDialogShown = false
                Preferences[PAGE_TURN_INTERVAL_KEY] = interval
                model.pageTurnInterval = interval
            },
            onDismiss = { timerDialogShown = false },
        )

    if (confirmRemove)
        RemoveDownloadDialog(
            galleryID = galleryID,
            title = galleryInfo?.title.orEmpty(),
            onDismiss = { confirmRemove = false },
        )

    if (pageGridOpen)
        ReaderPageGridSheet(
            cache = model.cache,
            pageCount = model.pageCount,
            currentPage = model.currentPage,
            downloadedPages = downloadedPages,
            onPageSelected = { page ->
                pageGridOpen = false
                jumpToPage(page)
            },
            onDismiss = { pageGridOpen = false },
        )

    if (optionsOpen)
        ReaderOptionsSheet(
            quickActions = quickActions,
            actions = actions,
            onDismiss = { optionsOpen = false },
        )

    cameraDialogTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { cameraDialogTitle = null },
            title = { Text(stringResource(title)) },
            text = { Text(stringResource(R.string.camera_denied)) },
            confirmButton = {
                TextButton(onClick = { cameraDialogTitle = null }) {
                    Text(stringResource(android.R.string.ok))
                }
            },
        )
    }
}

private const val DOWNLOADED_PAGES_POLL_INTERVAL = 1000L

/**
 * Which of the gallery's pages have downloaded. Image progress is not snapshot
 * state, so it is asked after while composed, until every page is in.
 */
@Composable
private fun rememberDownloadedPages(galleryID: Int, pageCount: Int): List<Boolean> {
    val pages by produceState(emptyList<Boolean>(), galleryID, pageCount) {
        while (true) {
            value = List(pageCount) { Downloads.imageProgress(galleryID, it) is ImageProgress.Complete }

            if (value.isNotEmpty() && value.all { it }) break

            delay(DOWNLOADED_PAGES_POLL_INTERVAL)
        }
    }

    return pages
}

/** Turns at most one page per fling, the way a pager does. */
@Composable
private fun rememberPageFlingBehavior(state: LazyListState) = rememberSnapFlingBehavior(
    remember(state) {
        val provider = SnapLayoutInfoProvider(state, SnapPosition.Start)

        object : SnapLayoutInfoProvider by provider {
            override fun calculateApproachOffset(velocity: Float, decayOffset: Float) = 0f
        }
    }
)

/**
 * Keeps the spread either side of the one on screen composed, so a turn onto it
 * is already drawn rather than put together on arrival.
 */
@OptIn(ExperimentalFoundationApi::class)
private class NeighbourPrefetchStrategy : LazyListPrefetchStrategy {
    private val handles = mutableMapOf<Int, LazyLayoutPrefetchState.PrefetchHandle>()

    override fun LazyListPrefetchScope.onScroll(delta: Float, layoutInfo: LazyListLayoutInfo) {
        keepNeighbours(layoutInfo)
    }

    override fun LazyListPrefetchScope.onVisibleItemsUpdated(layoutInfo: LazyListLayoutInfo) {
        keepNeighbours(layoutInfo)
    }

    override fun NestedPrefetchScope.onNestedPrefetch(firstVisibleItemIndex: Int) {}

    private fun LazyListPrefetchScope.keepNeighbours(layoutInfo: LazyListLayoutInfo) {
        val visible = layoutInfo.visibleItemsInfo
        if (visible.isEmpty()) return

        val wanted = (visible.first().index - 1)..(visible.last().index + 1)

        handles.keys.filter { it !in wanted }.forEach { handles.remove(it)?.cancel() }

        for (index in wanted) {
            if (index < 0 || index >= layoutInfo.totalItemsCount) continue
            if (visible.any { it.index == index } || index in handles) continue

            handles[index] = schedulePrefetch(index)
        }
    }
}

/**
 * The box a spread is laid out in, which is the size its image is asked for at.
 * It mirrors the modifier the spread is given: the whole viewport when pages are
 * fitted to the screen, and otherwise the aspect the spread is drawn at.
 */
private fun spreadSize(viewport: IntSize, ratio: Float, padding: Boolean, vertical: Boolean) = when {
    padding -> viewport
    vertical -> IntSize(viewport.width, (viewport.width / ratio).roundToInt())
    else -> IntSize(
        (viewport.height * ratio).roundToInt().coerceAtMost(viewport.width),
        viewport.height,
    )
}

/** The first spread on screen and the last one fully shown. */
private fun LazyListState.shownSpreads(): Pair<Int, Int>? {
    val info: LazyListLayoutInfo = layoutInfo
    if (info.visibleItemsInfo.isEmpty()) return null

    val first = firstVisibleItemIndex
    val lastFullyShown = info.visibleItemsInfo
        .lastOrNull { it.offset + it.size <= info.viewportEndOffset }
        ?.index ?: first

    return first to maxOf(first, lastFullyShown)
}
