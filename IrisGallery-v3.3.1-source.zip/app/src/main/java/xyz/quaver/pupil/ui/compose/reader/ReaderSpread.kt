/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.reader

import android.net.Uri
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil3.request.ImageRequest
import coil3.request.error
import coil3.size.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import me.saket.telephoto.zoomable.DoubleClickToZoomListener
import me.saket.telephoto.zoomable.ZoomSpec
import me.saket.telephoto.zoomable.ZoomableState
import me.saket.telephoto.zoomable.coil3.ZoomableAsyncImage
import me.saket.telephoto.zoomable.rememberZoomableImageState
import me.saket.telephoto.zoomable.rememberZoomableState
import xyz.quaver.pupil.R
import xyz.quaver.pupil.util.downloader.Cache
import xyz.quaver.pupil.util.downloader.DownloadFailure
import xyz.quaver.pupil.util.downloader.Downloads
import xyz.quaver.pupil.util.downloader.ImageProgress
import xyz.quaver.pupil.util.downloader.message
import xyz.quaver.pupil.util.spreadImage

private const val PROGRESS_POLL_INTERVAL = 1000L

private const val SINGLE_PAGE_MAX_ZOOM = 2f
private const val SPREAD_MAX_ZOOM = 4f

private sealed interface SpreadImage {
    data class Loading(val progress: Float) : SpreadImage
    data class Failed(val reason: DownloadFailure) : SpreadImage
    data class Ready(val uri: Uri) : SpreadImage
}

/**
 * The pages of a spread, in the order they are drawn, as one zoomable image once
 * they have all arrived.
 *
 * [onTap] is handed where across the spread the tap landed, from 0 at the left
 * edge to 1 at the right, and [onLongPress] the page pressed.
 *
 * [size] is the box the spread is laid out in. The image is asked for at that
 * size rather than at the one the drawn node reports, so a spread composed ahead
 * of being shown -- the one a page turn is about to land on -- can finish
 * loading while it is still off screen instead of starting when it arrives.
 */
@Composable
fun ReaderSpread(
    galleryID: Int,
    cache: Cache,
    pages: List<Int>,
    label: String,
    size: IntSize,
    contentScale: ContentScale,
    onTap: (Float) -> Unit,
    onLongPress: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val currentOnTap by rememberUpdatedState(onTap)
    val currentOnLongPress by rememberUpdatedState(onLongPress)
    val currentPages by rememberUpdatedState(pages)

    var width by remember { mutableIntStateOf(0) }

    // A new listener restarts telephoto's gesture detection, and the pages
    // recompose with every page that downloads, so the listener stays the same.
    val onLongClick = remember {
        { offset: Offset -> currentOnLongPress(pressedPage(currentPages, offset.x / width.coerceAtLeast(1))) }
    }

    // Image progress is not snapshot state, and a failed page can be put back on
    // its way by a retry, so it is asked after until the spread is on disk.
    val image by produceState<SpreadImage>(SpreadImage.Loading(0f), galleryID, pages) {
        while (true) {
            val progress = pages.map { Downloads.imageProgress(galleryID, it) }

            if (progress.all { it is ImageProgress.Complete }) {
                val images = withContext(Dispatchers.IO) { pages.map { cache.getImage(it) } }

                if (images.all { it != null }) {
                    value = SpreadImage.Ready(context.spreadImage(cache, pages, images.map { it!! }))
                    return@produceState
                }
            }

            value = progress.filterIsInstance<ImageProgress.Failed>().minOfOrNull { it.reason }
                ?.let { SpreadImage.Failed(it) }
                ?: SpreadImage.Loading(
                    progress.minOf {
                        when (it) {
                            is ImageProgress.Complete -> 1f
                            is ImageProgress.Downloading -> it.fraction
                            else -> 0f
                        }
                    }
                )

            delay(PROGRESS_POLL_INTERVAL)
        }
    }

    Box(
        modifier.onSizeChanged { width = it.width },
        contentAlignment = Alignment.Center,
    ) {
        when (val current = image) {
            is SpreadImage.Ready -> {
                val request = remember(current.uri, size) {
                    ImageRequest.Builder(context)
                        .data(current.uri)
                        .size(Size(size.width.coerceAtLeast(1), size.height.coerceAtLeast(1)))
                        .error(R.drawable.image_broken_variant)
                        .build()
                }

                ZoomableAsyncImage(
                    model = request,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) { turnOnTap { currentOnTap(it.x / size.width.coerceAtLeast(1)) } },
                    state = rememberZoomableImageState(
                        rememberZoomableState(
                            ZoomSpec(maxZoomFactor = if (pages.size > 1) SPREAD_MAX_ZOOM else SINGLE_PAGE_MAX_ZOOM)
                        )
                    ),
                    contentScale = contentScale,
                    onLongClick = onLongClick,
                    onDoubleClick = NoZoomOnDoubleClick,
                )
            }

            else -> Column(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { currentOnTap(it.x / size.width.coerceAtLeast(1)) },
                            onLongPress = {
                                currentOnLongPress(
                                    pressedPage(currentPages, it.x / size.width.coerceAtLeast(1))
                                )
                            },
                        )
                    },
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (current is SpreadImage.Failed)
                    Text(
                        stringResource(current.reason.message()),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                else {
                    LinearProgressIndicator(progress = { (current as SpreadImage.Loading).progress })
                    Text(label, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

/**
 * Turns the page on the tap itself rather than on what the tap turns out to be.
 *
 * Telephoto holds a tap for the length of the double tap window before reporting
 * it, which a page turn that slides covers with its animation and one that does
 * not leaves as a fifth of a second of nothing. The tap is read here first, on
 * the initial pass, and nothing is consumed, so panning and pinching still reach
 * the image below. Double tapping to zoom is given up for it -- see
 * [NoZoomOnDoubleClick].
 */
private suspend fun PointerInputScope.turnOnTap(onTap: (Offset) -> Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)

        val up = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)

                if (event.changes.size > 1) return@withTimeoutOrNull null

                val change = event.changes.first()

                if ((change.position - down.position).getDistance() > viewConfiguration.touchSlop)
                    return@withTimeoutOrNull null

                if (change.changedToUpIgnoreConsumed()) return@withTimeoutOrNull change
            }

            @Suppress("UNREACHABLE_CODE")
            null
        }

        if (up != null) onTap(down.position)
    }
}

/**
 * A double tap is two page turns now that the first one is acted on at once, so
 * it no longer zooms as well. Pinching still does.
 */
private object NoZoomOnDoubleClick : DoubleClickToZoomListener {
    override suspend fun onDoubleClick(state: ZoomableState, centroid: Offset) = Unit
}

/** The page of a spread under a press, from the fraction across it. */
private fun pressedPage(pages: List<Int>, x: Float) = pages[if (x < 0.5f) 0 else pages.lastIndex]
