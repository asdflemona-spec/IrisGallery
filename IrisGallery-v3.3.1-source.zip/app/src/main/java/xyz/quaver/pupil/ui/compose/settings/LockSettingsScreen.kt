/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.settings

import android.content.Intent
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.LifecycleResumeEffect
import xyz.quaver.pupil.R
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.ui.LockActivity
import xyz.quaver.pupil.util.Lock
import xyz.quaver.pupil.util.LockManager

@Composable
fun LockSettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    var revision by remember { mutableIntStateOf(0) }
    val lockManager = remember(revision) { LockManager(context) }

    var removing by rememberSaveable { mutableStateOf<Lock.Type?>(null) }

    LifecycleResumeEffect(Unit) {
        revision++
        onPauseOrDispose { }
    }

    LaunchedEffect(lockManager) {
        if (lockManager.isEmpty()) settings.update { it.copy(lockFingerprint = false) }
    }

    val onLockClick = { type: Lock.Type ->
        if (lockManager.contains(type)) removing = type
        else context.startActivity(
            Intent(context, LockActivity::class.java)
                .putExtra("mode", "add_lock")
                .putExtra("type", type.name.lowercase())
        )
    }

    SettingsScaffold(title = stringResource(R.string.settings_app_lock), onBack = onBack) {
        Preference(
            title = stringResource(R.string.settings_lock_pattern),
            summary = if (lockManager.contains(Lock.Type.PATTERN)) stringResource(R.string.settings_lock_enabled) else null,
            onClick = { onLockClick(Lock.Type.PATTERN) },
        )
        Preference(
            title = stringResource(R.string.settings_lock_pin),
            summary = if (lockManager.contains(Lock.Type.PIN)) stringResource(R.string.settings_lock_enabled) else null,
            onClick = { onLockClick(Lock.Type.PIN) },
        )
        ListPreference(
            title = stringResource(R.string.settings_lock_timeout),
            value = settings.value.lockTimeoutMinutes,
            entries = listOf(
                0 to stringResource(R.string.settings_lock_timeout_immediately),
                1 to stringResource(R.string.settings_lock_timeout_1),
                5 to stringResource(R.string.settings_lock_timeout_5),
                15 to stringResource(R.string.settings_lock_timeout_15),
                30 to stringResource(R.string.settings_lock_timeout_30),
            ),
            enabled = lockManager.isNotEmpty(),
            onValueChange = { minutes -> settings.update { it.copy(lockTimeoutMinutes = minutes) } },
        )

        PreferenceCategory(stringResource(R.string.settings_lock_biometrics))
        SwitchPreference(
            title = stringResource(R.string.settings_lock_fingerprint),
            checked = settings.value.lockFingerprint,
            onCheckedChange = { enable ->
                if (enable && lockManager.isEmpty())
                    Toast.makeText(context, R.string.settings_lock_fingerprint_without_lock, Toast.LENGTH_SHORT).show()
                else
                    settings.update { it.copy(lockFingerprint = enable) }
            },
        )
    }

    removing?.let { type ->
        ConfirmDialog(
            message = stringResource(R.string.settings_lock_remove_message),
            onConfirm = {
                lockManager.remove(type)
                revision++
            },
            onDismiss = { removing = null },
        )
    }
}
