/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.FileProvider
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.jsonObject
import xyz.quaver.io.FileX
import xyz.quaver.io.util.readText
import xyz.quaver.pupil.R
import xyz.quaver.pupil.favoriteTags
import xyz.quaver.pupil.favorites
import xyz.quaver.pupil.types.Tag
import java.io.File

@Composable
fun ManageFavoritesScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    val pickBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult

        val restored = restoreFavorites(context, uri)

        Toast.makeText(
            context,
            restored?.let { context.getString(R.string.settings_restore_success, it) }
                ?: context.getString(R.string.error),
            Toast.LENGTH_LONG,
        ).show()
    }

    SettingsScaffold(title = stringResource(R.string.settings_manage_favorites), onBack = onBack) {
        Preference(
            title = stringResource(R.string.settings_backup_title),
            onClick = { shareFavoritesBackup(context) },
        )
        Preference(
            title = stringResource(R.string.settings_restore_title),
            onClick = { pickBackup.launch(arrayOf("*/*")) },
        )
    }
}

private fun shareFavoritesBackup(context: Context) {
    val backup = buildJsonObject {
        put("favorites", Json.encodeToJsonElement(favorites.items))
        put("favorite_tags", Json.encodeToJsonElement(favoriteTags.items))
    }

    val file = File(context.filesDir, "pupil-backup.json").apply { writeText(backup.toString()) }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)

    val share = Intent(Intent.ACTION_SEND)
        .setDataAndType(uri, "application/json")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        .putExtra(Intent.EXTRA_STREAM, uri)

    context.startActivity(Intent.createChooser(share, context.getString(R.string.settings_backup_share)))
}

private fun restoreFavorites(context: Context, uri: Uri): Int? {
    val backup = runCatching {
        FileX(context, uri).readText()?.let { Json.parseToJsonElement(it).jsonObject }
    }.getOrNull() ?: return null

    val restoredFavorites = runCatching {
        backup["favorites"]?.let { Json.decodeFromJsonElement<List<Int>>(it) }
    }.getOrNull().orEmpty()
    val restoredTags = runCatching {
        backup["favorite_tags"]?.let { Json.decodeFromJsonElement<List<Tag>>(it) }
    }.getOrNull().orEmpty()

    favorites.addAll(restoredFavorites)
    favoriteTags.addAll(restoredTags)

    return restoredFavorites.size + restoredTags.size
}
