/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.settings

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import xyz.quaver.io.FileX
import xyz.quaver.io.util.readText
import xyz.quaver.pupil.R
import xyz.quaver.pupil.histories
import xyz.quaver.pupil.hitomi.json
import xyz.quaver.pupil.readProgress
import xyz.quaver.pupil.util.byteToString
import xyz.quaver.pupil.util.downloader.Cache
import xyz.quaver.pupil.util.downloader.DownloadManager
import xyz.quaver.pupil.util.downloader.Metadata
import xyz.quaver.pupil.util.downloader.isArchiveName
import xyz.quaver.pupil.util.downloader.readArchiveEntry
import java.io.File

private enum class StorageTask { RECOVER_DOWNLOADS, RESTORE_DOWNLOAD_ORDER }

private enum class StorageConfirmation { CLEAR_CACHE, CLEAR_HISTORY }

@Composable
fun ManageStorageScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val cacheDir = remember { File(context.cacheDir, "imageCache") }
    var cacheRevision by remember { mutableIntStateOf(0) }
    val cacheSize by produceState(0L, cacheRevision) {
        value = withContext(Dispatchers.IO) { cacheDir.walk().sumOf { it.length() } }
    }

    var running by remember { mutableStateOf<StorageTask?>(null) }
    var confirming by rememberSaveable { mutableStateOf<StorageConfirmation?>(null) }

    val run = { task: StorageTask, work: suspend () -> Unit ->
        running = task
        scope.launch {
            work()
            running = null
            Toast.makeText(context, android.R.string.ok, Toast.LENGTH_SHORT).show()
        }
    }

    SettingsScaffold(title = stringResource(R.string.settings_manage_storage), onBack = onBack) {
        Preference(
            title = stringResource(R.string.settings_clear_cache),
            summary = stringResource(R.string.settings_storage_usage, byteToString(cacheSize)),
            onClick = { confirming = StorageConfirmation.CLEAR_CACHE },
        )
        Preference(
            title = stringResource(R.string.settings_recover_downloads),
            onClick = if (running == null) {
                { run(StorageTask.RECOVER_DOWNLOADS) { recoverDownloads(context) } }
            } else null,
            leading = progressWhile(running == StorageTask.RECOVER_DOWNLOADS),
        )
        Preference(
            title = stringResource(R.string.settings_restore_download_order),
            summary = stringResource(R.string.settings_restore_download_order_summary),
            onClick = if (running == null) {
                {
                    run(StorageTask.RESTORE_DOWNLOAD_ORDER) {
                        withContext(Dispatchers.IO) { DownloadManager.getInstance(context).restoreDownloadOrder() }
                    }
                }
            } else null,
            leading = progressWhile(running == StorageTask.RESTORE_DOWNLOAD_ORDER),
        )
        Preference(
            title = stringResource(R.string.settings_clear_history),
            summary = stringResource(R.string.settings_clear_history_summary, histories.size),
            onClick = { confirming = StorageConfirmation.CLEAR_HISTORY },
        )
    }

    when (confirming) {
        StorageConfirmation.CLEAR_CACHE -> ConfirmDialog(
            message = stringResource(R.string.settings_clear_cache_alert_message),
            onConfirm = {
                scope.launch {
                    withContext(Dispatchers.IO) { cacheDir.deleteRecursively() }
                    Cache.instances.clear()
                    cacheRevision++
                }
            },
            onDismiss = { confirming = null },
        )
        StorageConfirmation.CLEAR_HISTORY -> ConfirmDialog(
            message = stringResource(R.string.settings_clear_history_alert_message),
            onConfirm = {
                histories.clear()
                readProgress.clear()
            },
            onDismiss = { confirming = null },
        )
        null -> Unit
    }
}

private fun progressWhile(running: Boolean): (@Composable () -> Unit)? =
    if (running) {
        { CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp) }
    } else null

private suspend fun recoverDownloads(context: Context) {
    val downloadManager = DownloadManager.getInstance(context)

    val folders = withContext(Dispatchers.IO) {
        downloadManager.downloadFolder.listFiles().orEmpty().mapNotNull { entry ->
            val serialized = when {
                entry.isDirectory ->
                    FileX(context, entry, ".metadata")
                        .takeIf { it.exists() }
                        ?.readText()

                isArchiveName(entry.name) ->
                    readArchiveEntry(FileX(context, entry), ".metadata")
                        ?.decodeToString()

                else -> null
            } ?: return@mapNotNull null

            val metadata = runCatching {
                json.decodeFromString<Metadata>(serialized)
            }.getOrNull() ?: return@mapNotNull null

            val galleryID = metadata.galleryBlock?.id
                ?: metadata.galleryInfo?.id?.toIntOrNull()
                ?: return@mapNotNull null

            galleryID to entry.name
        }.toMap()
    }

    downloadManager.replaceDownloadFolders(folders)
}
