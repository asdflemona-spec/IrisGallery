/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.io.FileX
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.GalleryBlock
import xyz.quaver.pupil.setProxy
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.util.ProxyInfo
import xyz.quaver.pupil.util.byteToString
import xyz.quaver.pupil.util.downloader.Cache
import xyz.quaver.pupil.util.downloader.DownloadManager
import xyz.quaver.pupil.util.formatDownloadFolderTest
import xyz.quaver.pupil.util.formatMap
import java.io.File
import java.net.Proxy

@Composable
fun DefaultQueryMovedDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings_default_query)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(stringResource(R.string.default_query_moved_message))
                Image(
                    painter = painterResource(R.drawable.default_query_moved),
                    contentDescription = stringResource(R.string.default_query_moved_screenshot_description),
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(android.R.string.ok)) }
        },
    )
}

private const val SAMPLE_GALLERY_ID = 1199708

@Composable
fun DownloadFolderNameDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current

    var pattern by rememberSaveable { mutableStateOf(settings.value.downloadFolderName) }
    val invalid = pattern.contains('/')

    val sample by produceState<GalleryBlock?>(null) {
        val galleryID = Cache.instances.keys.randomOrNull() ?: SAMPLE_GALLERY_ID

        value = withContext(Dispatchers.IO) {
            runCatching { Cache.getInstance(context, galleryID).getGalleryBlock() }.getOrNull()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings_download_folder_name)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    stringResource(
                        R.string.settings_download_folder_name_message,
                        formatMap.keys.toString(),
                        sample?.formatDownloadFolderTest(pattern).orEmpty(),
                    )
                )
                OutlinedTextField(
                    value = pattern,
                    onValueChange = { pattern = it },
                    isError = invalid,
                    supportingText = if (invalid) {
                        { Text(stringResource(R.string.settings_invalid_download_folder_name)) }
                    } else null,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = !invalid,
                onClick = {
                    settings.update { it.copy(downloadFolderName = pattern) }
                    onDismiss()
                },
            ) { Text(stringResource(android.R.string.ok)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(android.R.string.cancel)) }
        },
    )
}

private class OpenDocumentTreeShowingAdvanced : ActivityResultContracts.OpenDocumentTree() {
    override fun createIntent(context: Context, input: Uri?): Intent =
        super.createIntent(context, input).putExtra("android.content.extra.SHOW_ADVANCED", true)
}

private class StorageLocation(val dir: File, val labelRes: Int)

@Composable
fun DownloadLocationDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current

    val locations = remember {
        context.getExternalFilesDirs(null).mapIndexedNotNull { index, dir ->
            dir ?: return@mapIndexedNotNull null

            StorageLocation(
                dir = dir,
                labelRes = if (index == 0) R.string.settings_download_folder_internal
                           else R.string.settings_download_folder_removable,
            )
        }
    }

    val current = remember(settings.value.downloadFolder) {
        DownloadManager.getInstance(context).downloadFolder.canonicalPath
    }
    val selected = locations.firstOrNull { it.dir.canonicalPath == current }

    val pickFolder = rememberLauncherForActivityResult(OpenDocumentTreeShowingAdvanced()) { uri ->
        uri ?: return@rememberLauncherForActivityResult

        context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
        )

        if (runCatching { FileX(context, uri).canWrite() }.getOrDefault(false))
            settings.update { it.copy(downloadFolder = uri.toString()) }
        else
            Toast.makeText(context, R.string.settings_download_folder_not_writable, Toast.LENGTH_LONG).show()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings_download_folder)) },
        text = {
            Column(Modifier.selectableGroup()) {
                locations.forEach { location ->
                    LocationRow(
                        title = stringResource(location.labelRes),
                        subtitle = stringResource(
                            R.string.settings_download_folder_available,
                            byteToString(location.dir.freeSpace),
                        ),
                        selected = location == selected,
                        onClick = {
                            settings.update { it.copy(downloadFolder = location.dir.toUri().toString()) }
                        },
                    )
                }

                LocationRow(
                    title = stringResource(R.string.settings_download_folder_custom),
                    subtitle = if (selected == null) current else null,
                    selected = selected == null,
                    onClick = { pickFolder.launch(null) },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(android.R.string.ok)) }
        },
    )
}

@Composable
private fun LocationRow(title: String, subtitle: String?, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Column(Modifier.padding(start = 16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            subtitle?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun ProxyDialog(onDismiss: () -> Unit) {
    val stored = settings.value.proxy

    var type by rememberSaveable { mutableStateOf(stored.type) }
    var host by rememberSaveable { mutableStateOf(stored.host.orEmpty()) }
    var port by rememberSaveable { mutableStateOf(stored.port?.toString().orEmpty()) }
    var username by rememberSaveable { mutableStateOf(stored.username.orEmpty()) }
    var password by rememberSaveable { mutableStateOf(stored.password.orEmpty()) }
    var showErrors by rememberSaveable { mutableStateOf(false) }

    val direct = type == Proxy.Type.DIRECT
    val hostError = showErrors && !direct && host.isBlank()
    val portError = showErrors && !direct && port.toIntOrNull() == null

    val typeLabels = stringArrayResource(R.array.proxy_type)
    val errorText = stringResource(R.string.proxy_dialog_error)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings_proxy_title)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Column(Modifier.selectableGroup()) {
                    Proxy.Type.entries.forEach { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(
                                    selected = type == entry,
                                    role = Role.RadioButton,
                                    onClick = { type = entry },
                                )
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = type == entry, onClick = null)
                            Text(typeLabels[entry.ordinal], modifier = Modifier.padding(start = 16.dp))
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = host,
                        onValueChange = { host = it },
                        enabled = !direct,
                        label = { Text(stringResource(R.string.proxy_dialog_addr_hint)) },
                        isError = hostError,
                        supportingText = if (hostError) {{ Text(errorText) }} else null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.weight(2f),
                    )
                    OutlinedTextField(
                        value = port,
                        onValueChange = { port = it.filter(Char::isDigit) },
                        enabled = !direct,
                        label = { Text(stringResource(R.string.proxy_dialog_port_hint)) },
                        isError = portError,
                        supportingText = if (portError) {{ Text(errorText) }} else null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                }
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    enabled = !direct,
                    label = { Text(stringResource(R.string.proxy_dialog_username_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    enabled = !direct,
                    label = { Text(stringResource(R.string.proxy_dialog_password_hint)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val proxy = if (direct) ProxyInfo(Proxy.Type.DIRECT)
                else ProxyInfo(
                    type = type,
                    host = host.trim().ifEmpty { null },
                    port = port.toIntOrNull(),
                    username = username.ifEmpty { null },
                    password = password.ifEmpty { null },
                )

                if (!direct && (proxy.host == null || proxy.port == null)) {
                    showErrors = true
                    return@TextButton
                }

                settings.update { it.copy(proxy = proxy) }
                setProxy(proxy)

                onDismiss()
            }) { Text(stringResource(android.R.string.ok)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(android.R.string.cancel)) }
        },
    )
}
