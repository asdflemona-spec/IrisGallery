/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose.settings

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.oss.licenses.OssLicensesMenuActivity
import xyz.quaver.io.util.getChild
import xyz.quaver.pupil.BuildConfig
import xyz.quaver.pupil.R
import xyz.quaver.pupil.nightMode
import xyz.quaver.pupil.setMaxConcurrentRequests
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.types.SendLogException
import xyz.quaver.pupil.ui.LockActivity
import xyz.quaver.pupil.ui.VOLUME_PAGE_TURN
import xyz.quaver.pupil.util.Crashlytics
import xyz.quaver.pupil.util.Lock
import xyz.quaver.pupil.util.LockManager
import xyz.quaver.pupil.util.MultipageFit
import xyz.quaver.pupil.util.MultipageOrder
import xyz.quaver.pupil.util.NightMode
import xyz.quaver.pupil.util.Preferences
import xyz.quaver.pupil.util.downloader.DownloadManager
import xyz.quaver.pupil.util.getAvailableLanguages
import xyz.quaver.pupil.util.updateTranslations
import java.util.Locale

private const val ROOT = "root"
private const val STORAGE = "storage"
private const val FAVORITES = "favorites"
private const val LOCK = "lock"

@Composable
fun SettingsApp(
    highlight: String?,
    onClose: () -> Unit,
    onCheckUpdate: () -> Unit,
) {
    val navController = rememberNavController()
    val backToRoot: () -> Unit = { navController.popBackStack(ROOT, inclusive = false) }

    NavHost(navController = navController, startDestination = ROOT) {
        composable(ROOT) {
            SettingsScreen(
                highlight = highlight,
                onBack = onClose,
                onCheckUpdate = onCheckUpdate,
                onManageStorage = { navController.navigate(STORAGE) },
                onManageFavorites = { navController.navigate(FAVORITES) },
                onLockSettings = { navController.navigate(LOCK) },
            )
        }
        composable(STORAGE) { ManageStorageScreen(onBack = backToRoot) }
        composable(FAVORITES) { ManageFavoritesScreen(onBack = backToRoot) }
        composable(LOCK) { LockSettingsScreen(onBack = backToRoot) }
    }
}

private enum class SettingsDialog { DEFAULT_QUERY_MOVED, DOWNLOAD_FOLDER_NAME, DOWNLOAD_LOCATION, PROXY }

@Composable
private fun SettingsScreen(
    highlight: String?,
    onBack: () -> Unit,
    onCheckUpdate: () -> Unit,
    onManageStorage: () -> Unit,
    onManageFavorites: () -> Unit,
    onLockSettings: () -> Unit,
) {
    val context = LocalContext.current
    val current = settings.value

    var pendingHighlight by rememberSaveable { mutableStateOf(highlight) }
    var dialog by rememberSaveable { mutableStateOf<SettingsDialog?>(null) }

    val unlockForLockSettings = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == Activity.RESULT_OK) onLockSettings()
    }

    SettingsScaffold(title = stringResource(R.string.settings_title), onBack = onBack) {
        Preference(
            title = stringResource(R.string.settings_app_version_title),
            summary = stringResource(R.string.settings_app_version_description, BuildConfig.VERSION_NAME),
            onClick = onCheckUpdate,
        )
        SwitchPreference(
            title = stringResource(R.string.settings_beta),
            checked = current.beta,
            onCheckedChange = { beta -> settings.update { it.copy(beta = beta) } },
        )

        PreferenceCategory(stringResource(R.string.settings_search_title))
        ListPreference(
            title = stringResource(R.string.settings_galleries_per_page),
            value = current.perPage,
            entries = listOf(5, 10, 25, 50).map { it to it.toString() },
            onValueChange = { perPage -> settings.update { it.copy(perPage = perPage) } },
        )
        SwitchPreference(
            title = stringResource(R.string.settings_simplified_search_title),
            summary = stringResource(R.string.settings_simplified_search_summary),
            checked = current.simplifiedSearch,
            onCheckedChange = { simplified -> settings.update { it.copy(simplifiedSearch = simplified) } },
        )
        Preference(
            title = stringResource(R.string.settings_default_query),
            summary = stringResource(R.string.default_query_moved_summary),
            onClick = { dialog = SettingsDialog.DEFAULT_QUERY_MOVED },
        )

        PreferenceCategory(stringResource(R.string.settings_reader_title))
        SwitchPreference(
            title = stringResource(R.string.settings_tap_sides_title),
            summary = stringResource(R.string.settings_tap_sides_summary),
            checked = current.tapSides,
            onCheckedChange = { tapSides -> settings.update { it.copy(tapSides = tapSides) } },
        )
        SwitchPreference(
            title = stringResource(R.string.settings_multipage_portrait_title),
            summary = stringResource(R.string.settings_multipage_portrait_summary),
            checked = current.multipagePortrait,
            onCheckedChange = { portrait -> settings.update { it.copy(multipagePortrait = portrait) } },
        )
        ListPreference(
            title = stringResource(R.string.settings_multipage_fit),
            value = current.multipageFit,
            entries = listOf(
                MultipageFit.SCREEN to stringResource(R.string.settings_multipage_fit_screen),
                MultipageFit.FILL to stringResource(R.string.settings_multipage_fit_fill),
            ),
            onValueChange = { fit -> settings.update { it.copy(multipageFit = fit) } },
        )
        ListPreference(
            title = stringResource(R.string.settings_multipage_order),
            value = current.multipageOrder,
            entries = listOf(
                MultipageOrder.AUTO to stringResource(R.string.settings_multipage_order_auto),
                MultipageOrder.LTR to stringResource(R.string.settings_multipage_order_ltr),
                MultipageOrder.RTL to stringResource(R.string.settings_multipage_order_rtl),
            ),
            onValueChange = { order -> settings.update { it.copy(multipageOrder = order) } },
        )
        SwitchPreference(
            title = stringResource(R.string.settings_volume_page_turn_title),
            summary = stringResource(R.string.settings_volume_page_turn_summary),
            checked = current.volumePageTurn,
            onCheckedChange = { volume -> settings.update { it.copy(volumePageTurn = volume) } },
            highlighted = pendingHighlight == VOLUME_PAGE_TURN,
            onHighlighted = { pendingHighlight = null },
        )

        PreferenceCategory(stringResource(R.string.settings_storage))
        Preference(
            title = stringResource(R.string.settings_manage_storage),
            onClick = onManageStorage,
        )
        Preference(
            title = stringResource(R.string.settings_download_folder_name),
            summary = current.downloadFolderName,
            onClick = { dialog = SettingsDialog.DOWNLOAD_FOLDER_NAME },
        )
        Preference(
            title = stringResource(R.string.settings_download_folder),
            summary = remember(current.downloadFolder) {
                runCatching { DownloadManager.getInstance(context).downloadFolder.canonicalPath }.getOrNull()
            },
            onClick = { dialog = SettingsDialog.DOWNLOAD_LOCATION },
        )
        SwitchPreference(
            title = stringResource(R.string.settings_download_archive),
            summary = stringResource(R.string.settings_download_archive_summary),
            checked = current.downloadArchive,
            onCheckedChange = { archive -> settings.update { it.copy(downloadArchive = archive) } },
        )
        ListPreference(
            title = stringResource(R.string.settings_cache_limit),
            value = current.cacheLimitGigabytes,
            entries = listOf(0, 1, 2, 4, 8, 16, 32).map {
                it to if (it == 0) stringResource(R.string.unlimited) else "${it}G"
            },
            onValueChange = { limit -> settings.update { it.copy(cacheLimitGigabytes = limit) } },
        )
        NoMediaPreference(current.downloadFolder)

        PreferenceCategory(stringResource(R.string.settings_app_lock))
        Preference(
            title = stringResource(R.string.settings_app_lock_type),
            summary = rememberOnResume { lockSummary(context) },
            onClick = {
                unlockForLockSettings.launch(
                    Intent(context, LockActivity::class.java).putExtra("force", true)
                )
            },
        )

        PreferenceCategory(stringResource(R.string.settings_networking))
        Preference(
            title = stringResource(R.string.settings_proxy_title),
            summary = current.proxy.type.name,
            onClick = { dialog = SettingsDialog.PROXY },
        )
        ListPreference(
            title = stringResource(R.string.settings_max_concurrent_download),
            value = current.maxConcurrentDownload,
            entries = listOf(0, 1, 2, 4, 8, 16, 32).map {
                it to if (it == 0) stringResource(R.string.unlimited) else it.toString()
            },
            onValueChange = { max ->
                settings.update { it.copy(maxConcurrentDownload = max) }
                setMaxConcurrentRequests(max)
            },
        )

        PreferenceCategory(stringResource(R.string.settings_miscellaneous_title))
        TagTranslationPreference(current.tagTranslation)
        SwitchPreference(
            title = stringResource(R.string.settings_security_mode_title),
            summary = stringResource(R.string.settings_security_mode_summary),
            checked = current.securityMode,
            onCheckedChange = { secure -> settings.update { it.copy(securityMode = secure) } },
        )
        ListPreference(
            title = stringResource(R.string.settings_dark_mode_title),
            value = nightMode.mode,
            entries = listOf(
                NightMode.SYSTEM to stringResource(R.string.settings_dark_mode_system),
                NightMode.ON to stringResource(R.string.settings_dark_mode_on),
                NightMode.OFF to stringResource(R.string.settings_dark_mode_off),
            ),
            onValueChange = { mode ->
                nightMode.set(mode)
                AppCompatDelegate.setDefaultNightMode(mode.delegateMode)
            },
        )
        Preference(
            title = stringResource(R.string.settings_manage_favorites),
            onClick = onManageFavorites,
        )
        UserIdPreference()
        Preference(
            title = stringResource(R.string.settings_oss),
            onClick = { context.startActivity(Intent(context, OssLicensesMenuActivity::class.java)) },
        )
    }

    val dismiss = { dialog = null }

    when (dialog) {
        SettingsDialog.DEFAULT_QUERY_MOVED -> DefaultQueryMovedDialog(onDismiss = dismiss)
        SettingsDialog.DOWNLOAD_FOLDER_NAME -> DownloadFolderNameDialog(onDismiss = dismiss)
        SettingsDialog.DOWNLOAD_LOCATION -> DownloadLocationDialog(onDismiss = dismiss)
        SettingsDialog.PROXY -> ProxyDialog(onDismiss = dismiss)
        null -> Unit
    }
}

@Composable
private fun NoMediaPreference(downloadFolder: String) {
    val context = LocalContext.current

    val noMedia = { DownloadManager.getInstance(context).downloadFolder.getChild(".nomedia") }
    var hidden by remember(downloadFolder) {
        mutableStateOf(runCatching { noMedia().exists() }.getOrDefault(false))
    }

    SwitchPreference(
        title = stringResource(R.string.settings_nomedia_title),
        checked = hidden,
        onCheckedChange = { hide ->
            val changed = runCatching {
                if (hide) noMedia().createNewFile() else noMedia().delete()
            }.getOrDefault(false)

            if (changed) hidden = hide
        },
    )
}

@Composable
private fun TagTranslationPreference(tagTranslation: String) {
    val languages = remember {
        getAvailableLanguages().map { code ->
            code to Locale.forLanguageTag(code).let { it.getDisplayLanguage(it) }
        }
    }

    ListPreference(
        title = stringResource(R.string.settings_tag_translation),
        value = tagTranslation.ifEmpty { Locale.getDefault().language },
        entries = languages,
        onValueChange = { language ->
            settings.update { it.copy(tagTranslation = language) }
            updateTranslations()
        },
    )
}

@Composable
private fun UserIdPreference() {
    val context = LocalContext.current
    val userID = remember { Preferences.get<String>("user_id") }

    Preference(
        title = stringResource(R.string.settings_user_id),
        summary = userID,
        onClick = {
            Crashlytics.recordException(SendLogException())

            (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("user_id", userID))

            Toast.makeText(context, R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show()
        },
    )
}

private fun lockSummary(context: Context): String {
    val locks = LockManager(context).locks

    if (locks.isNullOrEmpty()) return context.getString(R.string.settings_lock_none)

    return locks.joinToString(", ") {
        context.getString(
            when (it.type) {
                Lock.Type.PATTERN -> R.string.settings_lock_pattern
                Lock.Type.PIN -> R.string.settings_lock_pin
                Lock.Type.PASSWORD -> R.string.settings_lock_password
            }
        )
    }
}
