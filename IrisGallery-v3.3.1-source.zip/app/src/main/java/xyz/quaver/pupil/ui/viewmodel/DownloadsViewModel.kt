/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.snapshotFlow
import xyz.quaver.pupil.downloadsState
import xyz.quaver.pupil.util.downloader.DownloadManager

/**
 * Backs [xyz.quaver.pupil.ui.compose.DownloadsScreen].
 *
 * The download folder map is keyed by gallery ID and grows as galleries are
 * downloaded, so the newest download is its last key.
 */
class DownloadsViewModel(application: Application) :
    LocalGalleryListViewModel(application, "Downloads", downloadsState) {

    private val downloadManager get() = DownloadManager.getInstance(getApplication())

    override fun localIDs() = downloadManager.downloadFolderMap.keys.toList().asReversed()

    override fun source() = snapshotFlow { downloadManager.downloadFolderMap.keys.toList() }
}
