/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.snapshotFlow
import xyz.quaver.pupil.favorites
import xyz.quaver.pupil.favoritesState

/**
 * Backs [xyz.quaver.pupil.ui.compose.FavoritesScreen].
 *
 * [favorites] keeps the most recently favourited gallery last, so the list is
 * its reverse.
 *
 * A gallery unfavourited from its own card keeps its place until the list is
 * built again -- a pull to refresh, or the next time the app starts. The star
 * empties where it was tapped, which is the answer the tap was after; taking
 * the card away as well moves everything below it up under the finger, and
 * leaves nothing to tap again when the star was a mistake.
 *
 * Newly favourited galleries still arrive as they are added.
 */
class FavoritesViewModel(application: Application) :
    LocalGalleryListViewModel(application, "Favorites", favoritesState) {

    private var shown: List<Int> = emptyList()

    override fun localIDs(): List<Int> {
        shown = favorites.items.asReversed().filterNot(shown::contains) + shown
        return shown
    }

    // Holding the unfavourited IDs means the set this answers for changes only
    // when one is added, so a removal no longer reloads the page it is on.
    override fun source() = snapshotFlow { favorites.items.toSet() + shown }

    override fun refresh() {
        shown = emptyList()
        super.refresh()
    }
}
