/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import xyz.quaver.pupil.hitomi.GalleryBlock
import xyz.quaver.pupil.hitomi.NoResultReason
import xyz.quaver.pupil.hitomi.Revalidate
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.usesReadLater
import xyz.quaver.pupil.readLater
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.util.Crashlytics
import xyz.quaver.pupil.util.GalleryListState
import xyz.quaver.pupil.util.GalleryListStateStore
import xyz.quaver.pupil.util.downloader.Cache
import xyz.quaver.pupil.util.heapUsage
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** Scrolling moves the list every frame, so a burst settles before it is written. */
private const val STATE_WRITE_DEBOUNCE_MS = 500L

/**
 * Shared backing for the gallery lists rendered by
 * [xyz.quaver.pupil.ui.compose.GalleryList].
 *
 * A subclass only decides which IDs the list holds; the page arithmetic, the
 * concurrent block fetch and the loading/error state are the same everywhere.
 */
abstract class GalleryListViewModel(
    application: Application,
    protected val listName: String,
) : AndroidViewModel(application) {

    val galleries = mutableStateListOf<GalleryBlock>()

    /** Structured query supporting AND / OR / NOT grouping. */
    var query by mutableStateOf<SearchQuery?>(null)
        private set

    /**
     * Driven by the list's nested scroll to slide the search bar away, and reset
     * by [xyz.quaver.pupil.ui.compose.GalleryList] whenever the list is not
     * scrolled off the top.
     */
    var searchBarOffset by mutableIntStateOf(0)

    /**
     * Where the list is scrolled, kept here rather than in the composition: the
     * list is rebuilt from nothing whenever the screen is, and its own saved
     * position is measured away by the empty list the reload starts from.
     */
    var firstVisibleItemIndex by mutableIntStateOf(0)
        private set
    var firstVisibleItemScrollOffset by mutableIntStateOf(0)
        private set

    var currentPage by mutableIntStateOf(1)
        private set
    var totalItems by mutableIntStateOf(0)
        private set
    var maxPage by mutableIntStateOf(0)
        private set

    var loading by mutableStateOf(false)
        private set

    var exception by mutableStateOf<Throwable?>(null)
        private set

    /**
     * What emptied the list, worked out once the page it belongs to is already
     * on screen: answering it runs the search again a term at a time, which the
     * list has nothing to wait for.
     */
    var noResultReason by mutableStateOf<NoResultReason?>(null)
        private set

    /** A reload the user pulled for, rather than one a page or query change asked for. */
    var refreshing by mutableStateOf(false)
        private set

    val prevPageAvailable by derivedStateOf { currentPage > 1 }
    val nextPageAvailable by derivedStateOf { currentPage < maxPage }

    private val itemsPerPage: Int
        get() = settings.value.perPage.coerceAtLeast(1)

    private var loadJob: Job? = null

    private var loadedIDs: IntArray? = null

    init {
        // Read later is the one term a query answers out of local state, and the
        // card menu changes it from inside the results: a gallery unmarked there
        // has to leave the list it was unmarked from.
        viewModelScope.launch {
            snapshotFlow { readLater.items }
                .drop(1)
                .collect {
                    if (query?.usesReadLater() != true) return@collect

                    invalidateQueryCache()
                    load()
                }
        }
    }

    /** IDs to page through, in display order. Called on [Dispatchers.IO]. */
    protected abstract suspend fun galleryIDs(): IntArray

    /** Drops whatever a subclass kept from the last run of the active query. */
    protected open fun invalidateQueryCache() = Unit

    /**
     * The list has gone back to holding everything, so whatever a subclass
     * narrowed alongside the query goes back to its default too.
     */
    protected open fun onQueryCleared() = Unit

    /**
     * Why the query the last load ran found nothing, where the list can tell.
     * Called on [Dispatchers.IO].
     */
    protected open suspend fun diagnoseNoResult(): NoResultReason? = null

    /** One of the IDs the last load paged through, past the page on screen. */
    fun randomGalleryID(): Int? = loadedIDs?.randomOrNull()

    /** Re-runs the current query against hitomi rather than against what is cached. */
    open fun refresh() {
        if (refreshing) return
        refreshing = true
        invalidateQueryCache()
        load()
    }

    /**
     * Back to an unnarrowed, freshly loaded first page: the destination's own
     * navigation bar button, tapped while its list is already on screen.
     */
    fun reset() {
        query = null
        onQueryCleared()
        currentPage = 1
        onScroll(0, 0)
        refresh()
    }

    fun goToPage(page: Int) {
        if (page == currentPage || page < 1) return
        currentPage = page
        onScroll(0, 0)
        load()
    }

    fun onScroll(index: Int, offset: Int) {
        firstVisibleItemIndex = index
        firstVisibleItemScrollOffset = offset
    }

    fun onQueryChange(newQuery: SearchQuery?) {
        if (newQuery == query) return
        query = newQuery
        if (newQuery == null) onQueryCleared()
        goToFirstPage()
    }

    /**
     * Seeds the list without loading, for a subclass restoring what it stored.
     * [load] clamps a page the list has since shrunk past.
     */
    protected fun restore(state: GalleryListState) {
        query = state.query
        currentPage = state.page.coerceAtLeast(1)
        firstVisibleItemIndex = state.firstVisibleItemIndex
        firstVisibleItemScrollOffset = state.firstVisibleItemScrollOffset
        searchBarOffset = state.searchBarOffset
    }

    /** The state every list keeps, for a subclass to add its own to. */
    protected fun stateSnapshot() = GalleryListState(
        query = query,
        page = currentPage,
        firstVisibleItemIndex = firstVisibleItemIndex,
        firstVisibleItemScrollOffset = firstVisibleItemScrollOffset,
        searchBarOffset = searchBarOffset,
    )

    /**
     * Watching the state beats writing from each setter: the page also moves
     * when a load clamps it, which no caller goes through.
     */
    protected fun persistTo(store: GalleryListStateStore, snapshot: () -> GalleryListState) {
        viewModelScope.launch {
            snapshotFlow(snapshot)
                .drop(1)
                .debounce(STATE_WRITE_DEBOUNCE_MS)
                .collect(store::set)
        }
    }

    protected fun goToFirstPage() {
        currentPage = 1
        onScroll(0, 0)
        load()
    }

    fun load() {
        viewModelScope.launch {
            loadJob?.cancelAndJoin()

            // A gallery whose block cannot be fetched again -- the reader is
            // busy on the same connection, say -- keeps the one it is already
            // showing rather than dropping off the list until the next load.
            val shown = galleries.associateBy { it.id }

            // A refresh leaves the page it is replacing on screen until the new
            // one has arrived, so the pull indicator is the only thing moving.
            val replacing = refreshing

            if (!replacing) galleries.clear()
            loading = true
            exception = null
            noResultReason = null

            loadJob = launch(Dispatchers.IO) {
                runCatching {
                    yield()

                    Crashlytics.log("$listName: loading page $currentPage, ${heapUsage()}")

                    val ids =
                        if (replacing) withContext(Revalidate()) { galleryIDs() } else galleryIDs()

                    Crashlytics.log("$listName: ${ids.size} galleries, ${heapUsage()}")

                    val pageCount = ceil(ids.size / itemsPerPage.toDouble()).toInt()
                    // The set backing a list can shrink under a page we are on.
                    val page = currentPage.coerceIn(1, max(pageCount, 1))

                    withContext(Dispatchers.Main) {
                        loadedIDs = ids
                        totalItems = ids.size
                        maxPage = pageCount
                        if (page != currentPage) {
                            currentPage = page
                            onScroll(0, 0)
                        }
                    }

                    val from = max((page - 1) * itemsPerPage, 0)
                    val to = min(page * itemsPerPage, ids.size)

                    val fetched = mutableListOf<GalleryBlock>()

                    // Fetch the page's blocks concurrently, but append in order so
                    // the list doesn't shuffle as responses land.
                    if (from < to)
                        ids.copyOfRange(from, to)
                            .map { galleryID ->
                                galleryID to async {
                                    runCatching {
                                        Cache.getInstance(getApplication(), galleryID)
                                            .getGalleryBlock()
                                    }.getOrNull()
                                }
                            }
                            .forEach { (galleryID, deferred) ->
                                yield()
                                val block = deferred.await() ?: shown[galleryID] ?: return@forEach
                                if (replacing) fetched.add(block)
                                else withContext(Dispatchers.Main) { galleries.add(block) }
                            }

                    if (replacing) withContext(Dispatchers.Main) {
                        galleries.clear()
                        galleries.addAll(fetched)
                    }
                }.onFailure {
                    if (it is CancellationException) throw it
                    if (it is OutOfMemoryError) Crashlytics.recordException(it)
                    withContext(Dispatchers.Main) { exception = it }
                }

                withContext(Dispatchers.Main) {
                    loading = false
                    refreshing = false
                }

                if (exception == null && totalItems == 0) {
                    val reason = try {
                        diagnoseNoResult()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        Crashlytics.log("$listName: could not tell why the search found nothing: $e")
                        null
                    }

                    withContext(Dispatchers.Main) { noResultReason = reason }
                }
            }
        }
    }
}
