/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.snapshotFlow
import xyz.quaver.pupil.histories
import xyz.quaver.pupil.historyState

/**
 * Backs [xyz.quaver.pupil.ui.compose.HistoryScreen].
 *
 * [histories] keeps the most recently opened gallery last, so the list is its
 * reverse.
 */
class HistoryViewModel(application: Application) :
    LocalGalleryListViewModel(application, "History", historyState) {

    override fun localIDs() = histories.items.asReversed()

    override fun source() = snapshotFlow { histories.items }
}
