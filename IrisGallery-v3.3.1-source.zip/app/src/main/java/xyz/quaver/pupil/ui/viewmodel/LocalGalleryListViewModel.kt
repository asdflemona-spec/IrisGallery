/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.viewmodel

import android.app.Application
import androidx.collection.IntSet
import androidx.collection.MutableIntSet
import androidx.collection.emptyIntSet
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import xyz.quaver.pupil.hitomi.NoResultReason
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.emptyTerm
import xyz.quaver.pupil.hitomi.evaluateWithin
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.hitomi.shape
import xyz.quaver.pupil.util.Crashlytics
import xyz.quaver.pupil.util.GalleryListStateStore

/**
 * A list of gallery IDs the app keeps for itself -- history, favourites,
 * downloads -- rather than one hitomi answers with.
 *
 * A query narrows such a list instead of replacing it, the way
 * `MainActivity`'s non-search modes did: the search runs against hitomi and
 * only decides which of [localIDs] survive.
 *
 * The list follows [source] rather than being told when to re-read, since what
 * it shows changes from the reader, a service or the settings screen while it
 * is on screen.
 */
abstract class LocalGalleryListViewModel(
    application: Application,
    listName: String,
    private val store: GalleryListStateStore,
) : GalleryListViewModel(application, listName) {

    private class QueryMatches(
        val query: SearchQuery,
        val checked: IntSet,
        val matching: IntSet,
    )

    private var cachedMatches: QueryMatches? = null

    /** The IDs to show when no query narrows them, newest first. */
    protected abstract fun localIDs(): List<Int>

    /** Emits whenever [localIDs] would answer differently. */
    protected abstract fun source(): Flow<*>

    init {
        restore(store.state)
        persistTo(store) { stateSnapshot() }

        load()

        viewModelScope.launch {
            // A subclass is still being constructed here, so its own fields are
            // unassigned, and viewModelScope runs a launch on the spot when it
            // is already on the main thread. [source] waits for a dispatch.
            yield()

            source().drop(1).collect { load() }
        }
    }

    override fun invalidateQueryCache() {
        cachedMatches = null
    }

    /**
     * Only a term that matches nothing anywhere: everything else a query does
     * here it does within one list, which is too small a pool to read anything
     * into an empty result.
     */
    override suspend fun diagnoseNoResult(): NoResultReason? =
        query?.let { hitomiClient.emptyTerm(it) }?.let(NoResultReason::EmptyTerm)

    final override suspend fun galleryIDs(): IntArray {
        val ids = localIDs()

        val currentQuery = query ?: return ids.toIntArray()

        val known = cachedMatches?.takeIf { it.query == currentQuery }
            ?: QueryMatches(currentQuery, emptyIntSet(), emptyIntSet())

        val unchecked = ids.filterNot { known.checked.contains(it) }.toIntArray()

        if (unchecked.isNotEmpty()) {
            Crashlytics.setCustomKey("last_query", "$listName ${currentQuery.shape()}")
            Crashlytics.log(
                "$listName: evaluating ${currentQuery.shape()} " +
                    "within ${unchecked.size} of ${ids.size} galleries",
            )
        }

        val matches = if (unchecked.isEmpty()) known else QueryMatches(
            query = currentQuery,
            checked = known.checked + unchecked,
            matching = known.matching + hitomiClient.evaluateWithin(currentQuery, unchecked),
        ).also { cachedMatches = it }

        return ids.filter { matches.matching.contains(it) }.toIntArray()
    }

    private operator fun IntSet.plus(ids: IntArray): IntSet =
        MutableIntSet(size + ids.size).also {
            it += this
            it += ids
        }
}
