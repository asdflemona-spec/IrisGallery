/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.hitomi.GalleryInfo
import xyz.quaver.pupil.readProgress
import xyz.quaver.pupil.util.downloader.Cache
import xyz.quaver.pupil.util.downloader.DownloadState
import xyz.quaver.pupil.util.downloader.Downloads
import xyz.quaver.pupil.util.resumePage

private const val GALLERY_INFO_POLL_INTERVAL = 1000L

/**
 * Backs [xyz.quaver.pupil.ui.compose.reader.ReaderScreen].
 *
 * [startPage] is the one-based page the reader was opened at, or 0 to resume
 * where the gallery was left.
 */
class ReaderViewModel(
    application: Application,
    val galleryID: Int,
    private var startPage: Int,
) : AndroidViewModel(application) {

    val cache: Cache = Cache.getInstance(application, galleryID)

    var galleryInfo by mutableStateOf<GalleryInfo?>(null)
        private set

    val pageCount: Int
        get() = galleryInfo?.files?.size ?: 0

    /** One-based; the downloader fetches the images nearest it first. */
    var currentPage by mutableIntStateOf(0)
        private set

    private var furthestPage = 0

    var cameraEnabled by mutableStateOf(false)

    /** Seconds per page, while the pages turn on a timer. */
    var pageTurnInterval by mutableStateOf<Int?>(null)

    private var opened = false

    init {
        viewModelScope.launch {
            while (galleryInfo == null) {
                delay(GALLERY_INFO_POLL_INTERVAL)

                val state = Downloads.state(galleryID)

                // Nothing is coming for a gallery hitomi does not have; the
                // snackbar says so, and there is no metadata to wait for.
                if (state is DownloadState.NotFound) return@launch

                if (state == null || state is DownloadState.Preparing) continue

                galleryInfo = withContext(Dispatchers.IO) { cache.metadata.galleryInfo }
            }
        }
    }

    /**
     * The page to bring on screen when the pages are laid out again: where the
     * reader asked to start the first time, and where it is after that.
     */
    fun pageToShow(): Int {
        if (opened) return currentPage

        opened = true

        val page = startPage.takeIf { it in 1..pageCount } ?: readProgress[galleryID].resumePage(pageCount)
        startPage = 0

        return page
    }

    /** The first page on screen and the last one fully shown, both one-based. */
    fun onPagesShown(first: Int, last: Int) {
        if (first != currentPage) {
            currentPage = first
            Downloads.focus(galleryID, first - 1)
        }

        furthestPage = maxOf(furthestPage, last)
    }

    fun recordProgress() {
        if (furthestPage > 0 && pageCount > 0)
            readProgress.record(galleryID, furthestPage, pageCount)
    }

    /** Where the downloader should start, including before the gallery info says how many pages there are. */
    fun focusPage(): Int? = when {
        opened -> (currentPage - 1).takeIf { it >= 0 }
        startPage > 0 -> startPage - 1
        else -> readProgress[galleryID]?.let { it.resumePage(it.pageCount) - 1 }
    }
}
