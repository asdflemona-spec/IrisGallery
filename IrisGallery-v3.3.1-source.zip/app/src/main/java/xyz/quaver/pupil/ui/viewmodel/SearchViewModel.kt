/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import xyz.quaver.pupil.hitomi.NoResultReason
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.SortMode
import xyz.quaver.pupil.hitomi.diagnoseNoResult
import xyz.quaver.pupil.hitomi.doSearch
import xyz.quaver.pupil.hitomi.evaluate
import xyz.quaver.pupil.hitomi.hitomiClient
import xyz.quaver.pupil.hitomi.shape
import xyz.quaver.pupil.searchState
import xyz.quaver.pupil.util.Crashlytics
import xyz.quaver.pupil.util.DefaultQuery

/**
 * Backs [xyz.quaver.pupil.ui.compose.SearchScreen].
 *
 * Deliberately sits on the existing [doSearch] stack rather than a new
 * networking layer, so this change is UI-only.
 */
class SearchViewModel(application: Application) : GalleryListViewModel(application, "Search") {

    var sortMode by mutableStateOf(SortMode.DATE_ADDED)
        private set

    /** Gallery IDs for the active query, reused across page turns. */
    private var cachedIDs: IntArray? = null

    private var cachedQuery: SearchQuery? = null
    private var cachedSortMode: SortMode? = null

    init {
        sortMode = searchState.state.sortMode
        restore(searchState.state)

        persistTo(searchState) { stateSnapshot().copy(sortMode = sortMode) }
    }

    override suspend fun galleryIDs(): IntArray {
        val currentQuery = DefaultQuery.apply(query)

        cachedIDs?.let {
            if (cachedQuery == currentQuery && cachedSortMode == sortMode) return it
        }

        val shape = currentQuery?.shape() ?: "everything"
        Crashlytics.setCustomKey("last_query", "$listName $shape")
        Crashlytics.log("$listName: evaluating $shape sorted by $sortMode")

        // A null query means "everything", which doSearch expresses as an empty
        // string; anything else goes through the tree.
        val ids = currentQuery?.let { hitomiClient.evaluate(it, sortMode) }
            ?: hitomiClient.doSearch("", sortMode)

        cachedIDs = ids
        cachedQuery = currentQuery
        cachedSortMode = sortMode

        return ids
    }

    override fun invalidateQueryCache() {
        cachedIDs = null
    }

    override fun onQueryCleared() {
        sortMode = SortMode.DATE_ADDED
    }

    override suspend fun diagnoseNoResult(): NoResultReason? = hitomiClient.diagnoseNoResult(
        query = query,
        languages = DefaultQuery.languageTerm,
        requiredTags = DefaultQuery.requiredTags,
        bannedTags = DefaultQuery.bannedTags,
        sortMode = sortMode,
    )

    fun onDefaultQueryChange() {
        goToFirstPage()
    }

    fun onSortModeChange(newSortMode: SortMode) {
        if (newSortMode == sortMode) return
        sortMode = newSortMode
        goToFirstPage()
    }
}
