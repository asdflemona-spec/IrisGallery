/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.app.ActivityManager
import android.content.Context
import android.util.Log
import androidx.core.content.getSystemService
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics

private const val TAG = "Crashlytics"

/**
 * Crash reporting for a build that may have none.
 *
 * Without google-services.json there is no default [FirebaseApp] --
 * [FirebaseApp.initializeApp] returns null and [FirebaseCrashlytics.getInstance]
 * throws -- so such a build reports to the log instead of crashing on the way
 * to the crash reporter.
 */
object Crashlytics {

    private var crashlytics: FirebaseCrashlytics? = null

    fun init(context: Context, userID: String) {
        crashlytics = FirebaseApp.initializeApp(context)?.let { FirebaseCrashlytics.getInstance() }

        if (crashlytics == null) Log.w(TAG, "no google-services.json; not reporting crashes")
        else crashlytics?.setUserId(userID)

        setCustomKey("heap_max_mb", (Runtime.getRuntime().maxMemory() / MB).toInt())
        context.getSystemService<ActivityManager>()?.let {
            setCustomKey("memory_class_mb", it.memoryClass)
            setCustomKey("low_ram_device", it.isLowRamDevice)
        }
    }

    fun log(message: String) {
        val crashlytics = crashlytics

        if (crashlytics == null) Log.d(TAG, message)
        else crashlytics.log(message)
    }

    fun recordException(throwable: Throwable) {
        val crashlytics = crashlytics

        if (crashlytics == null) Log.w(TAG, "not reported", throwable)
        else crashlytics.recordException(throwable)
    }

    fun setCustomKey(key: String, value: Int) {
        crashlytics?.setCustomKey(key, value)
    }

    fun setCustomKey(key: String, value: Boolean) {
        crashlytics?.setCustomKey(key, value)
    }

    fun setCustomKey(key: String, value: String) {
        crashlytics?.setCustomKey(key, value)
    }
}

private const val MB = 1024 * 1024

fun heapUsage(): String = Runtime.getRuntime().let {
    "heap ${(it.totalMemory() - it.freeMemory()) / MB}/${it.maxMemory() / MB} MB"
}
