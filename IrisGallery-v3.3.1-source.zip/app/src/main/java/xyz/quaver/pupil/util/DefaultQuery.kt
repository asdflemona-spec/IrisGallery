/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import kotlinx.serialization.json.Json
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.types.Tag

private const val PREFERENCE_KEY = "default_query"

object DefaultQuery {

    private val _languages = mutableStateListOf<String>()

    val languages: List<String> get() = _languages

    private val _requiredTags = mutableStateListOf<SearchQuery.Tag>()

    val requiredTags: List<SearchQuery.Tag> get() = _requiredTags

    private val _bannedTags = mutableStateListOf<SearchQuery.Tag>()

    val bannedTags: List<SearchQuery.Tag> get() = _bannedTags

    val signature: String
        get() = encodeDefaultQuery(languages, requiredTags, bannedTags)

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == PREFERENCE_KEY) reload()
    }

    fun init() {
        reload()
        Preferences.registerOnSharedPreferenceChangeListener(listener)
    }

    /** The picked languages as the one term [apply] narrows a search with. */
    val languageTerm: SearchQuery?
        get() = languages.map { SearchQuery.Tag("language", it) }.let { tags ->
            when (tags.size) {
                0 -> null
                1 -> tags.single()
                else -> SearchQuery.Or(tags)
            }
        }

    fun apply(query: SearchQuery?): SearchQuery? {
        val terms = buildList {
            query?.let { add(it) }

            languageTerm?.let { add(it) }

            requiredTags.forEach { add(it) }

            bannedTags.forEach { add(SearchQuery.Not(it)) }
        }

        return when (terms.size) {
            0 -> null
            1 -> terms.single()
            else -> SearchQuery.And(terms)
        }
    }

    fun isLanguageSelected(code: String) = _languages.contains(code)

    fun toggleLanguage(code: String) {
        if (!_languages.remove(code)) _languages.add(code)

        save()
    }

    fun clearLanguages() {
        if (_languages.isEmpty()) return

        _languages.clear()
        save()
    }

    fun isRequired(tag: SearchQuery.Tag) = _requiredTags.contains(tag.spaced())

    fun addRequired(tag: SearchQuery.Tag) {
        val spaced = tag.spaced()
        if (_requiredTags.contains(spaced)) return

        _requiredTags.add(spaced)
        save()
    }

    fun removeRequired(tag: SearchQuery.Tag) {
        if (!_requiredTags.remove(tag.spaced())) return

        save()
    }

    fun isBanned(tag: SearchQuery.Tag) = _bannedTags.contains(tag.spaced())

    fun ban(tag: SearchQuery.Tag) {
        val spaced = tag.spaced()
        if (_bannedTags.contains(spaced)) return

        _bannedTags.add(spaced)
        save()
    }

    fun unban(tag: SearchQuery.Tag) {
        if (!_bannedTags.remove(tag.spaced())) return

        save()
    }

    private fun save() {
        Preferences[PREFERENCE_KEY] = signature
    }

    private fun reload() {
        val stored: String = Preferences[PREFERENCE_KEY]

        if (stored == signature) return

        val terms = parseDefaultQuery(stored)

        _languages.clear()
        _languages.addAll(terms.languages)

        _requiredTags.clear()
        _requiredTags.addAll(terms.requiredTags)

        _bannedTags.clear()
        _bannedTags.addAll(terms.bannedTags)
    }
}

/** What [DefaultQuery] keeps, as it is stored. */
internal data class DefaultQueryTerms(
    val languages: List<String> = emptyList(),
    val requiredTags: List<SearchQuery.Tag> = emptyList(),
    val bannedTags: List<SearchQuery.Tag> = emptyList(),
)

/**
 * Hitomi answers to either spelling -- [xyz.quaver.pupil.hitomi.getGalleryIDsForQuery]
 * reads an underscore as a space -- but a tag chip carries the spaced form, so
 * an underscore kept here matches no chip and shows as unbanned. Users typed
 * them for as long as a space could not be stored.
 */
private fun SearchQuery.Tag.spaced() =
    if (tag.contains('_')) copy(tag = tag.replace('_', ' ')) else this

private val json = Json

/**
 * A JSON array rather than the terms joined by spaces, which a tag is allowed
 * to contain: splitting `-artist:mizuryu kei` back apart on spaces left a
 * banned `-artist:mizuryu` and a required `kei`.
 */
internal fun encodeDefaultQuery(
    languages: List<String>,
    requiredTags: List<SearchQuery.Tag>,
    bannedTags: List<SearchQuery.Tag>,
): String = json.encodeToString(
    buildList {
        languages.forEach { add("language:$it") }
        requiredTags.forEach { add(it.toString()) }
        bannedTags.forEach { add("-$it") }
    }
)

internal fun parseDefaultQuery(stored: String): DefaultQueryTerms {
    val tags = runCatching { json.decodeFromString<List<String>>(stored) }
        // Stored while the terms were joined by spaces, so it splits on them.
        .getOrElse { stored.split(' ') }
        .filter { it.isNotBlank() }
        .map { Tag.parse(it) }
        .distinct()

    return DefaultQueryTerms(
        languages = tags.filter { it.area == "language" && !it.isNegative }.map { it.tag },
        requiredTags = tags.filter { !it.isNegative && it.area != "language" }
            .map { SearchQuery.Tag(it.area, it.tag).spaced() },
        bannedTags = tags.filter { it.isNegative }
            .map { SearchQuery.Tag(it.area, it.tag).spaced() },
    )
}
