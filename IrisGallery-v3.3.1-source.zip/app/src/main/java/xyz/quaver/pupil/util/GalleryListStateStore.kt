/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import androidx.datastore.core.CorruptionException
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.Serializer
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.dataStoreFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.SortMode
import java.io.InputStream
import java.io.OutputStream

/** Where a gallery list was left. Every field defaults on its own. */
@Serializable
data class GalleryListState(
    val query: SearchQuery? = null,
    val sortMode: SortMode = SortMode.DATE_ADDED,
    val page: Int = 1,
    val firstVisibleItemIndex: Int = 0,
    val firstVisibleItemScrollOffset: Int = 0,
    val searchBarOffset: Int = 0,
)

/**
 * One gallery list's place, persisted through DataStore.
 *
 * The read on [init] blocks, the way [NightModeStore]'s does: the view model
 * reads [state] as it is constructed and loads from it immediately, and a state
 * arriving after that would show as the screen fetching page one and then
 * replacing it with where you actually were.
 */
class GalleryListStateStore(private val fileName: String) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var store: DataStore<GalleryListState>

    /** Not snapshot state: nothing composes off it, the view model owns the live copy. */
    var state: GalleryListState = GalleryListState()
        private set

    fun init(context: Context) {
        store = DataStoreFactory.create(
            serializer = GalleryListStateSerializer,
            corruptionHandler = ReplaceFileCorruptionHandler {
                Crashlytics.recordException(it)
                GalleryListState()
            },
            scope = scope,
            produceFile = { context.dataStoreFile(fileName) },
        )

        state = runBlocking { store.data.first() }
    }

    fun set(newState: GalleryListState) {
        state = newState

        scope.launch { store.updateData { newState } }
    }
}

private val json = Json { ignoreUnknownKeys = true }

internal object GalleryListStateSerializer : Serializer<GalleryListState> {

    override val defaultValue = GalleryListState()

    override suspend fun readFrom(input: InputStream): GalleryListState =
        runCatching { json.decodeFromString<GalleryListState>(input.readBytes().decodeToString()) }
            .getOrElse { throw CorruptionException("Unreadable gallery list state", it) }

    override suspend fun writeTo(t: GalleryListState, output: OutputStream) =
        output.write(json.encodeToString(t).encodeToByteArray())
}
