/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.core.DataMigration
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.Serializer
import androidx.datastore.dataStoreFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.InputStream
import java.io.OutputStream

/** How the gallery lists draw their galleries. [THIN] leaves the tags off the cards. */
enum class ListStyle(val value: String) {
    DETAILED("detailed"),
    THIN("thin"),
    GRID("grid");

    companion object {
        fun of(value: String?) = entries.firstOrNull { it.value == value } ?: DETAILED
    }
}

class ListStyleStore(private val fileName: String) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var store: DataStore<ListStyle>

    var style: ListStyle by mutableStateOf(ListStyle.DETAILED)
        private set

    fun init(context: Context) {
        store = DataStoreFactory.create(
            serializer = ListStyleSerializer,
            migrations = listOf(ThinPreferenceMigration),
            scope = scope,
            produceFile = { context.dataStoreFile(fileName) },
        )

        style = runBlocking { store.data.first() }

        scope.launch { store.data.collect { style = it } }
    }

    fun set(newStyle: ListStyle) {
        style = newStyle

        scope.launch { store.updateData { newStyle } }
    }
}

internal object ListStyleSerializer : Serializer<ListStyle> {
    override val defaultValue = ListStyle.DETAILED

    override suspend fun readFrom(input: InputStream) =
        ListStyle.of(input.readBytes().decodeToString())

    override suspend fun writeTo(t: ListStyle, output: OutputStream) =
        output.write(t.value.encodeToByteArray())
}

private object ThinPreferenceMigration : DataMigration<ListStyle> {
    private const val KEY = "thin"

    override suspend fun shouldMigrate(currentData: ListStyle) = Preferences.contains(KEY)

    override suspend fun migrate(currentData: ListStyle) =
        if (Preferences[KEY, false]) ListStyle.THIN else ListStyle.DETAILED

    override suspend fun cleanUp() = Preferences.remove(KEY)
}
