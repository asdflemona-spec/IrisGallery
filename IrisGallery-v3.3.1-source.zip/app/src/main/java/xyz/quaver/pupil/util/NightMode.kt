/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.core.DataMigration
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.Serializer
import androidx.datastore.dataStoreFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.InputStream
import java.io.OutputStream

enum class NightMode(val value: String, val delegateMode: Int) {
    SYSTEM("system", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM),
    ON("on", AppCompatDelegate.MODE_NIGHT_YES),
    OFF("off", AppCompatDelegate.MODE_NIGHT_NO);

    companion object {
        fun of(value: String?) = entries.firstOrNull { it.value == value } ?: SYSTEM
    }
}

/**
 * The dark mode setting, persisted through DataStore and mirrored into snapshot
 * state so Compose recomposes on every change.
 *
 * The read on [init] blocks: `AppCompatDelegate` has to be told the mode before
 * the first activity is themed, and a mode that arrives afterwards would show
 * as the app repainting itself in front of the user.
 */
class NightModeStore(private val fileName: String) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var store: DataStore<NightMode>

    var mode: NightMode by mutableStateOf(NightMode.SYSTEM)
        private set

    fun init(context: Context) {
        store = DataStoreFactory.create(
            serializer = NightModeSerializer,
            migrations = listOf(DarkModeSwitchMigration),
            scope = scope,
            produceFile = { context.dataStoreFile(fileName) },
        )

        mode = runBlocking { store.data.first() }

        scope.launch { store.data.collect { mode = it } }
    }

    fun set(newMode: NightMode) {
        mode = newMode

        scope.launch { store.updateData { newMode } }
    }
}

private object NightModeSerializer : Serializer<NightMode> {
    override val defaultValue = NightMode.SYSTEM

    override suspend fun readFrom(input: InputStream) =
        NightMode.of(input.readBytes().decodeToString())

    override suspend fun writeTo(t: NightMode, output: OutputStream) =
        output.write(t.value.encodeToByteArray())
}

/** One-shot import of the `dark_mode` switch this store replaces. */
private object DarkModeSwitchMigration : DataMigration<NightMode> {
    override suspend fun shouldMigrate(currentData: NightMode) = Preferences.contains("dark_mode")

    override suspend fun migrate(currentData: NightMode) =
        if (Preferences["dark_mode", false]) NightMode.ON else NightMode.OFF

    override suspend fun cleanUp() = Preferences.remove("dark_mode")
}
