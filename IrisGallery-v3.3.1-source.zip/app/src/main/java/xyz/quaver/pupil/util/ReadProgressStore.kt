/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.core.CorruptionException
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.Serializer
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.dataStoreFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.io.InputStream
import java.io.OutputStream

/** The furthest page read in a gallery, out of the pages it had then. */
@Serializable
data class ReadProgress(val page: Int, val pageCount: Int) {
    val fraction: Float
        get() = if (pageCount > 0) (page.toFloat() / pageCount).coerceIn(0f, 1f) else 0f
}

fun ReadProgress?.advancedTo(page: Int, pageCount: Int) =
    ReadProgress(maxOf(page, this?.page ?: 0).coerceAtMost(pageCount), pageCount)

/** The page the reader opens at: the furthest read, or the first one once the gallery was finished. */
fun ReadProgress?.resumePage(pageCount: Int) =
    if (this == null || page !in 1 until pageCount) 1 else page

/**
 * [ReadProgress] by gallery ID, persisted through DataStore and mirrored into
 * snapshot state so the gallery cards recompose on every change.
 */
class ReadProgressStore(private val fileName: String) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var store: DataStore<Map<Int, ReadProgress>>

    var progress: Map<Int, ReadProgress> by mutableStateOf(emptyMap())
        private set

    fun init(context: Context) {
        store = DataStoreFactory.create(
            serializer = ReadProgressSerializer,
            corruptionHandler = ReplaceFileCorruptionHandler {
                Crashlytics.recordException(it)
                emptyMap()
            },
            scope = scope,
            produceFile = { context.dataStoreFile(fileName) },
        )

        scope.launch { store.data.collect { progress = it } }
    }

    operator fun get(galleryID: Int) = progress[galleryID]

    fun record(galleryID: Int, page: Int, pageCount: Int) = update {
        it + (galleryID to it[galleryID].advancedTo(page, pageCount))
    }

    fun remove(galleryID: Int) = update { it - galleryID }

    fun clear() = update { emptyMap() }

    private fun update(transform: (Map<Int, ReadProgress>) -> Map<Int, ReadProgress>) {
        progress = transform(progress)

        scope.launch { store.updateData(transform) }
    }
}

internal object ReadProgressSerializer : Serializer<Map<Int, ReadProgress>> {

    private val serializer = MapSerializer(Int.serializer(), ReadProgress.serializer())

    override val defaultValue = emptyMap<Int, ReadProgress>()

    override suspend fun readFrom(input: InputStream): Map<Int, ReadProgress> =
        runCatching { Json.decodeFromString(serializer, input.readBytes().decodeToString()) }
            .getOrElse { throw CorruptionException("Unreadable read progress", it) }

    override suspend fun writeTo(t: Map<Int, ReadProgress>, output: OutputStream) =
        output.write(Json.encodeToString(serializer, t).encodeToByteArray())
}
