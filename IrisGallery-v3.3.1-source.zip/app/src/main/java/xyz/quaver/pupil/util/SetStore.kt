/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.datastore.core.CorruptionException
import androidx.datastore.core.DataMigration
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.Serializer
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.dataStoreFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Insertion-ordered set persisted through DataStore and mirrored into snapshot
 * state so Compose recomposes on every change.
 *
 * Writes are atomic and leave the caller's thread; reads never do, because the
 * reader wants an answer the moment it starts.
 * DataStore stays the source of truth -- every write goes to it and comes back
 * through [items].
 */
class SetStore<T : Any>(
    private val fileName: String,
    elementSerializer: KSerializer<T>,
    // Null for a set that never had a [SavedSet] file to import.
    private val legacyFileName: String? = null,
    // How to read that file when what it holds is not already [T]: 5.x kept the
    // search history as the query lines the reader typed, not as queries.
    private val readLegacy: ((String) -> List<T>)? = null,
) {
    private val serializer = ListSerializer(elementSerializer)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var store: DataStore<List<T>>

    var items: List<T> by mutableStateOf(emptyList())
        private set

    val size: Int get() = items.size

    fun init(context: Context) {
        store = DataStoreFactory.create(
            serializer = JsonListSerializer(serializer),
            corruptionHandler = ReplaceFileCorruptionHandler {
                Crashlytics.recordException(it)
                emptyList()
            },
            migrations = legacyFileName?.let {
                listOf(
                    SavedSetMigration(
                        File(ContextCompat.getDataDir(context), it),
                        readLegacy ?: { text -> Json.decodeFromString(serializer, text) },
                    )
                )
            } ?: emptyList(),
            scope = scope,
            produceFile = { context.dataStoreFile(fileName) },
        )

        items = runBlocking { store.data.first() }

        scope.launch { store.data.collect { items = it } }
    }

    fun contains(item: T) = items.contains(item)

    fun add(item: T) = update { it - item + item }

    fun remove(item: T) = update { it - item }

    fun toggle(item: T) = if (contains(item)) remove(item) else add(item)

    fun addAll(newItems: Collection<T>) = update { it - newItems.toSet() + newItems }

    fun removeAll(oldItems: Collection<T>) = update { it - oldItems.toSet() }

    fun clear() = update { emptyList() }

    // Applied to the mirror first: the reader's menu reads the set back the
    // moment it writes to it, and cannot wait for the file. DataStore skips the
    // write when the transform is a no-op, so an update that changes nothing
    // costs nothing.
    private fun update(transform: (List<T>) -> List<T>) {
        items = transform(items)

        scope.launch { store.updateData(transform) }
    }
}

internal class JsonListSerializer<T>(
    private val serializer: KSerializer<List<T>>,
) : Serializer<List<T>> {

    override val defaultValue = emptyList<T>()

    override suspend fun readFrom(input: InputStream): List<T> =
        runCatching { Json.decodeFromString(serializer, input.readBytes().decodeToString()) }
            .getOrElse { throw CorruptionException("Unreadable saved set", it) }

    override suspend fun writeTo(t: List<T>, output: OutputStream) =
        output.write(Json.encodeToString(serializer, t).encodeToByteArray())
}

/** One-shot import of the [SavedSet] JSON file the store replaces. */
internal class SavedSetMigration<T>(
    private val file: File,
    private val read: (String) -> List<T>,
) : DataMigration<List<T>> {

    override suspend fun shouldMigrate(currentData: List<T>) = file.exists()

    override suspend fun migrate(currentData: List<T>): List<T> {
        val legacy = runCatching { read(file.readText()) }.getOrDefault(emptyList())

        return currentData + legacy.filterNot(currentData::contains)
    }

    override suspend fun cleanUp() {
        file.delete()
    }
}
