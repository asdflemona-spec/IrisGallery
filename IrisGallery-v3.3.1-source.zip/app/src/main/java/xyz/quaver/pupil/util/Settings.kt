/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.edit
import androidx.datastore.core.CorruptionException
import androidx.datastore.core.DataMigration
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.Serializer
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.dataStoreFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.InputStream
import java.io.OutputStream
import java.net.Proxy

@Serializable
enum class MultipageFit {
    @SerialName("screen") SCREEN,
    @SerialName("fill") FILL,
}

@Serializable
enum class MultipageOrder {
    @SerialName("auto") AUTO,
    @SerialName("ltr") LTR,
    @SerialName("rtl") RTL,
}

@Serializable
enum class ReaderLayout {
    @SerialName("single") SINGLE,
    @SerialName("double") DOUBLE,
    /** Two pages where there is room for them: landscape, or a wide portrait screen when allowed. */
    @SerialName("auto") AUTO,
}

@Serializable
enum class ReaderOrientation {
    @SerialName("vertical") VERTICAL,
    @SerialName("horizontal") HORIZONTAL,
}

const val DEFAULT_DOWNLOAD_FOLDER_NAME = "[-id-] -title-"

@Serializable
data class Settings(
    val beta: Boolean = false,

    val perPage: Int = 25,
    val simplifiedSearch: Boolean = false,

    val tapSides: Boolean = true,
    val instantFlip: Boolean = false,
    val readerLayout: ReaderLayout = ReaderLayout.AUTO,
    val readerOrientation: ReaderOrientation = ReaderOrientation.HORIZONTAL,
    val readerReverse: Boolean = false,
    val readerSnap: Boolean = true,
    val readerPadding: Boolean = true,
    val multipagePortrait: Boolean = false,
    val multipageFit: MultipageFit = MultipageFit.SCREEN,
    val multipageOrder: MultipageOrder = MultipageOrder.AUTO,
    val multipageCover: Boolean = true,
    val volumePageTurn: Boolean = true,

    val downloadFolder: String = "",
    val downloadFolderName: String = DEFAULT_DOWNLOAD_FOLDER_NAME,
    val downloadArchive: Boolean = false,
    val cacheLimitGigabytes: Int = 8,

    val lockTimeoutMinutes: Int = 5,
    val lockFingerprint: Boolean = false,

    val proxy: ProxyInfo = ProxyInfo(Proxy.Type.DIRECT),
    val maxConcurrentDownload: Int = 0,

    val tagTranslation: String = "",
    val securityMode: Boolean = false,
)

class SettingsStore(private val fileName: String) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var store: DataStore<Settings>

    var value: Settings by mutableStateOf(Settings())
        private set

    fun init(context: Context) {
        store = DataStoreFactory.create(
            serializer = SettingsSerializer,
            corruptionHandler = ReplaceFileCorruptionHandler {
                Crashlytics.recordException(it)
                Settings()
            },
            migrations = listOf(SharedPreferencesSettingsMigration),
            scope = scope,
            produceFile = { context.dataStoreFile(fileName) },
        )

        value = runBlocking { store.data.first() }

        scope.launch { store.data.collect { value = it } }
    }

    fun update(transform: (Settings) -> Settings) {
        value = transform(value)

        scope.launch { store.updateData(transform) }
    }
}

// Defaults are written too, so a field missing from a stored file means the
// file predates it, which is what the reader options are migrated by.
private val json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
}

internal object SettingsSerializer : Serializer<Settings> {
    override val defaultValue = Settings()

    override suspend fun readFrom(input: InputStream): Settings =
        runCatching {
            val stored = json.parseToJsonElement(input.readBytes().decodeToString()).jsonObject

            json.decodeFromJsonElement(Settings.serializer(), withReaderOptions(stored))
        }.getOrElse { throw CorruptionException("Unreadable settings", it) }

    override suspend fun writeTo(t: Settings, output: OutputStream) =
        output.write(json.encodeToString(Settings.serializer(), t).encodeToByteArray())
}

/**
 * Settings written before the reader options sheet kept two pages as `multipage`
 * and the page order as `rtl`. A file holding no layout at all is one of those,
 * whatever the layout's default has since become.
 *
 * `rtl` turned the pages of a spread around and said which way a page turn went
 * in the reader's sideways mode, which was never a stored one. It carries into
 * the order of a spread, not into a reader that scrolls bottom to top.
 */
private fun withReaderOptions(stored: JsonObject): JsonObject {
    if ("readerLayout" in stored) return stored

    val multipage = stored["multipage"]?.jsonPrimitive?.booleanOrNull
    val rightToLeft = stored["rtl"]?.jsonPrimitive?.booleanOrNull == true

    return buildJsonObject {
        stored.forEach { (key, value) -> put(key, value) }

        put(
            "readerLayout",
            json.encodeToJsonElement(
                ReaderLayout.serializer(),
                if (multipage == true) ReaderLayout.AUTO else ReaderLayout.SINGLE,
            )
        )

        // The reader these settings were written for scrolled down the gallery,
        // whatever the reader opens on now.
        put(
            "readerOrientation",
            json.encodeToJsonElement(ReaderOrientation.serializer(), ReaderOrientation.VERTICAL),
        )
        put("readerSnap", JsonPrimitive(false))
        put("readerPadding", JsonPrimitive(false))

        if (rightToLeft && "multipageOrder" !in stored)
            put("multipageOrder", json.encodeToJsonElement(MultipageOrder.serializer(), MultipageOrder.RTL))
    }
}

internal val LEGACY_SETTINGS_KEYS = setOf(
    "beta",
    "per_page",
    "simplified_search",
    "tap_sides",
    "multipage",
    "multipage_portrait",
    "multipage_fit",
    "multipage_order",
    "multipage_cover",
    "volume_page_turn",
    "rtl",
    "download_folder",
    "download_folder_name",
    "download_archive",
    "cache_limit",
    "lock_timeout",
    "lock_fingerprint",
    "proxy",
    "max_concurrent_download",
    "tag_translation",
    "security_mode",
)

/**
 * The preference screen wrote its lists as strings, and wrote a list's default
 * only once the screen was opened. A missing `cache_limit` read as no limit, so
 * that is what it stays.
 */
internal fun settingsFromLegacy(legacy: Map<String, Any?>): Settings {
    val defaults = Settings()

    fun boolean(key: String, default: Boolean) = legacy[key] as? Boolean ?: default
    fun string(key: String) = legacy[key] as? String
    fun int(key: String) = string(key)?.toIntOrNull()

    return Settings(
        beta = boolean("beta", defaults.beta),
        perPage = int("per_page")?.coerceAtLeast(1) ?: defaults.perPage,
        simplifiedSearch = boolean("simplified_search", defaults.simplifiedSearch),
        tapSides = boolean("tap_sides", defaults.tapSides),
        readerLayout = if (boolean("multipage", false)) ReaderLayout.AUTO else ReaderLayout.SINGLE,
        readerOrientation = ReaderOrientation.VERTICAL,
        readerSnap = false,
        readerPadding = false,
        multipagePortrait = boolean("multipage_portrait", defaults.multipagePortrait),
        multipageFit = when (string("multipage_fit")) {
            "fill" -> MultipageFit.FILL
            else -> MultipageFit.SCREEN
        },
        multipageOrder = when (string("multipage_order")) {
            "ltr" -> MultipageOrder.LTR
            "rtl" -> MultipageOrder.RTL
            else -> if (boolean("rtl", false)) MultipageOrder.RTL else MultipageOrder.AUTO
        },
        multipageCover = boolean("multipage_cover", defaults.multipageCover),
        volumePageTurn = boolean("volume_page_turn", defaults.volumePageTurn),
        readerReverse = defaults.readerReverse,
        downloadFolder = string("download_folder") ?: defaults.downloadFolder,
        downloadFolderName = string("download_folder_name") ?: defaults.downloadFolderName,
        downloadArchive = boolean("download_archive", defaults.downloadArchive),
        cacheLimitGigabytes = int("cache_limit") ?: 0,
        lockTimeoutMinutes = int("lock_timeout") ?: defaults.lockTimeoutMinutes,
        lockFingerprint = boolean("lock_fingerprint", defaults.lockFingerprint),
        proxy = string("proxy")
            ?.let { runCatching { json.decodeFromString(ProxyInfo.serializer(), it) }.getOrNull() }
            ?: defaults.proxy,
        maxConcurrentDownload = int("max_concurrent_download") ?: defaults.maxConcurrentDownload,
        tagTranslation = string("tag_translation") ?: defaults.tagTranslation,
        securityMode = boolean("security_mode", defaults.securityMode),
    )
}

private object SharedPreferencesSettingsMigration : DataMigration<Settings> {
    override suspend fun shouldMigrate(currentData: Settings) =
        LEGACY_SETTINGS_KEYS.any(Preferences::contains)

    override suspend fun migrate(currentData: Settings) = settingsFromLegacy(Preferences.all)

    override suspend fun cleanUp() {
        Preferences.edit { LEGACY_SETTINGS_KEYS.forEach(::remove) }
    }
}
