/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.dataStoreFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import xyz.quaver.pupil.hitomi.SearchQuery

/**
 * How many of the newest matches a check remembers.
 *
 * A watched query can match the whole index, and only what arrived since the
 * last check is worth reporting, so the head of the result is all that has to
 * be kept to recognise it.
 */
const val WATCH_SEEN_LIMIT = 100

/**
 * A search that reports what it turns up.
 *
 * The query is the identity: watching one twice is the same watch.
 */
@Serializable
data class Watch(
    val query: SearchQuery,
    val seen: List<Int> = emptyList(),
    val lastCheckedAt: Long = 0,
    val newCount: Int = 0,
)

/**
 * The watch as of a check that matched [ids], paired with the matches that are
 * new since the check before it.
 *
 * The first check on a watch reports nothing: everything a query already
 * matches is what the reader asked to be told about additions to.
 */
fun Watch.afterCheck(ids: IntArray, at: Long): Pair<Watch, List<Int>> {
    val head = ids.take(WATCH_SEEN_LIMIT)

    val seenIDs = seen.toHashSet()
    val new = if (seen.isEmpty()) emptyList() else head.filterNot(seenIDs::contains)

    return copy(
        seen = head,
        lastCheckedAt = at,
        newCount = newCount + new.size,
    ) to new
}

/**
 * The watched queries, persisted through DataStore and mirrored into snapshot
 * state the way [SetStore] holds a set.
 *
 * [onWatchesChanged] fires when a query is watched or dropped, and not when a
 * check writes back what it found: only the former decides whether there is
 * anything left to check for.
 */
class WatchlistStore(
    private val fileName: String,
    private val onWatchesChanged: () -> Unit = {},
) {
    private val serializer = ListSerializer(Watch.serializer())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var store: DataStore<List<Watch>>

    var items: List<Watch> by mutableStateOf(emptyList())
        private set

    fun init(context: Context) {
        store = DataStoreFactory.create(
            serializer = JsonListSerializer(serializer),
            corruptionHandler = ReplaceFileCorruptionHandler {
                Crashlytics.recordException(it)
                emptyList()
            },
            scope = scope,
            produceFile = { context.dataStoreFile(fileName) },
        )

        items = runBlocking { store.data.first() }

        scope.launch { store.data.collect { items = it } }
    }

    operator fun get(query: SearchQuery): Watch? = items.find { it.query == query }

    fun contains(query: SearchQuery) = get(query) != null

    fun toggle(query: SearchQuery) {
        update { watches ->
            if (watches.any { it.query == query }) watches.filterNot { it.query == query }
            else watches + Watch(query)
        }

        onWatchesChanged()
    }

    fun remove(query: SearchQuery) {
        update { watches -> watches.filterNot { it.query == query } }

        onWatchesChanged()
    }

    /** Replaces the watch [watch] was read from, or does nothing if it is gone. */
    fun set(watch: Watch) = update { watches ->
        watches.map { if (it.query == watch.query) watch else it }
    }

    fun markSeen(query: SearchQuery) = update { watches ->
        watches.map { if (it.query == query) it.copy(newCount = 0) else it }
    }

    // Mirror first, then the file: a menu reads the watch back the moment it
    // writes to it, the way [SetStore] does.
    private fun update(transform: (List<Watch>) -> List<Watch>) {
        items = transform(items)

        scope.launch { store.updateData(transform) }
    }
}
