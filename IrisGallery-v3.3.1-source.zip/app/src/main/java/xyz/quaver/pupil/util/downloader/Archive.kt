/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util.downloader

import xyz.quaver.io.FileX
import xyz.quaver.io.util.getChild
import xyz.quaver.io.util.inputStream
import xyz.quaver.io.util.outputStream
import java.io.IOException
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

const val ARCHIVE_EXTENSION = ".zip"

fun isArchiveName(name: String) = name.endsWith(ARCHIVE_EXTENSION, ignoreCase = true)

/**
 * Writes [files] into [target] as a zip, under the names they already have, so
 * that anything that opens comic archives opens a saved gallery.
 *
 * Whatever [target] held is replaced. Images are stored rather than deflated:
 * they are compressed already, and a gallery is large enough that the pass would
 * cost seconds for a percent.
 */
fun packArchive(target: FileX, files: List<FileX>) {
    if (!target.exists()) target.createNewFile()

    val stream = target.outputStream() ?: throw IOException("Could not write ${target.name}")

    ZipOutputStream(stream.buffered()).use { zip ->
        zip.setLevel(Deflater.NO_COMPRESSION)

        files.forEach { file ->
            zip.putNextEntry(ZipEntry(file.name))

            file.inputStream()?.use { it.copyTo(zip) }
                ?: throw IOException("Could not read ${file.name}")

            zip.closeEntry()
        }
    }
}

/**
 * Writes every entry of [source] into [into], and answers the names it wrote.
 *
 * An archive cut short by a process that died while writing it reads as the
 * entries that did land: the caller is left to fill in the rest.
 */
fun unpackArchive(source: FileX, into: FileX): Set<String> {
    val stream = source.inputStream() ?: return emptySet()

    val written = mutableSetOf<String>()

    ZipInputStream(stream.buffered()).use { zip ->
        while (true) {
            val entry = zip.nextEntry ?: break

            // A gallery is a flat archive, and a path is how an archive from
            // elsewhere would write outside the folder it is unpacked into.
            val name = entry.name.substringAfterLast('/')

            if (entry.isDirectory || name.isEmpty()) continue

            val file = into.getChild(name)

            if (!file.exists()) file.createNewFile()

            val target = file.outputStream() ?: continue
            target.use { zip.copyTo(it) }

            written.add(name)
        }
    }

    return written
}

/** Reads one entry out of [source], or null when it holds no entry by that name. */
fun readArchiveEntry(source: FileX, name: String): ByteArray? {
    val stream = source.inputStream() ?: return null

    return ZipInputStream(stream.buffered()).use { zip ->
        var entry = zip.nextEntry

        while (entry != null) {
            if (entry.name == name) return@use zip.readBytes()

            entry = zip.nextEntry
        }

        null
    }
}
