/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util.downloader

import android.content.Context
import android.content.ContextWrapper
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import xyz.quaver.io.FileX
import xyz.quaver.io.util.*
import xyz.quaver.pupil.hitomi.*
import xyz.quaver.pupil.util.Crashlytics
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

@Serializable
data class OldReader(
    val code: String,
    val galleryInfo: OldGalleryInfo
)

@Serializable
data class OldGalleryInfo(
    val language_localname: String? = null,
    val language: String? = null,
    val date: String? = null,
    val files: List<OldGalleryFiles>,
    val id: Int? = null,
    val type: String? = null,
    val title: String? = null
)

@Serializable
data class OldGalleryFiles(
    val width: Int,
    val hash: String,
    val haswebp: Int = 0,
    val name: String,
    val height: Int,
    val hasavif: Int = 0,
    val hasavifsmalltn: Int? = 0
)

@Serializable
data class OldMetadata(
    var galleryBlock: GalleryBlock? = null,
    var reader: OldReader? = null,
    var imageList: MutableList<String?>? = null
) {
    fun copy(): OldMetadata = OldMetadata(galleryBlock, reader, imageList?.let { MutableList(it.size) { i -> it[i] } })
}

@Serializable
data class Metadata(
    var galleryBlock: GalleryBlock? = null,
    var galleryInfo: GalleryInfo? = null,
    var imageList: MutableList<String?>? = null
) {
    constructor(old: OldMetadata) : this(
        old.galleryBlock,
        old.reader?.galleryInfo?.let { oldGalleryInfo ->
            GalleryInfo(
                oldGalleryInfo.id.toString(),
                oldGalleryInfo.title ?: "",
                null,
                oldGalleryInfo.language,
                oldGalleryInfo.type ?: "",
                oldGalleryInfo.date ?: "",
                files = oldGalleryInfo.files.map {
                    GalleryFiles(
                        it.width,
                        it.hash,
                        it.haswebp,
                        it.name,
                        it.height,
                        it.hasavif,
                        it.hasavifsmalltn
                    )
                }
            )
        },
        old.imageList
    )

    fun copy(): Metadata = Metadata(galleryBlock, galleryInfo, imageList?.let { MutableList(it.size) { i -> it[i] } })
}

class Cache private constructor(context: Context, val galleryID: Int) : ContextWrapper(context) {
    companion object {
        val instances = ConcurrentHashMap<Int, Cache>()

        fun getInstance(context: Context, galleryID: Int) =
            instances[galleryID] ?: synchronized(this) {
                instances[galleryID] ?: Cache(context, galleryID).also { instances.put(galleryID, it) }
            }

        @Synchronized
        fun delete(context: Context, galleryID: Int) {
            File(context.cacheDir, "imageCache/$galleryID").deleteRecursively()
            instances.remove(galleryID)
        }
    }

    init {
        cacheFolder.mkdirs()
    }

    private fun readMetadata(): Metadata = kotlin.runCatching {
        findFile(".metadata")?.readText()?.let { metadata ->
            kotlin.runCatching {
                Json.decodeFromString<Metadata>(metadata)
            }.getOrElse {
                Metadata(json.decodeFromString<OldMetadata>(metadata))
            }
        }
    }.onFailure { it.printStackTrace() }.getOrNull() ?: Metadata()

    var metadata = readMetadata()

    val downloadFolder: FileX?
        get() = DownloadManager.getInstance(this).getDownloadFolder(galleryID)

    val downloadArchive: FileX?
        get() = DownloadManager.getInstance(this).getDownloadArchive(galleryID)

    val cacheFolder: FileX
        get() = FileX(this, cacheDir, "imageCache/$galleryID").also {
            if (!it.exists())
                it.mkdirs()
        }

    /**
     * Where this gallery's files are written: its download folder once it is a
     * download, the cache otherwise.
     *
     * A running job cannot see this change under it, since both saving and
     * unsaving a gallery go through [DownloadService], which stops the job first.
     *
     * The folder is created if it is not there: a download folder deleted from a
     * file manager leaves the gallery registered as a download, and every write
     * into a folder that no longer exists fails.
     */
    val folder: FileX
        get() = downloadFolder?.also { if (!it.exists()) it.mkdirs() } ?: cacheFolder

    /**
     * Reads fall back to the cache, which is where a gallery's images are until it
     * becomes a download and they are moved.
     */
    fun findFile(fileName: String): FileX? =
         downloadFolder?.let { downloadFolder -> downloadFolder.getChild(fileName).let {
            if (it.exists()) it else null
        } } ?: cacheFolder.getChild(fileName).let {
            if (it.exists()) it else null
        }

    @Suppress("BlockingMethodInNonBlockingContext")
    fun setMetadata(change: (Metadata) -> Unit) {
        change.invoke(metadata)

        writeMetadata()
    }

    @Suppress("BlockingMethodInNonBlockingContext")
    private fun writeMetadata() {
        val file = folder.getChild(".metadata")

        kotlin.runCatching {
            if (!file.exists()) {
                file.createNewFile()
            }
            file.writeText(Json.encodeToString(metadata))
        }
    }

    suspend fun getGalleryBlock(): GalleryBlock? {
        val galleryBlock = metadata.galleryBlock
            ?: withContext(Dispatchers.IO) {
                try {
                    hitomiClient.getGalleryBlock(galleryID).also {
                        setMetadata { metadata -> metadata.galleryBlock = it }
                    }
                } catch (e: Exception) { return@withContext null }
            }
            ?: return null

        val cover =
            if (DownloadManager.getInstance(this).isSaved(galleryID)) getImage(0)?.uri?.toString()
            else null

        return galleryBlock.copy(thumbnails = listOfNotNull(cover ?: thumbnailUrl()))
    }

    /**
     * Hitomi serves a thumbnail from a host and path it derives from the gallery's
     * file hash, so the URL stored beside a block outlives the host it names: one
     * written before the images left hitomi.la points at a host that no longer
     * resolves. The hash doesn't change, so the URL is built again rather than
     * read back.
     */
    private suspend fun thumbnailUrl(): String? =
        metadata.galleryInfo?.files?.firstOrNull()?.let { file ->
            kotlin.runCatching {
                hitomiClient.urlFromUrlFromHash(galleryID, file, "webpbigtn", "webp", "tn")
            }.getOrNull()
        } ?: metadata.galleryBlock?.thumbnails?.firstOrNull()

    /**
     * Throws rather than answering null for a fetch that failed: hitomi saying it
     * has no such gallery and hitomi not answering at all are the same absence here
     * but not to the reader, which would otherwise tell someone with no signal that
     * their gallery is gone.
     */
    suspend fun getGalleryInfo(): GalleryInfo =
        metadata.galleryInfo
            ?: withContext(Dispatchers.IO) {
                hitomiClient.getGalleryInfo(galleryID).also {
                    setMetadata { metadata ->
                        metadata.galleryInfo = it

                        if (metadata.imageList == null)
                            metadata.imageList = MutableList(it.files.size) { null }
                    }
                }
            }

    fun getImage(index: Int): FileX? =
        metadata.imageList?.getOrNull(index)?.let { findFile(it) }

    @Suppress("BlockingMethodInNonBlockingContext")
    /**
     * The image is written before the metadata that names it, so a write cut short
     * leaves a file nothing points at rather than a name pointing at half a file.
     */
    suspend fun putImage(index: Int, fileName: String, data: ByteArray) = coroutineScope {
        val file = folder.getChild(fileName)

        if (!file.exists())
            file.createNewFile()

        file.writeBytes(data)
        setMetadata { metadata -> metadata.imageList!![index] = fileName }
    }

    /** Whether every image the metadata names is in [cacheFolder]. */
    private fun cached(): Boolean {
        val imageList = metadata.imageList ?: return false

        return imageList.isNotEmpty() && imageList.all { fileName ->
            fileName != null &&
                cacheFolder.getChild(fileName).let { it.exists() && it.length() > 0L }
        }
    }

    /**
     * Unpacks the gallery's archive into the cache, which is where a gallery saved
     * as one is read from: nothing downstream of here can open an image that is an
     * entry of a zip rather than a file of its own.
     *
     * @return whether the cache now holds the whole gallery.
     */
    suspend fun restoreFromArchive(): Boolean = withContext(Dispatchers.IO) {
        val archive = downloadArchive?.takeIf { it.exists() } ?: return@withContext false

        if (cached()) return@withContext true

        kotlin.runCatching { unpackArchive(archive, cacheFolder) }
            .onFailure { Crashlytics.recordException(it) }

        metadata = readMetadata()

        cached()
    }

    /**
     * Packs the gallery into its archive and drops the loose images, which is what
     * saving as an archive is for.
     *
     * The cover is kept: it is what the downloads list draws, and re-reading it
     * from the archive would mean unpacking the gallery to scroll past it.
     * [keepImages] keeps the rest as well, for a gallery the reader has open and
     * is drawing them from.
     *
     * @return whether the archive now holds the gallery.
     */
    suspend fun saveToArchive(keepImages: Boolean): Boolean = withContext(Dispatchers.IO) {
        val archive = downloadArchive ?: return@withContext false

        if (!cached()) return@withContext false

        val names = metadata.imageList.orEmpty().filterNotNull()

        val files = listOf(cacheFolder.getChild(".metadata")) + names.map { cacheFolder.getChild(it) }

        kotlin.runCatching { packArchive(archive, files) }
            .onFailure {
                Crashlytics.recordException(it)
                return@withContext false
            }

        if (!keepImages) names.drop(1).forEach { cacheFolder.getChild(it).delete() }

        true
    }

    /**
     * Makes [folder] hold every image the metadata names, and the metadata name
     * only images that are there.
     *
     * A gallery cached before it became a download has its images brought over one
     * at a time -- copied, checked, and only then dropped from the cache -- so a
     * run cut short anywhere leaves every image readable from one folder or the
     * other and the next run carries on where it stopped. An image in neither
     * folder is dropped from the metadata instead: a name with no file behind it
     * is a page the downloader counts as done and never fetches again.
     *
     * @return the indices of [Metadata.imageList] whose image is in [folder].
     */
    suspend fun reconcile(): Set<Int> = withContext(Dispatchers.IO) {
        val imageList = metadata.imageList ?: return@withContext emptySet()

        val downloadFolder = downloadFolder
        val destination = folder

        val present = mutableSetOf<Int>()

        /** The copy staged in the cache, for a gallery that is being promoted. */
        fun staged(fileName: String) =
            downloadFolder?.let { cacheFolder.getChild(fileName).takeIf { file -> file.exists() } }

        imageList.forEachIndexed { index, fileName ->
            if (fileName == null) return@forEachIndexed

            val target = destination.getChild(fileName)
            val staged = staged(fileName)

            when {
                target.exists() && target.length() > 0L -> {
                    staged?.delete()
                    present.add(index)
                }

                staged != null && kotlin.runCatching {
                    staged.copyTo(target, overwrite = true).length() == staged.length()
                }.getOrDefault(false) -> {
                    staged.delete()
                    present.add(index)
                }

                else -> imageList[index] = null
            }
        }

        // Last, so the folder never holds a metadata naming an image it doesn't
        // have: a run killed before this point simply happens again.
        writeMetadata()

        // Nothing the metadata names is left in the cache by now.
        if (downloadFolder != null)
            cacheFolder.deleteRecursively()

        present
    }
}