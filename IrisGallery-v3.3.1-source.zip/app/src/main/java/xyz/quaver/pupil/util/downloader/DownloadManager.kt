/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util.downloader

import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.referentialEqualityPolicy
import androidx.compose.runtime.snapshots.Snapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import xyz.quaver.io.FileX
import xyz.quaver.io.RawFileX
import xyz.quaver.io.util.deleteRecursively
import xyz.quaver.io.util.getChild
import xyz.quaver.io.util.readText
import xyz.quaver.io.util.writeText
import xyz.quaver.pupil.services.DownloadService
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.util.formatDownloadFolder
import java.io.File

class DownloadManager private constructor(context: Context) : ContextWrapper(context) {

    companion object {
        @Volatile private var instance: DownloadManager? = null

        fun getInstance(context: Context) =
            instance ?: synchronized(this) {
                instance ?: DownloadManager(context).also { instance = it }
            }
    }

    val defaultDownloadFolder = FileX(this, getExternalFilesDir(null)!!)

    val downloadFolder: FileX
        get() = settings.value.downloadFolder
            .takeIf { it.isNotEmpty() }
            ?.let { runCatching { FileX(this, it) }.getOrNull() }
            ?: defaultDownloadFolder

    // documentfilex appends a child to a file URI as if it were already encoded, so
    // a gallery title with a `%` in it decodes into a different path, or into one
    // with a NUL in it that no file can be created at.
    fun downloadFolderChild(name: String): FileX =
        downloadFolder.let { folder ->
            if (folder is RawFileX) FileX(this, File(folder, name)) else folder.getChild(name)
        }

    private var prevDownloadFolder: FileX? = null

    // An ordered map in snapshot state, rather than a SnapshotStateMap: a screen
    // listing the downloads has to follow them being added and removed from the
    // reader and the settings screen, and has to list them in the order they
    // were downloaded, which a hash map does not keep.
    //
    // Built with the manager rather than on first read: a read-only snapshot --
    // what snapshotFlow reads the map in -- cannot see a state object that came
    // into existence after it was taken.
    private val downloadFolderMapInstance =
        mutableStateOf(emptyMap<Int, String>(), referentialEqualityPolicy())

    val downloadFolderMap: Map<Int, String>
        get() = downloadFolderMapState().value

    @Synchronized
    private fun downloadFolderMapState(): MutableState<Map<Int, String>> {
        if (prevDownloadFolder != downloadFolder) {
            prevDownloadFolder = downloadFolder

            val file = downloadFolder.getChild(".download")
            val data = if (file.exists())
                kotlin.runCatching {
                    file.readText()?.let{ Json.decodeFromString<Map<Int, String>>(it) }
                }.onFailure { file.delete() }.getOrNull()
            else
                null
            if (data == null) file.createNewFile()

            // A reader can be inside a read-only snapshot, which refuses writes.
            // The value it goes on to see is the one its snapshot was taken with;
            // the write lands globally and wakes the observers.
            Snapshot.global { downloadFolderMapInstance.value = data.orEmpty() }
        }

        return downloadFolderMapInstance
    }

    /** Rewrites `.download`, whose key order is the order things were downloaded. */
    @Synchronized
    private fun update(transform: (Map<Int, String>) -> Map<Int, String>) {
        val state = downloadFolderMapState()
        val folders = transform(state.value)

        state.value = folders

        downloadFolder.getChild(".download").let { if (!it.exists()) it.createNewFile() }
        downloadFolder.getChild(".download").writeText(Json.encodeToString(folders))
    }

    /** Replaces every entry, for the settings screen rebuilding them from the folders. */
    fun replaceDownloadFolders(folders: Map<Int, String>) = update { folders }

    /**
     * Reorders the downloads by when each folder was last modified, oldest first.
     * Queries every folder, so keep it off the main thread.
     */
    fun restoreDownloadOrder() = update { folders ->
        folders.entries
            .map { it to downloadFolderChild(it.value).lastModified() }
            .sortedBy { (_, lastModified) -> lastModified }
            .associate { (entry, _) -> entry.key to entry.value }
    }

    /** A gallery being saved, as opposed to one merely being cached for the reader. */
    @Synchronized
    fun isDownloading(galleryID: Int): Boolean =
        downloadFolderMap.containsKey(galleryID) && DownloadService.isDownloading(galleryID)

    fun isSaved(galleryID: Int): Boolean = downloadFolderMap.containsKey(galleryID)

    @Synchronized
    fun getDownloadFolder(galleryID: Int): FileX? =
        downloadFolderMap[galleryID]
            ?.takeUnless { isArchiveName(it) }
            ?.let { downloadFolderChild(it) }

    /**
     * The zip [galleryID] is saved into, for a download saved as an archive. It
     * only exists once the gallery is complete and has been packed into it.
     */
    @Synchronized
    fun getDownloadArchive(galleryID: Int): FileX? =
        downloadFolderMap[galleryID]
            ?.takeIf { isArchiveName(it) }
            ?.let { downloadFolderChild(it) }

    /**
     * Registers [galleryID] as a download and creates the folder it is saved to.
     *
     * Suspends rather than launching: a download that starts before its folder is
     * registered writes to the cache and never moves, since the move is skipped for
     * a gallery [getDownloadFolder] doesn't answer for.
     *
     * A gallery that is already a download keeps the name it was saved under, so
     * that saving it again -- from the reader, say -- never leaves the files it
     * already has behind under a name nothing points at.
     */
    suspend fun addDownloadFolder(galleryID: Int) = withContext(Dispatchers.IO) {
        val name = downloadFolderMap[galleryID] ?: run {
            val galleryBlock = Cache.getInstance(this@DownloadManager, galleryID).getGalleryBlock()
                ?: return@withContext

            val extension = if (settings.value.downloadArchive) ARCHIVE_EXTENSION else ""

            (galleryBlock.formatDownloadFolder() + extension).also { registered ->
                update { it + (galleryID to registered) }
            }
        }

        // An archive is written in one piece once the gallery is complete; until
        // then the download lives in the cache like any other.
        if (isArchiveName(name)) return@withContext

        val folder = downloadFolderChild(name)

        if (folder.exists()) return@withContext
        folder.mkdir()
    }

    /**
     * Drops [galleryID] from the downloads once its folder is gone, whether this
     * call deleted it or something outside the app already had: deleting a folder
     * that isn't there throws, and an entry left behind is a download the user
     * cannot get rid of and the downloader keeps writing to.
     */
    @Synchronized
    fun deleteDownloadFolder(galleryID: Int) {
        val folder = downloadFolderMap[galleryID]?.let { downloadFolderChild(it) } ?: return

        kotlin.runCatching { folder.deleteRecursively() }

        if (!folder.exists()) update { map -> map - galleryID }
    }
}