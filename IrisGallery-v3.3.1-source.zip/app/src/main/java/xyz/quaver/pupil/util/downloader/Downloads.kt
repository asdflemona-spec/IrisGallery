/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util.downloader

import androidx.annotation.StringRes
import androidx.compose.runtime.mutableStateMapOf
import xyz.quaver.pupil.R
import java.util.concurrent.ConcurrentHashMap

/**
 * Why a download stopped short of every image.
 *
 * Declared worst first: a gallery that hit more than one of these is named by the
 * one the user has to act on, and running out of room outranks a page hitomi would
 * probably hand over on the next try.
 */
enum class DownloadFailure {

    /** The device has no room left for the rest of the gallery. */
    OUT_OF_SPACE,

    /** The images arrived but could not be written to the folder they belong in. */
    STORAGE,

    /** Hitomi could not be reached, or gave up part way through. */
    NETWORK,
}

/** What to put in front of the user for a [DownloadFailure]. */
@StringRes
fun DownloadFailure.message(): Int = when (this) {
    DownloadFailure.OUT_OF_SPACE -> R.string.download_failed_out_of_space
    DownloadFailure.STORAGE -> R.string.download_failed_storage
    DownloadFailure.NETWORK -> R.string.download_failed_network
}

/** How far a gallery's download has got. */
sealed interface DownloadState {

    /** Commanded, but the gallery info that says how many images there are hasn't landed. */
    data object Preparing : DownloadState

    /** Hitomi has no gallery with this ID. */
    data object NotFound : DownloadState

    /** [completed] of [total] images are on disk. Never all of them; that is [Complete]. */
    data class Downloading(val completed: Int, val total: Int) : DownloadState

    /** Every image is on disk. */
    data class Complete(val total: Int) : DownloadState

    /**
     * Nothing is still being fetched and [completed] of [total] images made it.
     * [total] is 0 for a gallery that failed before there was an image count.
     *
     * A reader left looking at a page that is never going to arrive is the thing
     * this exists to prevent, so every way a download can stop short ends here.
     */
    data class Failed(
        val reason: DownloadFailure,
        val completed: Int,
        val total: Int,
    ) : DownloadState
}

/** How far one image of a gallery has got. */
sealed interface ImageProgress {

    /** [fraction] of the bytes have arrived, `0f..1f`. A response of unknown length reads 0f. */
    data class Downloading(val fraction: Float) : ImageProgress

    /** Written to the cache. */
    data object Complete : ImageProgress

    /** It is not coming: [reason] is what stopped it. */
    data class Failed(val reason: DownloadFailure) : ImageProgress
}

/**
 * What [xyz.quaver.pupil.services.DownloadService] is working on, and how far each
 * gallery has got.
 *
 * Process-wide rather than a field of the service, so a screen can ask without
 * binding to it and keeps its answer once the service stops itself. [DownloadState]
 * is mirrored into snapshot state the way [xyz.quaver.pupil.util.SetStore] mirrors a
 * set, so Compose follows a download instead of polling for it.
 *
 * The per-image byte counts stay off snapshot state: they change thousands of times
 * per gallery, and only the reader reads them, a frame at a time.
 */
object Downloads {

    private val galleries = ConcurrentHashMap<Int, GalleryDownload>()

    private val states = mutableStateMapOf<Int, DownloadState>()

    /**
     * The gallery whose notification is shown even when it is only being cached --
     * the one the reader has open. 0 for none.
     */
    @Volatile
    var priority: Int = 0

    /**
     * The gallery a reader is showing, 0 for none.
     *
     * It draws its pages out of the cache, so a gallery saved as an archive keeps
     * its images there while a reader is on it rather than losing them to the zip
     * under itself.
     */
    @Volatile
    var reading: Int = 0

    private val focuses = ConcurrentHashMap<Int, Int>()

    /**
     * Tells the downloader which image of [galleryID] a reader is showing.
     *
     * Held until the reader that set it says [unfocus], rather than being dropped
     * with the rest of a gallery's state: a download that is cancelled and
     * immediately commanded again -- which is what unsaving one does -- is still
     * the gallery on the screen.
     */
    fun focus(galleryID: Int, index: Int) {
        focuses[galleryID] = index
    }

    /** No reader is on [galleryID] any more; it goes back to being fetched in order. */
    fun unfocus(galleryID: Int) {
        focuses.remove(galleryID)
    }

    /** The image [galleryID] is being read at; its first until a reader says otherwise. */
    internal fun focusOf(galleryID: Int): Int = focuses[galleryID] ?: 0

    /** Null when nothing has been commanded for [galleryID] this process. */
    fun state(galleryID: Int): DownloadState? = states[galleryID]

    fun imageProgress(galleryID: Int, index: Int): ImageProgress? =
        galleries[galleryID]?.imageProgress(index)

    internal fun preparing(galleryID: Int) {
        states[galleryID] = DownloadState.Preparing
    }

    internal fun notFound(galleryID: Int) {
        galleries.remove(galleryID)
        states[galleryID] = DownloadState.NotFound
    }

    /** Tracks [total] images for [galleryID], none of them on disk yet. */
    internal fun begin(galleryID: Int, total: Int) {
        val download = GalleryDownload(total)

        galleries[galleryID] = download
        synchronized(download) { states[galleryID] = download.state() }
    }

    internal fun advance(galleryID: Int, index: Int, fraction: Float) {
        galleries[galleryID]?.advance(index, fraction)
    }

    internal fun complete(galleryID: Int, index: Int) {
        val download = galleries[galleryID] ?: return

        // The published state is written under the same lock that counts the image,
        // or two images landing together could leave the older count behind.
        synchronized(download) {
            download.complete(index)
            states[galleryID] = download.state()
        }
    }

    internal fun fail(galleryID: Int, index: Int, reason: DownloadFailure) {
        val download = galleries[galleryID] ?: return

        synchronized(download) {
            download.fail(index, reason)
            states[galleryID] = download.state()
        }
    }

    /** For a gallery that failed before [begin] gave it an image count to track. */
    internal fun failed(galleryID: Int, reason: DownloadFailure) {
        galleries.remove(galleryID)
        states[galleryID] = DownloadState.Failed(reason, 0, 0)
    }

    internal fun forget(galleryID: Int) {
        galleries.remove(galleryID)
        states.remove(galleryID)
    }

    internal fun forgetAll() {
        galleries.clear()
        states.clear()
    }
}

/**
 * One gallery's images.
 *
 * Everything but [advance] is touched under [Downloads]' lock on the instance;
 * [advance] is the byte callback of a single download coroutine writing the index
 * it owns, which nothing reads but a progress bar.
 */
private class GalleryDownload(private val total: Int) {

    private val fractions = FloatArray(total)
    private val done = BooleanArray(total)
    private val failures = arrayOfNulls<DownloadFailure>(total)
    private var completed = 0
    private var failed = 0

    fun advance(index: Int, fraction: Float) {
        if (index in fractions.indices && !done[index]) fractions[index] = fraction
    }

    fun complete(index: Int) {
        if (index !in done.indices || done[index]) return

        done[index] = true
        completed++
    }

    fun fail(index: Int, reason: DownloadFailure) {
        if (index !in done.indices || done[index] || failures[index] != null) return

        failures[index] = reason
        failed++
    }

    fun imageProgress(index: Int): ImageProgress? = when {
        index !in done.indices -> null
        done[index] -> ImageProgress.Complete
        else -> failures[index]?.let { ImageProgress.Failed(it) }
            ?: ImageProgress.Downloading(fractions[index])
    }

    /**
     * Failed only once nothing is still on its way: an image that could not be
     * written while the rest are still arriving is not the whole gallery giving up.
     */
    fun state(): DownloadState = when {
        completed == total -> DownloadState.Complete(total)
        completed + failed < total -> DownloadState.Downloading(completed, total)
        else -> DownloadState.Failed(failures.filterNotNull().min(), completed, total)
    }
}
