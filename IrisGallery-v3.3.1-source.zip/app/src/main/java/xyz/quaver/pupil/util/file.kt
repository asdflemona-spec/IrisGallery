/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import xyz.quaver.pupil.histories
import xyz.quaver.pupil.services.DownloadService
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.util.downloader.Cache
import java.io.File

val mutex = Mutex()
fun cleanCache(context: Context) = CoroutineScope(Dispatchers.IO).launch {
    if (mutex.isLocked) return@launch

    mutex.withLock {
        val cacheFolder = File(context.cacheDir, "imageCache")

        val limit = settings.value.cacheLimitGigabytes.toLong()*1024*1024*1024

        if (limit == 0L) return@withLock

        val cacheSize = {
            var size = 0L

            cacheFolder.walk().forEach {
                size += it.length()
            }

            size
        }

        if (cacheSize.invoke() > limit)
            while (cacheSize.invoke() > limit/2) {
                val caches = cacheFolder.list() ?: return@withLock

                // Any gallery with a job on it, saved or merely being read: the
                // folder about to be deleted is the one being written to.
                val oldest = histories.items.firstOrNull {
                    caches.contains(it.toString()) && !DownloadService.isDownloading(it)
                } ?: return@withLock

                Cache.delete(context, oldest)
            }
    }
}