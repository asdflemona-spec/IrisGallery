/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PageImage(val source: Uri, val displayName: String) {
    val mimeType: String
        get() {
            val extension = displayName.substringAfterLast('.', "").lowercase()

            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "image/$extension"
        }
}

suspend fun Context.copyImage(source: Uri, target: Uri) = withContext(Dispatchers.IO) {
    val input = contentResolver.openInputStream(source) ?: throw IOException("Could not read $source")
    val output = contentResolver.openOutputStream(target, "wt") ?: throw IOException("Could not write $target")

    input.use { output.use { input.copyTo(output) } }
}

suspend fun Context.shareImage(image: PageImage) {
    val shared = withContext(Dispatchers.IO) {
        val folder = File(cacheDir, "shared").apply {
            deleteRecursively()
            mkdirs()
        }

        File(folder, image.displayName).also { file ->
            copyImage(image.source, Uri.fromFile(file))
        }
    }

    val uri = FileProvider.getUriForFile(this, "$packageName.provider", shared)

    Intent(Intent.ACTION_SEND).apply {
        type = image.mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }.let {
        startActivity(Intent.createChooser(it, null))
    }
}

/** Hands the gallery on as the link this app opens for itself. */
fun Context.shareGallery(galleryID: Int, title: String) {
    Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, title)
        putExtra(Intent.EXTRA_TEXT, "https://pupil-app.com/redirect/$galleryID")
    }.let {
        startActivity(Intent.createChooser(it, null))
    }
}
