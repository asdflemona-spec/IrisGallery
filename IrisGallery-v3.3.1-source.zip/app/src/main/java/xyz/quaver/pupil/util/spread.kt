/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import androidx.core.graphics.createBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.io.FileX
import xyz.quaver.io.util.getChild
import xyz.quaver.io.util.outputStream
import xyz.quaver.pupil.hitomi.GalleryFiles
import xyz.quaver.pupil.util.downloader.Cache
import java.io.IOException

private const val MAX_SPREAD_PIXELS = 12_000_000
private const val MAX_ARGB_SPREAD_PIXELS = 6_000_000

/** The pages shown at once, as zero-based indices; landscape and strip pages go alone. */
fun buildSpreads(files: List<GalleryFiles>, multipage: Boolean, coverAlone: Boolean): List<List<Int>> {
    if (!multipage) return files.indices.map { listOf(it) }

    return buildList {
        var page = if (coverAlone && files.isNotEmpty()) {
            add(listOf(0))
            1
        } else 0

        while (page < files.size) {
            if (page + 1 < files.size && files[page].fitsSpread && files[page + 1].fitsSpread) {
                add(listOf(page, page + 1))
                page += 2
            } else {
                add(listOf(page))
                page++
            }
        }
    }
}

/**
 * One image for the pages of a spread, in the order they are drawn, so the spread
 * zooms as one. Falls back to the first page when they cannot be merged.
 */
suspend fun Context.spreadImage(cache: Cache, pages: List<Int>, images: List<FileX>): Uri {
    if (pages.size == 1) return images.single().uri

    val name = pages.joinToString("-", "spread-", ".webp")

    return withContext(Dispatchers.IO) {
        val file = cache.cacheFolder.getChild(name)

        if (!file.exists())
            runCatching { mergeSpread(images, name, cache, file) }
                .onFailure { return@withContext images.first().uri }

        file.uri
    }
}

private fun Context.mergeSpread(images: List<FileX>, name: String, cache: Cache, target: FileX) {
    val uris = images.map { it.uri }

    // The served image is smaller than the gallery says, so it is measured.
    val bounds = uris.map { uri ->
        BitmapFactory.Options().apply {
            inJustDecodeBounds = true
            contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, this) }
        }
    }

    var sample = 1
    while (bounds.sumOf { it.outWidth / sample } * bounds.maxOf { it.outHeight / sample } > MAX_SPREAD_PIXELS)
        sample *= 2

    val width = bounds.sumOf { it.outWidth / sample }
    val height = bounds.maxOf { it.outHeight / sample }

    if (width <= 0 || height <= 0)
        throw IOException("Gallery ${cache.galleryID} has no size for $name")

    val config =
        if (width * height > MAX_ARGB_SPREAD_PIXELS) Bitmap.Config.RGB_565
        else Bitmap.Config.ARGB_8888

    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = config
    }

    val merged = createBitmap(width, height, config)

    try {
        val canvas = Canvas(merged)
        var left = 0

        uris.forEachIndexed { i, uri ->
            val bitmap = contentResolver.openInputStream(uri).use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: throw IOException("${images[i].name} could not be read")

            try {
                canvas.drawBitmap(bitmap, left.toFloat(), ((height - bitmap.height) / 2).toFloat(), null)
                left += bitmap.width
            } finally {
                bitmap.recycle()
            }
        }

        // Moved in whole, so a half written spread is never read.
        val temp = cache.cacheFolder.getChild("$name.tmp")

        if (!temp.exists())
            temp.createNewFile()

        val stream = temp.outputStream() ?: throw IOException("Could not write $name")

        stream.use { merged.compress(Bitmap.CompressFormat.WEBP, 90, it) }

        if (!temp.renameTo(target))
            throw IOException("Could not move $name into the cache")
    } finally {
        merged.recycle()
    }
}
