/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import xyz.quaver.pupil.Pupil
import java.util.Locale
import xyz.quaver.pupil.settings

private const val TRANSLATIONS_DIR = "tags"

var translations: Map<String, String> by mutableStateOf(run {
    updateTranslations()
    emptyMap()
})
    private set

fun updateTranslations() = CoroutineScope(Dispatchers.IO).launch {
    translations = kotlin.runCatching {
        loadTranslations(
            settings.value.tagTranslation
                .ifEmpty { Locale.getDefault().toLanguageTag().substringBefore('-') }
        )
    }.getOrElse { emptyMap() }
}

private fun loadTranslations(language: String): Map<String, String> =
    Pupil.instance.assets.open("$TRANSLATIONS_DIR/$language.json").bufferedReader().use {
        Json.decodeFromString<Map<String, String>>(it.readText())
    }.filterValues { it.isNotEmpty() }

fun getAvailableLanguages(): List<String> =
    listOf("en") + Pupil.instance.assets.list(TRANSLATIONS_DIR).orEmpty().map { it.substringBefore('.') }.sorted()

/**
 * Tag names whose translation in the reader's language matches [term], closest
 * match first.
 *
 * Hitomi's tag index only knows the English names, so a reader searching in
 * their own language has to be pointed back at the English tag before anything
 * can be looked up.
 */
fun Map<String, String>.tagsMatchingTranslation(term: String, limit: Int = 5): List<String> {
    val needle = term.trim().lowercase()

    if (needle.isEmpty()) return emptyList()

    return this
        .mapNotNull { (tag, translation) ->
            translation.lowercase().indexOf(needle).takeIf { it >= 0 }?.let { it to tag }
        }
        .sortedWith(compareBy({ it.first }, { it.second }))
        .take(limit)
        .map { it.second }
}
