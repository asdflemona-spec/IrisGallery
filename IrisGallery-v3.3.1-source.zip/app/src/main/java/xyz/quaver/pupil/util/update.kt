/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import ru.noties.markwon.Markwon
import xyz.quaver.pupil.*
import xyz.quaver.pupil.network.pupilClient
import xyz.quaver.pupil.settings
import xyz.quaver.pupil.types.Tag
import java.io.File
import java.util.*

const val UPDATE_DOWNLOAD_ID = "update_download_id"
const val UPDATE_DOWNLOAD_VERSION = "update_download_version"

suspend fun getReleases(url: String) : JsonArray {
    return try {
        pupilClient.getReleases(url)
    } catch (e: Exception) {
        JsonArray(emptyList())
    }
}

suspend fun checkUpdate(url: String) : JsonObject? {
    val releases = getReleases(url)

    if (releases.isEmpty())
        return null

    return releases.firstOrNull {
        settings.value.beta || it.jsonObject["prerelease"]?.jsonPrimitive?.booleanOrNull == false
    }?.let {
        if (it.jsonObject["tag_name"]?.jsonPrimitive?.contentOrNull == BuildConfig.VERSION_NAME)
            null
        else
            it.jsonObject
    }
}

fun getApkUrl(releases: JsonObject) : String? {
    return releases["assets"]?.jsonArray?.firstOrNull {
        Regex("Pupil-v.+\\.apk").matches(it.jsonObject["name"]?.jsonPrimitive?.contentOrNull ?: "")
    }.let {
        it?.jsonObject?.get("browser_download_url")?.jsonPrimitive?.contentOrNull
    }
}

fun checkUpdate(context: Context, force: Boolean = false) {

    val ignoreUpdateUntil = Preferences["ignore_update_until", 0L]

    if (!force && ignoreUpdateUntil > System.currentTimeMillis())
        return

    fun extractReleaseNote(update: JsonObject, locale: Locale) : String {
        val markdown = update["body"]!!.jsonPrimitive.content

        val target = when(locale.language) {
            "ko" -> "한국어"
            "ja" -> "日本語"
            else -> "English"
        }

        val releaseNote = Regex("^# Release Note.+$")
        val language = Regex("^## $target$")
        val end = Regex("^#.+$")

        var releaseNoteFlag = false
        var languageFlag = false

        val result = StringBuilder()

        for(line in markdown.lines()) {
            if (releaseNote.matches(line)) {
                releaseNoteFlag = true
                continue
            }

            if (releaseNoteFlag) {
                if (language.matches(line)) {
                    languageFlag = true
                    continue
                }
            }

            if (languageFlag) {
                if (end.matches(line))
                    break

                result.append(line+"\n")
            }
        }

        return context.getString(R.string.update_release_note, update["tag_name"]?.jsonPrimitive?.contentOrNull, result.toString())
    }

    CoroutineScope(Dispatchers.Default).launch {
        val update =
            checkUpdate(context.getString(R.string.release_url)) ?: return@launch

        val version = update["tag_name"]?.jsonPrimitive?.contentOrNull ?: return@launch
        val url = getApkUrl(update) ?: return@launch

        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val queued: Long = Preferences[UPDATE_DOWNLOAD_ID]

        if (queued != -1L && Preferences.get<String>(UPDATE_DOWNLOAD_VERSION) == version)
            when (downloadStatusOf(downloadManager, queued)) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    withContext(Dispatchers.Main) { offerUpdateInstall(context, queued) }
                    return@launch
                }
                DownloadManager.STATUS_PENDING,
                DownloadManager.STATUS_RUNNING,
                DownloadManager.STATUS_PAUSED -> return@launch
            }

        val dialog = AlertDialog.Builder(context).apply {
            setTitle(R.string.update_title)
            val msg = extractReleaseNote(update, Locale.getDefault())
            setMessage(Markwon.create(context).toMarkdown(msg))
            setPositiveButton(android.R.string.ok) { _, _ ->
                if (!checkNotificationEnabled(context)) {
                    showNotificationPermissionExplanationDialog(context)
                    return@setPositiveButton
                }

                if (queued != -1L)
                    downloadManager.remove(queued)

                val target = File(context.getExternalFilesDir(null), "Pupil.apk").also {
                    it.delete()
                }

                val request = DownloadManager.Request(Uri.parse(url))
                    .setTitle(context.getText(R.string.update_notification_description))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationUri(Uri.fromFile(target))

                val id = downloadManager.enqueue(request)

                Preferences[UPDATE_DOWNLOAD_VERSION] = version
                Preferences[UPDATE_DOWNLOAD_ID] = id
            }
            setNegativeButton(if (force) android.R.string.cancel else R.string.ignore) { _, _ ->
                if (!force)
                    Preferences["ignore_update_until"] = System.currentTimeMillis() + 86400000
            }
        }

        show(context, dialog)
    }
}

private suspend fun show(context: Context, dialog: AlertDialog.Builder) = withContext(Dispatchers.Main) {
    if (context is Activity && (context.isFinishing || context.isDestroyed))
        return@withContext

    dialog.show()
}

private fun installDialog(activity: Activity, id: Long, uri: Uri) =
    AlertDialog.Builder(activity)
        .setTitle(R.string.update_download_completed)
        .setMessage(R.string.update_download_completed_description)
        .setPositiveButton(android.R.string.ok) { _, _ -> activity.startActivity(installIntent(uri)) }
        .setNegativeButton(android.R.string.cancel) { _, _ -> discardUpdateDownload(activity, id) }
        .setOnCancelListener { discardUpdateDownload(activity, id) }

/**
 * Turning the offer down throws the apk away rather than remembering it, so the
 * dialog stops coming back on every resume and the next update check starts over
 * from the ordinary offer to download.
 */
private fun discardUpdateDownload(context: Context, id: Long) {
    (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id)

    Preferences.remove(UPDATE_DOWNLOAD_ID)
    Preferences.remove(UPDATE_DOWNLOAD_VERSION)
}

private fun installIntent(uri: Uri) = Intent(Intent.ACTION_VIEW).apply {
    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
    setDataAndType(uri, MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk"))
}

private fun downloadStatusOf(downloadManager: DownloadManager, id: Long): Int? =
    downloadManager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
        if (!cursor.moveToFirst()) return@use null

        val status = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)

        if (status < 0) null else cursor.getInt(status)
    }

private fun installUriOf(context: Context, id: Long): Uri? {
    val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    return downloadManager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
        if (!cursor.moveToFirst()) return@use null

        val localUri = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)

        if (localUri < 0) return@use null

        cursor.getString(localUri)?.let {
            val uri = Uri.parse(it)

            when (uri.scheme) {
                "file" ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        FileProvider.getUriForFile(context, context.applicationContext.packageName + ".provider", File(uri.path!!))
                    else
                        uri
                "content" -> uri
                else -> null
            }
        }
    }
}

/**
 * Hands a finished download to the package installer: a dialog when the user is
 * looking at the app, a notification when they are not. Called from the
 * DownloadManager broadcast and again from the next update check, because a
 * broadcast to a stopped package is dropped and would otherwise leave the apk on
 * disk with nothing to open it.
 *
 * Main thread only.
 */
fun offerUpdateInstall(context: Context, id: Long) {
    val uri = installUriOf(context, id) ?: return

    Pupil.instance.resumedActivity?.let {
        installDialog(it, id, uri).show()
        return
    }

    notifyUpdateDownloaded(context, uri)
}

@SuppressLint("MissingPermission")
private fun notifyUpdateDownloaded(context: Context, uri: Uri) {
    if (!checkNotificationEnabled(context)) return

    val pendingIntent = PendingIntent.getActivity(
        context,
        System.currentTimeMillis().toInt(),
        installIntent(uri),
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0
    )

    val notification = NotificationCompat.Builder(context, "update")
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle(context.getText(R.string.update_download_completed))
        .setContentText(context.getText(R.string.update_download_completed_description))
        .setContentIntent(pendingIntent)
        .build()

    NotificationManagerCompat.from(context).notify(R.id.notification_id_update, notification)
}

fun restore(url: String, onFailure: ((Throwable) -> Unit)? = null, onSuccess: ((Int) -> Unit)? = null) {
    if (!URLUtil.isValidUrl(url)) {
        onFailure?.invoke(IllegalArgumentException())
        return
    }

    CoroutineScope(Dispatchers.IO).launch {
        kotlin.runCatching {
            when (val data = pupilClient.getBackup(url)) {
                is JsonArray -> favorites.addAll(data.map { it.jsonPrimitive.int })
                is JsonObject -> {
                    val newFavorites = data["favorites"]?.let { Json.decodeFromJsonElement<List<Int>>(it) }.orEmpty()
                    val newFavoriteTags = data["favorite_tags"]?.let { Json.decodeFromJsonElement<List<Tag>>(it) }.orEmpty()

                    favorites.addAll(newFavorites)
                    favoriteTags.addAll(newFavoriteTags)

                    onSuccess?.invoke(favorites.size + favoriteTags.size)
                }
                else -> error("data is neither JsonArray or JsonObject")
            }
        }.onFailure { onFailure?.invoke(it) }
    }
}