/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.random.Random

class EvaluateWithinTest {

    private val random = Random(5079)

    private val index = (1..200).toList()

    private val tagged = listOf("a", "b", "c", "d").associateWith {
        index.filter { random.nextInt(3) == 0 }.shuffled(random).toIntArray()
    }

    private val candidates = index.shuffled(random).take(60).toIntArray()

    private fun tag(name: String) = SearchQuery.Tag("tag", name)

    private fun reference(query: SearchQuery): Set<Int> = when (query) {
        is SearchQuery.Tag -> tagged.getValue(query.tag).toSet()
        is SearchQuery.And -> query.queries.map(::reference).reduce(Set<Int>::intersect)
        is SearchQuery.Or -> query.queries.map(::reference).reduce(Set<Int>::union)
        is SearchQuery.Not -> index.toSet() - reference(query.query)
        else -> error("not part of this index: $query")
    }

    private fun assertMatchesReference(query: SearchQuery) = runTest {
        val result = evaluateWithin(query, candidates) { tagged.getValue(it.tag) }

        assertEquals(query.toString(), result.size, result.toSet().size)
        assertEquals(query.toString(), reference(query) intersect candidates.toSet(), result.toSet())
    }

    @Test
    fun `a tag keeps only the candidates it is on`() =
        assertMatchesReference(tag("a"))

    @Test
    fun `a lone negation complements within the candidates`() =
        assertMatchesReference(SearchQuery.Not(tag("a")))

    @Test
    fun `an and of negations subtracts every one`() =
        assertMatchesReference(SearchQuery.And(listOf(SearchQuery.Not(tag("a")), SearchQuery.Not(tag("b")))))

    @Test
    fun `an and subtracts its negations from its positive terms`() =
        assertMatchesReference(SearchQuery.And(listOf(tag("a"), tag("c"), SearchQuery.Not(tag("b")))))

    @Test
    fun `an or with a negated branch`() =
        assertMatchesReference(SearchQuery.Or(listOf(tag("a"), SearchQuery.Not(tag("b")))))

    @Test
    fun `nested negations resolve the same as against the whole index`() {
        assertMatchesReference(
            SearchQuery.Not(SearchQuery.Or(listOf(tag("a"), SearchQuery.And(listOf(tag("b"), SearchQuery.Not(tag("c"))))))),
        )
        assertMatchesReference(
            SearchQuery.And(
                listOf(
                    SearchQuery.Or(listOf(tag("a"), tag("b"))),
                    SearchQuery.Not(SearchQuery.And(listOf(tag("c"), SearchQuery.Not(tag("d"))))),
                ),
            ),
        )
    }
}
