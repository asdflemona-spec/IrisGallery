/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NoResultTest {

    private val index = (1..20).toList().toIntArray()

    private val tagged = mapOf(
        "everything" to (1..20),
        "first half" to (1..10),
        "second half" to (11..20),
        "a few" to (1..5),
        "a few more" to (6..10),
        "nothing" to IntRange.EMPTY,
    ).mapValues { (_, ids) -> ids.toList().toIntArray() }

    private fun tag(name: String) = SearchQuery.Tag("tag", name)

    private fun assertDiagnosis(
        expected: NoResultReason?,
        query: SearchQuery?,
        languages: SearchQuery? = null,
        requiredTags: List<SearchQuery.Tag> = emptyList(),
        bannedTags: List<SearchQuery.Tag> = emptyList(),
    ) = runTest {
        assertEquals(
            expected,
            diagnoseNoResult(
                query = query,
                languages = languages,
                requiredTags = requiredTags,
                bannedTags = bannedTags,
                all = { index },
                lookup = { tagged.getValue(it.tag) },
            ),
        )
    }

    @Test
    fun `a term nothing carries is the one reported`() = assertDiagnosis(
        NoResultReason.EmptyTerm(tag("nothing")),
        SearchQuery.And(listOf(tag("first half"), tag("nothing"))),
    )

    @Test
    fun `a query that is one dead term reports that term`() = assertDiagnosis(
        NoResultReason.EmptyTerm(tag("nothing")),
        tag("nothing"),
    )

    @Test
    fun `terms that each find something but never the same gallery`() = assertDiagnosis(
        NoResultReason.NoOverlap,
        SearchQuery.And(listOf(tag("first half"), tag("second half"))),
    )

    @Test
    fun `a negated term that leaves out everything the rest finds`() = assertDiagnosis(
        NoResultReason.ExcludingTerm(SearchQuery.Not(tag("everything"))),
        SearchQuery.And(listOf(tag("first half"), SearchQuery.Not(tag("everything")))),
    )

    @Test
    fun `negations that only empty the result together are not blamed on one`() = assertDiagnosis(
        NoResultReason.NoOverlap,
        SearchQuery.And(
            listOf(
                tag("first half"),
                SearchQuery.Not(tag("a few")),
                SearchQuery.Not(tag("a few more")),
            ),
        ),
    )

    @Test
    fun `a language nothing the query finds is in`() = assertDiagnosis(
        NoResultReason.UnavailableLanguage(SearchQuery.Tag("language", "second half")),
        tag("first half"),
        languages = SearchQuery.Tag("language", "second half"),
    )

    @Test
    fun `a required tag nothing the query finds carries`() = assertDiagnosis(
        NoResultReason.MissingRequiredTag(tag("second half")),
        tag("first half"),
        requiredTags = listOf(tag("second half")),
    )

    @Test
    fun `a banned tag everything the query finds carries`() = assertDiagnosis(
        NoResultReason.BannedTag(tag("everything")),
        tag("first half"),
        bannedTags = listOf(tag("everything")),
    )

    @Test
    fun `bans that only empty the result together blame the filter as a whole`() = assertDiagnosis(
        NoResultReason.Filtered,
        tag("first half"),
        bannedTags = listOf(tag("a few"), tag("a few more")),
    )

    @Test
    fun `a filter that empties what a query with no terms of its own finds`() = assertDiagnosis(
        NoResultReason.BannedTag(tag("everything")),
        null,
        bannedTags = listOf(tag("everything")),
    )

    @Test
    fun `nothing to report where the search does find something`() = assertDiagnosis(
        null,
        tag("first half"),
        bannedTags = listOf(tag("a few")),
    )

    @Test
    fun `the first term that matches nothing at all`() = runTest {
        assertEquals(
            tag("nothing"),
            emptyTerm(
                SearchQuery.And(listOf(tag("first half"), tag("nothing"))),
                { index },
                { tagged.getValue(it.tag) },
            ),
        )

        assertNull(
            emptyTerm(
                SearchQuery.And(listOf(tag("first half"), tag("second half"))),
                { index },
                { tagged.getValue(it.tag) },
            ),
        )
    }

    @Test
    fun `a term is taken out of the conjunction it is part of`() {
        val first = tag("first half")
        val second = tag("second half")
        val third = tag("a few")

        assertEquals(
            SearchQuery.And(listOf(first, third)),
            SearchQuery.And(listOf(first, second, third)).without(second),
        )

        assertEquals(first, SearchQuery.And(listOf(first, second)).without(second))

        assertNull(first.without(first))
    }
}
