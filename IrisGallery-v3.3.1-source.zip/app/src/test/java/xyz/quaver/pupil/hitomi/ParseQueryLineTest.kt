/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ParseQueryLineTest {

    @Test
    fun `a bare tag keeps no namespace`() {
        assertEquals(SearchQuery.Tag(null, "glasses"), parseQueryLine("glasses"))
    }

    @Test
    fun `a namespace is split off`() {
        assertEquals(SearchQuery.Tag("female", "glasses"), parseQueryLine("female:glasses"))
    }

    @Test
    fun `underscores are the spaces 5_x wrote`() {
        assertEquals(SearchQuery.Tag("female", "sole female"), parseQueryLine("female:sole_female"))
    }

    @Test
    fun `a leading dash negates`() {
        assertEquals(
            SearchQuery.Not(SearchQuery.Tag("male", "yaoi")),
            parseQueryLine("-male:yaoi"),
        )
    }

    @Test
    fun `several tags are one and`() {
        assertEquals(
            SearchQuery.And(
                listOf(
                    SearchQuery.Tag("female", "glasses"),
                    SearchQuery.Not(SearchQuery.Tag(null, "yaoi")),
                    SearchQuery.Tag("language", "korean"),
                ),
            ),
            parseQueryLine("female:glasses -yaoi language:korean"),
        )
    }

    @Test
    fun `runs of spaces are not tags`() {
        assertEquals(SearchQuery.Tag(null, "glasses"), parseQueryLine("  glasses   "))
    }

    @Test
    fun `a line with no tag left is no query`() {
        assertNull(parseQueryLine(""))
        assertNull(parseQueryLine("   "))
        assertNull(parseQueryLine("female:"))
    }
}
