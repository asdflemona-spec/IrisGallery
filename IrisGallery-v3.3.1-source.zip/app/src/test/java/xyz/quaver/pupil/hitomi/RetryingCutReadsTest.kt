/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.hitomi

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.EOFException
import java.io.IOException

class RetryingCutReadsTest {

    private var attempts = 0

    private fun cutTimes(times: Int): suspend () -> String = {
        attempts++
        if (attempts <= times) throw EOFException() else "body"
    }

    @Test
    fun `a read that succeeds is not repeated`() = runTest {
        assertEquals("body", retryingCutReads(cutTimes(0)))
        assertEquals(1, attempts)
    }

    @Test
    fun `a cut read is asked again`() = runTest {
        assertEquals("body", retryingCutReads(cutTimes(1)))
        assertEquals(2, attempts)
    }

    @Test
    fun `a read cut twice still gets a third attempt`() = runTest {
        assertEquals("body", retryingCutReads(cutTimes(2)))
        assertEquals(3, attempts)
    }

    @Test
    fun `a read cut every time fails with what the last attempt threw`() = runTest {
        val thrown = runCatching { retryingCutReads(cutTimes(Int.MAX_VALUE)) }.exceptionOrNull()

        assertTrue(thrown.toString(), thrown is EOFException)
        assertEquals(3, attempts)
    }

    @Test
    fun `any cut connection is retried, not just an early end`() = runTest {
        val read = retryingCutReads {
            attempts++
            if (attempts == 1) throw IOException("unexpected end of stream") else "body"
        }

        assertEquals("body", read)
        assertEquals(2, attempts)
    }

    @Test
    fun `a status code is not asked again`() = runTest {
        val thrown = runCatching {
            retryingCutReads {
                attempts++
                throw HitomiResponseException(404)
            }
        }.exceptionOrNull()

        assertEquals(404, (thrown as? HitomiResponseException)?.statusCode)
        assertEquals(1, attempts)
    }

    @Test
    fun `a failure that is not a read failure goes straight out`() = runTest {
        val thrown = runCatching {
            retryingCutReads {
                attempts++
                error("not a read failure")
            }
        }.exceptionOrNull()

        assertTrue(thrown.toString(), thrown is IllegalStateException)
        assertEquals(1, attempts)
    }
}
