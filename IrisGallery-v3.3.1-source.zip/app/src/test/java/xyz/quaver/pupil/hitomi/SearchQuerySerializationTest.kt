package xyz.quaver.pupil.hitomi

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

class SearchQuerySerializationTest {

    private fun roundTrip(query: SearchQuery) =
        assertEquals(query, Json.decodeFromString<SearchQuery>(Json.encodeToString(query)))

    @Test
    fun `round trips every node`() {
        roundTrip(
            SearchQuery.And(
                listOf(
                    SearchQuery.Tag("artist", "someone"),
                    SearchQuery.Tag(tag = "bare"),
                    SearchQuery.Or(
                        listOf(
                            SearchQuery.Tag("language", "korean"),
                            SearchQuery.FavoriteArtists,
                        ),
                    ),
                    SearchQuery.ReadLater,
                    SearchQuery.Not(SearchQuery.Tag("female", "loli")),
                ),
            ),
        )
    }

    @Test
    fun `writes the names a stored query is read back by`() {
        assertEquals(
            """{"type":"or","queries":[{"type":"tag","tag":"a"},{"type":"not",""" +
                """"query":{"type":"favoriteArtists"}},{"type":"readLater"},""" +
                """{"type":"and","queries":[{"type":"tag","tag":"b"}]}]}""",
            Json.encodeToString<SearchQuery>(
                SearchQuery.Or(
                    listOf(
                        SearchQuery.Tag(tag = "a"),
                        SearchQuery.Not(SearchQuery.FavoriteArtists),
                        SearchQuery.ReadLater,
                        SearchQuery.And(listOf(SearchQuery.Tag(tag = "b"))),
                    ),
                ),
            ),
        )
    }
}
