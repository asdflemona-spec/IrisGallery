package xyz.quaver.pupil.hitomi

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SearchQueryTextTest {

    @Test
    fun `parses a term per word`() {
        assertEquals(
            SearchQuery.And(
                listOf(
                    SearchQuery.Tag("female", "big breasts"),
                    SearchQuery.Tag(null, "bare"),
                    SearchQuery.Not(SearchQuery.Tag("artist", "someone")),
                ),
            ),
            parseQueryText("female:big_breasts  bare -artist:Someone "),
        )
    }

    @Test
    fun `parses a single term as itself`() {
        assertEquals(SearchQuery.Tag("language", "korean"), parseQueryText("language:korean"))
    }

    @Test
    fun `parses nothing out of blank text`() {
        assertNull(parseQueryText("  "))
        assertNull(parseQueryText("- female:"))
    }

    @Test
    fun `keeps an unknown namespace as part of the tag`() {
        assertEquals(SearchQuery.Tag(null, "nope:whatever"), parseQueryText("nope:whatever"))
    }

    @Test
    fun `round trips what it can spell`() {
        val text = "female:big_breasts bare -artist:someone"

        assertEquals(text, parseQueryText(text)?.toQueryText())
    }

    @Test
    fun `spells nothing it cannot parse back`() {
        assertNull(SearchQuery.FavoriteArtists.toQueryText())
        assertNull(SearchQuery.ReadLater.toQueryText())
        assertNull(SearchQuery.Or(listOf(SearchQuery.Tag(tag = "a"))).toQueryText())
        assertNull(SearchQuery.Not(SearchQuery.ReadLater).toQueryText())
        assertNull(
            SearchQuery.And(
                listOf(SearchQuery.Tag(tag = "a"), SearchQuery.FavoriteArtists),
            ).toQueryText(),
        )
    }

    @Test
    fun `finds the term the cursor is in`() {
        val text = "female:big_breasts bare"

        assertEquals(QueryTerm(0, 18, "female:big_breasts"), termAt(text, 4))
        assertEquals(QueryTerm(19, 23, "bare"), termAt(text, 23))
        assertEquals(QueryTerm(0, 0, ""), termAt("", 0))
        assertEquals(QueryTerm(5, 5, ""), termAt("bare ", 5))
    }
}
