/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2020  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.services

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class ImageQueueTest {

    private suspend fun ImageQueue.drain(focus: Int): List<Int> {
        val taken = mutableListOf<Int>()

        while (true) taken.add(take(focus) ?: return taken)
    }

    @Test
    fun `hands out every image once`() = runTest {
        val queue = ImageQueue((0 until 5).toList(), 5)

        assertEquals(listOf(0, 1, 2, 3, 4), queue.drain(0))
        assertEquals(null, queue.take(0))
    }

    @Test
    fun `starts at the page being read and carries on forward`() = runTest {
        val queue = ImageQueue((0 until 10).toList(), 10)

        assertEquals(listOf(4, 5, 6, 7, 8, 9), (4..9).map { queue.take(4) })
    }

    @Test
    fun `fills in the pages behind only once the ones ahead are taken`() = runTest {
        val queue = ImageQueue((0 until 6).toList(), 6)

        repeat(3) { queue.take(3) }

        assertEquals(listOf(2, 1, 0), queue.drain(3))
    }

    @Test
    fun `follows the page being read`() = runTest {
        val queue = ImageQueue((0 until 100).toList(), 100)

        assertEquals(0, queue.take(0))
        assertEquals(50, queue.take(50))
        assertEquals(51, queue.take(50))
        assertEquals(20, queue.take(20))
    }

    @Test
    fun `skips what is already on disk`() = runTest {
        val queue = ImageQueue(listOf(2, 7), 10)

        assertEquals(listOf(7, 2), queue.drain(5))
    }
}
