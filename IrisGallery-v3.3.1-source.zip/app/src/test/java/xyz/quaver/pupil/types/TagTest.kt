package xyz.quaver.pupil.types

import org.junit.Assert.assertEquals
import org.junit.Test

class TagTest {

    @Test
    fun `parses a bare tag`() {
        assertEquals(Tag(null, "guro", false), Tag.parse("guro"))
    }

    @Test
    fun `parses a namespaced tag`() {
        assertEquals(Tag("female", "guro", false), Tag.parse("female:guro"))
    }

    @Test
    fun `spells out the implicit tag namespace`() {
        assertEquals(Tag("tag", "guro", false), Tag.parseNamespaced("guro"))
    }

    @Test
    fun `leaves an explicit namespace alone`() {
        assertEquals(Tag("female", "guro", false), Tag.parseNamespaced("female:guro"))
    }

    @Test
    fun `keeps the minus while spelling out the namespace`() {
        val tag = Tag.parseNamespaced("-guro")

        assertEquals("tag", tag.area)
        assertEquals("guro", tag.tag)
        assertEquals(true, tag.isNegative)
    }

    @Test
    fun `parses a namespaced negative`() {
        val tag = Tag.parse("-female:guro")

        assertEquals("female", tag.area)
        assertEquals("guro", tag.tag)
        assertEquals(true, tag.isNegative)
    }

    @Test
    fun `strips the minus from a bare negative`() {
        val tag = Tag.parse("-guro")

        assertEquals(null, tag.area)
        assertEquals("guro", tag.tag)
        assertEquals(true, tag.isNegative)
    }

    @Test
    fun `bare negative round trips`() {
        assertEquals("-guro", Tag.parse("-guro").toString())
    }

    @Test
    fun `namespaced negative round trips`() {
        assertEquals("-female:guro", Tag.parse("-female:guro").toString())
    }

    @Test
    fun `repeated parsing is stable`() {
        val once = Tag.parse("-guro").toString()

        assertEquals(once, Tag.parse(once).toString())
    }

    @Test
    fun `a query of mixed tags round trips`() {
        val query = "language:english -female:guro -shota"

        assertEquals(query, Tags.parse(query).toString())
    }
}
