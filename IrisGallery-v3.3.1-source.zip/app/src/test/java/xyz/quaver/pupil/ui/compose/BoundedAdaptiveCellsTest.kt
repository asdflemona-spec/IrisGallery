/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BoundedAdaptiveCellsTest {

    private val cells = BoundedAdaptiveCells(minWidth = 150.dp, maxWidth = 200.dp, gap = 8.dp)

    private fun sizes(availableDp: Int) =
        with(cells) { Density(1f).calculateCrossAxisCellSizes(availableDp, 0) }

    @Test
    fun `columns share the row between the bounds`() {
        (158..2000).forEach { available ->
            val sizes = sizes(available)

            assertTrue("$available: $sizes", sizes.all { it in 150..200 })
            assertTrue("$available: $sizes", available - sizes.sum() >= sizes.size * 8)
        }
    }

    @Test
    fun `a wide single column stops at the maximum`() {
        assertEquals(listOf(200), sizes(300))
    }

    @Test
    fun `a phone fits two columns`() {
        assertEquals(listOf(193, 193), sizes(403))
    }

    @Test
    fun `a row too narrow for the minimum still gets one column`() {
        assertEquals(listOf(92), sizes(100))
    }
}
