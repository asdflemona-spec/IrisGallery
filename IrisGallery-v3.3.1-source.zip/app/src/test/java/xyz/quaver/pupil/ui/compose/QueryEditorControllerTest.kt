/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import xyz.quaver.pupil.hitomi.SearchQuery

class QueryEditorControllerTest {

    @Test
    fun `text left in the field is committed`() {
        val controller = QueryEditorController(null.toEditableState())
        controller.input.tag = "abcde"

        assertEquals(SearchQuery.Tag(null, "abcde"), controller.commitQuery())
        assertEquals("", controller.input.tag)
    }

    @Test
    fun `text left in the field joins the existing query`() {
        val controller = QueryEditorController(SearchQuery.Tag("female", "glasses").toEditableState())
        controller.input.namespace = "artist"
        controller.input.tag = " Abc "

        assertEquals(
            SearchQuery.And(listOf(SearchQuery.Tag("female", "glasses"), SearchQuery.Tag("artist", "abc"))),
            controller.commitQuery(),
        )
    }

    @Test
    fun `text left in the field follows the not mode`() {
        val controller = QueryEditorController(null.toEditableState())
        controller.toggleNot()
        controller.input.tag = "abcde"

        assertEquals(SearchQuery.Not(SearchQuery.Tag(null, "abcde")), controller.commitQuery())
    }

    @Test
    fun `a namespace sent whole with the text is split off`() {
        val controller = QueryEditorController(null.toEditableState())
        controller.input.tag = "language:korean"

        assertEquals(SearchQuery.Tag("language", "korean"), controller.commitQuery())
    }

    @Test
    fun `a bare namespace is dropped`() {
        val controller = QueryEditorController(null.toEditableState())
        controller.input.namespace = "female"

        assertNull(controller.commitQuery())
    }
}
