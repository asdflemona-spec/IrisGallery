/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import org.junit.Assert.assertEquals
import org.junit.Test

class SplitNamespaceTest {

    @Test
    fun `a prefix the field never promoted is split off`() {
        assertEquals("male" to "yaoi", splitNamespace("male:yaoi", null))
        assertEquals("language" to "korean", splitNamespace("language:korean", null))
    }

    @Test
    fun `a prefix repeated under the namespace it names is not doubled`() {
        assertEquals("male" to "yaoi", splitNamespace("male:yaoi", "male"))
    }

    @Test
    fun `a namespace already promoted is kept`() {
        assertEquals("male" to "yaoi", splitNamespace("yaoi", "male"))
        assertEquals(null to "yaoi", splitNamespace("yaoi", null))
    }

    @Test
    fun `a colon that names no namespace stays in the tag`() {
        assertEquals(null to "re:zero", splitNamespace("re:zero", null))
        assertEquals("artist" to "re:zero", splitNamespace("re:zero", "artist"))
        assertEquals(null to ":", splitNamespace(":", null))
    }

    @Test
    fun `a prefix on its own leaves nothing to commit`() {
        assertEquals("female" to "", splitNamespace("female:", null))
    }

    @Test
    fun `a tag with spaces in it survives the split`() {
        assertEquals("artist" to "mizuryu kei", splitNamespace("artist:mizuryu kei", null))
    }
}
