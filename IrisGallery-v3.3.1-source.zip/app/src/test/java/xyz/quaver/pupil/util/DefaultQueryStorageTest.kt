package xyz.quaver.pupil.util

import org.junit.Assert.assertEquals
import org.junit.Test
import xyz.quaver.pupil.hitomi.SearchQuery

class DefaultQueryStorageTest {

    private fun roundTrip(stored: DefaultQueryTerms) = parseDefaultQuery(
        encodeDefaultQuery(
            languages = stored.languages,
            requiredTags = stored.requiredTags,
            bannedTags = stored.bannedTags,
        )
    )

    @Test
    fun `a banned tag with a space in it comes back banned`() {
        val stored = DefaultQueryTerms(
            bannedTags = listOf(SearchQuery.Tag("artist", "mizuryu kei")),
        )

        assertEquals(stored, roundTrip(stored))
    }

    @Test
    fun `every list survives a round trip together`() {
        val stored = DefaultQueryTerms(
            languages = listOf("korean", "japanese"),
            requiredTags = listOf(
                SearchQuery.Tag("series", "kantai collection"),
                SearchQuery.Tag("tag", "full color"),
            ),
            bannedTags = listOf(
                SearchQuery.Tag("female", "guro"),
                SearchQuery.Tag("group", "ozashiki asobi"),
            ),
        )

        assertEquals(stored, roundTrip(stored))
    }

    @Test
    fun `a tag with no namespace keeps its space too`() {
        val stored = DefaultQueryTerms(
            bannedTags = listOf(SearchQuery.Tag(null, "full censorship")),
        )

        assertEquals(stored, roundTrip(stored))
    }

    @Test
    fun `a query stored before this was a list is still read`() {
        assertEquals(
            DefaultQueryTerms(
                languages = listOf("korean"),
                requiredTags = listOf(SearchQuery.Tag("tag", "loli")),
                bannedTags = listOf(SearchQuery.Tag("female", "guro")),
            ),
            parseDefaultQuery("language:korean tag:loli -female:guro"),
        )
    }

    @Test
    fun `a tag spelled with an underscore is read as the spaced tag`() {
        assertEquals(
            DefaultQueryTerms(
                bannedTags = listOf(SearchQuery.Tag("artist", "mizuryu kei")),
            ),
            parseDefaultQuery("""["-artist:mizuryu_kei"]"""),
        )
    }

    @Test
    fun `nothing stored is nothing set`() {
        assertEquals(DefaultQueryTerms(), parseDefaultQuery(""))
    }
}
