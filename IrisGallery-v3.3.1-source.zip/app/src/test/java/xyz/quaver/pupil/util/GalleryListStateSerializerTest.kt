package xyz.quaver.pupil.util

import androidx.datastore.core.CorruptionException
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.hitomi.SortMode
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class GalleryListStateSerializerTest {

    private suspend fun read(stored: String) =
        GalleryListStateSerializer.readFrom(ByteArrayInputStream(stored.encodeToByteArray()))

    private suspend fun write(state: GalleryListState) = ByteArrayOutputStream()
        .also { GalleryListStateSerializer.writeTo(state, it) }
        .toString(Charsets.UTF_8.name())

    @Test
    fun `round trips a whole screen worth of state`() = runTest {
        val state = GalleryListState(
            query = SearchQuery.Tag("artist", "someone"),
            sortMode = SortMode.POPULAR_WEEK,
            page = 4,
            firstVisibleItemIndex = 11,
            firstVisibleItemScrollOffset = 240,
            searchBarOffset = -137,
        )

        assertEquals(state, read(write(state)))
    }

    @Test
    fun `a state written before a field existed keeps the rest`() = runTest {
        assertEquals(
            GalleryListState(sortMode = SortMode.RANDOM, page = 2),
            read("""{"sortMode":"RANDOM","page":2}"""),
        )
    }

    @Test
    fun `a state written after a field was dropped keeps the rest`() = runTest {
        assertEquals(GalleryListState(page = 3), read("""{"page":3,"itemsPerPage":25}"""))
    }

    @Test
    fun `an unreadable state is corruption, for the handler to replace`() = runTest {
        assertEquals(
            CorruptionException::class.java,
            runCatching { read("not json") }.exceptionOrNull()?.javaClass,
        )
    }
}
