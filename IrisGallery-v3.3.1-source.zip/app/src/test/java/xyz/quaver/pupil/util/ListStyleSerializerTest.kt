/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class ListStyleSerializerTest {

    private suspend fun read(stored: String) =
        ListStyleSerializer.readFrom(ByteArrayInputStream(stored.encodeToByteArray()))

    private suspend fun write(style: ListStyle) = ByteArrayOutputStream()
        .also { ListStyleSerializer.writeTo(style, it) }
        .toString(Charsets.UTF_8.name())

    @Test
    fun `round trips every style`() = runTest {
        ListStyle.entries.forEach { assertEquals(it, read(write(it))) }
    }

    @Test
    fun `anything unreadable is the detailed list`() = runTest {
        assertEquals(ListStyle.DETAILED, read(""))
        assertEquals(ListStyle.DETAILED, read("masonry"))
    }
}
