/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import androidx.datastore.core.CorruptionException
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class ReadProgressTest {

    private suspend fun read(stored: String) =
        ReadProgressSerializer.readFrom(ByteArrayInputStream(stored.encodeToByteArray()))

    private suspend fun write(progress: Map<Int, ReadProgress>) = ByteArrayOutputStream()
        .also { ReadProgressSerializer.writeTo(progress, it) }
        .toString(Charsets.UTF_8.name())

    @Test
    fun `round trips every gallery`() = runTest {
        val progress = mapOf(
            1234 to ReadProgress(page = 3, pageCount = 20),
            5678 to ReadProgress(page = 41, pageCount = 41),
        )

        assertEquals(progress, read(write(progress)))
    }

    @Test
    fun `unreadable progress is corruption, for the handler to replace`() = runTest {
        assertEquals(
            CorruptionException::class.java,
            runCatching { read("not json") }.exceptionOrNull()?.javaClass,
        )
    }

    @Test
    fun `the first read starts the progress`() {
        assertEquals(ReadProgress(5, 20), null.advancedTo(5, 20))
    }

    @Test
    fun `reading further moves the progress on`() {
        assertEquals(ReadProgress(12, 20), ReadProgress(5, 20).advancedTo(12, 20))
    }

    @Test
    fun `going back to an earlier page keeps the furthest one`() {
        assertEquals(ReadProgress(12, 20), ReadProgress(12, 20).advancedTo(1, 20))
    }

    @Test
    fun `a gallery that lost pages caps the progress at its end`() {
        assertEquals(ReadProgress(15, 15), ReadProgress(18, 20).advancedTo(2, 15))
    }

    @Test
    fun `a gallery opens where it was left`() {
        assertEquals(12, ReadProgress(12, 20).resumePage(20))
    }

    @Test
    fun `a gallery never read opens at the first page`() {
        assertEquals(1, null.resumePage(20))
    }

    @Test
    fun `a gallery read to the end opens at the first page again`() {
        assertEquals(1, ReadProgress(20, 20).resumePage(20))
    }

    @Test
    fun `a gallery that lost the page it was left on opens at the first page`() {
        assertEquals(1, ReadProgress(18, 20).resumePage(15))
    }

    @Test
    fun `a gallery that gained pages still opens where it was left`() {
        assertEquals(20, ReadProgress(20, 20).resumePage(25))
    }

    @Test
    fun `the bar fills to the fraction read`() {
        assertEquals(0.25f, ReadProgress(5, 20).fraction)
        assertEquals(0f, ReadProgress(0, 0).fraction)
    }
}
