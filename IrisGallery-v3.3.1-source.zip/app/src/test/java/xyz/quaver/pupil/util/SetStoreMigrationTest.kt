package xyz.quaver.pupil.util

import androidx.datastore.core.DataStoreFactory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class SetStoreMigrationTest {

    @get:Rule
    val folder = TemporaryFolder()

    private val serializer = ListSerializer(Int.serializer())

    private fun TemporaryFolder.savedSet(contents: String) =
        newFile("favorites.json").apply { writeText(contents) }

    private fun TemporaryFolder.store(legacy: File) = DataStoreFactory.create(
        serializer = JsonListSerializer(serializer),
        migrations = listOf(SavedSetMigration(legacy) { Json.decodeFromString(serializer, it) }),
        produceFile = { File(root, "datastore/favorites.json") },
    )

    @Test
    fun `imports the saved set and drops the legacy file`() = runTest {
        val legacy = folder.savedSet("[1,2,3]")

        assertEquals(listOf(1, 2, 3), folder.store(legacy).data.first())
        assertFalse(legacy.exists())
    }

    @Test
    fun `keeps what the store already holds`() = runTest {
        val store = folder.store(folder.savedSet("[1,2]"))
        store.updateData { listOf(2, 9) }

        assertEquals(listOf(2, 9), store.data.first())
    }

    @Test
    fun `reads a saved set whose elements are not the store's`() = runTest {
        val legacy = folder.savedSet("[\"1\",\"2\"]")

        val store = DataStoreFactory.create(
            serializer = JsonListSerializer(serializer),
            migrations = listOf(
                SavedSetMigration(legacy) { text ->
                    Json.decodeFromString(ListSerializer(String.serializer()), text)
                        .mapNotNull(String::toIntOrNull)
                },
            ),
            produceFile = { File(folder.root, "datastore/converted.json") },
        )

        assertEquals(listOf(1, 2), store.data.first())
        assertFalse(legacy.exists())
    }

    @Test
    fun `an unreadable saved set migrates to nothing`() = runTest {
        val legacy = folder.savedSet("not json")

        assertEquals(emptyList<Int>(), folder.store(legacy).data.first())
        assertFalse(legacy.exists())
    }
}
