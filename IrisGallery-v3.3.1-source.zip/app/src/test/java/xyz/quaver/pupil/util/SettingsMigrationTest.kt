/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2026  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.Proxy

class SettingsMigrationTest {

    @Test
    fun `reads the preference screen's string lists as numbers`() {
        val settings = settingsFromLegacy(
            mapOf(
                "per_page" to "50",
                "cache_limit" to "16",
                "max_concurrent_download" to "4",
                "lock_timeout" to "0",
            )
        )

        assertEquals(50, settings.perPage)
        assertEquals(16, settings.cacheLimitGigabytes)
        assertEquals(4, settings.maxConcurrentDownload)
        assertEquals(0, settings.lockTimeoutMinutes)
    }

    @Test
    fun `carries switches and choices over`() {
        val settings = settingsFromLegacy(
            mapOf(
                "beta" to true,
                "tap_sides" to false,
                "multipage" to true,
                "rtl" to true,
                "multipage_fit" to "fill",
                "multipage_order" to "rtl",
                "download_folder_name" to "-title-",
                "tag_translation" to "ko",
                "security_mode" to true,
            )
        )

        assertEquals(true, settings.beta)
        assertEquals(false, settings.tapSides)
        assertEquals(ReaderLayout.AUTO, settings.readerLayout)
        assertEquals(false, settings.readerReverse)
        assertEquals(MultipageFit.FILL, settings.multipageFit)
        assertEquals(MultipageOrder.RTL, settings.multipageOrder)
        assertEquals("-title-", settings.downloadFolderName)
        assertEquals("ko", settings.tagTranslation)
        assertEquals(true, settings.securityMode)
    }

    @Test
    fun `decodes the stored proxy`() {
        val settings = settingsFromLegacy(
            mapOf("proxy" to """{"type":"SOCKS","host":"localhost","port":1080}""")
        )

        assertEquals(ProxyInfo(Proxy.Type.SOCKS, "localhost", 1080), settings.proxy)
    }

    @Test
    fun `a cache limit never written stays unlimited`() {
        assertEquals(0, settingsFromLegacy(mapOf("beta" to true)).cacheLimitGigabytes)
    }

    @Test
    fun `anything unreadable falls back to the default`() {
        val settings = settingsFromLegacy(
            mapOf(
                "per_page" to "lots",
                "multipage_fit" to "stretch",
                "proxy" to "not json",
                "tap_sides" to "yes",
            )
        )

        assertEquals(Settings().perPage, settings.perPage)
        assertEquals(MultipageFit.SCREEN, settings.multipageFit)
        assertEquals(Settings().proxy, settings.proxy)
        assertEquals(true, settings.tapSides)
    }

    @Test
    fun `round trips through the serializer`() = runTest {
        val settings = Settings(
            multipageOrder = MultipageOrder.LTR,
            proxy = ProxyInfo(Proxy.Type.HTTP, "proxy", 8080, "user", "pass"),
            cacheLimitGigabytes = 2,
        )

        val written = ByteArrayOutputStream().also { SettingsSerializer.writeTo(settings, it) }

        assertEquals(settings, SettingsSerializer.readFrom(ByteArrayInputStream(written.toByteArray())))
    }

    @Test
    fun `multipage turned off stays a single page rather than the new default`() = runTest {
        val read = SettingsSerializer.readFrom(
            ByteArrayInputStream("""{"multipage":false}""".encodeToByteArray())
        )

        assertEquals(ReaderLayout.SINGLE, read.readerLayout)
        assertEquals(ReaderLayout.SINGLE, settingsFromLegacy(mapOf("beta" to true)).readerLayout)
    }

    @Test
    fun `stored multipage and rtl become reader options`() = runTest {
        val read = SettingsSerializer.readFrom(
            ByteArrayInputStream("""{"multipage":true,"rtl":true,"beta":true}""".encodeToByteArray())
        )

        assertEquals(
            Settings(
                beta = true,
                readerLayout = ReaderLayout.AUTO,
                multipageOrder = MultipageOrder.RTL,
                readerOrientation = ReaderOrientation.VERTICAL,
                readerSnap = false,
                readerPadding = false,
            ),
            read,
        )
    }

    @Test
    fun `settings written before the reader options keep the reader that scrolled`() = runTest {
        val read = SettingsSerializer.readFrom(
            ByteArrayInputStream("""{"beta":true}""".encodeToByteArray())
        )

        assertEquals(ReaderOrientation.VERTICAL, read.readerOrientation)
        assertEquals(false, read.readerSnap)
        assertEquals(false, read.readerPadding)

        val legacy = settingsFromLegacy(mapOf("beta" to true))

        assertEquals(ReaderOrientation.VERTICAL, legacy.readerOrientation)
        assertEquals(false, legacy.readerSnap)
        assertEquals(false, legacy.readerPadding)
    }

    @Test
    fun `a reader opened for the first time turns pages sideways`() {
        val fresh = Settings()

        assertEquals(ReaderOrientation.HORIZONTAL, fresh.readerOrientation)
        assertEquals(true, fresh.readerSnap)
        assertEquals(true, fresh.readerPadding)
        assertEquals(ReaderLayout.AUTO, fresh.readerLayout)
    }

    @Test
    fun `settings written before the layout existed keep a single page`() = runTest {
        val read = SettingsSerializer.readFrom(
            ByteArrayInputStream("""{"beta":true,"rtl":true}""".encodeToByteArray())
        )

        assertEquals(ReaderLayout.SINGLE, read.readerLayout)
        assertEquals(false, read.readerReverse)
        assertEquals(MultipageOrder.RTL, read.multipageOrder)
    }

    @Test
    fun `every field is written, so a stored layout is never taken for an old file`() = runTest {
        val written = ByteArrayOutputStream().also { SettingsSerializer.writeTo(Settings(), it) }

        assertEquals(true, written.toString().contains("readerLayout"))
        assertEquals(Settings(), SettingsSerializer.readFrom(ByteArrayInputStream(written.toByteArray())))
    }

    @Test
    fun `reader options already stored win over the old keys`() = runTest {
        val read = SettingsSerializer.readFrom(
            ByteArrayInputStream(
                """{"multipage":true,"rtl":true,"readerLayout":"double","readerReverse":false}""".encodeToByteArray()
            )
        )

        assertEquals(Settings(readerLayout = ReaderLayout.DOUBLE, readerReverse = false), read)
    }

    @Test
    fun `a field added later reads as its default`() = runTest {
        val read = SettingsSerializer.readFrom(ByteArrayInputStream("""{"beta":true}""".encodeToByteArray()))

        // Except the reader's own, which a file this old is read as the reader it
        // was written for rather than as the defaults that came after it.
        assertEquals(
            Settings(
                beta = true,
                readerLayout = ReaderLayout.SINGLE,
                readerOrientation = ReaderOrientation.VERTICAL,
                readerSnap = false,
                readerPadding = false,
            ),
            read,
        )
    }
}
