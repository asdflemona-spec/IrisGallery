package xyz.quaver.pupil.util

import org.junit.Assert.assertEquals
import org.junit.Test

class TagsMatchingTranslationTest {

    private val translations = mapOf(
        "big breasts" to "거유",
        "nakadashi" to "질내사정",
        "sole female" to "단독 여성",
        "sole male" to "단독 남성",
        "glasses" to "안경",
    )

    @Test
    fun `matches a whole translated name`() {
        assertEquals(listOf("big breasts"), translations.tagsMatchingTranslation("거유"))
    }

    @Test
    fun `matches a partly typed translated name`() {
        assertEquals(listOf("nakadashi"), translations.tagsMatchingTranslation("질내"))
    }

    @Test
    fun `offers every tag a prefix matches`() {
        assertEquals(
            listOf("sole female", "sole male"),
            translations.tagsMatchingTranslation("단독"),
        )
    }

    @Test
    fun `puts a name starting with the term ahead of one merely containing it`() {
        val matches = mapOf(
            "sole female" to "단독 여성",
            "female" to "여성",
        ).tagsMatchingTranslation("여성")

        assertEquals(listOf("female", "sole female"), matches)
    }

    @Test
    fun `ignores case`() {
        val matches = mapOf("glasses" to "Gafas").tagsMatchingTranslation("gaf")

        assertEquals(listOf("glasses"), matches)
    }

    @Test
    fun `caps the number of matches`() {
        val matches = translations.tagsMatchingTranslation("단독", limit = 1)

        assertEquals(listOf("sole female"), matches)
    }

    @Test
    fun `matches nothing for a blank term`() {
        assertEquals(emptyList<String>(), translations.tagsMatchingTranslation("   "))
    }

    @Test
    fun `matches nothing when no translation contains the term`() {
        assertEquals(emptyList<String>(), translations.tagsMatchingTranslation("존재하지"))
    }
}
