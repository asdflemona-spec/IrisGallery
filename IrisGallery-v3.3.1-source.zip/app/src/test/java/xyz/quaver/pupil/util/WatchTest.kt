/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.util

import org.junit.Assert.assertEquals
import org.junit.Test
import xyz.quaver.pupil.hitomi.SearchQuery

class WatchTest {

    private val watch = Watch(SearchQuery.Tag("artist", "someone"))

    @Test
    fun `the first check reports nothing`() {
        val (checked, new) = watch.afterCheck(intArrayOf(3, 2, 1), 1000)

        assertEquals(emptyList<Int>(), new)
        assertEquals(listOf(3, 2, 1), checked.seen)
        assertEquals(1000, checked.lastCheckedAt)
        assertEquals(0, checked.newCount)
    }

    @Test
    fun `only what arrived since the last check is new`() {
        val (_, new) = watch.copy(seen = listOf(3, 2, 1)).afterCheck(intArrayOf(5, 4, 3, 2, 1), 0)

        assertEquals(listOf(5, 4), new)
    }

    @Test
    fun `a gallery that fell out of the results is not new again`() {
        val (_, new) = watch.copy(seen = listOf(3, 2, 1)).afterCheck(intArrayOf(3, 1), 0)

        assertEquals(emptyList<Int>(), new)
    }

    @Test
    fun `counts pile up until they are marked seen`() {
        val (once, _) = watch.copy(seen = listOf(1), newCount = 2).afterCheck(intArrayOf(2, 1), 0)

        assertEquals(3, once.newCount)
    }

    @Test
    fun `only the head of a long result is remembered`() {
        val ids = IntArray(WATCH_SEEN_LIMIT * 2) { it }

        val (checked, _) = watch.afterCheck(ids, 0)

        assertEquals(WATCH_SEEN_LIMIT, checked.seen.size)
        assertEquals(ids.take(WATCH_SEEN_LIMIT), checked.seen)
    }
}
