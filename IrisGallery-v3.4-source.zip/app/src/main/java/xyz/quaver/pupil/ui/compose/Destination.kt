package xyz.quaver.pupil.ui.compose

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import xyz.quaver.pupil.R

/** Iris-owned top-level navigation. Source-specific screens live below this shell. */
enum class Destination(
    val route: String,
    @StringRes val labelRes: Int,
    @DrawableRes val iconRes: Int,
) {
    Home("home", R.string.iris_discover, R.drawable.ic_home),
    Search("search", R.string.iris_search, R.drawable.ic_search),
    Favorites("library", R.string.iris_library, R.drawable.ic_star_filled),
    Downloads("offline", R.string.iris_offline, R.drawable.ic_download),
    Settings("settings", R.string.settings_title, R.drawable.ic_settings),
}
