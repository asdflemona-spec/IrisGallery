package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Breadboard-inspired Iris landing page: content/library first, sources second. */
@Composable
fun IrisDiscoverScreen(onSearchClick: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Text("IRIS", style = MaterialTheme.typography.headlineLarge)
            Text("Your visual library across the web", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(18.dp))
            Surface(
                tonalElevation = 2.dp,
                shape = MaterialTheme.shapes.extraLarge,
                modifier = Modifier.fillMaxWidth().clickable(onClick = onSearchClick),
            ) {
                Text("Search artwork, tags, creators…", Modifier.padding(18.dp), style = MaterialTheme.typography.bodyLarge)
            }
        }
        Text("Recently viewed", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        IrisLibrarySection(IrisLibraryFilter.HISTORY, Modifier.weight(1f))
    }
}
