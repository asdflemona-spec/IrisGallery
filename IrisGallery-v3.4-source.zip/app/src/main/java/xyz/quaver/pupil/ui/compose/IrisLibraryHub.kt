package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun IrisLibraryHub(
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text("Library", style = MaterialTheme.typography.headlineMedium)
            Text("Saved and viewed items from every source", style = MaterialTheme.typography.bodySmall)
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Saved") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("History") })
        }
        when (tab) {
            0 -> FavoritesScreen(Modifier.fillMaxSize(), onGalleryClick, onShowDetail)
            else -> HistoryScreen(Modifier.fillMaxSize(), onGalleryClick, onShowDetail)
        }
    }
}
