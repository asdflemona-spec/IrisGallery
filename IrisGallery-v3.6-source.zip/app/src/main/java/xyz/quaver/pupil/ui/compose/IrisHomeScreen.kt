/*
 * Iris Gallery fork of Pupil.
 * Pupil portions remain licensed under GPLv3; see app/LICENSE and FORK_NOTICE_KO.md.
 */
package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import kotlinx.coroutines.launch
import xyz.quaver.pupil.source.GgoorrSource
import xyz.quaver.pupil.source.SourceDetail
import xyz.quaver.pupil.source.SourceItem
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel
import xyz.quaver.pupil.util.IrisSourceActions

enum class IrisHomeSource(val label: String) { HITOMI("Hitomi"), GGOORR("Ggoorr") }

@Composable
fun IrisHomeScreen(
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
    searchViewModel: SearchViewModel,
) {
    var selected by remember { mutableStateOf(IrisHomeSource.HITOMI) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("Search", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Search your sources. Source choice is a filter, not the destination.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))
            Row {
                FilterChip(
                    selected = selected == IrisHomeSource.HITOMI,
                    onClick = { selected = IrisHomeSource.HITOMI },
                    label = { Text("Hitomi") },
                )
                Spacer(Modifier.size(8.dp))
                FilterChip(
                    selected = selected == IrisHomeSource.GGOORR,
                    onClick = { selected = IrisHomeSource.GGOORR },
                    label = { Text("Ggoorr") },
                )
            }
        }

        when (selected) {
            IrisHomeSource.HITOMI -> SearchScreen(
                modifier = Modifier.weight(1f),
                onGalleryClick = onGalleryClick,
                onShowDetail = onShowDetail,
                viewModel = searchViewModel,
            )
            IrisHomeSource.GGOORR -> GgoorrSourceScreen(Modifier.weight(1f))
        }
    }
}

@Composable
private fun GgoorrSourceScreen(modifier: Modifier = Modifier) {
    val source = remember { GgoorrSource() }
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var detail by remember { mutableStateOf<SourceDetail?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    var saved by remember { mutableStateOf(false) }

    fun search() {
        scope.launch {
            loading = true
            error = null
            detail = null
            try { items = source.search(query).items }
            catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
            finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { search() }

    Column(modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                label = { Text("Search Ggoorr") },
                singleLine = true,
            )
            Button(onClick = { search() }, modifier = Modifier.padding(start = 8.dp)) { Text("Go") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text("Source error: $it", modifier = Modifier.padding(vertical = 8.dp)) }

        val current = detail
        if (current == null) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.remoteId }) { item ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            scope.launch {
                                loading = true
                                error = null
                                try {
                                    detail = source.detail(item.remoteId)
                                    detail?.let {
                                        IrisSourceActions.recordHistory(context, it)
                                        saved = IrisSourceActions.isSaved(context, it)
                                    }
                                }
                                catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
                                finally { loading = false }
                            }
                        }.padding(vertical = 8.dp)
                    ) {
                        RemoteImage(item.thumbnailUrl, Modifier.size(84.dp), item.title, headers = source.requestHeaders)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium)
                            Text("Ggoorr", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        } else {
            Button(onClick = { detail = null }) { Text("Back to results") }
            Text(current.item.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth()) {
                Button(onClick = { scope.launch { IrisSourceActions.download(context, current, source.requestHeaders) } }) { Text("Download") }
                Spacer(Modifier.size(6.dp))
                Button(onClick = { saved = IrisSourceActions.toggleSaved(context, current) }) { Text(if (saved) "Saved" else "Save") }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Button(onClick = { IrisSourceActions.openOriginal(context, current.item.pageUrl) }) { Text("Original") }
                Spacer(Modifier.size(6.dp))
                Button(onClick = { IrisSourceActions.share(context, current) }) { Text("Share") }
            }
            if (current.imageUrls.isEmpty()) Text("No supported media URL was found on this post.")
            LazyColumn(Modifier.fillMaxSize()) {
                items(current.imageUrls) { url ->
                    if (IrisSourceActions.isVideoUrl(url)) {
                        IrisVideoPlayer(url, source.requestHeaders)
                    } else {
                        RemoteImage(url, Modifier.fillMaxWidth().height(420.dp), contentScale = ContentScale.Fit, headers = source.requestHeaders)
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}


@Composable
private fun IrisVideoPlayer(url: String, headers: Map<String, String>) {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(420.dp),
        factory = { context ->
            VideoView(context).apply {
                val controls = MediaController(context)
                controls.setAnchorView(this)
                setMediaController(controls)
                setVideoURI(Uri.parse(url), headers)
                setOnPreparedListener { player ->
                    player.isLooping = false
                    seekTo(1)
                }
            }
        },
        update = { view ->
            if (view.tag != url) {
                view.tag = url
                view.setVideoURI(Uri.parse(url), headers)
            }
        },
    )
}
