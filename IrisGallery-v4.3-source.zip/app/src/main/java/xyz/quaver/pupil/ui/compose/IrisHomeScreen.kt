/*
 * Iris Gallery fork of Pupil.
 * Pupil portions remain licensed under GPLv3; see app/LICENSE and FORK_NOTICE_KO.md.
 */
package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import xyz.quaver.pupil.source.GgoorrSource
import xyz.quaver.pupil.source.SourceDetail
import xyz.quaver.pupil.source.SourceItem
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel
import xyz.quaver.pupil.util.IrisSourceActions
import xyz.quaver.pupil.util.IrisSecureCredentialStore

enum class IrisHomeSource(val label: String) { HITOMI("Hitomi"), GGOORR("Ggoorr"), PIXIV("Pixiv"), PINTEREST("Pinterest"), X("X") }

@Composable
fun IrisHomeScreen(
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
    searchViewModel: SearchViewModel,
    onViewerActiveChanged: (Boolean) -> Unit = {},
) {
    var selected by remember { mutableStateOf(IrisHomeSource.HITOMI) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("Search", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Search your sources. Source choice is a filter, not the destination.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))
            Row {
                FilterChip(
                    selected = selected == IrisHomeSource.HITOMI,
                    onClick = { selected = IrisHomeSource.HITOMI },
                    label = { Text("Hitomi") },
                )
                Spacer(Modifier.size(8.dp))
                FilterChip(
                    selected = selected == IrisHomeSource.GGOORR,
                    onClick = { selected = IrisHomeSource.GGOORR },
                    label = { Text("Ggoorr") },
                )
            }
            Row {
                listOf(IrisHomeSource.PIXIV, IrisHomeSource.PINTEREST, IrisHomeSource.X).forEach { source ->
                    FilterChip(
                        selected = selected == source,
                        onClick = { selected = source },
                        label = { Text(source.label) },
                        modifier = Modifier.padding(end = 8.dp),
                    )
                }
            }
        }

        when (selected) {
            IrisHomeSource.HITOMI -> SearchScreen(
                modifier = Modifier.weight(1f),
                onGalleryClick = onGalleryClick,
                onShowDetail = onShowDetail,
                viewModel = searchViewModel,
            )
            IrisHomeSource.GGOORR -> GgoorrSourceScreen(Modifier.weight(1f), onViewerActiveChanged)
            IrisHomeSource.PIXIV -> ConfiguredSourceScreen("pixiv", "Pixiv", "Connect only with an authorized API access token. Iris never asks for or stores your Pixiv password.")
            IrisHomeSource.PINTEREST -> ConfiguredSourceScreen("pinterest", "Pinterest", "Use a token issued by an approved Pinterest developer app/OAuth flow. Iris never collects Pinterest passwords or session cookies.")
            IrisHomeSource.X -> ConfiguredSourceScreen("x", "X", "Use an access token issued by your authorized X API app. Credentials stay isolated from every other source.")
        }
    }
}


@Composable
private fun ConfiguredSourceScreen(sourceId: String, name: String, message: String) {
    val context = LocalContext.current
    val store = remember { IrisSecureCredentialStore(context.applicationContext) }
    var connected by remember(sourceId) { mutableStateOf(store.get(sourceId, "access_token") != null) }

    val provider = remember(sourceId) {
        when (sourceId) {
            "x" -> xyz.quaver.pupil.source.XAuthProvider()
            "pinterest" -> xyz.quaver.pupil.source.PinterestAuthProvider()
            else -> xyz.quaver.pupil.source.PixivAuthProvider()
        }
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text(name, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(if (connected) "Connected securely" else "Account connection", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Text(provider.setupHint, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        if (connected) {
            Text("Credential: encrypted locally • source: $sourceId", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                store.clearSource(sourceId)
                connected = false
            }) { Text("Disconnect account") }
        } else {
            Text(
                "Manual token entry was removed. Iris now uses the browser → provider approval → callback → encrypted token pattern used by established OAuth clients.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                when (sourceId) {
                    "x" -> "Next requirement: register Iris as an X developer app and configure its public client ID + callback URI."
                    "pinterest" -> "Next requirement: an approved Pinterest app and a secure token-exchange endpoint; the client secret must not be shipped inside the APK."
                    else -> "Next requirement: legitimate Pixiv application credentials. Iris will not reuse credentials copied from another app."
                },
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun GgoorrSourceScreen(
    modifier: Modifier = Modifier,
    onViewerActiveChanged: (Boolean) -> Unit = {},
) {
    val source = remember { GgoorrSource() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var nextPage by remember { mutableStateOf<Int?>(null) }
    var detail by remember { mutableStateOf<SourceDetail?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    var saved by remember { mutableStateOf(false) }

    fun load(page: Int, append: Boolean) {
        if (loading || loadingMore) return
        scope.launch {
            if (append) loadingMore = true else loading = true
            error = null
            if (!append) detail = null
            try {
                val result = source.search(query, page)
                if (append) {
                    // Notice/sticky rows can repeat between board pages. Keep one Iris item per source ID.
                    items = (items + result.items).distinctBy { "${it.sourceId}:${it.remoteId}" }
                } else {
                    items = result.items.distinctBy { "${it.sourceId}:${it.remoteId}" }
                }
                nextPage = result.nextPage
            } catch (t: Throwable) {
                error = t.message ?: t.javaClass.simpleName
            } finally {
                if (append) loadingMore = false else loading = false
            }
        }
    }

    fun search() = load(page = 0, append = false)
    fun loadMore() = nextPage?.let { load(page = it, append = true) }

    LaunchedEffect(Unit) { search() }
    LaunchedEffect(detail) { onViewerActiveChanged(detail != null) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { onViewerActiveChanged(false) }
    }

    // Incremental loading: when the user gets near the end, request the next real Ggoorr board page.
    LaunchedEffect(listState) {
        snapshotFlow {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            last to listState.layoutInfo.totalItemsCount
        }.distinctUntilChanged().collect { (last, total) ->
            if (total > 0 && last >= total - 5 && !loading && !loadingMore && nextPage != null && detail == null) {
                loadMore()
            }
        }
    }

    val current = detail
    if (current != null) {
        IrisViewer(
            detail = current,
            headers = source.requestHeaders,
            saved = saved,
            onBack = { detail = null },
            onToggleSaved = { saved = IrisSourceActions.toggleSaved(context, current) },
            onDownload = { scope.launch { IrisSourceActions.download(context, current, source.requestHeaders) } },
            onShare = { IrisSourceActions.share(context, current) },
            onOriginal = { IrisSourceActions.openOriginal(context, current.item.pageUrl) },
        )
        return
    }

    Column(modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                label = { Text("Search Ggoorr") },
                singleLine = true,
            )
            Button(onClick = { search() }, modifier = Modifier.padding(start = 8.dp)) { Text("Go") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text("Source error: $it", modifier = Modifier.padding(vertical = 8.dp)) }

        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            items(items, key = { it.remoteId }) { item ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        scope.launch {
                            loading = true
                            error = null
                            try {
                                detail = source.detail(item.remoteId)
                                detail?.let {
                                    IrisSourceActions.recordHistory(context, it)
                                    saved = IrisSourceActions.isSaved(context, it)
                                }
                            } catch (t: Throwable) {
                                error = t.message ?: t.javaClass.simpleName
                            } finally { loading = false }
                        }
                    }.padding(vertical = 8.dp)
                ) {
                    RemoteImage(item.thumbnailUrl, Modifier.size(84.dp), item.title, headers = source.requestHeaders)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                        Text("Ggoorr", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (loadingMore) {
                item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 12.dp)) }
            }
            if (items.isNotEmpty() && nextPage == null) {
                item { Text("End of results", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(16.dp)) }
            }
        }
    }
}
