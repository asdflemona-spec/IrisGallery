package xyz.quaver.pupil.ui.compose

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import xyz.quaver.pupil.util.IrisGalleryIndex
import xyz.quaver.pupil.util.IrisGalleryMedia

@Composable
fun IrisGallerySection(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    fun hasAccess(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasAccess()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        granted = result.values.any { it } || hasAccess(); refresh++
    }
    val media = remember(granted, refresh) { if (granted) runCatching { IrisGalleryIndex.scan(context) }.getOrDefault(emptyList()) else emptyList() }
    var category by remember { mutableStateOf("All") }
    val categories = listOf("All", "Camera", "Screenshots", "Downloads", "Iris", "Videos", "Other")
    val shown = remember(media, category) { if (category == "All") media else media.filter { it.category == category } }

    Column(modifier) {
        if (!granted) {
            Column(Modifier.padding(20.dp)) {
                Text("Your gallery stays on this device", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("Iris only indexes photos and videos so they can be organized with your personal library. Originals are not moved or copied.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val permissions = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                    launcher.launch(permissions)
                }) { Text("Allow gallery access") }
            }
            return@Column
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories.size) { i ->
                val c = categories[i]
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
        }
        Text("${shown.size} items · indexed locally", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(Modifier.fillMaxWidth()) {
            items(shown, key = { "gallery:${it.uri}" }) { item -> GalleryMediaRow(item) }
        }
    }
}

@Composable
private fun GalleryMediaRow(item: IrisGalleryMedia) {
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.uri)).apply { setDataAndType(Uri.parse(item.uri), item.mimeType); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
        }.padding(horizontal = 16.dp, vertical = 7.dp)
    ) {
        RemoteImage(item.uri, Modifier.size(76.dp), item.name)
        Column(Modifier.padding(start = 12.dp)) {
            Text(item.name, style = MaterialTheme.typography.titleSmall, maxLines = 2)
            Text("${item.category} · ${if (item.isVideo) "Video" else "Image"}", style = MaterialTheme.typography.labelSmall)
            Text(item.bucket, style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
    }
}
