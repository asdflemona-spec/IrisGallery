package xyz.quaver.pupil.ui.compose

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryIndex
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisTasteCluster
import xyz.quaver.pupil.util.IrisTasteEngine

private enum class GalleryMode(val label: String) { TASTE("For You"), ALL("All"), FAVORITES("Favorites"), IRIS("Iris"), VIDEOS("Videos") }

@Composable
fun IrisGallerySection(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    fun hasAccess(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasAccess()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result -> granted = result.values.any { it } || hasAccess(); refresh++ }
    val media = remember(granted, refresh) { if (granted) runCatching { IrisGalleryIndex.scan(context) }.getOrDefault(emptyList()) else emptyList() }
    var mode by remember { mutableStateOf(GalleryMode.TASTE) }
    var clusters by remember { mutableStateOf<List<IrisTasteCluster>>(emptyList()) }
    var analyzing by remember { mutableStateOf(false) }

    LaunchedEffect(media) {
        if (media.isNotEmpty()) {
            analyzing = true
            clusters = withContext(Dispatchers.Default) { IrisTasteEngine.discover(context, media) }
            analyzing = false
        }
    }

    Column(modifier) {
        if (!granted) {
            Column(Modifier.padding(20.dp)) {
                Text("Your gallery stays on this device", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp)); Text("Iris learns visual patterns locally. Originals are never moved or copied.")
                Spacer(Modifier.height(12.dp)); Button(onClick = {
                    launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                }) { Text("Allow gallery access") }
            }; return@Column
        }
        Text("Personal Library", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        Text("Iris discovers patterns in what you keep. No manual labels required.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(GalleryMode.entries) { value -> FilterChip(mode == value, { mode = value }, { Text(value.label) }) }
        }
        when (mode) {
            GalleryMode.TASTE -> TasteClusters(clusters, analyzing)
            else -> {
                val shown = when (mode) { GalleryMode.ALL -> media; GalleryMode.FAVORITES -> media.filter { it.isFavorite }; GalleryMode.IRIS -> media.filter { it.isIris }; GalleryMode.VIDEOS -> media.filter { it.isVideo }; else -> media }
                Text("${shown.size} items · local only", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                LazyColumn(Modifier.fillMaxWidth()) { items(shown, key = { "gallery:${it.uri}" }) { GalleryMediaRow(it) } }
            }
        }
    }
}

@Composable private fun TasteClusters(clusters: List<IrisTasteCluster>, analyzing: Boolean) {
    if (analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Discovering your visual patterns…", Modifier.padding(16.dp)); return }
    if (clusters.isEmpty()) { Text("Keep using Iris. Taste groups appear after enough visual history is available.", Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.fillMaxWidth()) {
        items(clusters, key = { "taste:${it.id}" }) { cluster ->
            Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Taste ${cluster.id + 1}", style = MaterialTheme.typography.titleMedium)
                    Text("${cluster.media.size} similar", style = MaterialTheme.typography.labelMedium)
                }
                Text("Discovered from visual similarity · stronger groups rise with Favorites and Iris saves", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(cluster.media.take(12), key = { it.uri }) { item -> GalleryTasteThumb(item) }
                }
            }
        }
    }
}

@Composable private fun GalleryTasteThumb(item: IrisGalleryMedia) {
    val context = LocalContext.current
    RemoteImage(item.uri, Modifier.size(112.dp).clickable { openGalleryItem(context, item) }, item.name)
}

@Composable private fun GalleryMediaRow(item: IrisGalleryMedia) {
    val context = LocalContext.current
    val badges = buildList { if (item.isFavorite) add("Favorite"); if (item.isIris) add("Iris"); if (item.isVideo) add("Video") else add("Image") }.joinToString(" · ")
    Row(Modifier.fillMaxWidth().clickable { openGalleryItem(context, item) }.padding(horizontal = 16.dp, vertical = 7.dp)) {
        RemoteImage(item.uri, Modifier.size(76.dp), item.name)
        Column(Modifier.padding(start = 12.dp)) { Text(item.name, style = MaterialTheme.typography.titleSmall, maxLines = 2); Text(badges, style = MaterialTheme.typography.labelSmall); Text(item.bucket, style = MaterialTheme.typography.bodySmall, maxLines = 1) }
    }
}

private fun openGalleryItem(context: android.content.Context, item: IrisGalleryMedia) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(Uri.parse(item.uri), item.mimeType); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
}
