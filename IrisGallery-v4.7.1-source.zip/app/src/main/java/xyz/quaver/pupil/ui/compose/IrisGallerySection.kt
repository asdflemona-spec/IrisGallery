package xyz.quaver.pupil.ui.compose

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryIndex
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisTasteCluster
import xyz.quaver.pupil.util.IrisTasteEngine

private enum class LibraryView(val label: String) { FOR_YOU("For You"), TASTES("Tastes"), COLLECTIONS("Collections"), CREATE("Create") }
private enum class CollectionFilter(val label: String) { ALL("All"), FAVORITES("Favorites"), IRIS("Iris"), DOWNLOADS("Downloads"), SCREENSHOTS("Screenshots"), CAMERA("Camera"), IMAGES("Images"), VIDEOS("Videos") }

@Composable
fun IrisGallerySection(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    fun hasAccess(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasAccess()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result -> granted = result.values.any { it } || hasAccess(); refresh++ }
    val media = remember(granted, refresh) { if (granted) runCatching { IrisGalleryIndex.scan(context) }.getOrDefault(emptyList()) else emptyList() }
    var view by remember { mutableStateOf(LibraryView.FOR_YOU) }
    var clusters by remember { mutableStateOf<List<IrisTasteCluster>>(emptyList()) }
    var analyzing by remember { mutableStateOf(false) }

    LaunchedEffect(media) {
        if (media.isNotEmpty()) {
            analyzing = true
            clusters = withContext(Dispatchers.Default) { IrisTasteEngine.discover(context, media) }
            analyzing = false
        }
    }

    Column(modifier) {
        if (!granted) {
            Column(Modifier.padding(20.dp)) {
                Text("Your gallery stays on this device", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp)); Text("Iris learns visual patterns locally. Originals are never moved or copied.")
                Spacer(Modifier.height(12.dp)); Button(onClick = {
                    launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                }) { Text("Allow gallery access") }
            }; return@Column
        }

        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(LibraryView.entries) { item -> FilterChip(view == item, { view = item }, { Text(item.label) }) }
        }
        when (view) {
            LibraryView.FOR_YOU -> ForYouView(clusters, media, analyzing)
            LibraryView.TASTES -> TasteClustersView(clusters, analyzing)
            LibraryView.COLLECTIONS -> CollectionsView(media)
            LibraryView.CREATE -> CreateView(clusters, media, analyzing)
        }
    }
}

@Composable private fun ForYouView(clusters: List<IrisTasteCluster>, media: List<IrisGalleryMedia>, analyzing: Boolean) {
    if (analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Discovering patterns only you may have missed…", Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            SectionTitle("Your visual fingerprint", "Not folders or manual tags — groups discovered from similarity and your positive signals.")
        }
        if (clusters.isEmpty()) item { Text("Keep using Iris. For You becomes useful after enough visual history is available.", Modifier.padding(16.dp)) }
        items(clusters.take(3), key = { "fy:${it.id}" }) { cluster -> TasteCard(cluster) }
        if (media.isNotEmpty()) {
            item { SectionTitle("Rediscover", "Recent favorites and Iris saves worth seeing again.") }
            item {
                val rediscover = media.filter { it.isFavorite || it.isIris }.sortedByDescending { it.dateAdded }.take(14)
                GalleryStrip(rediscover.ifEmpty { media.take(14) })
            }
        }
    }
}

@Composable private fun TasteClustersView(clusters: List<IrisTasteCluster>, analyzing: Boolean) {
    if (analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()); return }
    if (clusters.isEmpty()) { Text("No taste groups yet.", Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle("Discovered tastes", "A photo can belong to objective collections while Iris separately learns its visual taste group.") }
        items(clusters, key = { "taste:${it.id}" }) { TasteCard(it) }
    }
}

@Composable private fun TasteCard(cluster: IrisTasteCluster) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("Taste ${cluster.id + 1}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text("${cluster.media.size} visually related", style = MaterialTheme.typography.labelMedium) }
                if (cluster.affinity > 0f) AssistChip(onClick = {}, label = { Text("Strong match") })
            }
            Spacer(Modifier.height(8.dp)); GalleryStrip(cluster.media.take(12))
        }
    }
}

@Composable private fun CollectionsView(media: List<IrisGalleryMedia>) {
    var filter by remember { mutableStateOf(CollectionFilter.ALL) }
    Column {
        Text("Objective collections", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        Text("Useful facts stay separate from Iris' inferred tastes.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CollectionFilter.entries) { item -> FilterChip(filter == item, { filter = item }, { Text(item.label) }) }
        }
        val shown = media.filter { item -> when (filter) {
            CollectionFilter.ALL -> true
            CollectionFilter.FAVORITES -> item.isFavorite
            CollectionFilter.IRIS -> item.isIris
            CollectionFilter.DOWNLOADS -> item.isDownload
            CollectionFilter.SCREENSHOTS -> item.isScreenshot
            CollectionFilter.CAMERA -> item.isCamera
            CollectionFilter.IMAGES -> !item.isVideo
            CollectionFilter.VIDEOS -> item.isVideo
        } }
        Text("${shown.size} items", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(Modifier.fillMaxWidth()) { items(shown, key = { "gallery:${it.uri}" }) { GalleryMediaRow(it) } }
    }
}

@Composable private fun CreateView(clusters: List<IrisTasteCluster>, media: List<IrisGalleryMedia>, analyzing: Boolean) {
    val context = LocalContext.current
    if (analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()); return }
    val source = clusters.firstOrNull()?.media?.take(12) ?: media.filter { !it.isScreenshot }.take(12)
    if (source.isEmpty()) { Text("Add more photos to create a memory.", Modifier.padding(16.dp)); return }
    var playing by remember { mutableStateOf(false) }
    var frame by remember(source) { mutableIntStateOf(0) }
    LaunchedEffect(playing, source) {
        while (playing && source.isNotEmpty()) { delay(2200); frame = (frame + 1) % source.size }
    }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { SectionTitle("Create from what you already have", "No generative video bill. Iris uses photo sequencing, crop/zoom-ready frames and transitions.") }
        item {
            Card(Modifier.fillMaxWidth().padding(12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Taste Story", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("A lightweight memory assembled from your strongest current taste.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    Crossfade(targetState = source[frame.coerceIn(0, source.lastIndex)], label = "storyFrame") { item ->
                        RemoteImage(item.uri, Modifier.fillMaxWidth().height(310.dp).clickable { openGalleryItem(context, item) }, item.name)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { playing = !playing }) { Text(if (playing) "Pause" else "Play memory") }
                        AssistChip(onClick = {}, label = { Text("${source.size} photos") })
                        AssistChip(onClick = {}, label = { Text("~${source.size * 2}s") })
                    }
                }
            }
        }
        item { SectionTitle("Storyboard", "The project is only a list of media + timing, so it stays tiny until you choose to export later.") }
        item { GalleryStrip(source) }
        item { SectionTitle("Remix board", "A zero-generation mood board from the same taste group.") }
        item {
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                source.chunked(3).take(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { item -> GalleryThumb(item, Modifier.weight(1f).height(132.dp)) }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) { Text(title, style = MaterialTheme.typography.titleLarge); Text(subtitle, style = MaterialTheme.typography.bodySmall) }
}

@Composable private fun GalleryStrip(items: List<IrisGalleryMedia>) {
    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(items, key = { it.uri }) { item -> GalleryThumb(item, Modifier.size(112.dp)) } }
}

@Composable private fun GalleryThumb(item: IrisGalleryMedia, modifier: Modifier) {
    val context = LocalContext.current
    RemoteImage(item.uri, modifier.clickable { openGalleryItem(context, item) }, item.name)
}

@Composable private fun GalleryMediaRow(item: IrisGalleryMedia) {
    val context = LocalContext.current
    val badges = buildList { if (item.isFavorite) add("Favorite"); if (item.isIris) add("Iris"); if (item.isVideo) add("Video") else add("Image") }.joinToString(" · ")
    Row(Modifier.fillMaxWidth().clickable { openGalleryItem(context, item) }.padding(horizontal = 16.dp, vertical = 7.dp)) {
        RemoteImage(item.uri, Modifier.size(76.dp), item.name)
        Column(Modifier.padding(start = 12.dp)) { Text(item.name, style = MaterialTheme.typography.titleSmall, maxLines = 2); Text(badges, style = MaterialTheme.typography.labelSmall); Text(item.bucket, style = MaterialTheme.typography.bodySmall, maxLines = 1) }
    }
}

private fun openGalleryItem(context: android.content.Context, item: IrisGalleryMedia) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(Uri.parse(item.uri), item.mimeType); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
}
