package xyz.quaver.pupil.util

import android.content.Context

/** Local, zero-cost preference memory. Kept source-neutral so later viewers can feed the same profile. */
object IrisTasteProfile {
    private const val PREFS = "iris_taste_profile_v1"
    fun vote(context: Context, uri: String, positive: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(uri, if (positive) 1 else -1).apply()
    }
    fun signal(context: Context, uri: String): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(uri, 0)
}
