# Iris Gallery v4.9.1 — View Skins + Local Video

- Corrects v4.9 direction: successful-app patterns are presentation skins, not new classification systems.
- Adds Gallery / Vertical / Social / Webtoon view switcher over the same MediaStore dataset.
- Adds in-app Media3 ExoPlayer for local `content://` videos when opened from view skins.
- Same photos, videos, taste metadata and originals under every skin; no copying or moving files.
- Keeps For You / Tastes / Collections / Create under Gallery view.
- Play experiment is removed from the primary Library UI; taste engine remains available behind the gallery experience.
