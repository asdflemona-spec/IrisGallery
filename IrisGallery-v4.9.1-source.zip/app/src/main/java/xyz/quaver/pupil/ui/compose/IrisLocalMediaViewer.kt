package xyz.quaver.pupil.ui.compose

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisGalleryMedia

enum class IrisGallerySkin(val label: String) { GALLERY("Gallery"), VERTICAL("Vertical"), SOCIAL("Social"), WEBTOON("Webtoon") }

@Composable
fun IrisLocalMediaViewer(item: IrisGalleryMedia, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (item.isVideo) IrisVideoPlayer(item.uri) else AsyncImage(model = item.uri, contentDescription = item.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        TextButton(onClick = onClose, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) { Text("Close", color = Color.White) }
    }
}

@Composable
private fun IrisVideoPlayer(uri: String) {
    val context = LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(Uri.parse(uri))); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player; useController = true; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) } },
        update = { it.player = player },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
fun IrisSkinnedGallery(items: List<IrisGalleryMedia>, skin: IrisGallerySkin, onOpen: (IrisGalleryMedia) -> Unit, modifier: Modifier = Modifier) {
    when (skin) {
        IrisGallerySkin.GALLERY -> GalleryGridForSkin(items, onOpen, modifier)
        IrisGallerySkin.VERTICAL -> LazyColumn(modifier.fillMaxSize()) {
            items(items, key = { "vertical:${it.uri}" }) { item ->
                Box(Modifier.fillParentMaxHeight(.72f).fillMaxWidth().background(Color.Black).clickable { onOpen(item) }) {
                    RemoteImage(item.uri, Modifier.fillMaxSize(), item.name)
                    if (item.isVideo) Text("▶ Video", color = Color.White, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
                }
            }
        }
        IrisGallerySkin.SOCIAL -> LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(items, key = { "social:${it.uri}" }) { item ->
                Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(item.bucket.ifBlank { "Gallery" }, style = MaterialTheme.typography.titleSmall); Spacer(Modifier.weight(1f)); if (item.isFavorite) Text("♥") }
                    Box(Modifier.fillMaxWidth().aspectRatio(if (item.isVideo) 9f/12f else 1f).clickable { onOpen(item) }) { RemoteImage(item.uri, Modifier.fillMaxSize(), item.name); if (item.isVideo) Text("▶", color = Color.White, style = MaterialTheme.typography.headlineLarge, modifier = Modifier.align(Alignment.Center)) }
                    Text(item.name, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
            }
        }
        IrisGallerySkin.WEBTOON -> LazyColumn(modifier.fillMaxSize()) {
            items(items, key = { "webtoon:${it.uri}" }) { item ->
                Box(Modifier.fillMaxWidth().clickable { onOpen(item) }) {
                    RemoteImage(item.uri, Modifier.fillMaxWidth().height(if (item.isVideo) 300.dp else 520.dp), item.name)
                    if (item.isVideo) Text("▶ Video", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp))
                }
            }
        }
    }
}

@Composable
private fun GalleryGridForSkin(items: List<IrisGalleryMedia>, onOpen: (IrisGalleryMedia) -> Unit, modifier: Modifier) {
    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(3), modifier = modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        items(items.size, key = { items[it].uri }) { index -> val item = items[index]; Box(Modifier.aspectRatio(1f).clickable { onOpen(item) }) { RemoteImage(item.uri, Modifier.fillMaxSize(), item.name); if (item.isVideo) Text("▶", color = Color.White, modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)) } }
    }
}
