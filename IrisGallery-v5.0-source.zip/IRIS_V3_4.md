# Iris Gallery v3.4

This release changes ownership of the top-level UI from Pupil to Iris.

- Breadboard-inspired content-first landing page.
- Iris top-level navigation: Discover / Search / Library / Offline / Settings.
- Source selection moved under Search instead of being the app's primary navigation.
- Iris Library hub groups Saved and History under one Iris-owned screen.
- Existing Hitomi/Pupil engines remain in place behind the Iris shell to reduce regression risk.
- Ggoorr Iris Library data remains available through the unified Library sections.

This is a shell migration release, not a new-source release.
