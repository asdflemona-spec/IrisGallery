# Iris Gallery v3.4.2

Build-fix release for the Iris shell introduced in v3.4.

- Added the missing `ic_search` drawable used by the Iris Search destination.
- Removed the stale `Destination.History` top-level route reference left behind after navigation moved to the Iris shell.
- Keeps the v3.4 Discover / Search / Library / Offline / Settings structure unchanged.
