# Iris Gallery v3.5

- Discover now consumes both Hitomi and Ggoorr adapters with All / Hitomi / Ggoorr filters.
- Discover uses a dense image-first adaptive grid inspired by mature multi-source artwork browsers.
- Ggoorr detail distinguishes video URLs from images instead of sending video files to the image loader.
- Ggoorr video playback uses Android VideoView with the same source request headers.
- Ggoorr downloads now include MP4/WEBM/M4V/MOV and store videos in Movies/Iris/ggoorr via MediaStore on Android 10+.
- Images remain in Pictures/Iris/ggoorr.
