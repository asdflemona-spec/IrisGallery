# Iris Gallery v3.6

- Removed Discover as a top-level destination; Search is now the start destination.
- Simplified bottom navigation to Search / Library / Settings.
- Moved Offline into Iris Library as Saved / History / Offline tabs.
- Added All / Hitomi / Ggoorr source filters to Library.
- Ggoorr Saved, History, and downloaded media are read from IrisSourceActions.
- Hitomi continues to use the proven Pupil stores behind Iris Library while the visible shell is Iris-owned.
- Preserved v3.5 Ggoorr image/video viewer and MediaStore download behavior.
