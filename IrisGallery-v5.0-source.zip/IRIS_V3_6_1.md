# Iris Gallery v3.6.1

- Fix Kotlin compile error in IrisLibrarySection filter lambda (`it` -> `entry`).
- No functional rollback from v3.6.
