# Iris Gallery v3.7

- Introduces source-neutral `IrisViewer` as the common media-viewer boundary.
- Replaces the Ggoorr detail page's large search/back/action layout with a media-first viewer.
- Adds horizontal paging and page count for multi-media posts.
- Keeps image/video handling in the same viewer and preserves Ggoorr request headers.
- Hides Iris bottom navigation while a Ggoorr detail viewer is open to prevent video-control overlap.
- Keeps v3.6.1 Saved/History/Offline behavior and source separation unchanged.
- Hitomi continues to use its proven reader for now; `IrisViewer` is the migration target rather than risking a reader regression in this release.
