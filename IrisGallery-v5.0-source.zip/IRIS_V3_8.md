# Iris Gallery v3.8

- Fixed Ggoorr board pagination: page 2+ now uses `/ao/page/N` instead of the ineffective `?page=N` form.
- Ggoorr results now load incrementally near the end of the list.
- Added cross-page source/remote-ID de-duplication for sticky/repeated rows.
- Scoped Ggoorr result parsing toward the board article list to avoid weekly/sidebar links contaminating browse results.
- Stabilized the Iris source contract with `browse()` and source capability declarations.
- Explicit capabilities are declared for Hitomi and Ggoorr, preparing the app for additional source adapters.
- Preserved v3.7 IrisViewer, Ggoorr video playback/download, and v3.6 Library/History behavior.
