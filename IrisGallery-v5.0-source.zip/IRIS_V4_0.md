# Iris Gallery v4.0 — Security Foundation

- Removed REQUEST_INSTALL_PACKAGES; Iris no longer self-installs APKs.
- Disabled Android backup for app-private state to keep future sessions off cloud/device backup paths.
- Enforced HTTPS-only cleartext policy globally.
- Added IrisSecureCredentialStore: source-scoped AES-GCM secrets protected by Android Keystore.
- Credentials are deliberately separate from Iris Library/History preferences.
- Future login contract: third-party OAuth uses system browser/Custom Tabs; Iris never stores account passwords.
- Logout must clear only that source's credentials/cookies; "clear all sessions" clears every source.
- Release signing already supports CI-injected KEYSTORE_FILE / passwords. Never include signing keys in source ZIP or git.
- Android Developer Verification/package registration remains an external developer-account step and cannot be embedded in source code.
