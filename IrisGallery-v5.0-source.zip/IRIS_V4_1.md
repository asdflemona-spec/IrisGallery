# Iris Gallery v4.1 — Auth-ready sources

- Added Pixiv, Pinterest and X as visible Iris source entries.
- These providers are intentionally locked until supported authorization/API configuration exists.
- No password collection, copied session cookies, or scraping around provider authentication.
- Provider secrets/tokens must use the v4.0 source-scoped secure credential store.
- Removed the stale Rule34 registry placeholder.
- Existing Hitomi and Ggoorr behavior is unchanged.

Pinterest requires an approved developer app and OAuth for official API use. X/Pixiv adapters must likewise use supported/authorized access rather than bypassing provider controls.
