# Iris Gallery v4.2 — Account connection bridge

- Pixiv, Pinterest and X now expose a real source-scoped account connection screen.
- Accepts only provider-issued access tokens; never asks for provider passwords, browser cookies or client secrets.
- Tokens are encrypted locally through the v4.0 Android Keystore-backed credential store.
- Each source can be disconnected independently; disconnect deletes only that source credential.
- Search stays deliberately locked until each provider's supported API adapter is implemented and validated.
- Hitomi/Ggoorr behavior is unchanged.

## Security boundary
A mobile APK must not embed Pinterest/X app client secrets. Provider app registration and any server-side secret exchange remain external configuration. Pinterest access in particular requires an approved developer app and OAuth/API access.
