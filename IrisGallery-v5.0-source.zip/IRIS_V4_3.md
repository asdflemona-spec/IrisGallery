# Iris Gallery v4.3 — Provider Auth Foundation

- Removed manual provider-token entry from Search.
- Added shared SourceAuthProvider contract and PKCE helper.
- X: OAuth 2.0 Authorization Code + PKCE request builder foundation.
- Pinterest: official Authorization Code request builder foundation; client secret is never embedded in the APK.
- Pixiv: PKCE-compatible provider slot, intentionally disabled until Iris has legitimate provider credentials; no copied third-party app credentials.
- Existing Android Keystore encrypted credential store remains the destination for tokens after callback/token exchange.

This version establishes the safe connection architecture. It does not pretend that provider registration/approval has happened and does not bypass provider authentication.
