# Iris Gallery v4.3.1

Build-fix release for v4.3.

- Restores the missing Material 3 `OutlinedTextField` import in `IrisHomeScreen.kt`.
- Fixes the cascading Kotlin errors around the Ggoorr search field.
- No authentication, source, viewer, or library behavior changed from v4.3.
