# Iris Gallery v4.4 — Personal Gallery Index

- Keeps Pixiv/X/Pinterest connection work on hold.
- Adds the phone gallery as a first-class Library source using Android MediaStore.
- Read-only indexing: Iris does not move or copy existing gallery originals.
- Android 13+ uses READ_MEDIA_IMAGES / READ_MEDIA_VIDEO; older supported Android versions use READ_EXTERNAL_STORAGE.
- Local collections: Camera, Screenshots, Downloads, Iris, Videos, Other.
- Gallery items open with the device's media viewer.
- This is the foundation for later local personalization, user tags, ratings and duplicate/media identity work.
