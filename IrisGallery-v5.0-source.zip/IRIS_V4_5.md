# Iris Gallery v4.5 — Personal Collections

- Search is intentionally focused on the two active sources: Hitomi and Ggoorr.
- Pixiv, Pinterest, and X placeholders were removed from Search while those integrations are on hold.
- Gallery organization now uses overlapping facets rather than a single exclusive folder category.
- Local collections: All, Recent (30 days), Favorites (Android MediaStore favorites where available), Iris, Downloads, Screenshots, Camera, Videos, Other.
- A camera video can be both Camera and Videos; an Iris-downloaded video can be both Iris and Videos.
- Gallery indexing remains local/read-only and does not move or copy originals.

Design references: Mihon multi-category library organization, Hydrus local tags/inbox/archive concepts, and Immich metadata/media-type/favorites filtering. Future personalization can layer ratings/tags and duplicate review on this index without changing original media.
