# Iris Gallery v4.6 — Latent Taste Discovery

- Search remains Hitomi + Ggoorr only.
- Gallery defaults to For You instead of technical folders.
- Local-only visual feature extraction from thumbnails (8×8 luminance + colour signature).
- Unsupervised k-means groups visually similar media without user labels.
- Screenshots are excluded from taste learning by default.
- Android Favorites and Iris-downloaded media are positive ranking signals, not hard category labels.
- No image, feature vector, or preference data leaves the phone.
- All / Favorites / Iris / Videos remain as utility filters.

This is the first functional latent-taste layer. A later stage can replace the lightweight visual signature with a mobile embedding model while preserving the same UI/data contract.
