# Iris Gallery v4.7 — Personal Library + Lightweight Create

- Library UI reorganized into For You / Tastes / Collections / Create.
- Objective collections (Favorites, Iris, Downloads, Screenshots, Camera, Images, Videos) remain available but no longer pretend to be taste categories.
- Latent taste clusters are presented as visual cards with representative media.
- For You prioritizes discovered taste groups and rediscovery.
- Create adds a photo-only Taste Story preview: automatic sequence + lightweight crossfade playback, with no generated video or cloud inference.
- Remix Board builds a mood-board-like composition from the same taste cluster.
- Story projects are intentionally represented by media order/timing rather than rendered video; export can be added later.
- Existing gallery files remain read-only and local.
