# Iris Gallery v4.7.1

Build fix for v4.7. Hoists LocalContext.current out of the clickable callback in CreateView so Compose context is valid. No feature changes.
