# Iris Gallery v4.8 — Taste Gallery

- Taste groups now open into a real 3-column gallery grid; the grouped photos are no longer hidden behind a Strong match badge.
- Objective Collections also use a dense gallery grid instead of filename rows.
- Strong match copy removed from the primary UI: a discovered taste is shown by its media, not an unexplained score.
- Existing objective facets remain: Favorites, Iris, Downloads, Screenshots, Camera, Images, Videos.
- Added a local preference-memory primitive for future More/Less feedback and progressive taste refinement.
- Design references: Immich-style search/facets, Hydrus tags/ratings/similarity/duplicate relationships, conventional mobile gallery thumbnail density.
- All analysis remains local; no paid service or server is required.
