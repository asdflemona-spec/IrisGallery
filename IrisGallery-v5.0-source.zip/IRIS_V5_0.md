# Iris Gallery v5.0

Unified local gallery presentation foundation.

- Five presentation skins over the same MediaStore items: Photos, TikTok, Instagram, Pinterest, Webtoon.
- Video thumbnails use MediaStore/loadThumbnail instead of decoding video URIs as still images.
- Full-screen video uses Media3 ExoPlayer 1.8.0 (minSdk 21 compatible).
- Keep and Trash Queue state are shared across presentation skins and stored locally.
- Keep always clears/prevents Trash Queue state.
- No source file is deleted automatically in this build; destructive deletion requires a reviewed system deletion flow in the next cleanup step.
