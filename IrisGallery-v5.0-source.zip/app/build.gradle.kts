import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlinx.serialization)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.gms.oss.licenses)
    alias(libs.plugins.gms.google.services) apply false
    alias(libs.plugins.firebase.crashlytics) apply false
    alias(libs.plugins.firebase.perf) apply false
    id("kotlin-parcelize")
}

val hasGoogleServices = file("google-services.json").exists()

if (hasGoogleServices) {
    apply(plugin = libs.plugins.gms.google.services.get().pluginId)
    apply(plugin = libs.plugins.firebase.crashlytics.get().pluginId)
    apply(plugin = libs.plugins.firebase.perf.get().pluginId)
} else {
    logger.lifecycle("app/google-services.json not found — Firebase plugins disabled; this build cannot report to Firebase at runtime.")
}

android {
    namespace = "xyz.quaver.pupil"
    compileSdk = 37

    defaultConfig {
        applicationId = "app.iris.gallery"
        minSdk = 21
        targetSdk = 37
        // Derived from git in CI (no commit-back); falls back to these for local builds.
        versionCode = (System.getenv("PUPIL_VERSION_CODE") ?: "70").toInt()
        versionName = System.getenv("PUPIL_VERSION_NAME") ?: "5.3.24"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true
    }
    buildFeatures {
        buildConfig = true
        compose = true
    }
    // Release signing is driven by CI secrets. When KEYSTORE_FILE is absent
    // (local dev), the release build stays unsigned instead of failing.
    val hasReleaseKeystore = System.getenv("KEYSTORE_FILE") != null
    signingConfigs {
        create("release") {
            if (hasReleaseKeystore) {
                storeFile = file(System.getenv("KEYSTORE_FILE"))
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        debug {
            isMinifyEnabled = false
            isShrinkResources = false

            isDebuggable = true
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-DEBUG"

            extra.apply {
                set("enableCrashlytics", false)
                set("alwaysUpdateBuildId", false)
            }
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true

            if (hasReleaseKeystore) {
                signingConfig = signingConfigs.getByName("release")
            }

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    buildFeatures {
        viewBinding = true
    }
    lint {
        ignoreTestSources = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.JVM_11
    }
}

dependencies {
    implementation(libs.kotlin.stdlib.jdk8)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.datetime)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.runtime)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.animation.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.collection)
    implementation(libs.androidx.datastore)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.process)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.core.ktx)
    implementation(libs.appcompat)
    implementation(libs.activity.ktx)
    implementation(libs.fragment.ktx)
    implementation(libs.recyclerview)
    implementation(libs.constraintlayout)
    implementation(libs.gridlayout)
    implementation(libs.biometric)
    implementation(libs.work.runtime.ktx)

    implementation(libs.library)

    implementation(libs.material)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.analytics.ktx)
    implementation(libs.firebase.crashlytics.ktx)
    implementation(libs.firebase.perf.ktx)

    implementation(libs.play.services.oss.licenses)
    implementation(libs.play.services.mlkit.face.detection)


    implementation(libs.okhttp)
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.okhttp)

    implementation(libs.coil.compose)
    implementation(libs.coil.network.ktor3)
    implementation(libs.coil.gif)
    implementation(libs.telephoto.zoomable.image.coil3)

    implementation(libs.pinlockview)
    implementation(libs.patternlockview)

    implementation(libs.core)

    implementation(libs.ripplebackground.library)

    implementation(libs.jsoup)

    implementation(libs.documentfilex)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.rules)
    androidTestImplementation(libs.runner)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.mockwebserver)
}