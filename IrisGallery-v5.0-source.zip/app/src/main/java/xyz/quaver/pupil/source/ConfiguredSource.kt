package xyz.quaver.pupil.source

/** Provider-backed source that stays disabled until an approved OAuth/API configuration is connected. */
class ConfiguredSource(
    override val id: String,
    override val displayName: String,
    override val maturity: SourceMaturity = SourceMaturity.GENERAL,
) : ContentSource {
    override val availability = SourceAvailability.REQUIRES_CONFIGURATION
    override val capabilities = setOf(
        SourceCapability.BROWSE, SourceCapability.SEARCH, SourceCapability.DETAIL,
        SourceCapability.AUTHOR, SourceCapability.MULTI_IMAGE, SourceCapability.VIDEO,
        SourceCapability.DOWNLOAD,
    )

    override suspend fun search(query: String, page: Int): SourcePage =
        error("$displayName requires an authorized provider connection")

    override suspend fun detail(remoteId: String): SourceDetail =
        error("$displayName requires an authorized provider connection")
}
