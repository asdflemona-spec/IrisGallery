package xyz.quaver.pupil.source

/** A site-independent item that Iris can show in unified search/results UI. */
data class SourceItem(
    val sourceId: String,
    val remoteId: String,
    val title: String,
    val thumbnailUrl: String?,
    val pageUrl: String?,
    val tags: List<String> = emptyList(),
)

data class SourceDetail(
    val item: SourceItem,
    val imageUrls: List<String>,
    val creators: List<String> = emptyList(),
    val description: String? = null,
)

data class SourcePage(
    val items: List<SourceItem>,
    val nextPage: Int? = null,
)

enum class SourceMaturity { GENERAL, ADULT }
enum class SourceAvailability { READY, REQUIRES_CONFIGURATION }
enum class SourceCapability { BROWSE, SEARCH, DETAIL, TAGS, AUTHOR, MULTI_IMAGE, VIDEO, DOWNLOAD }

/**
 * Stable adapter boundary for Iris providers. UI code consumes this contract instead of
 * knowing provider URL/page rules. Implementations must use public/authorized endpoints.
 */
interface ContentSource {
    val id: String
    val displayName: String
    val maturity: SourceMaturity
    val availability: SourceAvailability
    val capabilities: Set<SourceCapability> get() = setOf(SourceCapability.SEARCH, SourceCapability.DETAIL)

    suspend fun search(query: String, page: Int = 0): SourcePage
    suspend fun browse(page: Int = 0): SourcePage = search("", page)
    suspend fun detail(remoteId: String): SourceDetail
}
