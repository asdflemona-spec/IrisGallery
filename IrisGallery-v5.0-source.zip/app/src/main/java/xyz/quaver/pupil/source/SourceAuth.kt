package xyz.quaver.pupil.source

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

/** Shared OAuth state for provider-backed Iris sources. No passwords or browser cookies. */
data class SourceAuthSession(
    val sourceId: String,
    val authorizationUrl: String,
    val state: String,
    val codeVerifier: String? = null,
)

data class SourceTokenSet(
    val accessToken: String,
    val refreshToken: String? = null,
    val expiresAtEpochSeconds: Long? = null,
    val scopes: String? = null,
)

object IrisPkce {
    private val random = SecureRandom()

    fun verifier(): String {
        val bytes = ByteArray(32).also(random::nextBytes)
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    fun challenge(verifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        return Base64.encodeToString(digest, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    fun state(): String {
        val bytes = ByteArray(24).also(random::nextBytes)
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
}

/**
 * Provider auth contract modeled after established OAuth clients:
 * browser authorization -> callback -> token exchange -> encrypted storage -> refresh.
 * Provider app credentials are deliberately not embedded here.
 */
interface SourceAuthProvider {
    val sourceId: String
    val displayName: String
    val setupHint: String
    fun begin(clientId: String, redirectUri: String): SourceAuthSession?
}

class XAuthProvider : SourceAuthProvider {
    override val sourceId = "x"
    override val displayName = "X"
    override val setupHint = "OAuth 2.0 Authorization Code + PKCE. Requires an X developer app/client ID."

    override fun begin(clientId: String, redirectUri: String): SourceAuthSession? {
        if (clientId.isBlank()) return null
        val verifier = IrisPkce.verifier()
        val state = IrisPkce.state()
        val challenge = IrisPkce.challenge(verifier)
        val url = "https://twitter.com/i/oauth2/authorize" +
            "?response_type=code&client_id=${enc(clientId)}&redirect_uri=${enc(redirectUri)}" +
            "&scope=${enc("tweet.read users.read offline.access")}" +
            "&state=${enc(state)}&code_challenge=${enc(challenge)}&code_challenge_method=S256"
        return SourceAuthSession(sourceId, url, state, verifier)
    }
}

class PinterestAuthProvider : SourceAuthProvider {
    override val sourceId = "pinterest"
    override val displayName = "Pinterest"
    override val setupHint = "Official Authorization Code flow. Token exchange needs the registered app secret, so Iris will not embed that secret in the APK."

    override fun begin(clientId: String, redirectUri: String): SourceAuthSession? {
        if (clientId.isBlank()) return null
        val state = IrisPkce.state()
        val url = "https://www.pinterest.com/oauth/" +
            "?client_id=${enc(clientId)}&redirect_uri=${enc(redirectUri)}&response_type=code" +
            "&scope=${enc("user_accounts:read boards:read pins:read")}&state=${enc(state)}"
        return SourceAuthSession(sourceId, url, state)
    }
}

class PixivAuthProvider : SourceAuthProvider {
    override val sourceId = "pixiv"
    override val displayName = "Pixiv"
    override val setupHint = "PKCE-style browser login is used by established third-party clients, but Iris does not copy another app's client credentials. Provider credentials must be supplied legitimately before enabling login."
    override fun begin(clientId: String, redirectUri: String): SourceAuthSession? = null
}

private fun enc(value: String): String = java.net.URLEncoder.encode(value, "UTF-8")
