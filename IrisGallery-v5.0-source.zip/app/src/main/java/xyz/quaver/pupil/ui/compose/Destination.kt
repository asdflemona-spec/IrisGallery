package xyz.quaver.pupil.ui.compose

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import xyz.quaver.pupil.R

/** Iris-owned top-level navigation. Sources are filters inside these destinations. */
enum class Destination(
    val route: String,
    @StringRes val labelRes: Int,
    @DrawableRes val iconRes: Int,
) {
    Search("search", R.string.iris_search, R.drawable.ic_search),
    Favorites("library", R.string.iris_library, R.drawable.ic_star_filled),
    Settings("settings", R.string.settings_title, R.drawable.ic_settings),
}
