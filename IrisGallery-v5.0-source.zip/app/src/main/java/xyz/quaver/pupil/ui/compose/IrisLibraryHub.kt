package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

enum class IrisLibrarySource { ALL, HITOMI, GGOORR, GALLERY }

@Composable
fun IrisLibraryHub(
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    var source by remember { mutableStateOf(IrisLibrarySource.ALL) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(top = 12.dp, bottom = 8.dp)) {
            Text("Library", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(horizontal = 16.dp))
            Text("Your personal visual library", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(8.dp))
            val sources = listOf(IrisLibrarySource.ALL to "All", IrisLibrarySource.HITOMI to "Hitomi", IrisLibrarySource.GGOORR to "Ggoorr", IrisLibrarySource.GALLERY to "Gallery")
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sources) { (value, label) -> FilterChip(source == value, { source = value }, { Text(label) }) }
            }
        }
        if (source == IrisLibrarySource.GALLERY) {
            IrisGallerySection(Modifier.weight(1f))
        } else {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Saved") })
                Tab(tab == 1, { tab = 1 }, text = { Text("History") })
                Tab(tab == 2, { tab = 2 }, text = { Text("Offline") })
            }
            IrisLibraryPage(tab, source, onGalleryClick, onShowDetail, Modifier.weight(1f))
        }
    }
}

@Composable
private fun IrisLibraryPage(
    tab: Int,
    source: IrisLibrarySource,
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
    modifier: Modifier,
) {
    val irisFilter = when (tab) {
        0 -> IrisLibraryFilter.SAVED
        1 -> IrisLibraryFilter.HISTORY
        else -> IrisLibraryFilter.DOWNLOADED
    }
    Column(modifier) {
        if (source != IrisLibrarySource.GGOORR) {
            Text("Hitomi", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp))
            when (tab) {
                0 -> FavoritesScreen(Modifier.weight(1f), onGalleryClick, onShowDetail, includeIris = false)
                1 -> HistoryScreen(Modifier.weight(1f), onGalleryClick, onShowDetail, includeIris = false)
                else -> DownloadsScreen(Modifier.weight(1f), onGalleryClick, onShowDetail, includeIris = false)
            }
        }
        if (source != IrisLibrarySource.HITOMI) {
            IrisLibrarySection(irisFilter, Modifier.weight(1f), sourceId = "ggoorr", showHeader = true)
        }
    }
}
