package xyz.quaver.pupil.ui.compose

import android.net.Uri
import android.os.Build
import android.util.Size
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisMediaState

enum class IrisGallerySkin(val label: String) { GALLERY("Photos"), VERTICAL("TikTok"), SOCIAL("Instagram"), BOARD("Pinterest"), WEBTOON("Webtoon") }

@Composable fun IrisLocalMediaViewer(item: IrisGalleryMedia, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (item.isVideo) IrisVideoPlayer(item.uri) else AsyncImage(item.uri, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        TextButton(onClick = onClose, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) { Text("✕", color = Color.White) }
    }
}

@Composable private fun IrisVideoPlayer(uri: String) {
    val context = LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(Uri.parse(uri))); repeatMode = ExoPlayer.REPEAT_MODE_ONE; prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) } }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
}

@Composable private fun MediaSurface(item: IrisGalleryMedia, modifier: Modifier = Modifier, scale: ContentScale = ContentScale.Crop) {
    if (!item.isVideo) { AsyncImage(item.uri, item.name, modifier, contentScale = scale); return }
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(null, item.uri) {
        value = withContext(Dispatchers.IO) { runCatching {
            if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(Uri.parse(item.uri), Size(720, 720), null)
            else android.provider.MediaStore.Video.Thumbnails.getThumbnail(context.contentResolver, item.id, android.provider.MediaStore.Video.Thumbnails.MINI_KIND, null)
        }.getOrNull() }
    }
    Box(modifier.background(Color.DarkGray), contentAlignment = Alignment.Center) {
        bitmap?.let { Image(it.asImageBitmap(), item.name, Modifier.fillMaxSize(), contentScale = scale) }
        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(42.dp))
    }
}

@Composable private fun StateActions(item: IrisGalleryMedia) {
    val context = LocalContext.current
    var keep by remember(item.uri) { mutableStateOf(IrisMediaState.isKeep(context, item.uri)) }
    var trash by remember(item.uri) { mutableStateOf(IrisMediaState.isTrash(context, item.uri)) }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        IconButton(onClick = { keep = IrisMediaState.toggleKeep(context, item.uri); if (keep) trash = false }) { Icon(Icons.Default.Lock, "Keep", tint = if (keep) MaterialTheme.colorScheme.primary else LocalContentColor.current) }
        IconButton(onClick = { trash = IrisMediaState.toggleTrash(context, item.uri) }, enabled = !keep) { Icon(Icons.Default.Delete, "Trash", tint = if (trash) MaterialTheme.colorScheme.error else LocalContentColor.current) }
    }
}

@Composable fun IrisSkinnedGallery(items: List<IrisGalleryMedia>, skin: IrisGallerySkin, onOpen: (IrisGalleryMedia) -> Unit, modifier: Modifier = Modifier) {
    when (skin) {
        IrisGallerySkin.GALLERY -> LazyVerticalGrid(GridCells.Fixed(3), modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(items.size, key={items[it].uri}) { i -> val x=items[i]; Box(Modifier.aspectRatio(1f).clickable{onOpen(x)}) { MediaSurface(x, Modifier.fillMaxSize()); if(IrisMediaState.isKeep(LocalContext.current,x.uri)) Text("🔒",Modifier.align(Alignment.TopEnd).padding(5.dp)) } }
        }
        IrisGallerySkin.VERTICAL -> LazyColumn(modifier.fillMaxSize().background(Color.Black)) { items(items,key={"v:${it.uri}"}) { x ->
            Box(Modifier.fillParentMaxHeight().fillMaxWidth().background(Color.Black)) { MediaSurface(x,Modifier.fillMaxSize().clickable{onOpen(x)},ContentScale.Fit); Column(Modifier.align(Alignment.CenterEnd).padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally){ StateActions(x) }; Column(Modifier.align(Alignment.BottomStart).padding(16.dp)){Text(x.bucket,color=Color.White,fontWeight=FontWeight.Bold);Text(x.name,color=Color.White,maxLines=1)} }
        } }
        IrisGallerySkin.SOCIAL -> LazyColumn(modifier.fillMaxSize()) { item { Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text("iris.gallery",fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("♡  ⊕")}}; items(items,key={"i:${it.uri}"}) { x -> Column(Modifier.fillMaxWidth().padding(bottom=16.dp)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Text(x.bucket,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("•••")};MediaSurface(x,Modifier.fillMaxWidth().aspectRatio(1f).clickable{onOpen(x)});Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){StateActions(x);Spacer(Modifier.weight(1f));Text("♡",Modifier.padding(14.dp))};Text(x.name,Modifier.padding(horizontal=12.dp),maxLines=1)} } }
        IrisGallerySkin.BOARD -> LazyVerticalGrid(GridCells.Fixed(2), modifier.fillMaxSize(), contentPadding=PaddingValues(6.dp), horizontalArrangement=Arrangement.spacedBy(8.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) { items(items.size,key={items[it].uri}){i->val x=items[i];Card{Column{MediaSurface(x,Modifier.fillMaxWidth().aspectRatio(if(i%3==0).72f else .9f).clickable{onOpen(x)});Row(verticalAlignment=Alignment.CenterVertically){Text(x.name,Modifier.weight(1f).padding(8.dp),maxLines=1,style=MaterialTheme.typography.labelSmall);StateActions(x)}}}} }
        IrisGallerySkin.WEBTOON -> LazyColumn(modifier.fillMaxSize().background(Color.Black)) { items(items,key={"w:${it.uri}"}){x->MediaSurface(x,Modifier.fillMaxWidth().height(if(x.isVideo)320.dp else 620.dp).clickable{onOpen(x)},ContentScale.FillWidth)} }
    }
}
