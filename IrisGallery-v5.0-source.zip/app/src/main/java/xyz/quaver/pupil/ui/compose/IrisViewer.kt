/* Iris Gallery common media viewer. GPLv3; see app/LICENSE. */
package xyz.quaver.pupil.ui.compose

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import xyz.quaver.pupil.source.SourceDetail
import xyz.quaver.pupil.util.IrisSourceActions

/** Source-neutral viewer surface. Ggoorr is the first adapter; Hitomi can migrate here next. */
@Composable
fun IrisViewer(
    detail: SourceDetail,
    headers: Map<String, String>,
    saved: Boolean,
    onBack: () -> Unit,
    onToggleSaved: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onOriginal: () -> Unit,
) {
    BackHandler(onBack = onBack)
    val media = detail.imageUrls
    val pagerState = rememberPagerState(pageCount = { media.size.coerceAtLeast(1) })

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().safeDrawingPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onBack) { Text("‹ Back") }
                Text(
                    detail.item.title,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium,
                )
                Text("Ggoorr", style = MaterialTheme.typography.labelMedium)
            }

            Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
                if (media.isEmpty()) {
                    Text("No supported media", color = Color.White, modifier = Modifier.align(Alignment.Center))
                } else {
                    HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                        val url = media[page]
                        if (IrisSourceActions.isVideoUrl(url)) {
                            IrisViewerVideo(url, headers)
                        } else {
                            RemoteImage(
                                url,
                                Modifier.fillMaxSize(),
                                detail.item.title,
                                contentScale = ContentScale.Fit,
                                headers = headers,
                            )
                        }
                    }
                    if (media.size > 1) {
                        Text(
                            "${pagerState.currentPage + 1} / ${media.size}",
                            color = Color.White,
                            modifier = Modifier.align(Alignment.TopEnd)
                                .padding(12.dp)
                                .background(Color.Black.copy(alpha = .55f))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                TextButton(onClick = onToggleSaved) { Text(if (saved) "♥ Saved" else "♡ Save") }
                TextButton(onClick = onDownload) { Text("↓ Download") }
                TextButton(onClick = onShare) { Text("Share") }
                TextButton(onClick = onOriginal) { Text("Original") }
            }
        }
    }
}

@Composable
private fun IrisViewerVideo(url: String, headers: Map<String, String>) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            VideoView(context).apply {
                val controls = MediaController(context)
                controls.setAnchorView(this)
                setMediaController(controls)
                tag = url
                setVideoURI(Uri.parse(url), headers)
                setOnPreparedListener { player ->
                    player.isLooping = false
                    seekTo(1)
                    controls.show(2500)
                }
            }
        },
        update = { view ->
            if (view.tag != url) {
                view.tag = url
                view.setVideoURI(Uri.parse(url), headers)
            }
        },
    )
}
