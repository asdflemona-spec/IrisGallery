package xyz.quaver.pupil.util

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

data class IrisGalleryMedia(
    val id: Long,
    val uri: String,
    val name: String,
    val bucket: String,
    val relativePath: String,
    val mimeType: String,
    val dateAdded: Long,
    val isVideo: Boolean,
    val isFavorite: Boolean = false,
) {
    private val path: String get() = "$relativePath/$bucket".lowercase()
    val isScreenshot: Boolean get() = path.contains("screenshot")
    val isIris: Boolean get() = path.contains("iris/") || path.contains("/iris") || path.endsWith("iris")
    val isDownload: Boolean get() = path.contains("download")
    val isCamera: Boolean get() = path.contains("dcim") || path.contains("camera")
    val isRecent: Boolean get() = dateAdded >= System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
}

object IrisGalleryIndex {
    fun scan(context: Context): List<IrisGalleryMedia> {
        val result = ArrayList<IrisGalleryMedia>()
        query(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, result)
        query(context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, result)
        return result.sortedByDescending { it.dateAdded }
    }

    private fun query(context: Context, collection: android.net.Uri, video: Boolean, out: MutableList<IrisGalleryMedia>) {
        val projection = buildList {
            add(MediaStore.MediaColumns._ID)
            add(MediaStore.MediaColumns.DISPLAY_NAME)
            add(MediaStore.MediaColumns.MIME_TYPE)
            add(MediaStore.MediaColumns.DATE_ADDED)
            add(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= 29) add(MediaStore.MediaColumns.RELATIVE_PATH)
            if (Build.VERSION.SDK_INT >= 30) add(MediaStore.MediaColumns.IS_FAVORITE)
        }.toTypedArray()
        context.contentResolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
            val mimeCol = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            val dateCol = c.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED)
            val bucketCol = c.getColumnIndex(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            val pathCol = if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH) else -1
            val favoriteCol = if (Build.VERSION.SDK_INT >= 30) c.getColumnIndex(MediaStore.MediaColumns.IS_FAVORITE) else -1
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                out += IrisGalleryMedia(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id).toString(),
                    name = if (nameCol >= 0) c.getString(nameCol) ?: "Media" else "Media",
                    bucket = if (bucketCol >= 0) c.getString(bucketCol) ?: "Gallery" else "Gallery",
                    relativePath = if (pathCol >= 0) c.getString(pathCol) ?: "" else "",
                    mimeType = if (mimeCol >= 0) c.getString(mimeCol) ?: if (video) "video/*" else "image/*" else if (video) "video/*" else "image/*",
                    dateAdded = if (dateCol >= 0) c.getLong(dateCol) * 1000L else 0L,
                    isVideo = video,
                    isFavorite = favoriteCol >= 0 && c.getInt(favoriteCol) == 1,
                )
            }
        }
    }
}
