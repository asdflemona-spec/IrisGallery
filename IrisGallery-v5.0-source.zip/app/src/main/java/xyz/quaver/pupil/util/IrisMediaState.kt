package xyz.quaver.pupil.util

import android.content.Context

object IrisMediaState {
    private const val PREFS = "iris_media_state"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun isKeep(context: Context, uri: String) = prefs(context).getBoolean("keep:$uri", false)
    fun isTrash(context: Context, uri: String) = prefs(context).getBoolean("trash:$uri", false)
    fun toggleKeep(context: Context, uri: String): Boolean {
        val next = !isKeep(context, uri)
        prefs(context).edit().putBoolean("keep:$uri", next).putBoolean("trash:$uri", false).apply()
        return next
    }
    fun toggleTrash(context: Context, uri: String): Boolean {
        if (isKeep(context, uri)) return false
        val next = !isTrash(context, uri)
        prefs(context).edit().putBoolean("trash:$uri", next).apply()
        return next
    }
}
