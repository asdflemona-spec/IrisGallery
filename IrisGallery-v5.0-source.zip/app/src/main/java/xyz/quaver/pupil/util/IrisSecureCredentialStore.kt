package xyz.quaver.pupil.util

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Source-scoped encrypted storage for future OAuth/session secrets. Never store passwords here. */
class IrisSecureCredentialStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("iris_secure_credentials_v1", Context.MODE_PRIVATE)
    private val alias = "iris.auth.credentials.v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build())
            generateKey()
        }
    }

    fun put(sourceId: String, name: String, value: String) {
        require(sourceId.matches(Regex("[a-zA-Z0-9._-]+")))
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val data = Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        prefs.edit().putString("$sourceId:$name", "$iv:$data").apply()
    }

    fun get(sourceId: String, name: String): String? = runCatching {
        val raw = prefs.getString("$sourceId:$name", null) ?: return null
        val (iv, data) = raw.split(':', limit = 2)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
        String(cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)), Charsets.UTF_8)
    }.getOrNull()

    fun clearSource(sourceId: String) {
        val edit = prefs.edit()
        prefs.all.keys.filter { it.startsWith("$sourceId:") }.forEach(edit::remove)
        edit.apply()
    }

    fun clearAll() = prefs.edit().clear().apply()
    fun connectedSources(): Set<String> = prefs.all.keys.mapNotNull { it.substringBefore(':').takeIf(String::isNotBlank) }.toSet()
}
