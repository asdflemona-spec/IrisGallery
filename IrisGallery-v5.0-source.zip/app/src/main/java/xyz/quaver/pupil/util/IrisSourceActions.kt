package xyz.quaver.pupil.util

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsBytes
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import xyz.quaver.pupil.client
import xyz.quaver.pupil.source.SourceDetail

@Serializable
data class IrisLibraryEntry(
    val sourceId: String,
    val remoteId: String,
    val title: String,
    val pageUrl: String? = null,
    val thumbnailUrl: String? = null,
    val saved: Boolean = false,
    val lastViewedAt: Long = 0,
    val downloadedAt: Long = 0,
)

object IrisSourceActions {
    private const val PREFS = "iris_library_v2"
    private const val ENTRIES = "entries"
    private val json = Json { ignoreUnknownKeys = true }

    private fun key(d: SourceDetail) = "${d.item.sourceId}:${d.item.remoteId}"
    private fun read(context: Context): MutableMap<String, IrisLibraryEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ENTRIES, null) ?: return mutableMapOf()
        return runCatching { json.decodeFromString<Map<String, IrisLibraryEntry>>(raw).toMutableMap() }.getOrDefault(mutableMapOf())
    }
    private fun write(context: Context, map: Map<String, IrisLibraryEntry>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ENTRIES, json.encodeToString(map)).apply()
    }
    private fun base(d: SourceDetail, old: IrisLibraryEntry? = null) = IrisLibraryEntry(
        d.item.sourceId, d.item.remoteId, d.item.title, d.item.pageUrl, d.item.thumbnailUrl,
        old?.saved ?: false, old?.lastViewedAt ?: 0, old?.downloadedAt ?: 0,
    )

    fun entries(context: Context): List<IrisLibraryEntry> = read(context).values.sortedByDescending { maxOf(it.lastViewedAt, it.downloadedAt) }

    suspend fun download(context: Context, detail: SourceDetail, headers: Map<String, String>) {
        var savedCount = 0
        detail.imageUrls.forEachIndexed { index, url ->
            runCatching {
                if (Build.VERSION.SDK_INT >= 29) {
                    val response = client.get(url) { headers.forEach { (k, v) -> header(k, v) } }
                    val bytes = response.bodyAsBytes()
                    val mime = response.headers["Content-Type"]?.substringBefore(';')?.trim()?.takeIf { it.startsWith("image/") || it.startsWith("video/") } ?: guessMime(url)
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: extension(url)
                    val safeId = detail.item.remoteId.replace(Regex("[^A-Za-z0-9_-]"), "_")
                    val isVideo = mime.startsWith("video/") || isVideoUrl(url)
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, "${safeId}_${index + 1}.$ext")
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, if (isVideo) "${Environment.DIRECTORY_MOVIES}/Iris/${detail.item.sourceId}" else "${Environment.DIRECTORY_PICTURES}/Iris/${detail.item.sourceId}")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    val uri = context.contentResolver.insert(collection, values) ?: error("MediaStore insert failed")
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("MediaStore output failed")
                        values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        context.contentResolver.update(uri, values, null, null)
                        savedCount++
                    } catch (t: Throwable) { context.contentResolver.delete(uri, null, null); throw t }
                } else {
                    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    val ext = extension(url)
                    val safeId = detail.item.remoteId.replace(Regex("[^A-Za-z0-9_-]"), "_")
                    val req = DownloadManager.Request(Uri.parse(url))
                        .setTitle("Iris · ${detail.item.title}")
                        .setMimeType(guessMime(url))
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, "Iris/${detail.item.sourceId}/${safeId}_${index + 1}.$ext")
                    headers.forEach { (k, v) -> req.addRequestHeader(k, v) }
                    dm.enqueue(req); savedCount++
                }
            }
        }
        if (savedCount > 0) {
            val map = read(context); val old = map[key(detail)]
            map[key(detail)] = base(detail, old).copy(downloadedAt = System.currentTimeMillis())
            write(context, map)
        }
        Toast.makeText(context, if (savedCount > 0) "$savedCount media files saved to Iris" else "No supported media saved", Toast.LENGTH_LONG).show()
    }

    fun isVideoUrl(url: String): Boolean = extension(url) in setOf("mp4", "webm", "m4v", "mov")
    private fun extension(url: String): String = url.substringBefore('?').substringAfterLast('.', "jpg").lowercase().takeIf { it.length in 2..5 } ?: "jpg"
    private fun guessMime(url: String): String = when (extension(url)) { "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"; "avif" -> "image/avif"; "mp4", "m4v" -> "video/mp4"; "webm" -> "video/webm"; "mov" -> "video/quicktime"; else -> "image/jpeg" }

    fun toggleSaved(context: Context, detail: SourceDetail): Boolean {
        val map = read(context); val old = map[key(detail)]; val next = !(old?.saved ?: false)
        val entry = base(detail, old).copy(saved = next)
        if (!next && entry.lastViewedAt == 0L && entry.downloadedAt == 0L) map.remove(key(detail)) else map[key(detail)] = entry
        write(context, map); return next
    }
    fun isSaved(context: Context, detail: SourceDetail): Boolean = read(context)[key(detail)]?.saved == true
    fun recordHistory(context: Context, detail: SourceDetail) {
        val map = read(context); val old = map[key(detail)]
        map[key(detail)] = base(detail, old).copy(lastViewedAt = System.currentTimeMillis()); write(context, map)
    }
    fun openOriginal(context: Context, url: String?) { if (url != null) context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    fun share(context: Context, detail: SourceDetail) {
        val text = detail.item.pageUrl ?: detail.imageUrls.firstOrNull() ?: return
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Share from Iris"))
    }
}
