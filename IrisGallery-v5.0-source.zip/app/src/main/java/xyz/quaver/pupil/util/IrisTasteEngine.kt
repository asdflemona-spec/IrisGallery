package xyz.quaver.pupil.util

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import kotlin.math.min
import kotlin.math.sqrt

/** Local-only visual taste discovery. No labels, uploads, accounts, or network calls. */
data class IrisTasteCluster(
    val id: Int,
    val media: List<IrisGalleryMedia>,
    val affinity: Float,
)

object IrisTasteEngine {
    private const val MAX_ANALYSIS = 240
    private const val FEATURE_SIZE = 8

    fun discover(context: Context, media: List<IrisGalleryMedia>): List<IrisTasteCluster> {
        val candidates = media.asSequence()
            .filter { !it.isScreenshot }
            .sortedWith(compareByDescending<IrisGalleryMedia> { it.isFavorite }.thenByDescending { it.isIris }.thenByDescending { it.dateAdded })
            .take(MAX_ANALYSIS)
            .mapNotNull { item -> feature(context, item)?.let { item to it } }
            .toList()
        if (candidates.size < 8) return emptyList()

        val k = min(6, maxOf(2, sqrt(candidates.size / 8.0).toInt()))
        var centers = (0 until k).map { i -> candidates[(i * candidates.size / k).coerceAtMost(candidates.lastIndex)].second.copyOf() }
        var assignment = IntArray(candidates.size)
        repeat(7) {
            candidates.forEachIndexed { index, pair -> assignment[index] = centers.indices.minBy { distance(pair.second, centers[it]) } }
            centers = centers.indices.map { cluster ->
                val vectors = candidates.indices.filter { assignment[it] == cluster }.map { candidates[it].second }
                if (vectors.isEmpty()) centers[cluster] else average(vectors)
            }
        }

        return centers.indices.mapNotNull { cluster ->
            val members = candidates.indices.filter { assignment[it] == cluster }.map { candidates[it].first }
            if (members.size < 3) null else {
                // Explicit positive signals rank discovered visual groups; they do not define the groups.
                val positives = members.sumOf { item ->
                    (if (item.isFavorite) 4 else 0) +
                        (if (item.isIris) 3 else 0) +
                        (if (item.isRecent) 1 else 0) +
                        IrisTasteProfile.signal(context, item.uri)
                }
                IrisTasteCluster(cluster, members.sortedByDescending { IrisTasteProfile.signal(context, it.uri) }, positives.toFloat() / members.size)
            }
        }.sortedWith(compareByDescending<IrisTasteCluster> { it.affinity }.thenByDescending { it.media.size })
    }

    private fun feature(context: Context, item: IrisGalleryMedia): FloatArray? = runCatching {
        val bitmap = thumbnail(context, item) ?: return null
        val scaled = Bitmap.createScaledBitmap(bitmap, FEATURE_SIZE, FEATURE_SIZE, true)
        val out = FloatArray(FEATURE_SIZE * FEATURE_SIZE + 3)
        var rSum = 0f; var gSum = 0f; var bSum = 0f
        var p = 0
        for (y in 0 until FEATURE_SIZE) for (x in 0 until FEATURE_SIZE) {
            val c = scaled.getPixel(x, y)
            val r = ((c shr 16) and 255) / 255f; val g = ((c shr 8) and 255) / 255f; val b = (c and 255) / 255f
            rSum += r; gSum += g; bSum += b
            out[p++] = (0.299f * r + 0.587f * g + 0.114f * b)
        }
        out[p++] = rSum / 64f; out[p++] = gSum / 64f; out[p] = bSum / 64f
        if (scaled !== bitmap) scaled.recycle()
        bitmap.recycle()
        out
    }.getOrNull()

    private fun thumbnail(context: Context, item: IrisGalleryMedia): Bitmap? {
        return if (Build.VERSION.SDK_INT >= 29) {
            context.contentResolver.loadThumbnail(android.net.Uri.parse(item.uri), Size(96, 96), null)
        } else if (item.isVideo) {
            MediaStore.Video.Thumbnails.getThumbnail(context.contentResolver, item.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
        } else {
            MediaStore.Images.Thumbnails.getThumbnail(context.contentResolver, item.id, MediaStore.Images.Thumbnails.MINI_KIND, null)
        }
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) { val d = a[i] - b[i]; sum += d * d }
        return sum
    }
    private fun average(vectors: List<FloatArray>): FloatArray {
        val out = FloatArray(vectors.first().size)
        vectors.forEach { v -> for (i in out.indices) out[i] += v[i] }
        for (i in out.indices) out[i] /= vectors.size
        return out
    }
}
