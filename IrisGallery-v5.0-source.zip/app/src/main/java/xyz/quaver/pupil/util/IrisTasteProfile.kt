package xyz.quaver.pupil.util

import android.content.Context

/** Local-only preference memory shared by Gallery, Taste and Play. */
object IrisTasteProfile {
    private const val PREFS = "iris_taste_profile_v2"
    private const val LIMIT = 24

    fun reinforce(context: Context, uri: String, delta: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val next = (prefs.getInt(uri, 0) + delta).coerceIn(-LIMIT, LIMIT)
        prefs.edit().putInt(uri, next).apply()
    }

    fun vote(context: Context, uri: String, positive: Boolean) = reinforce(context, uri, if (positive) 2 else -2)

    fun versus(context: Context, winnerUri: String, loserUri: String) {
        reinforce(context, winnerUri, 3)
        reinforce(context, loserUri, -1)
    }

    fun signal(context: Context, uri: String): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(uri, 0)

    fun totalSignals(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all.values.count { (it as? Int ?: 0) != 0 }
}
