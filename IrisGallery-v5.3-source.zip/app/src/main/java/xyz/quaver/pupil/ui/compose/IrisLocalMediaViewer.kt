package xyz.quaver.pupil.ui.compose

import android.net.Uri
import android.os.Build
import android.util.Size
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisMediaState

/** Presentation lenses. Brand assets are Iris-owned; interaction/content grammar follows proven media patterns. */
enum class IrisGallerySkin(val label: String) { GALLERY("Photos"), VERTICAL("TikTok"), SOCIAL("Instagram"), BOARD("Pinterest"), WEBTOON("Webtoon") }

private data class PresentationCopy(val author:String,val caption:String,val commenter1:String,val comment1:String,val commenter2:String,val comment2:String,val dialogue:String,val narration:String)
private data class IrisPersona(val name:String,val reactions:List<String>)
private val irisPersonas=listOf(
    IrisPersona("mori",listOf("색감 좋다","이 장면은 오래 보게 된다","두 번째 느낌도 궁금함","이건 저장")),
    IrisPersona("yun",listOf("여기 어디지?","뭔가 기억날 듯 말 듯ㅋㅋ","분위기 뭐야","이 다음 장면도 있어?")),
    IrisPersona("hae",listOf("빛이 되게 조용하다","이런 순간이 나중에 더 기억나더라","구도가 묘하게 좋네","말 없이 봐도 좋다")),
    IrisPersona("noa",listOf("오 이건 좋음","첫눈에 들어온다","Keep 각","한참 보게 되네")),
    IrisPersona("sori",listOf("사진 사이에 이야기가 있는 느낌","왜인지 다음 컷이 궁금해","이건 밤에 다시 보고 싶다","조용해서 더 좋네"))
)
private fun copyFor(x:IrisGalleryMedia):PresentationCopy {
    val stem=x.name.substringBeforeLast('.').replace('_',' ').replace('-',' ').take(32).ifBlank{"untitled"}
    val author=x.bucket.ifBlank{"iris.gallery"}.lowercase().replace(" ",".").take(22)
    val seed=((x.id xor x.dateAdded) and Long.MAX_VALUE).toInt()
    val captions=listOf("오늘 저장해 두고 싶은 장면.","다시 보다가 여기서 멈췄다.","별일 없었는데 이상하게 기억나는 순간.","말보다 이미지가 먼저 남는 날.","한동안 잊고 있던 장면을 다시 발견했다.","이건 설명하지 않고 그냥 남겨두고 싶다.")
    val p1=irisPersonas[Math.floorMod(seed,irisPersonas.size)]
    val p2=irisPersonas[Math.floorMod(seed/7+2,irisPersonas.size)]
    val c1=p1.reactions[Math.floorMod(seed/3,p1.reactions.size)]
    val c2=p2.reactions[Math.floorMod(seed/11+1,p2.reactions.size)]
    val dialogue=listOf("…잠깐, 저거 봐.","이 장면, 전에 본 적 있지?","아무 말도 하지 마. 조금만 더 보자.","그때는 그냥 지나쳤는데.","응. 이건 기억해 둘래.","다음에는 어디로 가는 거야?")
    val narr=listOf("그날은 별일 없는 하루라고 생각했다.","기억은 순서보다 분위기를 먼저 데려왔다.","사진 사이의 빈칸에서 다음 장면이 시작됐다.","다시 발견한 순간은 처음과 조금 다르게 보였다.","한동안 잊고 있었지만 장면은 그대로 남아 있었다.","아무 일도 일어나지 않은 것처럼, 다음 순간이 이어졌다.")
    return PresentationCopy(author,"$stem · ${captions[Math.floorMod(seed,captions.size)]}",p1.name,c1,p2.name,c2,dialogue[Math.floorMod(seed/5,dialogue.size)],narr[Math.floorMod(seed/13,narr.size)])
}

@Composable fun IrisLocalMediaViewer(item:IrisGalleryMedia,onClose:()->Unit){
    // Full-screen dialog keeps the player outside the weighted presentation layout.
    // Presentation lenses may recompose freely without owning the playback surface.
    Dialog(
        onDismissRequest=onClose,
        properties=DialogProperties(usePlatformDefaultWidth=false, decorFitsSystemWindows=false)
    ){
        BackHandler(onBack=onClose)
        Box(Modifier.fillMaxSize().background(Color.Black)){
            if(item.isVideo) IrisVideoPlayer(item.uri)
            else AsyncImage(item.uri,item.name,Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
            TextButton(onClick=onClose,modifier=Modifier.align(Alignment.TopStart).padding(8.dp)){
                Text("✕",color=Color.White,fontSize=22.sp)
            }
        }
    }
}

@Composable private fun IrisVideoPlayer(uri:String){
    val context=LocalContext.current
    val player=remember(uri){ExoPlayer.Builder(context).build().apply{setMediaItem(MediaItem.fromUri(Uri.parse(uri)));repeatMode=ExoPlayer.REPEAT_MODE_ONE;prepare();playWhenReady=true}}
    DisposableEffect(player){onDispose{player.release()}}
    AndroidView(factory={PlayerView(it).apply{this.player=player;useController=true;layoutParams=FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)}},update={it.player=player},modifier=Modifier.fillMaxSize())
}

@Composable private fun MediaSurface(item:IrisGalleryMedia,modifier:Modifier=Modifier,scale:ContentScale=ContentScale.Crop){
    if(!item.isVideo){AsyncImage(item.uri,item.name,modifier,contentScale=scale);return}
    val context=LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(null,item.uri){value=withContext(Dispatchers.IO){runCatching{if(Build.VERSION.SDK_INT>=29)context.contentResolver.loadThumbnail(Uri.parse(item.uri),Size(720,720),null) else android.provider.MediaStore.Video.Thumbnails.getThumbnail(context.contentResolver,item.id,android.provider.MediaStore.Video.Thumbnails.MINI_KIND,null)}.getOrNull()}}
    Box(modifier.background(Color.DarkGray),contentAlignment=Alignment.Center){bitmap?.let{Image(it.asImageBitmap(),item.name,Modifier.fillMaxSize(),contentScale=scale)};Icon(Icons.Default.PlayArrow,null,tint=Color.White,modifier=Modifier.size(42.dp))}
}

@Composable private fun StateActions(item:IrisGalleryMedia,dark:Boolean=false){
    val context=LocalContext.current;var keep by remember(item.uri){mutableStateOf(IrisMediaState.isKeep(context,item.uri))};var trash by remember(item.uri){mutableStateOf(IrisMediaState.isTrash(context,item.uri))};val normal=if(dark)Color.White else LocalContentColor.current
    Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){IconButton(onClick={keep=IrisMediaState.toggleKeep(context,item.uri);if(keep)trash=false}){Icon(Icons.Default.Lock,"Keep",tint=if(keep)Color(0xFFFFD54F) else normal)};IconButton(onClick={trash=IrisMediaState.toggleTrash(context,item.uri)},enabled=!keep){Icon(Icons.Default.Delete,"Trash",tint=if(trash)Color(0xFFFF5252) else normal)}}
}

@Composable private fun Avatar(item:IrisGalleryMedia,size:Int=34){Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFFECECEC))){MediaSurface(item,Modifier.fillMaxSize())}}

@Composable private fun InstagramPost(x:IrisGalleryMedia,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x)
    Column(Modifier.fillMaxWidth().padding(bottom=18.dp)){
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){Avatar(x);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(c.author,fontWeight=FontWeight.SemiBold,fontSize=13.sp);Text(x.bucket,fontSize=11.sp)};Text("•••",fontWeight=FontWeight.Bold)}
        MediaSurface(x,Modifier.fillMaxWidth().aspectRatio(1f).clickable{onOpen(x)})
        Row(Modifier.fillMaxWidth().height(48.dp),verticalAlignment=Alignment.CenterVertically){Text("♡",fontSize=28.sp,modifier=Modifier.padding(start=12.dp,end=14.dp));Text("○",fontSize=27.sp);Text("⌁",fontSize=28.sp,modifier=Modifier.padding(start=14.dp));Spacer(Modifier.weight(1f));StateActions(x)}
        Text("좋아요 ${(x.id%800)+24}개",fontWeight=FontWeight.SemiBold,fontSize=13.sp,modifier=Modifier.padding(horizontal=12.dp))
        Row(Modifier.padding(horizontal=12.dp,vertical=4.dp)){Text(c.author,fontWeight=FontWeight.Bold,fontSize=13.sp);Spacer(Modifier.width(5.dp));Text(c.caption,fontSize=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis)}
        Text("댓글 ${(x.id%31)+2}개 모두 보기",color=Color.Gray,fontSize=13.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=2.dp))
        Row(Modifier.padding(horizontal=12.dp)){Text(c.commenter1,fontWeight=FontWeight.Bold,fontSize=13.sp);Spacer(Modifier.width(5.dp));Text(c.comment1,fontSize=13.sp)}
        Text("1시간 전",color=Color.Gray,fontSize=10.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=6.dp))
    }
}

@Composable private fun TikTokItem(x:IrisGalleryMedia,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x)
    Box(Modifier.fillMaxSize().background(Color.Black)){
        MediaSurface(x,Modifier.fillMaxSize().clickable{onOpen(x)},ContentScale.Crop)
        Row(Modifier.align(Alignment.TopCenter).padding(top=16.dp),verticalAlignment=Alignment.CenterVertically){Text("Following",color=Color.White.copy(.75f),fontWeight=FontWeight.SemiBold);Spacer(Modifier.width(20.dp));Column(horizontalAlignment=Alignment.CenterHorizontally){Text("For You",color=Color.White,fontWeight=FontWeight.Bold);Box(Modifier.padding(top=4.dp).width(24.dp).height(2.dp).background(Color.White))}}
        Column(Modifier.align(Alignment.CenterEnd).padding(end=9.dp,bottom=80.dp),horizontalAlignment=Alignment.CenterHorizontally){Avatar(x,46);Spacer(Modifier.height(18.dp));Text("♥",color=Color.White,fontSize=30.sp);Text("${(x.id%900)+99}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(14.dp));Text("●",color=Color.White,fontSize=27.sp);Text("${(x.id%90)+4}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(8.dp));StateActions(x,true)}
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(.78f).padding(14.dp)){Text("@${c.author}",color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp);Spacer(Modifier.height(6.dp));Text(c.caption,color=Color.White,fontSize=13.sp,maxLines=2);Spacer(Modifier.height(8.dp));Text("♫ original sound · ${c.author}",color=Color.White,fontSize=12.sp)}
    }
}

@Composable private fun WebtoonPanel(x:IrisGalleryMedia,index:Int,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x);val light=index%2==0
    Column(Modifier.fillMaxWidth().background(if(light)Color.White else Color(0xFFF5F5F5))){
        if(index%3==0)Text(c.narration,Modifier.fillMaxWidth().padding(horizontal=28.dp,vertical=26.dp),fontSize=14.sp,lineHeight=22.sp)
        Box(Modifier.fillMaxWidth()){
            MediaSurface(x,Modifier.fillMaxWidth().height(if(x.isVideo)360.dp else 590.dp).clickable{onOpen(x)},ContentScale.Crop)
            Surface(modifier=Modifier.align(if(index%2==0)Alignment.TopStart else Alignment.TopEnd).padding(18.dp).widthIn(max=230.dp),shape=RoundedCornerShape(18.dp),color=Color.White.copy(.94f),shadowElevation=3.dp){Text(c.dialogue,Modifier.padding(horizontal=16.dp,vertical=11.dp),fontSize=14.sp,lineHeight=20.sp,color=Color.Black)}
        }
        if(index%4==2)Text("…",Modifier.fillMaxWidth().padding(30.dp),fontSize=30.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(if(index%3==1)34.dp else 8.dp))
    }
}

@Composable fun IrisSkinnedGallery(
    items: List<IrisGalleryMedia>,
    skin: IrisGallerySkin,
    onOpen: (IrisGalleryMedia) -> Unit,
    modifier: Modifier = Modifier
) {
    when (skin) {
        IrisGallerySkin.GALLERY -> LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(items.size, key = { items[it].uri }) { i ->
                val x = items[i]
                Box(Modifier.aspectRatio(1f).clickable { onOpen(x) }) {
                    MediaSurface(x, Modifier.fillMaxSize())
                    if (IrisMediaState.isKeep(LocalContext.current, x.uri)) {
                        Text("🔒", Modifier.align(Alignment.TopEnd).padding(5.dp))
                    }
                }
            }
        }

        IrisGallerySkin.VERTICAL -> LazyColumn(modifier.fillMaxSize().background(Color.Black)) {
            items(items, key = { "v:${it.uri}" }) { x ->
                Box(Modifier.fillParentMaxSize()) { TikTokItem(x, onOpen) }
            }
        }

        IrisGallerySkin.SOCIAL -> LazyColumn(modifier.fillMaxSize().background(Color.White)) {
            item {
                Column {
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Iris", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                        Spacer(Modifier.weight(1f))
                        Text("♡   ⊕", fontSize = 23.sp)
                    }
                    Row(
                        Modifier.fillMaxWidth().height(92.dp).padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items.take(6).forEach { story ->
                            Column(
                                modifier = Modifier.width(58.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    Modifier.padding(4.dp).size(54.dp).clip(CircleShape)
                                        .background(Color(0xFFFFE0E8))
                                ) { MediaSurface(story, Modifier.fillMaxSize()) }
                                Text(copyFor(story).author.take(8), fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
            items(items, key = { "i:${it.uri}" }) { InstagramPost(it, onOpen) }
        }

        IrisGallerySkin.BOARD -> LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items.size, key = { items[it].uri }) { i ->
                val x = items[i]
                Column {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        MediaSurface(
                            x,
                            Modifier.fillMaxWidth()
                                .aspectRatio(if (i % 4 == 0) .68f else if (i % 3 == 0) .78f else .9f)
                                .clickable { onOpen(x) }
                        )
                    }
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(copyFor(x).caption, Modifier.weight(1f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("•••", Modifier.padding(6.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(x, 22); Spacer(Modifier.width(5.dp))
                        Text(copyFor(x).author, fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }
        }

        IrisGallerySkin.WEBTOON -> LazyColumn(modifier.fillMaxSize().background(Color.White)) {
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("IRIS ORIGINAL", fontSize = 11.sp, color = Color.Gray)
                    Text("기억의 조각들", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("EP. 01  다시 발견한 장면", fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                    Text("내 갤러리의 사진으로 구성된 개인 에피소드", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
                }
            }
            items(items.size, key = { "w:${items[it].uri}" }) { i -> WebtoonPanel(items[i], i, onOpen) }
            item {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("EP. 01 END", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("♡ 좋아요   ·   댓글   ·   다음 에피소드", fontSize = 14.sp)
                    Spacer(Modifier.height(36.dp))
                }
            }
        }
    }
}
