package xyz.quaver.pupil.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.util.Size
import java.util.concurrent.TimeUnit

/** Conservative, local-only cleanup suggestions. It never deletes files itself. */
data class IrisCleanupGroup(val keep: IrisGalleryMedia, val remove: List<IrisGalleryMedia>, val reason: String)
data class IrisCleanupPlan(val groups: List<IrisCleanupGroup>, val staleScreenshots: List<IrisGalleryMedia>) {
    val candidates: List<IrisGalleryMedia> get() = (groups.flatMap { it.remove } + staleScreenshots).distinctBy { it.uri }
}

object IrisCleanupEngine {
    private const val MAX_SCAN = 500
    private const val NEAR_TIME_MS = 8L * 60 * 1000
    private const val OLD_SCREENSHOT_MS = 45L * 24 * 60 * 60 * 1000

    fun analyze(context: Context, all: List<IrisGalleryMedia>): IrisCleanupPlan {
        val media = all.filterNot { IrisMediaState.isKeep(context, it.uri) }
        val images = media.filterNot { it.isVideo }.take(MAX_SCAN)
        val hashes = images.associateWith { hash(context, it) }
        val used = mutableSetOf<String>()
        val groups = mutableListOf<IrisCleanupGroup>()
        for (a in images) {
            if (a.uri in used) continue
            val ah = hashes[a] ?: continue
            val similar = images.asSequence().filter { b ->
                b.uri != a.uri && b.uri !in used && kotlin.math.abs(a.dateAdded - b.dateAdded) <= NEAR_TIME_MS
            }.mapNotNull { b -> hashes[b]?.let { b to distance(ah, it) } }
                .filter { it.second <= 6 }.map { it.first }.take(8).toList()
            if (similar.isEmpty()) continue
            val stack = (listOf(a) + similar)
            val keep = stack.maxWithOrNull(compareBy<IrisGalleryMedia> { if (it.isFavorite) 1 else 0 }.thenBy { it.dateAdded }) ?: a
            val remove = stack.filter { it.uri != keep.uri && !it.isFavorite }
            if (remove.isNotEmpty()) {
                groups += IrisCleanupGroup(keep, remove, "Near-duplicate burst")
                used += stack.map { it.uri }
            }
        }
        val cutoff = System.currentTimeMillis() - OLD_SCREENSHOT_MS
        val stale = media.filter { it.isScreenshot && !it.isFavorite && it.dateAdded in 1 until cutoff && it.uri !in used }
        return IrisCleanupPlan(groups, stale)
    }

    private fun hash(context: Context, item: IrisGalleryMedia): Long? = runCatching {
        val bmp: Bitmap = if (Build.VERSION.SDK_INT >= 29) {
            context.contentResolver.loadThumbnail(Uri.parse(item.uri), Size(32, 32), null)
        } else return null
        val scaled = Bitmap.createScaledBitmap(bmp, 8, 8, true)
        val lum = IntArray(64)
        var sum = 0L
        for (i in 0 until 64) {
            val p = scaled.getPixel(i % 8, i / 8)
            val y = ((p shr 16 and 255) * 30 + (p shr 8 and 255) * 59 + (p and 255) * 11) / 100
            lum[i] = y; sum += y
        }
        val avg = sum / 64
        var out = 0L
        for (i in 0 until 64) if (lum[i] >= avg) out = out or (1L shl i)
        out
    }.getOrNull()

    private fun distance(a: Long, b: Long) = java.lang.Long.bitCount(a xor b)
}
