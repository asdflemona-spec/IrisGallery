# Iris v5.3 — Local AI Curator

- Adds AI Curator to Gallery.
- Local classification: KEEP / NORMAL / REVIEW / TRASH.
- Uses explicit Keep, MediaStore favorite, Iris Taste signals, source/path facts, recency and conservative duplicate-filename evidence.
- Keep is a hard safety boundary.
- Auto queue only queues high-confidence Trash candidates (>=82%); it does not permanently delete originals.
- Every decision exposes short reasons and confidence.
- Manual Queue/Undo feeds the existing state model.
- v5.2 video player path is unchanged.

This is the safe first automation layer. A later stage can add perceptual duplicate/quality models and Android system-confirmed batch deletion after the queue has been validated on-device.
