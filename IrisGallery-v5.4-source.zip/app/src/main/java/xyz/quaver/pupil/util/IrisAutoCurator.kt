package xyz.quaver.pupil.util

import android.content.Context
import kotlin.math.abs

enum class IrisCuratorClass { KEEP, NORMAL, REVIEW, TRASH }

data class IrisCuratorDecision(
    val media: IrisGalleryMedia,
    val classification: IrisCuratorClass,
    val confidence: Int,
    val score: Int,
    val reasons: List<String>,
)

data class IrisCuratorReport(
    val decisions: List<IrisCuratorDecision>,
    val queued: Int,
    val protected: Int,
)

/**
 * Iris' first local auto-curator. No network/API and no destructive file deletion.
 * It combines explicit user state, MediaStore facts and near-duplicate metadata signals.
 * High-confidence trash is queued for review; Keep is a hard safety boundary.
 */
object IrisAutoCurator {
    fun analyze(context: Context, media: List<IrisGalleryMedia>): List<IrisCuratorDecision> {
        val nameGroups = media.groupBy { normalizedStem(it.name) }
        return media.map { item ->
            val reasons = mutableListOf<String>()
            if (IrisMediaState.isKeep(context, item.uri) || IrisMediaState.isPinned(context, item.uri)) {
                return@map IrisCuratorDecision(item, IrisCuratorClass.KEEP, 100, 100, listOf("Protected by Keep"))
            }
            var value = IrisLearning.preservationSignal(context, item.uri)
            if (item.isFavorite) { value += 55; reasons += "MediaStore favorite" }
            val taste = IrisTasteProfile.signal(context, item.uri)
            if (taste > 0) { value += (taste * 7).coerceAtMost(35); reasons += "Positive Iris history" }
            if (taste < 0) { value += (taste * 8).coerceAtLeast(-40); reasons += "Negative Iris history" }
            if (item.isCamera) { value += 8; reasons += "Camera original" }
            if (item.isScreenshot) { value -= 18; reasons += "Screenshot" }
            if (item.isDownload && !item.isIris) { value -= 7; reasons += "Downloaded media" }
            if (item.isRecent) { value += 8; reasons += "Recent media" }
            if (item.isVideo) { value += 5; reasons += "Video preserved conservatively" }

            val siblings = nameGroups[normalizedStem(item.name)].orEmpty()
            if (siblings.size > 1) {
                val newest = siblings.maxByOrNull { it.dateAdded }
                if (newest?.uri != item.uri) { value -= 32; reasons += "Likely duplicate filename" }
                else { value += 10; reasons += "Newest duplicate candidate" }
            }

            val cls = when {
                value >= 45 -> IrisCuratorClass.KEEP
                value <= -35 -> IrisCuratorClass.TRASH
                value <= -12 -> IrisCuratorClass.REVIEW
                else -> IrisCuratorClass.NORMAL
            }
            val confidence = when (cls) {
                IrisCuratorClass.KEEP -> (60 + abs(value - 45)).coerceAtMost(98)
                IrisCuratorClass.TRASH -> (70 + abs(value + 35)).coerceAtMost(98)
                IrisCuratorClass.REVIEW -> 68
                IrisCuratorClass.NORMAL -> 58
            }
            IrisCuratorDecision(item, cls, confidence, value, reasons.ifEmpty { listOf("Not enough evidence") })
        }
    }

    fun autoQueue(context: Context, media: List<IrisGalleryMedia>, minConfidence: Int = 82): IrisCuratorReport {
        val decisions = analyze(context, media)
        var queued = 0
        decisions.filter { it.classification == IrisCuratorClass.TRASH && it.confidence >= minConfidence }
            .forEach { d -> if (!IrisMediaState.isKeep(context, d.media.uri) && !IrisMediaState.isPinned(context, d.media.uri) && !IrisMediaState.isTrash(context, d.media.uri)) { IrisMediaState.setTrash(context, d.media.uri, true); queued++ } }
        return IrisCuratorReport(decisions, queued, decisions.count { it.classification == IrisCuratorClass.KEEP })
    }

    private fun normalizedStem(name: String): String = name.substringBeforeLast('.').lowercase()
        .replace(Regex("[ _-]?(copy|edited|[0-9]{1,3})$"), "")
        .take(80)
}
