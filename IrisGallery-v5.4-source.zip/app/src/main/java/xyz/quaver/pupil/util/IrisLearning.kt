package xyz.quaver.pupil.util

import android.content.Context

/** Tiny local feedback ledger. It never uploads media or behavior. */
object IrisLearning {
    private const val PREFS = "iris_learning_v1"
    fun record(context: Context, uri: String, event: String) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = "$event:$uri"
        p.edit().putInt(key, p.getInt(key, 0) + 1).apply()
    }
    fun preservationSignal(context: Context, uri: String): Int {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return p.getInt("pin:$uri", 0) * 30 + p.getInt("keep:$uri", 0) * 60 - p.getInt("delete_approved:$uri", 0) * 40
    }
}
