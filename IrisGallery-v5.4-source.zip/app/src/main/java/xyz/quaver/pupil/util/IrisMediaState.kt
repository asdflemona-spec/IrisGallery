package xyz.quaver.pupil.util

import android.content.Context

object IrisMediaState {
    private const val PREFS = "iris_media_state"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun isKeep(context: Context, uri: String) = prefs(context).getBoolean("keep:$uri", false)
    fun isTrash(context: Context, uri: String) = prefs(context).getBoolean("trash:$uri", false)
    fun isPinned(context: Context, uri: String) = prefs(context).getBoolean("pin:$uri", false)
    fun togglePin(context: Context, uri: String): Boolean {
        if (isKeep(context, uri)) return true
        val next = !isPinned(context, uri)
        prefs(context).edit().putBoolean("pin:$uri", next).putBoolean("trash:$uri", false).apply()
        IrisLearning.record(context, uri, if (next) "pin" else "unpin")
        return next
    }
    fun toggleKeep(context: Context, uri: String): Boolean {
        val next = !isKeep(context, uri)
        prefs(context).edit().putBoolean("keep:$uri", next).putBoolean("trash:$uri", false).putBoolean("pin:$uri", false).apply()
        IrisLearning.record(context, uri, if (next) "keep" else "unkeep")
        return next
    }
    fun setTrash(context: Context, uri: String, value: Boolean): Boolean {
        if (value && (isKeep(context, uri) || isPinned(context, uri))) return false
        prefs(context).edit().putBoolean("trash:$uri", value).apply()
        return value
    }
    fun toggleTrash(context: Context, uri: String): Boolean {
        if (isKeep(context, uri) || isPinned(context, uri)) return false
        val next = !isTrash(context, uri)
        prefs(context).edit().putBoolean("trash:$uri", next).apply()
        return next
    }
}
