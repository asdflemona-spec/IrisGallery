package xyz.quaver.pupil.ui.compose

import android.net.Uri
import android.os.Build
import android.util.Size
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisMediaState

/** Presentation lenses. Brand assets are Iris-owned; interaction/content grammar follows proven media patterns. */
enum class IrisGallerySkin(val label: String) { GALLERY("Photos"), VERTICAL("TikTok"), SOCIAL("Instagram"), BOARD("Pinterest"), WEBTOON("Webtoon") }

private data class PresentationCopy(
    val author:String, val caption:String, val commenter1:String, val comment1:String,
    val commenter2:String, val comment2:String, val dialogue:String, val narration:String,
    val memeTop:String, val memeBottom:String, val memeTag:String
)

/**
 * Simple meme grammar, deliberately not an AI model.
 * It borrows repeatable internet-meme structures (POV, expectation/reality,
 * "me vs me", reaction captions, anticlimax) without copying somebody else's image asset.
 */
private fun copyFor(x:IrisGalleryMedia):PresentationCopy {
    val stem=x.name.substringBeforeLast('.').replace('_',' ').replace('-',' ').take(28).ifBlank{"untitled"}
    val author=x.bucket.ifBlank{"iris.gallery"}.lowercase().replace(" ",".").take(22)
    val seed=((x.id xor x.dateAdded) and Long.MAX_VALUE).toInt()
    val meme=listOf(
        Triple("POV: 갤러리 정리하려고 들어옴", "그리고 40분째 추억 구경 중", "POV"),
        Triple("나: 이것만 보고 끈다", "또 나: 다음 사진도 봐야 함", "ME VS ME"),
        Triple("기대: 바로 삭제", "현실: 일단 고정함 📌", "EXPECTATION / REALITY"),
        Triple("아무 생각 없이 넘겼는데", "갑자기 이 사진에서 멈춤", "REACTION"),
        Triple("분명 필요 없는 사진이었음", "왜 지금 보니까 좋은데", "PLOT TWIST"),
        Triple("과거의 나: 일단 찍어", "현재의 나: 이걸 왜 찍었지", "THEN / NOW"),
        Triple("정리 대상 후보", "근데 이상하게 삭제는 못 하겠음", "RELATABLE"),
        Triple("평범한 하루인 줄 알았는데", "갤러리에서는 명장면이 됨", "MAIN CHARACTER")
    )[Math.floorMod(seed,8)]
    val reactions=listOf("ㅋㅋ 이건 못 지움","이 장면은 인정","왜 공감되지","두 번째 컷 필요함","핀 박아둬야 함","이런 게 나중에 재밌음")
    val dialogue=listOf("…이걸 지운다고?","잠깐. 이건 남겨.","분명 별거 아니었는데.","다음 장면 보면 이해됨.","아니, 계획은 이게 아니었어.","그래서 결국 고정했다.")
    val narr=listOf("정리를 시작했지만 추억이 먼저 말을 걸었다.","별 의미 없던 사진이 뒤늦게 장면이 됐다.","삭제 후보였던 사진은 그렇게 살아남았다.","사진 사이의 빈칸에서 이야기가 생겼다.")
    val r1=reactions[Math.floorMod(seed/3,reactions.size)]
    val r2=reactions[Math.floorMod(seed/11+2,reactions.size)]
    return PresentationCopy(author,"$stem · ${meme.first}","mori",r1,"yun",r2,dialogue[Math.floorMod(seed/5,dialogue.size)],narr[Math.floorMod(seed/13,narr.size)],meme.first,meme.second,meme.third)
}

@Composable fun IrisLocalMediaViewer(item:IrisGalleryMedia,onClose:()->Unit){
    // Full-screen dialog keeps the player outside the weighted presentation layout.
    // Presentation lenses may recompose freely without owning the playback surface.
    Dialog(
        onDismissRequest=onClose,
        properties=DialogProperties(usePlatformDefaultWidth=false, decorFitsSystemWindows=false)
    ){
        BackHandler(onBack=onClose)
        Box(Modifier.fillMaxSize().background(Color.Black)){
            if(item.isVideo) IrisVideoPlayer(item.uri)
            else AsyncImage(item.uri,item.name,Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
            TextButton(onClick=onClose,modifier=Modifier.align(Alignment.TopStart).padding(8.dp)){
                Text("✕",color=Color.White,fontSize=22.sp)
            }
        }
    }
}

@Composable private fun IrisVideoPlayer(uri:String){
    val context=LocalContext.current
    val player=remember(uri){ExoPlayer.Builder(context).build().apply{setMediaItem(MediaItem.fromUri(Uri.parse(uri)));repeatMode=ExoPlayer.REPEAT_MODE_ONE;prepare();playWhenReady=true}}
    DisposableEffect(player){onDispose{player.release()}}
    AndroidView(factory={PlayerView(it).apply{this.player=player;useController=true;layoutParams=FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)}},update={it.player=player},modifier=Modifier.fillMaxSize())
}

@Composable private fun MediaSurface(item:IrisGalleryMedia,modifier:Modifier=Modifier,scale:ContentScale=ContentScale.Crop){
    if(!item.isVideo){AsyncImage(item.uri,item.name,modifier,contentScale=scale);return}
    val context=LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(null,item.uri){value=withContext(Dispatchers.IO){runCatching{if(Build.VERSION.SDK_INT>=29)context.contentResolver.loadThumbnail(Uri.parse(item.uri),Size(720,720),null) else android.provider.MediaStore.Video.Thumbnails.getThumbnail(context.contentResolver,item.id,android.provider.MediaStore.Video.Thumbnails.MINI_KIND,null)}.getOrNull()}}
    Box(modifier.background(Color.DarkGray),contentAlignment=Alignment.Center){bitmap?.let{Image(it.asImageBitmap(),item.name,Modifier.fillMaxSize(),contentScale=scale)};Icon(Icons.Default.PlayArrow,null,tint=Color.White,modifier=Modifier.size(42.dp))}
}

@Composable private fun StateActions(item:IrisGalleryMedia,dark:Boolean=false){
    val context=LocalContext.current;var keep by remember(item.uri){mutableStateOf(IrisMediaState.isKeep(context,item.uri))};var pin by remember(item.uri){mutableStateOf(IrisMediaState.isPinned(context,item.uri))};var trash by remember(item.uri){mutableStateOf(IrisMediaState.isTrash(context,item.uri))};val normal=if(dark)Color.White else LocalContentColor.current
    Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){IconButton(onClick={keep=IrisMediaState.toggleKeep(context,item.uri);if(keep){trash=false;pin=false}}){Icon(Icons.Default.Lock,"Keep",tint=if(keep)Color(0xFFFFD54F) else normal)};TextButton(onClick={pin=IrisMediaState.togglePin(context,item.uri);if(pin)trash=false},enabled=!keep){Text(if(pin)"📌" else "Pin",color=normal)};IconButton(onClick={trash=IrisMediaState.toggleTrash(context,item.uri)},enabled=!keep&&!pin){Icon(Icons.Default.Delete,"Trash",tint=if(trash)Color(0xFFFF5252) else normal)}}
}

@Composable private fun Avatar(item:IrisGalleryMedia,size:Int=34){Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFFECECEC))){MediaSurface(item,Modifier.fillMaxSize())}}

@Composable private fun InstagramPost(x:IrisGalleryMedia,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x)
    Column(Modifier.fillMaxWidth().padding(bottom=18.dp)){
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){Avatar(x);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(c.author,fontWeight=FontWeight.SemiBold,fontSize=13.sp);Text(x.bucket,fontSize=11.sp)};Text("•••",fontWeight=FontWeight.Bold)}
        MediaSurface(x,Modifier.fillMaxWidth().aspectRatio(1f).clickable{onOpen(x)})
        Row(Modifier.fillMaxWidth().height(48.dp),verticalAlignment=Alignment.CenterVertically){Text("♡",fontSize=28.sp,modifier=Modifier.padding(start=12.dp,end=14.dp));Text("○",fontSize=27.sp);Text("⌁",fontSize=28.sp,modifier=Modifier.padding(start=14.dp));Spacer(Modifier.weight(1f));StateActions(x)}
        Text("좋아요 ${(x.id%800)+24}개",fontWeight=FontWeight.SemiBold,fontSize=13.sp,modifier=Modifier.padding(horizontal=12.dp))
        Row(Modifier.padding(horizontal=12.dp,vertical=4.dp)){Text(c.author,fontWeight=FontWeight.Bold,fontSize=13.sp);Spacer(Modifier.width(5.dp));Text("${c.memeTop} → ${c.memeBottom}",fontSize=13.sp,maxLines=3,overflow=TextOverflow.Ellipsis)}
        Text("댓글 ${(x.id%31)+2}개 모두 보기",color=Color.Gray,fontSize=13.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=2.dp))
        Row(Modifier.padding(horizontal=12.dp)){Text(c.commenter1,fontWeight=FontWeight.Bold,fontSize=13.sp);Spacer(Modifier.width(5.dp));Text(c.comment1,fontSize=13.sp)}
        Text("1시간 전",color=Color.Gray,fontSize=10.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=6.dp))
    }
}

@Composable private fun TikTokItem(x:IrisGalleryMedia,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x)
    Box(Modifier.fillMaxSize().background(Color.Black)){
        MediaSurface(x,Modifier.fillMaxSize().clickable{onOpen(x)},ContentScale.Crop)
        Row(Modifier.align(Alignment.TopCenter).padding(top=16.dp),verticalAlignment=Alignment.CenterVertically){Text("Following",color=Color.White.copy(.75f),fontWeight=FontWeight.SemiBold);Spacer(Modifier.width(20.dp));Column(horizontalAlignment=Alignment.CenterHorizontally){Text("For You",color=Color.White,fontWeight=FontWeight.Bold);Box(Modifier.padding(top=4.dp).width(24.dp).height(2.dp).background(Color.White))}}
        Column(Modifier.align(Alignment.CenterEnd).padding(end=9.dp,bottom=80.dp),horizontalAlignment=Alignment.CenterHorizontally){Avatar(x,46);Spacer(Modifier.height(18.dp));Text("♥",color=Color.White,fontSize=30.sp);Text("${(x.id%900)+99}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(14.dp));Text("●",color=Color.White,fontSize=27.sp);Text("${(x.id%90)+4}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(8.dp));StateActions(x,true)}
        Column(Modifier.align(Alignment.Center).fillMaxWidth(.88f),horizontalAlignment=Alignment.CenterHorizontally){Text(c.memeTop,color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=22.sp,lineHeight=27.sp);Spacer(Modifier.height(14.dp));Text(c.memeBottom,color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=22.sp,lineHeight=27.sp)}
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(.78f).padding(14.dp)){Text("@${c.author}",color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp);Spacer(Modifier.height(6.dp));Text("#${c.memeTag.replace(" ","")}  ${c.caption}",color=Color.White,fontSize=13.sp,maxLines=2);Spacer(Modifier.height(8.dp));Text("♫ iris meme mix · ${c.author}",color=Color.White,fontSize=12.sp)}
    }
}

@Composable private fun WebtoonPanel(x:IrisGalleryMedia,index:Int,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x);val light=index%2==0
    Column(Modifier.fillMaxWidth().background(if(light)Color.White else Color(0xFFF5F5F5))){
        if(index%3==0)Text(c.narration,Modifier.fillMaxWidth().padding(horizontal=28.dp,vertical=26.dp),fontSize=14.sp,lineHeight=22.sp)
        Box(Modifier.fillMaxWidth()){
            MediaSurface(x,Modifier.fillMaxWidth().height(if(x.isVideo)360.dp else 590.dp).clickable{onOpen(x)},ContentScale.Crop)
            Surface(modifier=Modifier.align(if(index%2==0)Alignment.TopStart else Alignment.TopEnd).padding(18.dp).widthIn(max=230.dp),shape=RoundedCornerShape(18.dp),color=Color.White.copy(.94f),shadowElevation=3.dp){Text(if(index%2==0)c.memeTop else c.memeBottom,Modifier.padding(horizontal=16.dp,vertical=11.dp),fontSize=14.sp,lineHeight=20.sp,color=Color.Black)}
        }
        if(index%4==2)Text("…",Modifier.fillMaxWidth().padding(30.dp),fontSize=30.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(if(index%3==1)34.dp else 8.dp))
    }
}

@Composable fun IrisSkinnedGallery(
    items: List<IrisGalleryMedia>,
    skin: IrisGallerySkin,
    onOpen: (IrisGalleryMedia) -> Unit,
    modifier: Modifier = Modifier
) {
    when (skin) {
        IrisGallerySkin.GALLERY -> LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(items.size, key = { items[it].uri }) { i ->
                val x = items[i]
                Box(Modifier.aspectRatio(1f).clickable { onOpen(x) }) {
                    MediaSurface(x, Modifier.fillMaxSize())
                    if (IrisMediaState.isKeep(LocalContext.current, x.uri)) {
                        Text("🔒", Modifier.align(Alignment.TopEnd).padding(5.dp))
                    }
                }
            }
        }

        IrisGallerySkin.VERTICAL -> LazyColumn(modifier.fillMaxSize().background(Color.Black)) {
            items(items, key = { "v:${it.uri}" }) { x ->
                Box(Modifier.fillParentMaxSize()) { TikTokItem(x, onOpen) }
            }
        }

        IrisGallerySkin.SOCIAL -> LazyColumn(modifier.fillMaxSize().background(Color.White)) {
            item {
                Column {
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Iris", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                        Spacer(Modifier.weight(1f))
                        Text("♡   ⊕", fontSize = 23.sp)
                    }
                    Row(
                        Modifier.fillMaxWidth().height(92.dp).padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items.take(6).forEach { story ->
                            Column(
                                modifier = Modifier.width(58.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    Modifier.padding(4.dp).size(54.dp).clip(CircleShape)
                                        .background(Color(0xFFFFE0E8))
                                ) { MediaSurface(story, Modifier.fillMaxSize()) }
                                Text(copyFor(story).author.take(8), fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
            items(items, key = { "i:${it.uri}" }) { InstagramPost(it, onOpen) }
        }

        IrisGallerySkin.BOARD -> LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items.size, key = { items[it].uri }) { i ->
                val x = items[i]
                Column {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        MediaSurface(
                            x,
                            Modifier.fillMaxWidth()
                                .aspectRatio(if (i % 4 == 0) .68f else if (i % 3 == 0) .78f else .9f)
                                .clickable { onOpen(x) }
                        )
                    }
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${copyFor(x).memeTag}: ${copyFor(x).memeBottom}", Modifier.weight(1f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("•••", Modifier.padding(6.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(x, 22); Spacer(Modifier.width(5.dp))
                        Text(copyFor(x).author, fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }
        }

        IrisGallerySkin.WEBTOON -> LazyColumn(modifier.fillMaxSize().background(Color.White)) {
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("IRIS ORIGINAL", fontSize = 11.sp, color = Color.Gray)
                    Text("기억의 조각들", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("EP. 01  다시 발견한 장면", fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                    Text("내 갤러리의 사진으로 구성된 개인 에피소드", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
                }
            }
            items(items.size, key = { "w:${items[it].uri}" }) { i -> WebtoonPanel(items[i], i, onOpen) }
            item {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("EP. 01 END", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("♡ 좋아요   ·   댓글   ·   다음 에피소드", fontSize = 14.sp)
                    Spacer(Modifier.height(36.dp))
                }
            }
        }
    }
}
