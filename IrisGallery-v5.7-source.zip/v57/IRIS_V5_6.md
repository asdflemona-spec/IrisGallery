# Iris Gallery v5.6
- Adds Careet as a read-only ContentSource for the public "요즘 뜨는 밈" series.
- Parses title, trend state/date, detail URL and public detail text/images.
- Supports Careet pagination and local title filtering.
- Membership/paywalled portions are not bypassed; Iris links to the original page.
- Video/gallery core unchanged from v5.5.
