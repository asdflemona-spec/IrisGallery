# Iris v5.7 — Careet live meme library

- Careet is now a live meme metadata provider, not only a browse tab.
- Iris reads public meme article headings/TOC labels at runtime and keeps status/date/source attribution.
- Member-only body text is not crossed, cached, or copied.
- Removed synthetic meme personas/comments/dialogue from Instagram/Webtoon/TikTok/Pinterest presentation copy.
- Presentation lenses share the same Careet meme library.
- v5.2 video player path remains unchanged.
