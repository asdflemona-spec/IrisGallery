package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI



data class CareetMeme(
    val name: String,
    val status: String?,
    val date: String?,
    val sourceTitle: String,
    val sourceUrl: String,
)

/** Read-only adapter for Careet's public "요즘 뜨는 밈" series pages. */
class CareetSource : ContentSource {
    override val id = "careet"
    override val displayName = "Careet"
    override val maturity = SourceMaturity.GENERAL
    override val availability = SourceAvailability.READY
    override val capabilities = setOf(SourceCapability.BROWSE, SourceCapability.SEARCH, SourceCapability.DETAIL)

    val baseUrl = "https://www.careet.net"
    val seriesUrl = "$baseUrl/Content/Series/1"
    val requestHeaders = mapOf(
        "Referer" to seriesUrl,
        "User-Agent" to "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
    )

    private suspend fun document(url: String): Document {
        val response = client.get(url) { requestHeaders.forEach { (k, v) -> header(k, v) } }
        if (!response.status.isSuccess()) throw IOException("Careet HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }

    override suspend fun search(query: String, page: Int): SourcePage {
        val pageNumber = page + 1
        val url = if (pageNumber <= 1) seriesUrl else "$seriesUrl?pageidx=$pageNumber"
        val doc = document(url)
        val q = query.trim()
        val seen = hashSetOf<String>()
        val items = doc.select("a[href]").mapNotNull { a ->
            val href = a.absUrl("href").ifBlank { a.attr("href") }
            val remoteId = remoteIdFrom(href) ?: return@mapNotNull null
            val text = a.text().replace(Regex("\\s+"), " ").trim()
            if (text.isBlank() || !seen.add(remoteId)) return@mapNotNull null
            if (q.isNotBlank() && !text.contains(q, ignoreCase = true)) return@mapNotNull null
            val status = when {
                text.contains("유행예감") || text.contains("유행 예감") -> "유행 예감"
                text.contains("유행중") || text.contains("유행 중") -> "유행 중"
                text.contains("유행지남") || text.contains("유행 지남") -> "유행 지남"
                else -> null
            }
            val date = Regex("20\\d{2}\\.\\d{2}\\.\\d{2}").find(text)?.value
            val cleanTitle = text
                .replace("북마크", "")
                .replace("유행예감", "").replace("유행 예감", "")
                .replace("유행중", "").replace("유행 중", "")
                .replace("유행지남", "").replace("유행 지남", "")
                .replace(Regex("20\\d{2}\\.\\d{2}\\.\\d{2}"), "")
                .replace(Regex("\\s+"), " ").trim()
            val image = a.selectFirst("img") ?: a.parent()?.selectFirst("img")
            val thumb = image?.let { it.absUrl("src").ifBlank { it.attr("data-src") } }?.takeIf { it.isNotBlank() }
            SourceItem(id, remoteId, cleanTitle.ifBlank { text }, thumb, "$baseUrl/$remoteId", listOfNotNull(status, date))
        }
        return SourcePage(items, if (items.isNotEmpty()) page + 1 else null)
    }

    /**
     * Builds a small live meme index from Careet's public series/article metadata.
     * Only public headings/TOC labels are retained; member-only body text is never crossed or cached.
     */
    suspend fun memes(maxArticles: Int = 6): List<CareetMeme> {
        val articles = search("", 0).items.take(maxArticles)
        val out = linkedMapOf<String, CareetMeme>()
        for (article in articles) {
            val doc = runCatching { document(article.pageUrl ?: continue) }.getOrNull() ?: continue
            val allText = doc.body().text().replace(Regex("\\s+"), " ")
            val status = when {
                allText.contains("유행예감") || allText.contains("유행 예감") -> "유행 예감"
                allText.contains("유행중") || allText.contains("유행 중") -> "유행 중"
                allText.contains("유행지남") || allText.contains("유행 지남") -> "유행 지남"
                else -> article.tags.firstOrNull { it.startsWith("유행") }
            }
            val date = Regex("20\\d{2}\\.\\d{2}\\.\\d{2}").find(allText)?.value
            // Careet exposes each article's meme names in its public table of contents / numbered headings.
            val names = linkedSetOf<String>()
            doc.select("h2, h3, h4").forEach { h ->
                val t = h.text().replace(Regex("\\s+"), " ").trim()
                Regex("^\\d+[.)]\\s*(.+)$").find(t)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.length in 2..80 }?.let(names::add)
            }
            // Fallback: article title is still useful as a trend card when individual names are not exposed.
            if (names.isEmpty()) names += article.title
            names.forEach { name ->
                out.putIfAbsent(name, CareetMeme(name, status, date, article.title, article.pageUrl ?: seriesUrl))
            }
        }
        return out.values.toList()
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        val url = "$baseUrl/$remoteId"
        val doc = document(url)
        val title = doc.selectFirst("h1, h2, h3")?.text()?.trim()?.takeIf { it.isNotBlank() } ?: doc.title()
        val article = doc.selectFirst("article, .content, .view-content, .detail-content, #content") ?: doc.body()
        val text = article.text().replace(Regex("\\s+"), " ").trim()
        val membershipCut = listOf("캐릿 멤버십을 시작", "무단 전재와 재배포").map { text.indexOf(it) }.filter { it >= 0 }.minOrNull()
        val publicText = (membershipCut?.let { text.take(it) } ?: text).take(1800).trim()
        val images = linkedSetOf<String>()
        doc.select("meta[property=og:image]").forEach { absolute(it.attr("content"))?.let(images::add) }
        article.select("img").forEach { img ->
            listOf("data-original", "data-src", "src").forEach { key -> absolute(img.attr(key))?.let(images::add) }
        }
        val filtered = images.filterNot { u -> listOf("logo", "icon", "favicon").any { u.contains(it, true) } }
        return SourceDetail(
            item = SourceItem(id, remoteId, title, filtered.firstOrNull(), url),
            imageUrls = filtered,
            description = publicText.ifBlank { "Careet 원문에서 확인하세요." },
        )
    }

    private fun remoteIdFrom(url: String): String? {
        val path = try { URI(url).path ?: return null } catch (_: Exception) { return null }
        return Regex("^/(\\d+)(?:/|$)").find(path)?.groupValues?.get(1)
    }

    private fun absolute(raw0: String): String? {
        val raw = raw0.trim().replace("&amp;", "&")
        if (raw.isBlank() || raw.startsWith("data:") || raw.startsWith("javascript:")) return null
        return try { if (raw.startsWith("//")) "https:$raw" else URI(baseUrl).resolve(raw).toString() } catch (_: Exception) { null }
    }
}
