package xyz.quaver.pupil.source

object SourceRegistry {
    val sources: List<ContentSource> = listOf(
        HitomiSource(),
        GgoorrSource(),
        CareetSource(),
        ConfiguredSource("pixiv", "Pixiv"),
        ConfiguredSource("pinterest", "Pinterest"),
        ConfiguredSource("x", "X"),
    )

    fun byId(id: String): ContentSource? = sources.firstOrNull { it.id == id }
    val ready: List<ContentSource> get() = sources.filter { it.availability == SourceAvailability.READY }
}
