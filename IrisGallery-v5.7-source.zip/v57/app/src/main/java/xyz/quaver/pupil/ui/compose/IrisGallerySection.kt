package xyz.quaver.pupil.ui.compose

import android.Manifest
import android.content.Intent
import android.app.RecoverableSecurityException
import android.app.Activity
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryIndex
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisTasteCluster
import xyz.quaver.pupil.util.IrisTasteEngine
import xyz.quaver.pupil.util.IrisTasteProfile
import xyz.quaver.pupil.util.IrisCleanupEngine
import xyz.quaver.pupil.util.IrisCleanupPlan
import xyz.quaver.pupil.util.IrisMediaState
import xyz.quaver.pupil.util.IrisLearning
import xyz.quaver.pupil.source.CareetSource
import xyz.quaver.pupil.source.CareetMeme

private enum class LibraryView(val label: String) { MEMES("Memes"), CLEANUP("Clean up"), COLLECTIONS("Collections") }
private enum class CollectionFilter(val label: String) { ALL("All"), FAVORITES("Favorites"), IRIS("Iris"), DOWNLOADS("Downloads"), SCREENSHOTS("Screenshots"), CAMERA("Camera"), IMAGES("Images"), VIDEOS("Videos") }

@Composable
fun IrisGallerySection(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    fun hasAccess(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasAccess()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result -> granted = result.values.any { it } || hasAccess(); refresh++ }
    val media = remember(granted, refresh) { if (granted) runCatching { IrisGalleryIndex.scan(context) }.getOrDefault(emptyList()) else emptyList() }
    var view by remember { mutableStateOf(LibraryView.MEMES) }
    var clusters by remember { mutableStateOf<List<IrisTasteCluster>>(emptyList()) }
    var analyzing by remember { mutableStateOf(false) }
    var selectedTaste by remember { mutableStateOf<IrisTasteCluster?>(null) }
    var profileRevision by remember { mutableIntStateOf(0) }
    var skin by remember { mutableStateOf(IrisGallerySkin.GALLERY) }
    var opened by remember { mutableStateOf<IrisGalleryMedia?>(null) }
    var careetMemes by remember { mutableStateOf<List<CareetMeme>>(emptyList()) }
    var careetError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { withContext(Dispatchers.IO) { CareetSource().memes() } }
            .onSuccess { careetMemes = it; careetError = null }
            .onFailure { careetError = it.message }
    }

    LaunchedEffect(media, profileRevision) {
        if (media.isNotEmpty()) {
            if (profileRevision > 0) delay(350)
            analyzing = true
            clusters = withContext(Dispatchers.Default) { IrisTasteEngine.discover(context, media) }
            analyzing = false
        }
    }

    Column(modifier) {
        if (!granted) {
            Column(Modifier.padding(20.dp)) {
                Text("Your gallery stays on this device", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp)); Text("Iris learns visual patterns locally. Originals are never moved or copied.")
                Spacer(Modifier.height(12.dp)); Button(onClick = {
                    launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                }) { Text("Allow gallery access") }
            }; return@Column
        }

        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(IrisGallerySkin.entries) { item -> FilterChip(skin == item, { skin = item }, { Text(item.label) }) }
        }
        if (skin != IrisGallerySkin.GALLERY) {
            IrisSkinnedGallery(media, skin, { opened = it }, Modifier.weight(1f), careetMemes)
            opened?.let { IrisLocalMediaViewer(it) { opened = null } }
            return@Column
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(LibraryView.entries) { item -> FilterChip(view == item, { view = item }, { Text(item.label) }) }
        }
        when (view) {
            LibraryView.MEMES -> MemeHomeView(media, careetMemes, careetError) { opened = it }
            LibraryView.CLEANUP -> CleanupView(media) { refresh++ }
            LibraryView.COLLECTIONS -> CollectionsView(media)
        }
        opened?.let { IrisLocalMediaViewer(it) { opened = null } }
    }
}



@Composable private fun MemeHomeView(media: List<IrisGalleryMedia>, memes: List<CareetMeme>, error: String?, onOpen: (IrisGalleryMedia) -> Unit) {
    val picks = media.filterNot { IrisMediaState.isTrash(LocalContext.current, it.uri) }.take(36)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(16.dp)) {
                Text("🔥 Careet meme feed", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(when { memes.isNotEmpty() -> "Careet 공개 목록에서 ${memes.size}개 밈을 추출해 내 갤러리에 적용 중"; error != null -> "Careet 연결 실패 · $error"; else -> "Careet 요즘 뜨는 밈을 불러오는 중…" }, style = MaterialTheme.typography.bodyMedium)
            }
        }
        items(picks, key = { "meme:${it.uri}" }) { item ->
            val seed = ((item.id xor item.dateAdded) and Long.MAX_VALUE).toInt()
            val meme = memes.getOrNull(if (memes.isEmpty()) 0 else Math.floorMod(seed, memes.size))
            ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clickable { onOpen(item) }) {
                Column {
                    RemoteImage(item.uri, Modifier.fillMaxWidth().height(280.dp), item.name)
                    Text(meme?.name ?: "Careet 밈 불러오는 중", Modifier.padding(start=14.dp, end=14.dp, top=14.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(listOfNotNull(meme?.status, meme?.date, "Careet").joinToString(" · "), Modifier.padding(horizontal=14.dp, vertical=8.dp), style=MaterialTheme.typography.bodySmall)
                    meme?.sourceTitle?.let { Text(it, Modifier.padding(start=14.dp,end=14.dp,bottom=14.dp), style=MaterialTheme.typography.bodySmall, maxLines=1) }
                }
            }
        }
    }
}

@Composable private fun CleanupView(media: List<IrisGalleryMedia>, onDeleted: () -> Unit) {
    val context = LocalContext.current
    var plan by remember(media) { mutableStateOf<IrisCleanupPlan?>(null) }
    var analyzing by remember(media) { mutableStateOf(true) }
    var pinRevision by remember { mutableIntStateOf(0) }
    var pendingDelete by remember { mutableStateOf<List<IrisGalleryMedia>>(emptyList()) }
    var status by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(media, pinRevision) {
        analyzing = true
        plan = withContext(Dispatchers.IO) { IrisCleanupEngine.analyze(context, media) }
        analyzing = false
    }

    fun markApproved(items: List<IrisGalleryMedia>) {
        items.forEach {
            IrisLearning.record(context, it.uri, "delete_approved")
            IrisMediaState.setTrash(context, it.uri, false)
        }
        status = "Deleted ${items.size} items. Rescanning gallery…"
        pendingDelete = emptyList()
        onDeleted()
    }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) markApproved(pendingDelete)
        else { status = "Deletion cancelled"; pendingDelete = emptyList() }
    }

    fun requestRealDelete(items: List<IrisGalleryMedia>) {
        val safe = items.filterNot { IrisMediaState.isKeep(context, it.uri) || IrisMediaState.isPinned(context, it.uri) }.distinctBy { it.uri }
        if (safe.isEmpty()) { status = "Nothing selected — pinned and Keep items are protected"; return }
        pendingDelete = safe
        val uris = safe.map { Uri.parse(it.uri) }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                val pending = MediaStore.createDeleteRequest(context.contentResolver, uris)
                deleteLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(pending.intentSender).build())
            }.onFailure { status = "Could not open Android delete confirmation: ${it.message ?: "unknown error"}" }
        } else {
            var deleted = 0
            var recoverable: RecoverableSecurityException? = null
            for (item in safe) {
                try { if (context.contentResolver.delete(Uri.parse(item.uri), null, null) > 0) { deleted++; IrisLearning.record(context, item.uri, "delete_approved") } }
                catch (e: RecoverableSecurityException) { recoverable = e; break }
                catch (_: SecurityException) { status = "Android denied deletion for one or more items" }
            }
            if (recoverable != null && Build.VERSION.SDK_INT >= 29) {
                deleteLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(recoverable!!.userAction.actionIntent.intentSender).build())
            } else if (deleted > 0) { status = "Deleted $deleted items. Rescanning gallery…"; pendingDelete = emptyList(); onDeleted() }
        }
    }

    if (analyzing) { Column(Modifier.padding(20.dp)) { LinearProgressIndicator(Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); Text("Finding near-duplicates and old screenshots…") }; return }
    val p = plan ?: return
    val candidates = p.candidates.filterNot { IrisMediaState.isKeep(context, it.uri) || IrisMediaState.isPinned(context, it.uri) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Automatic cleanup", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Iris proposes removals. Pin excludes an item from cleanup; Keep protects it permanently. Android performs the real deletion.", style = MaterialTheme.typography.bodyMedium)
            status?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                Text("${candidates.size} suggested removals", style = MaterialTheme.typography.titleLarge)
                Text("${p.groups.size} similar stacks · ${p.staleScreenshots.size} old screenshots")
                Spacer(Modifier.height(12.dp))
                Button(enabled = candidates.isNotEmpty(), onClick = { requestRealDelete(candidates) }) { Text("Delete ${candidates.size} for real") }
            } }
        }
        items(p.groups.take(30), key = { "clean:${it.keep.uri}" }) { group ->
            ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text("Similar burst · keep 1, suggest ${group.remove.count { !IrisMediaState.isPinned(context, it.uri) }}", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                (listOf(group.keep) + group.remove).take(8).forEach { item ->
                    val pinned = IrisMediaState.isPinned(context, item.uri)
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(58.dp)) { RemoteImage(item.uri, Modifier.fillMaxSize(), item.name) }
                        Spacer(Modifier.width(10.dp)); Text(if (item.uri == group.keep.uri) "BEST · ${item.name}" else item.name, Modifier.weight(1f), maxLines = 1)
                        TextButton(onClick = { IrisMediaState.togglePin(context, item.uri); pinRevision++ }, enabled = !IrisMediaState.isKeep(context, item.uri)) { Text(if (pinned) "📌 Pinned" else "Pin") }
                    }
                }
            } }
        }
        if (p.staleScreenshots.isNotEmpty()) item {
            ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text("Old screenshots · ${p.staleScreenshots.size}", fontWeight = FontWeight.SemiBold)
                p.staleScreenshots.take(12).forEach { item ->
                    val pinned = IrisMediaState.isPinned(context, item.uri)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(item.name, Modifier.weight(1f), maxLines = 1)
                        TextButton(onClick = { IrisMediaState.togglePin(context, item.uri); pinRevision++ }) { Text(if (pinned) "📌 Pinned" else "Pin") }
                    }
                }
            } }
        }
        item { Text("Pin is feedback: Iris remembers that you rejected its deletion suggestion. Keep remains the stronger permanent protection signal.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable private fun ForYouView(clusters: List<IrisTasteCluster>, media: List<IrisGalleryMedia>, analyzing: Boolean, onTaste: (IrisTasteCluster) -> Unit) {
    if (analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Discovering patterns only you may have missed…", Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            SectionTitle("Your visual fingerprint", "Not folders or manual tags — groups discovered from similarity and your positive signals.")
        }
        if (clusters.isEmpty()) item { Text("Keep using Iris. For You becomes useful after enough visual history is available.", Modifier.padding(16.dp)) }
        items(clusters.take(3), key = { "fy:${it.id}" }) { cluster -> TasteCard(cluster) { onTaste(cluster) } }
        if (media.isNotEmpty()) {
            item { SectionTitle("Rediscover", "Recent favorites and Iris saves worth seeing again.") }
            item {
                val rediscover = media.filter { it.isFavorite || it.isIris }.sortedByDescending { it.dateAdded }.take(14)
                GalleryStrip(rediscover.ifEmpty { media.take(14) })
            }
        }
    }
}

@Composable private fun TasteClustersView(clusters: List<IrisTasteCluster>, analyzing: Boolean, onTaste: (IrisTasteCluster) -> Unit) {
    if (analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()); return }
    if (clusters.isEmpty()) { Text("No taste groups yet.", Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle("Discovered tastes", "A photo can belong to objective collections while Iris separately learns its visual taste group.") }
        items(clusters, key = { "taste:${it.id}" }) { cluster -> TasteCard(cluster) { onTaste(cluster) } }
    }
}

@Composable private fun TasteCard(cluster: IrisTasteCluster, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clickable(onClick = onClick)) {
        Column(Modifier.padding(vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("Taste ${cluster.id + 1}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text("${cluster.media.size} visually related", style = MaterialTheme.typography.labelMedium) }
                Text("Open", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(8.dp)); GalleryStrip(cluster.media.take(12))
        }
    }
}


@Composable private fun TasteDetailView(cluster: IrisTasteCluster, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Tastes") }
            Column(Modifier.weight(1f)) {
                Text("Taste ${cluster.id + 1}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("${cluster.media.size} photos · learned locally", style = MaterialTheme.typography.labelMedium)
            }
        }
        Text("These are the actual photos Iris grouped together. Open any photo normally; future versions use your feedback to split and refine this taste.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        GalleryGrid(cluster.media, Modifier.fillMaxSize())
    }
}

@Composable private fun GalleryGrid(items: List<IrisGalleryMedia>, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    if (items.isEmpty()) { Box(modifier, contentAlignment = Alignment.Center) { Text("No photos here yet.") }; return }
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = modifier,
        contentPadding = PaddingValues(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        gridItems(items, key = { it.uri }) { item ->
            Box(Modifier.aspectRatio(1f).clickable { openGalleryItem(context, item) }) {
                RemoteImage(item.uri, Modifier.fillMaxSize(), item.name)
                if (item.isVideo) Surface(Modifier.align(Alignment.BottomEnd).padding(4.dp), shape = MaterialTheme.shapes.small, tonalElevation = 2.dp) { Text("VIDEO", Modifier.padding(horizontal = 5.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall) }
                if (item.isFavorite) Text("♥", Modifier.align(Alignment.TopEnd).padding(5.dp), style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable private fun CollectionsView(media: List<IrisGalleryMedia>) {
    var filter by remember { mutableStateOf(CollectionFilter.ALL) }
    Column {
        Text("Objective collections", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        Text("Useful facts stay separate from Iris' inferred tastes.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CollectionFilter.entries) { item -> FilterChip(filter == item, { filter = item }, { Text(item.label) }) }
        }
        val shown = media.filter { item -> when (filter) {
            CollectionFilter.ALL -> true
            CollectionFilter.FAVORITES -> item.isFavorite
            CollectionFilter.IRIS -> item.isIris
            CollectionFilter.DOWNLOADS -> item.isDownload
            CollectionFilter.SCREENSHOTS -> item.isScreenshot
            CollectionFilter.CAMERA -> item.isCamera
            CollectionFilter.IMAGES -> !item.isVideo
            CollectionFilter.VIDEOS -> item.isVideo
        } }
        Text("${shown.size} items", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        GalleryGrid(shown, Modifier.fillMaxSize())
    }
}



@Composable private fun PlayView(media: List<IrisGalleryMedia>, clusters: List<IrisTasteCluster>, onLearned: () -> Unit) {
    val context = LocalContext.current
    val pool = remember(media, clusters) {
        (clusters.flatMap { it.media.take(10) } + media.filter { !it.isScreenshot }.take(80))
            .distinctBy { it.uri }
    }
    var mode by remember { mutableStateOf("Versus") }
    var round by remember(pool) { mutableIntStateOf(0) }
    var learned by remember { mutableIntStateOf(IrisTasteProfile.totalSignals(context)) }
    fun advance() { round++; learned = IrisTasteProfile.totalSignals(context); onLearned() }

    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { SectionTitle("Play with your gallery", "Your photos become the game. Every choice quietly teaches Iris what catches your eye.") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Versus", "Swipe", "Memory")) { item -> FilterChip(mode == item, { mode = item; round++ }, { Text(item) }) }
            }
        }
        item { Text("$learned photos have preference signals", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
        if (pool.size < 4) item { Text("Add a few more gallery photos to play.", Modifier.padding(16.dp)) }
        else when (mode) {
            "Versus" -> item {
                val a = pool[(round * 2).mod(pool.size)]
                var bi = (round * 2 + 1).mod(pool.size); if (pool[bi].uri == a.uri) bi = (bi + 1).mod(pool.size)
                val b = pool[bi]
                Column(Modifier.padding(12.dp)) {
                    Text("Which one pulls you in?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("No rating scale. Just choose instinctively.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PlayPhoto(a, Modifier.weight(1f).height(270.dp)) { IrisTasteProfile.versus(context, a.uri, b.uri); advance() }
                        PlayPhoto(b, Modifier.weight(1f).height(270.dp)) { IrisTasteProfile.versus(context, b.uri, a.uri); advance() }
                    }
                    TextButton(onClick = { round++ }) { Text("Skip pair") }
                }
            }
            "Swipe" -> item {
                val item = pool[round.mod(pool.size)]
                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Gut reaction", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp)); RemoteImage(item.uri, Modifier.fillMaxWidth().height(360.dp), item.name)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { IrisTasteProfile.vote(context, item.uri, false); advance() }) { Text("Not me") }
                        Button(onClick = { IrisTasteProfile.vote(context, item.uri, true); advance() }) { Text("More like this") }
                    }
                }
            }
            else -> item {
                val base = pool[round.mod(pool.size)]
                val candidates = pool.filter { it.uri != base.uri }.drop((round * 3).mod(maxOf(1, pool.size - 1))).take(3).let { if (it.size < 3) (it + pool.filter { p -> p.uri != base.uri }).distinctBy { it.uri }.take(3) else it }
                Column(Modifier.padding(12.dp)) {
                    Text("Memory match", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("Pick the photo that feels closest to the reference. Your answer becomes a lightweight similarity hint.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp)); RemoteImage(base.uri, Modifier.fillMaxWidth().height(230.dp), base.name)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        candidates.forEach { candidate -> PlayPhoto(candidate, Modifier.weight(1f).height(150.dp)) { IrisTasteProfile.reinforce(context, base.uri, 1); IrisTasteProfile.reinforce(context, candidate.uri, 1); advance() } }
                    }
                }
            }
        }
        item { SectionTitle("Why this matters", "Play is not a separate gimmick: Versus gives pairwise preference, Swipe gives positive/negative preference, and Memory gives a similarity hint. All stay on-device.") }
    }
}

@Composable private fun PlayPhoto(item: IrisGalleryMedia, modifier: Modifier, onChoose: () -> Unit) {
    Card(modifier.clickable(onClick = onChoose)) { Box(Modifier.fillMaxSize()) { RemoteImage(item.uri, Modifier.fillMaxSize(), item.name) } }
}

@Composable private fun CreateView(clusters: List<IrisTasteCluster>, media: List<IrisGalleryMedia>, analyzing: Boolean) {
    val context = LocalContext.current
    if (analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()); return }
    val source = clusters.firstOrNull()?.media?.take(12) ?: media.filter { !it.isScreenshot }.take(12)
    if (source.isEmpty()) { Text("Add more photos to create a memory.", Modifier.padding(16.dp)); return }
    var playing by remember { mutableStateOf(false) }
    var frame by remember(source) { mutableIntStateOf(0) }
    LaunchedEffect(playing, source) {
        while (playing && source.isNotEmpty()) { delay(2200); frame = (frame + 1) % source.size }
    }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { SectionTitle("Create from what you already have", "No generative video bill. Iris uses photo sequencing, crop/zoom-ready frames and transitions.") }
        item {
            Card(Modifier.fillMaxWidth().padding(12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Taste Story", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("A lightweight memory assembled from your strongest current taste.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    Crossfade(targetState = source[frame.coerceIn(0, source.lastIndex)], label = "storyFrame") { item ->
                        RemoteImage(item.uri, Modifier.fillMaxWidth().height(310.dp).clickable { openGalleryItem(context, item) }, item.name)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { playing = !playing }) { Text(if (playing) "Pause" else "Play memory") }
                        AssistChip(onClick = {}, label = { Text("${source.size} photos") })
                        AssistChip(onClick = {}, label = { Text("~${source.size * 2}s") })
                    }
                }
            }
        }
        item { SectionTitle("Storyboard", "The project is only a list of media + timing, so it stays tiny until you choose to export later.") }
        item { GalleryStrip(source) }
        item { SectionTitle("Remix board", "A zero-generation mood board from the same taste group.") }
        item {
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                source.chunked(3).take(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { item -> GalleryThumb(item, Modifier.weight(1f).height(132.dp)) }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) { Text(title, style = MaterialTheme.typography.titleLarge); Text(subtitle, style = MaterialTheme.typography.bodySmall) }
}

@Composable private fun GalleryStrip(items: List<IrisGalleryMedia>) {
    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(items, key = { it.uri }) { item -> GalleryThumb(item, Modifier.size(112.dp)) } }
}

@Composable private fun GalleryThumb(item: IrisGalleryMedia, modifier: Modifier) {
    val context = LocalContext.current
    RemoteImage(item.uri, modifier.clickable { openGalleryItem(context, item) }, item.name)
}

@Composable private fun GalleryMediaRow(item: IrisGalleryMedia) {
    val context = LocalContext.current
    val badges = buildList { if (item.isFavorite) add("Favorite"); if (item.isIris) add("Iris"); if (item.isVideo) add("Video") else add("Image") }.joinToString(" · ")
    Row(Modifier.fillMaxWidth().clickable { openGalleryItem(context, item) }.padding(horizontal = 16.dp, vertical = 7.dp)) {
        RemoteImage(item.uri, Modifier.size(76.dp), item.name)
        Column(Modifier.padding(start = 12.dp)) { Text(item.name, style = MaterialTheme.typography.titleSmall, maxLines = 2); Text(badges, style = MaterialTheme.typography.labelSmall); Text(item.bucket, style = MaterialTheme.typography.bodySmall, maxLines = 1) }
    }
}

private fun openGalleryItem(context: android.content.Context, item: IrisGalleryMedia) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(Uri.parse(item.uri), item.mimeType); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
}
