/*
 * Iris Gallery fork of Pupil.
 * Pupil portions remain licensed under GPLv3; see app/LICENSE and FORK_NOTICE_KO.md.
 */
package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import xyz.quaver.pupil.source.GgoorrSource
import xyz.quaver.pupil.source.CareetSource
import xyz.quaver.pupil.source.SourceDetail
import xyz.quaver.pupil.source.SourceItem
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel
import xyz.quaver.pupil.util.IrisSourceActions

enum class IrisHomeSource(val label: String) { HITOMI("Hitomi"), GGOORR("Ggoorr"), CAREET("Careet") }

@Composable
fun IrisHomeScreen(
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
    searchViewModel: SearchViewModel,
    onViewerActiveChanged: (Boolean) -> Unit = {},
) {
    var selected by remember { mutableStateOf(IrisHomeSource.HITOMI) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("Search", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Search your sources. Source choice is a filter, not the destination.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))
            Row {
                FilterChip(
                    selected = selected == IrisHomeSource.HITOMI,
                    onClick = { selected = IrisHomeSource.HITOMI },
                    label = { Text("Hitomi") },
                )
                Spacer(Modifier.size(8.dp))
                FilterChip(
                    selected = selected == IrisHomeSource.GGOORR,
                    onClick = { selected = IrisHomeSource.GGOORR },
                    label = { Text("Ggoorr") },
                )
                Spacer(Modifier.size(8.dp))
                FilterChip(
                    selected = selected == IrisHomeSource.CAREET,
                    onClick = { selected = IrisHomeSource.CAREET },
                    label = { Text("Careet") },
                )
            }
        }

        when (selected) {
            IrisHomeSource.HITOMI -> SearchScreen(
                modifier = Modifier.weight(1f),
                onGalleryClick = onGalleryClick,
                onShowDetail = onShowDetail,
                viewModel = searchViewModel,
            )
            IrisHomeSource.GGOORR -> GgoorrSourceScreen(Modifier.weight(1f), onViewerActiveChanged)
            IrisHomeSource.CAREET -> CareetSourceScreen(Modifier.weight(1f), onViewerActiveChanged)
        }
    }
}


@Composable
private fun GgoorrSourceScreen(
    modifier: Modifier = Modifier,
    onViewerActiveChanged: (Boolean) -> Unit = {},
) {
    val source = remember { GgoorrSource() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var nextPage by remember { mutableStateOf<Int?>(null) }
    var detail by remember { mutableStateOf<SourceDetail?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    var saved by remember { mutableStateOf(false) }

    fun load(page: Int, append: Boolean) {
        if (loading || loadingMore) return
        scope.launch {
            if (append) loadingMore = true else loading = true
            error = null
            if (!append) detail = null
            try {
                val result = source.search(query, page)
                if (append) {
                    // Notice/sticky rows can repeat between board pages. Keep one Iris item per source ID.
                    items = (items + result.items).distinctBy { "${it.sourceId}:${it.remoteId}" }
                } else {
                    items = result.items.distinctBy { "${it.sourceId}:${it.remoteId}" }
                }
                nextPage = result.nextPage
            } catch (t: Throwable) {
                error = t.message ?: t.javaClass.simpleName
            } finally {
                if (append) loadingMore = false else loading = false
            }
        }
    }

    fun search() = load(page = 0, append = false)
    fun loadMore() = nextPage?.let { load(page = it, append = true) }

    LaunchedEffect(Unit) { search() }
    LaunchedEffect(detail) { onViewerActiveChanged(detail != null) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { onViewerActiveChanged(false) }
    }

    // Incremental loading: when the user gets near the end, request the next real Ggoorr board page.
    LaunchedEffect(listState) {
        snapshotFlow {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            last to listState.layoutInfo.totalItemsCount
        }.distinctUntilChanged().collect { (last, total) ->
            if (total > 0 && last >= total - 5 && !loading && !loadingMore && nextPage != null && detail == null) {
                loadMore()
            }
        }
    }

    val current = detail
    if (current != null) {
        IrisViewer(
            detail = current,
            headers = source.requestHeaders,
            saved = saved,
            onBack = { detail = null },
            onToggleSaved = { saved = IrisSourceActions.toggleSaved(context, current) },
            onDownload = { scope.launch { IrisSourceActions.download(context, current, source.requestHeaders) } },
            onShare = { IrisSourceActions.share(context, current) },
            onOriginal = { IrisSourceActions.openOriginal(context, current.item.pageUrl) },
        )
        return
    }

    Column(modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                label = { Text("Search Ggoorr") },
                singleLine = true,
            )
            Button(onClick = { search() }, modifier = Modifier.padding(start = 8.dp)) { Text("Go") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text("Source error: $it", modifier = Modifier.padding(vertical = 8.dp)) }

        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            items(items, key = { it.remoteId }) { item ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        scope.launch {
                            loading = true
                            error = null
                            try {
                                detail = source.detail(item.remoteId)
                                detail?.let {
                                    IrisSourceActions.recordHistory(context, it)
                                    saved = IrisSourceActions.isSaved(context, it)
                                }
                            } catch (t: Throwable) {
                                error = t.message ?: t.javaClass.simpleName
                            } finally { loading = false }
                        }
                    }.padding(vertical = 8.dp)
                ) {
                    RemoteImage(item.thumbnailUrl, Modifier.size(84.dp), item.title, headers = source.requestHeaders)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                        Text("Ggoorr", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (loadingMore) {
                item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 12.dp)) }
            }
            if (items.isNotEmpty() && nextPage == null) {
                item { Text("End of results", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(16.dp)) }
            }
        }
    }
}


@Composable
private fun CareetSourceScreen(
    modifier: Modifier = Modifier,
    onViewerActiveChanged: (Boolean) -> Unit = {},
) {
    val source = remember { CareetSource() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var sourceItems by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var nextPage by remember { mutableStateOf<Int?>(null) }
    var detail by remember { mutableStateOf<SourceDetail?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load(page: Int, append: Boolean) {
        if (loading || loadingMore) return
        scope.launch {
            if (append) loadingMore = true else loading = true
            error = null
            try {
                val result = source.search(query, page)
                sourceItems = if (append) (sourceItems + result.items).distinctBy { it.remoteId } else result.items.distinctBy { it.remoteId }
                nextPage = result.nextPage
            } catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
            finally { if (append) loadingMore = false else loading = false }
        }
    }

    fun search() = load(0, false)
    LaunchedEffect(Unit) { search() }
    LaunchedEffect(detail) { onViewerActiveChanged(detail != null) }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { onViewerActiveChanged(false) } }
    LaunchedEffect(listState) {
        snapshotFlow {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            last to listState.layoutInfo.totalItemsCount
        }.distinctUntilChanged().collect { (last, total) ->
            if (total > 0 && last >= total - 4 && !loading && !loadingMore && nextPage != null && detail == null) {
                nextPage?.let { load(it, true) }
            }
        }
    }

    detail?.let { current ->
        Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Button(onClick = { detail = null }) { Text("Back") }
                Spacer(Modifier.size(8.dp))
                Button(onClick = { IrisSourceActions.openOriginal(context, current.item.pageUrl) }) { Text("Open original") }
            }
            Spacer(Modifier.height(12.dp))
            Text(current.item.title, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text(current.description ?: "Careet 원문에서 확인하세요.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            current.imageUrls.firstOrNull()?.let { RemoteImage(it, Modifier.fillMaxWidth().height(260.dp), current.item.title, headers = source.requestHeaders) }
            Text("Careet의 공개 범위만 표시합니다. 멤버십 콘텐츠는 원문에서 확인하세요.", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 12.dp))
        }
        return
    }

    Column(modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), label = { Text("Search Careet memes") }, singleLine = true)
            Button(onClick = { search() }, Modifier.padding(start = 8.dp)) { Text("Go") }
        }
        Text("요즘 뜨는 밈 · Careet", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(vertical = 8.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text("Source error: $it", modifier = Modifier.padding(vertical = 8.dp)) }
        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            items(sourceItems, key = { it.remoteId }) { item ->
                Column(Modifier.fillMaxWidth().clickable {
                    scope.launch {
                        loading = true; error = null
                        try { detail = source.detail(item.remoteId) }
                        catch (t: Throwable) { error = t.message ?: t.javaClass.simpleName }
                        finally { loading = false }
                    }
                }.padding(vertical = 12.dp)) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                    if (item.tags.isNotEmpty()) Text(item.tags.joinToString(" · "), style = MaterialTheme.typography.labelSmall)
                }
            }
            if (loadingMore) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 12.dp)) }
        }
    }
}
