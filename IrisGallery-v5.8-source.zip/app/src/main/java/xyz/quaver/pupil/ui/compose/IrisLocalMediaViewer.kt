package xyz.quaver.pupil.ui.compose

import android.net.Uri
import android.os.Build
import android.util.Size
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisMediaState
import xyz.quaver.pupil.source.CareetMeme

/** Presentation lenses. Brand assets are Iris-owned; interaction/content grammar follows proven media patterns. */
enum class IrisGallerySkin(val label: String) { GALLERY("Photos"), VERTICAL("TikTok"), SOCIAL("Instagram"), BOARD("Pinterest"), WEBTOON("Webtoon") }

private data class PresentationCopy(
    val author: String,
    val meme: CareetMeme?,
    val label: String,
    val status: String,
    val source: String,
)

/** Presentation text now comes from the live Careet meme index, not synthetic personas/dialogue. */
private fun copyFor(x: IrisGalleryMedia, memes: List<CareetMeme>): PresentationCopy {
    val author = x.bucket.ifBlank { "iris.gallery" }.lowercase().replace(" ", ".").take(22)
    val seed = ((x.id xor x.dateAdded) and Long.MAX_VALUE).toInt()
    val meme = memes.getOrNull(if (memes.isEmpty()) 0 else Math.floorMod(seed, memes.size))
    return PresentationCopy(
        author = author,
        meme = meme,
        label = meme?.let { m ->
            when {
                m.usage.isNotBlank() -> "${m.name} · ${m.usage}"
                m.meaning.isNotBlank() -> "${m.name} · ${m.meaning.take(120)}"
                else -> m.name
            }
        } ?: "사용 가능한 Careet 밈 불러오는 중",
        status = meme?.status ?: "Careet",
        source = meme?.sourceTitle ?: "요즘 뜨는 밈",
    )
}

@Composable fun IrisLocalMediaViewer(item:IrisGalleryMedia,onClose:()->Unit){
    // Full-screen dialog keeps the player outside the weighted presentation layout.
    // Presentation lenses may recompose freely without owning the playback surface.
    Dialog(
        onDismissRequest=onClose,
        properties=DialogProperties(usePlatformDefaultWidth=false, decorFitsSystemWindows=false)
    ){
        BackHandler(onBack=onClose)
        Box(Modifier.fillMaxSize().background(Color.Black)){
            if(item.isVideo) IrisVideoPlayer(item.uri)
            else AsyncImage(item.uri,item.name,Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
            TextButton(onClick=onClose,modifier=Modifier.align(Alignment.TopStart).padding(8.dp)){
                Text("✕",color=Color.White,fontSize=22.sp)
            }
        }
    }
}

@Composable private fun IrisVideoPlayer(uri:String){
    val context=LocalContext.current
    val player=remember(uri){ExoPlayer.Builder(context).build().apply{setMediaItem(MediaItem.fromUri(Uri.parse(uri)));repeatMode=ExoPlayer.REPEAT_MODE_ONE;prepare();playWhenReady=true}}
    DisposableEffect(player){onDispose{player.release()}}
    AndroidView(factory={PlayerView(it).apply{this.player=player;useController=true;layoutParams=FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)}},update={it.player=player},modifier=Modifier.fillMaxSize())
}

@Composable private fun MediaSurface(item:IrisGalleryMedia,modifier:Modifier=Modifier,scale:ContentScale=ContentScale.Crop){
    if(!item.isVideo){AsyncImage(item.uri,item.name,modifier,contentScale=scale);return}
    val context=LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(null,item.uri){value=withContext(Dispatchers.IO){runCatching{if(Build.VERSION.SDK_INT>=29)context.contentResolver.loadThumbnail(Uri.parse(item.uri),Size(720,720),null) else android.provider.MediaStore.Video.Thumbnails.getThumbnail(context.contentResolver,item.id,android.provider.MediaStore.Video.Thumbnails.MINI_KIND,null)}.getOrNull()}}
    Box(modifier.background(Color.DarkGray),contentAlignment=Alignment.Center){bitmap?.let{Image(it.asImageBitmap(),item.name,Modifier.fillMaxSize(),contentScale=scale)};Icon(Icons.Default.PlayArrow,null,tint=Color.White,modifier=Modifier.size(42.dp))}
}

@Composable private fun StateActions(item:IrisGalleryMedia,dark:Boolean=false){
    val context=LocalContext.current;var keep by remember(item.uri){mutableStateOf(IrisMediaState.isKeep(context,item.uri))};var pin by remember(item.uri){mutableStateOf(IrisMediaState.isPinned(context,item.uri))};var trash by remember(item.uri){mutableStateOf(IrisMediaState.isTrash(context,item.uri))};val normal=if(dark)Color.White else LocalContentColor.current
    Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){IconButton(onClick={keep=IrisMediaState.toggleKeep(context,item.uri);if(keep){trash=false;pin=false}}){Icon(Icons.Default.Lock,"Keep",tint=if(keep)Color(0xFFFFD54F) else normal)};TextButton(onClick={pin=IrisMediaState.togglePin(context,item.uri);if(pin)trash=false},enabled=!keep){Text(if(pin)"📌" else "Pin",color=normal)};IconButton(onClick={trash=IrisMediaState.toggleTrash(context,item.uri)},enabled=!keep&&!pin){Icon(Icons.Default.Delete,"Trash",tint=if(trash)Color(0xFFFF5252) else normal)}}
}

@Composable private fun Avatar(item:IrisGalleryMedia,size:Int=34){Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFFECECEC))){MediaSurface(item,Modifier.fillMaxSize())}}

@Composable private fun InstagramPost(x:IrisGalleryMedia,memes:List<CareetMeme>,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x,memes)
    Column(Modifier.fillMaxWidth().padding(bottom=18.dp)){
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){Avatar(x);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(c.author,fontWeight=FontWeight.SemiBold,fontSize=13.sp);Text(x.bucket,fontSize=11.sp)};Text("•••",fontWeight=FontWeight.Bold)}
        MediaSurface(x,Modifier.fillMaxWidth().aspectRatio(1f).clickable{onOpen(x)})
        Row(Modifier.fillMaxWidth().height(48.dp),verticalAlignment=Alignment.CenterVertically){Text("♡",fontSize=28.sp,modifier=Modifier.padding(start=12.dp,end=14.dp));Text("○",fontSize=27.sp);Text("⌁",fontSize=28.sp,modifier=Modifier.padding(start=14.dp));Spacer(Modifier.weight(1f));StateActions(x)}
        Text("좋아요 ${(x.id%800)+24}개",fontWeight=FontWeight.SemiBold,fontSize=13.sp,modifier=Modifier.padding(horizontal=12.dp))
        Row(Modifier.padding(horizontal=12.dp,vertical=4.dp)){Text(c.author,fontWeight=FontWeight.Bold,fontSize=13.sp);Spacer(Modifier.width(5.dp));Text(c.label,fontSize=13.sp,maxLines=4,overflow=TextOverflow.Ellipsis)}
        Text("${c.status} · Careet",color=Color.Gray,fontSize=13.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=2.dp))
        Text(c.source,color=Color.Gray,fontSize=11.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=4.dp),maxLines=1,overflow=TextOverflow.Ellipsis)
    }
}

@Composable private fun TikTokItem(x:IrisGalleryMedia,memes:List<CareetMeme>,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x,memes)
    Box(Modifier.fillMaxSize().background(Color.Black)){
        MediaSurface(x,Modifier.fillMaxSize().clickable{onOpen(x)},ContentScale.Crop)
        Row(Modifier.align(Alignment.TopCenter).padding(top=16.dp),verticalAlignment=Alignment.CenterVertically){Text("Following",color=Color.White.copy(.75f),fontWeight=FontWeight.SemiBold);Spacer(Modifier.width(20.dp));Column(horizontalAlignment=Alignment.CenterHorizontally){Text("For You",color=Color.White,fontWeight=FontWeight.Bold);Box(Modifier.padding(top=4.dp).width(24.dp).height(2.dp).background(Color.White))}}
        Column(Modifier.align(Alignment.CenterEnd).padding(end=9.dp,bottom=80.dp),horizontalAlignment=Alignment.CenterHorizontally){Avatar(x,46);Spacer(Modifier.height(18.dp));Text("♥",color=Color.White,fontSize=30.sp);Text("${(x.id%900)+99}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(14.dp));Text("●",color=Color.White,fontSize=27.sp);Text("${(x.id%90)+4}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(8.dp));StateActions(x,true)}
        Column(Modifier.align(Alignment.Center).fillMaxWidth(.88f),horizontalAlignment=Alignment.CenterHorizontally){Text(c.label,color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=24.sp,lineHeight=29.sp);Spacer(Modifier.height(10.dp));Text(c.status,color=Color.White.copy(.8f),fontWeight=FontWeight.Bold,fontSize=13.sp)}
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(.78f).padding(14.dp)){Text("@${c.author}",color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp);Spacer(Modifier.height(6.dp));Text("#Careet  ${c.source}",color=Color.White,fontSize=13.sp,maxLines=2);Spacer(Modifier.height(8.dp));Text("Careet · 요즘 뜨는 밈",color=Color.White,fontSize=12.sp)}
    }
}

@Composable private fun WebtoonPanel(x:IrisGalleryMedia,index:Int,memes:List<CareetMeme>,onOpen:(IrisGalleryMedia)->Unit){
    val c=copyFor(x,memes);val light=index%2==0
    Column(Modifier.fillMaxWidth().background(if(light)Color.White else Color(0xFFF5F5F5))){
        if(index%3==0)Text("${c.status} · ${c.source}",Modifier.fillMaxWidth().padding(horizontal=28.dp,vertical=26.dp),fontSize=14.sp,lineHeight=22.sp)
        Box(Modifier.fillMaxWidth()){
            MediaSurface(x,Modifier.fillMaxWidth().height(if(x.isVideo)360.dp else 590.dp).clickable{onOpen(x)},ContentScale.Crop)
            Surface(modifier=Modifier.align(if(index%2==0)Alignment.TopStart else Alignment.TopEnd).padding(18.dp).widthIn(max=230.dp),shape=RoundedCornerShape(18.dp),color=Color.White.copy(.94f),shadowElevation=3.dp){Text(c.label,Modifier.padding(horizontal=16.dp,vertical=11.dp),fontSize=14.sp,lineHeight=20.sp,color=Color.Black)}
        }
        if(index%4==2)Text("…",Modifier.fillMaxWidth().padding(30.dp),fontSize=30.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(if(index%3==1)34.dp else 8.dp))
    }
}

@Composable fun IrisSkinnedGallery(
    items: List<IrisGalleryMedia>,
    skin: IrisGallerySkin,
    onOpen: (IrisGalleryMedia) -> Unit,
    modifier: Modifier = Modifier,
    careetMemes: List<CareetMeme> = emptyList()
) {
    when (skin) {
        IrisGallerySkin.GALLERY -> LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(items.size, key = { items[it].uri }) { i ->
                val x = items[i]
                Box(Modifier.aspectRatio(1f).clickable { onOpen(x) }) {
                    MediaSurface(x, Modifier.fillMaxSize())
                    if (IrisMediaState.isKeep(LocalContext.current, x.uri)) {
                        Text("🔒", Modifier.align(Alignment.TopEnd).padding(5.dp))
                    }
                }
            }
        }

        IrisGallerySkin.VERTICAL -> LazyColumn(modifier.fillMaxSize().background(Color.Black)) {
            items(items, key = { "v:${it.uri}" }) { x ->
                Box(Modifier.fillParentMaxSize()) { TikTokItem(x, careetMemes, onOpen) }
            }
        }

        IrisGallerySkin.SOCIAL -> LazyColumn(modifier.fillMaxSize().background(Color.White)) {
            item {
                Column {
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Iris", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                        Spacer(Modifier.weight(1f))
                        Text("♡   ⊕", fontSize = 23.sp)
                    }
                    Row(
                        Modifier.fillMaxWidth().height(92.dp).padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items.take(6).forEach { story ->
                            Column(
                                modifier = Modifier.width(58.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    Modifier.padding(4.dp).size(54.dp).clip(CircleShape)
                                        .background(Color(0xFFFFE0E8))
                                ) { MediaSurface(story, Modifier.fillMaxSize()) }
                                Text(copyFor(story, careetMemes).author.take(8), fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
            items(items, key = { "i:${it.uri}" }) { InstagramPost(it, careetMemes, onOpen) }
        }

        IrisGallerySkin.BOARD -> LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items.size, key = { items[it].uri }) { i ->
                val x = items[i]
                Column {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        MediaSurface(
                            x,
                            Modifier.fillMaxWidth()
                                .aspectRatio(if (i % 4 == 0) .68f else if (i % 3 == 0) .78f else .9f)
                                .clickable { onOpen(x) }
                        )
                    }
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${copyFor(x, careetMemes).status}: ${copyFor(x, careetMemes).label}", Modifier.weight(1f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("•••", Modifier.padding(6.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(x, 22); Spacer(Modifier.width(5.dp))
                        Text("Careet", fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }
        }

        IrisGallerySkin.WEBTOON -> LazyColumn(modifier.fillMaxSize().background(Color.White)) {
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("IRIS ORIGINAL", fontSize = 11.sp, color = Color.Gray)
                    Text("기억의 조각들", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("EP. 01  다시 발견한 장면", fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                    Text("내 갤러리의 사진으로 구성된 개인 에피소드", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
                }
            }
            items(items.size, key = { "w:${items[it].uri}" }) { i -> WebtoonPanel(items[i], i, careetMemes, onOpen) }
            item {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("EP. 01 END", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("♡ 좋아요   ·   댓글   ·   다음 에피소드", fontSize = 14.sp)
                    Spacer(Modifier.height(36.dp))
                }
            }
        }
    }
}
