package xyz.quaver.pupil.util

import android.content.Context
import kotlin.math.abs

enum class IrisRecommendationMode { TIKTOK, INSTAGRAM, PINTEREST }

/** Device-only ranking. Reproduces the observable mechanics of successful feeds without pretending to clone server models. */
object IrisRecommendationEngine {
    fun opened(context: Context, item: IrisGalleryMedia) = IrisTasteProfile.reinforce(context, item.uri, 1)

    fun rank(context: Context, media: List<IrisGalleryMedia>, mode: IrisRecommendationMode, anchor: IrisGalleryMedia? = null): List<IrisGalleryMedia> {
        if (media.isEmpty()) return media
        if (mode == IrisRecommendationMode.PINTEREST && anchor != null) {
            val related = IrisTasteEngine.related(context, anchor, media, 160)
            if (related.isNotEmpty()) return listOf(anchor) + related.filter { it.uri != anchor.uri }
        }
        val now = System.currentTimeMillis() / 1000L
        val scored = media.map { item ->
            val explicit = IrisTasteProfile.signal(context, item.uri).toDouble()
            val favorite = if (item.isFavorite) 8.0 else 0.0
            val keep = if (IrisMediaState.isKeep(context, item.uri)) 14.0 else 0.0
            val trash = if (IrisMediaState.isTrash(context, item.uri)) -40.0 else 0.0
            val iris = if (item.isIris) 2.5 else 0.0
            val ageDays = ((now - item.dateAdded).coerceAtLeast(0L) / 86400.0)
            val recency = (6.0 - ageDays / 7.0).coerceAtLeast(0.0)
            val score = when (mode) {
                IrisRecommendationMode.TIKTOK -> explicit * 2.4 + favorite + keep + trash + iris + recency * 1.3
                IrisRecommendationMode.INSTAGRAM -> explicit * 1.7 + favorite * 1.25 + keep + trash + iris + recency
                IrisRecommendationMode.PINTEREST -> explicit + favorite + keep + trash + iris + recency * .35
            }
            item to score
        }.sortedByDescending { it.second }.map { it.first }

        if (mode != IrisRecommendationMode.INSTAGRAM) return scored
        // Feed diversity: avoid long runs from one bucket/source while preserving the preference order.
        val remaining = scored.toMutableList(); val out = ArrayList<IrisGalleryMedia>(scored.size)
        var lastBucket = ""; var run = 0
        while (remaining.isNotEmpty()) {
            val idx = if (run >= 2) remaining.indexOfFirst { it.bucket != lastBucket }.takeIf { it >= 0 } ?: 0 else 0
            val x = remaining.removeAt(idx)
            if (x.bucket == lastBucket) run++ else { lastBucket = x.bucket; run = 1 }
            out += x
        }
        return out
    }
}
