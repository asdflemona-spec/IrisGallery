package xyz.quaver.pupil.ui.compose

import android.net.Uri
import android.os.Build
import android.util.Size
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisGalleryMedia
import xyz.quaver.pupil.util.IrisMediaState

/** Independent gallery lenses: consumption, rediscovery, cleanup, place, statistics and fast chronology. */
enum class IrisGallerySkin(val label: String) { VERTICAL("TikTok"), SOCIAL("Instagram"), BOARD("Pinterest"), MEMORIES("Memories"), REVIEW("Review"), MAP("Map"), RECAP("Recap"), FILMSTRIP("Filmstrip") }

private fun displayName(x: IrisGalleryMedia): String = x.name.substringBeforeLast('.').replace('_',' ').replace('-',' ').take(48).ifBlank { "Iris" }
private fun authorName(x: IrisGalleryMedia): String = x.bucket.ifBlank { "iris.gallery" }.lowercase().replace(" ", ".").take(22)

@Composable fun IrisLocalMediaViewer(item:IrisGalleryMedia,onClose:()->Unit){
    // Full-screen dialog keeps the player outside the weighted presentation layout.
    // Presentation lenses may recompose freely without owning the playback surface.
    Dialog(
        onDismissRequest=onClose,
        properties=DialogProperties(usePlatformDefaultWidth=false, decorFitsSystemWindows=false)
    ){
        BackHandler(onBack=onClose)
        Box(Modifier.fillMaxSize().background(Color.Black)){
            if(item.isVideo) IrisVideoPlayer(item.uri)
            else AsyncImage(item.uri,item.name,Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
            TextButton(onClick=onClose,modifier=Modifier.align(Alignment.TopStart).padding(8.dp)){
                Text("✕",color=Color.White,fontSize=22.sp)
            }
        }
    }
}

@Composable private fun IrisVideoPlayer(uri:String){
    val context=LocalContext.current
    val player=remember(uri){ExoPlayer.Builder(context).build().apply{setMediaItem(MediaItem.fromUri(Uri.parse(uri)));repeatMode=ExoPlayer.REPEAT_MODE_ONE;prepare();playWhenReady=true}}
    DisposableEffect(player){onDispose{player.release()}}
    AndroidView(factory={PlayerView(it).apply{this.player=player;useController=true;layoutParams=FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)}},update={it.player=player},modifier=Modifier.fillMaxSize())
}

@Composable private fun MediaSurface(item:IrisGalleryMedia,modifier:Modifier=Modifier,scale:ContentScale=ContentScale.Crop){
    if(!item.isVideo){AsyncImage(item.uri,item.name,modifier,contentScale=scale);return}
    val context=LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(null,item.uri){value=withContext(Dispatchers.IO){runCatching{if(Build.VERSION.SDK_INT>=29)context.contentResolver.loadThumbnail(Uri.parse(item.uri),Size(720,720),null) else android.provider.MediaStore.Video.Thumbnails.getThumbnail(context.contentResolver,item.id,android.provider.MediaStore.Video.Thumbnails.MINI_KIND,null)}.getOrNull()}}
    Box(modifier.background(Color.DarkGray),contentAlignment=Alignment.Center){bitmap?.let{Image(it.asImageBitmap(),item.name,Modifier.fillMaxSize(),contentScale=scale)};Icon(Icons.Default.PlayArrow,null,tint=Color.White,modifier=Modifier.size(42.dp))}
}

@Composable private fun StateActions(item:IrisGalleryMedia,dark:Boolean=false){
    val context=LocalContext.current;var keep by remember(item.uri){mutableStateOf(IrisMediaState.isKeep(context,item.uri))};var trash by remember(item.uri){mutableStateOf(IrisMediaState.isTrash(context,item.uri))};val normal=if(dark)Color.White else LocalContentColor.current
    Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){IconButton(onClick={keep=IrisMediaState.toggleKeep(context,item.uri);if(keep)trash=false}){Icon(Icons.Default.Lock,"Keep",tint=if(keep)Color(0xFFFFD54F) else normal)};IconButton(onClick={trash=IrisMediaState.toggleTrash(context,item.uri)},enabled=!keep){Icon(Icons.Default.Delete,"Trash",tint=if(trash)Color(0xFFFF5252) else normal)}}
}

@Composable private fun Avatar(item:IrisGalleryMedia,size:Int=34){Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFFECECEC))){MediaSurface(item,Modifier.fillMaxSize())}}

@Composable private fun InstagramPost(x:IrisGalleryMedia,onOpen:(IrisGalleryMedia)->Unit){
    Column(Modifier.fillMaxWidth().padding(bottom=18.dp)){
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){Avatar(x);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(authorName(x),fontWeight=FontWeight.SemiBold,fontSize=13.sp);Text(x.bucket,fontSize=11.sp)};Text("•••",fontWeight=FontWeight.Bold)}
        MediaSurface(x,Modifier.fillMaxWidth().aspectRatio(1f).clickable{onOpen(x)})
        Row(Modifier.fillMaxWidth().height(48.dp),verticalAlignment=Alignment.CenterVertically){Text("♡",fontSize=28.sp,modifier=Modifier.padding(start=12.dp,end=14.dp));Text("○",fontSize=27.sp);Text("⌁",fontSize=28.sp,modifier=Modifier.padding(start=14.dp));Spacer(Modifier.weight(1f));StateActions(x)}
        Text("좋아요 ${(x.id%800)+24}개",fontWeight=FontWeight.SemiBold,fontSize=13.sp,modifier=Modifier.padding(horizontal=12.dp))
        Row(Modifier.padding(horizontal=12.dp,vertical=4.dp)){Text(authorName(x),fontWeight=FontWeight.Bold,fontSize=13.sp);Spacer(Modifier.width(5.dp));Text(displayName(x),fontSize=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis)}
        Text("1시간 전",color=Color.Gray,fontSize=10.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=6.dp))
    }
}

@Composable private fun TikTokItem(x:IrisGalleryMedia,onOpen:(IrisGalleryMedia)->Unit){
    Box(Modifier.fillMaxSize().background(Color.Black)){
        MediaSurface(x,Modifier.fillMaxSize().clickable{onOpen(x)},ContentScale.Crop)
        Row(Modifier.align(Alignment.TopCenter).padding(top=16.dp),verticalAlignment=Alignment.CenterVertically){Text("Following",color=Color.White.copy(.75f),fontWeight=FontWeight.SemiBold);Spacer(Modifier.width(20.dp));Column(horizontalAlignment=Alignment.CenterHorizontally){Text("For You",color=Color.White,fontWeight=FontWeight.Bold);Box(Modifier.padding(top=4.dp).width(24.dp).height(2.dp).background(Color.White))}}
        Column(Modifier.align(Alignment.CenterEnd).padding(end=9.dp,bottom=80.dp),horizontalAlignment=Alignment.CenterHorizontally){Avatar(x,46);Spacer(Modifier.height(18.dp));Text("♥",color=Color.White,fontSize=30.sp);Text("${(x.id%900)+99}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(14.dp));Text("●",color=Color.White,fontSize=27.sp);Text("${(x.id%90)+4}",color=Color.White,fontSize=11.sp);Spacer(Modifier.height(8.dp));StateActions(x,true)}
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(.78f).padding(14.dp)){Text("@${authorName(x)}",color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp);Spacer(Modifier.height(6.dp));Text(displayName(x),color=Color.White,fontSize=13.sp,maxLines=2);Spacer(Modifier.height(8.dp));Text("♫ original sound · ${authorName(x)}",color=Color.White,fontSize=12.sp)}
    }
}

@Composable private fun IrisMemories(items: List<IrisGalleryMedia>, onOpen: (IrisGalleryMedia) -> Unit) {
    val groups = remember(items) { items.sortedByDescending { it.dateAdded }.groupBy { SimpleDateFormat("yyyy년 M월", Locale.KOREA).format(Date(it.dateAdded)) } }
    LazyColumn(Modifier.fillMaxSize().background(Color.Black), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Text("Memories", color=Color.White, fontWeight=FontWeight.Bold, fontSize=28.sp, modifier=Modifier.padding(18.dp)) }
        groups.forEach { (month, media) ->
            item { Text(month, color=Color.White, fontWeight=FontWeight.SemiBold, fontSize=18.sp, modifier=Modifier.padding(horizontal=16.dp, vertical=10.dp)) }
            item { Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=12.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                media.take(12).forEach { x -> Card(Modifier.width(190.dp).height(280.dp).clickable{onOpen(x)}, shape=RoundedCornerShape(18.dp)) { Box { MediaSurface(x,Modifier.fillMaxSize()); Text(displayName(x),color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.BottomStart).background(Color.Black.copy(.35f)).fillMaxWidth().padding(10.dp)) } } }
            } }
        }
    }
}

@Composable private fun IrisReview(items: List<IrisGalleryMedia>, onOpen: (IrisGalleryMedia) -> Unit) {
    val context=LocalContext.current; var index by remember(items){ mutableIntStateOf(0) }; var dx by remember{mutableStateOf(0f)}; var dy by remember{mutableStateOf(0f)}
    fun act(kind:String){ items.getOrNull(index)?.let{x-> when(kind){"keep"->IrisMediaState.setKeep(context,x.uri,true);"trash"->IrisMediaState.setTrash(context,x.uri,true);"fav"->IrisMediaState.toggleFavorite(context,x.uri)} }; index++ ; dx=0f;dy=0f }
    val x=items.getOrNull(index)
    Column(Modifier.fillMaxSize().padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Text("Review",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("← Trash   ↑ Favorite   Keep →",color=Color.Gray,fontSize=12.sp);Spacer(Modifier.height(12.dp))
        if(x==null){Box(Modifier.weight(1f),contentAlignment=Alignment.Center){Text("Review complete")}} else Card(Modifier.weight(1f).fillMaxWidth().pointerInput(index){detectDragGestures(onDragEnd={when{dx>180->act("keep");dx< -180->act("trash");dy< -180->act("fav")};dx=0f;dy=0f}){c,a->c.consume();dx+=a.x;dy+=a.y}}.clickable{onOpen(x)},shape=RoundedCornerShape(24.dp)){MediaSurface(x,Modifier.fillMaxSize())}
        if(x!=null){Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(18.dp)){Button(onClick={act("trash")}){Text("Trash")};Button(onClick={act("fav")}){Text("Favorite")};Button(onClick={act("keep")}){Text("Keep")}};Text("${index+1} / ${items.size}",modifier=Modifier.padding(8.dp),fontSize=12.sp,color=Color.Gray)}
    }
}

@Composable private fun IrisMap(items: List<IrisGalleryMedia>) {
    Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("Places",fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Text("위치 정보가 확인된 미디어만 지도에 표시됩니다.",fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(8.dp));Text("현재 Iris의 MediaStore 인덱스에는 좌표를 추측해서 넣지 않습니다. 위치 메타데이터가 없는 항목은 Map에서 제외됩니다.",color=Color.Gray);Spacer(Modifier.height(20.dp));Text("Indexed media: ${items.size}",fontSize=12.sp,color=Color.Gray)}
}

@Composable private fun IrisRecap(items: List<IrisGalleryMedia>) {
    val videos=items.count{it.isVideo}; val images=items.size-videos; val months=remember(items){items.groupBy{SimpleDateFormat("yyyy-MM",Locale.US).format(Date(it.dateAdded))}.mapValues{it.value.size}.toList().sortedByDescending{it.second}}
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFF111111)),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{Text("Your Recap",color=Color.White,fontSize=32.sp,fontWeight=FontWeight.Black)}
        item{Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(26.dp)){Column(Modifier.padding(24.dp)){Text("${items.size}",fontSize=48.sp,fontWeight=FontWeight.Black);Text("moments in your library")}}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Card(Modifier.weight(1f)){Column(Modifier.padding(18.dp)){Text("$images",fontSize=30.sp,fontWeight=FontWeight.Bold);Text("Photos")}};Card(Modifier.weight(1f)){Column(Modifier.padding(18.dp)){Text("$videos",fontSize=30.sp,fontWeight=FontWeight.Bold);Text("Videos")}}}}
        items(months.take(6)){m->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(18.dp)){Text(m.first,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("${m.second} items")}}}
    }
}

@Composable private fun IrisFilmstrip(items: List<IrisGalleryMedia>, onOpen:(IrisGalleryMedia)->Unit){
    LazyColumn(Modifier.fillMaxSize().background(Color.Black),contentPadding=PaddingValues(vertical=6.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){items(items.sortedByDescending{it.dateAdded},key={"f:${it.uri}"}){x->Row(Modifier.fillMaxWidth().height(92.dp).clickable{onOpen(x)},verticalAlignment=Alignment.CenterVertically){MediaSurface(x,Modifier.width(92.dp).fillMaxHeight());Column(Modifier.padding(12.dp).weight(1f)){Text(displayName(x),color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis);Text(SimpleDateFormat("yyyy.MM.dd  HH:mm",Locale.KOREA).format(Date(x.dateAdded)),color=Color.Gray,fontSize=11.sp);Text(x.bucket,color=Color.Gray,fontSize=11.sp)}}}}
}

@Composable fun IrisSkinnedGallery(
    items: List<IrisGalleryMedia>,
    skin: IrisGallerySkin,
    onOpen: (IrisGalleryMedia) -> Unit,
    modifier: Modifier = Modifier
) {
    when (skin) {
        IrisGallerySkin.VERTICAL -> LazyColumn(modifier.fillMaxSize().background(Color.Black)) {
            items(items, key = { "v:${it.uri}" }) { x ->
                Box(Modifier.fillParentMaxSize()) { TikTokItem(x, onOpen) }
            }
        }

        IrisGallerySkin.SOCIAL -> LazyColumn(modifier.fillMaxSize().background(Color.White)) {
            item {
                Column {
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Iris", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                        Spacer(Modifier.weight(1f))
                        Text("♡   ⊕", fontSize = 23.sp)
                    }
                    Row(
                        Modifier.fillMaxWidth().height(92.dp).padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items.take(6).forEach { story ->
                            Column(
                                modifier = Modifier.width(58.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    Modifier.padding(4.dp).size(54.dp).clip(CircleShape)
                                        .background(Color(0xFFFFE0E8))
                                ) { MediaSurface(story, Modifier.fillMaxSize()) }
                                Text(authorName(story).take(8), fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
            items(items, key = { "i:${it.uri}" }) { InstagramPost(it, onOpen) }
        }

        IrisGallerySkin.BOARD -> LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items.size, key = { items[it].uri }) { i ->
                val x = items[i]
                Column {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        MediaSurface(
                            x,
                            Modifier.fillMaxWidth()
                                .aspectRatio(if (i % 4 == 0) .68f else if (i % 3 == 0) .78f else .9f)
                                .clickable { onOpen(x) }
                        )
                    }
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(displayName(x), Modifier.weight(1f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("•••", Modifier.padding(6.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(x, 22); Spacer(Modifier.width(5.dp))
                        Text(authorName(x), fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }
        }

        IrisGallerySkin.MEMORIES -> IrisMemories(items, onOpen)
        IrisGallerySkin.REVIEW -> IrisReview(items, onOpen)
        IrisGallerySkin.MAP -> IrisMap(items)
        IrisGallerySkin.RECAP -> IrisRecap(items)
        IrisGallerySkin.FILMSTRIP -> IrisFilmstrip(items, onOpen)
    }
}
