package xyz.quaver.pupil.ui

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AlertDialog
import xyz.quaver.pupil.util.IrisSharedSourceStore

class IrisShareReceiverActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent.action != Intent.ACTION_SEND) { finish(); return }

        val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val url = IrisSharedSourceStore.firstUrl(text)
        val source = IrisSharedSourceStore.detectSource(url ?: text)
        val stream: Uri? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)

        if (source == null && stream == null) {
            AlertDialog.Builder(this).setTitle("Iris Gallery").setMessage("Pinterest 또는 X 공유 링크/미디어를 찾지 못했어요.")
                .setPositiveButton("확인") { _, _ -> finish() }.setOnCancelListener { finish() }.show()
            return
        }
        val label = if (source == "pinterest") "Pinterest" else if (source == "x") "X" else "공유 미디어"
        val details = buildString {
            append("${label}에서 받은 항목을 Iris에 저장할까요?")
            if (url != null) append("\n\n$url")
            if (stream != null) append("\n\n미디어 파일 포함")
        }
        AlertDialog.Builder(this).setTitle("Iris에 저장").setMessage(details)
            .setNegativeButton("취소") { _, _ -> finish() }
            .setPositiveButton("저장") { _, _ ->
                if (url != null && source != null) IrisSharedSourceStore.save(this, url, source)
                if (stream != null) runCatching { importMedia(stream, source ?: "shared") }
                finish()
            }.setOnCancelListener { finish() }.show()
    }

    private fun importMedia(uri: Uri, source: String) {
        val mime = contentResolver.getType(uri) ?: "image/jpeg"
        val video = mime.startsWith("video/")
        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val ext = if (video) "mp4" else if (mime.contains("png")) "png" else "jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "iris_${source}_${System.currentTimeMillis()}.$ext")
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, (if (video) "Movies" else "Pictures") + "/Iris/$source")
        }
        val dest = contentResolver.insert(collection, values) ?: return
        contentResolver.openInputStream(uri).use { input -> contentResolver.openOutputStream(dest).use { output ->
            if (input != null && output != null) input.copyTo(output)
        }}
    }
}
