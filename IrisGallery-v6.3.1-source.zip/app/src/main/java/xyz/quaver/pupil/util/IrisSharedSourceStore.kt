package xyz.quaver.pupil.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class IrisSharedSourceItem(val url: String, val source: String, val savedAt: Long)

object IrisSharedSourceStore {
    private const val PREFS = "iris_shared_sources"
    private const val KEY = "items"

    fun detectSource(text: String): String? {
        val lower = text.lowercase()
        return when {
            "pinterest.com" in lower || "pin.it" in lower -> "pinterest"
            "x.com" in lower || "twitter.com" in lower -> "x"
            else -> null
        }
    }

    fun firstUrl(text: String): String? = Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE)
        .find(text)?.value?.trimEnd('.', ',', ')', ']', '}')

    fun save(context: Context, url: String, source: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        val out = JSONArray()
        out.put(JSONObject().put("url", url).put("source", source).put("savedAt", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 199)) {
            val obj = old.optJSONObject(i) ?: continue
            if (obj.optString("url") != url) out.put(obj)
        }
        prefs.edit().putString(KEY, out.toString()).apply()
    }

    fun list(context: Context, source: String? = null): List<IrisSharedSourceItem> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val item = IrisSharedSourceItem(o.optString("url"), o.optString("source"), o.optLong("savedAt"))
                if (item.url.isNotBlank() && (source == null || item.source == source)) add(item)
            }
        }
    }

    fun openOriginal(context: Context, url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }
}
