# Iris Gallery v5.1 — High-Fidelity Presentation

- Instagram lens: profile/story chrome, author identity, likes, caption, comment preview, timestamp.
- TikTok lens: full-bleed vertical feed, Following/For You chrome, action rail, author/caption/sound metadata.
- Webtoon lens: episode header, narrative pacing, speech bubbles, narration and episode ending chrome.
- Pinterest lens: rounded variable-ratio pins, creator row and descriptive metadata.
- Existing Photos lens, Keep/Trash shared state and Media3 local video playback retained.
- Presentation text is local/deterministic and does not modify original media metadata.
