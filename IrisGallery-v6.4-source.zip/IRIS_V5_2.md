# Iris v5.2 — Stable Core + Human Presentation

- Video viewer moved into an independent full-screen Dialog so presentation lens layout/recomposition cannot constrain the playback surface.
- Media3 player remains pinned to 1.8.0 for minSdk 21 compatibility.
- Presentation copy now uses stable recurring Iris personas with heterogeneous speech patterns instead of one anonymous repeated commenter.
- Instagram captions/comments and Webtoon dialogue/narration are deterministic per media item so reopening an item preserves its social/story identity.
- Original MediaStore metadata is never modified by presentation text.
