# Iris Gallery v5.9 — Reset + Recommendation Engine

- Reset base to v5.2 (Hitomi + Ggoorr only).
- Presentation lenses reduced to TikTok, Instagram, Pinterest.
- Removed Webtoon/meme/Careet work from the active branch by rebuilding from v5.2.
- TikTok ranking: explicit interaction, Keep/Favorite, recency, Iris media; Trash strongly suppressed.
- Instagram ranking: preference ranking plus source/bucket diversity.
- Pinterest ranking: last-opened media becomes the anchor; local 8x8 visual features rank related media.
- Opening media feeds a local interaction signal. Keep and Trash are stronger explicit signals.
- v5.2 full-screen Media3 video player is unchanged.
