# Iris Gallery v6.0

- Returned to the Hitomi + Ggoorr baseline.
- Removed IrisRecommendationEngine and interaction-based media ranking.
- TikTok, Instagram and Pinterest lenses now use a fresh random media order when switching lenses.
- Keep/Trash no longer train a recommendation score.
- Added Iris Chat lens: messenger-style bubbles, compact Korean small-talk, split replies, and random local gallery media messages.
- Preserved the v5.2 full-screen Media3 video player baseline.
