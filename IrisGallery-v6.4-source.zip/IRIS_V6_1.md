# Iris Gallery v6.1 — Gallery Lenses

- Removed Chat lens.
- Lenses: TikTok, Instagram, Pinterest, Memories, Review, Map, Recap, Filmstrip.
- Recommendation ranking remains out of the lens path; random media order is used for discovery feeds.
- Memories groups media by month.
- Review maps swipe/actions to Trash, Favorite and Keep.
- Map intentionally does not fabricate locations when coordinate metadata is unavailable.
- Recap summarizes local library counts and monthly activity.
- Filmstrip provides dense chronological browsing.
- v5.2 full-screen Media3 video viewer retained unchanged.
