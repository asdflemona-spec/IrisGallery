# Iris Gallery v6.2

- Removed Map lens.
- Removed Filmstrip lens.
- Review media now uses ContentScale.Fit so the complete photo/video thumbnail stays visible.
- TikTok media now uses ContentScale.Fit with a black letterbox background instead of cropping.
- Instagram main post media now uses ContentScale.Fit with a black letterbox background instead of cropping.
- Remaining lenses: TikTok, Instagram, Pinterest, Memories, Review, Recap.
- Full-screen viewer/video playback architecture remains unchanged.
