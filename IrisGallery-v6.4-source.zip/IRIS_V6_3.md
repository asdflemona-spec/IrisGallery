# Iris Gallery v6.3 — Share Bridge

- Adds Android Sharesheet receiver for Pinterest/X links and shared image/video streams.
- Shows a confirmation preview before importing.
- Shared media streams are copied to Pictures/Iris/<source> or Movies/Iris/<source>.
- Original Pinterest/X URLs are stored locally and exposed as Library source chips.
- Tapping a stored source URL uses ACTION_VIEW, allowing the official app to handle its own links with browser fallback.
- No OAuth, cookie/session access, scraping, or private API integration.
- v6.2 gallery lenses and media-fit fixes are otherwise unchanged.
