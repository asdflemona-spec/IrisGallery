# Iris v6.3.1

- Fix Kotlin string interpolation in IrisShareReceiverActivity (`${label}에서`).
- No behavior changes from v6.3.
