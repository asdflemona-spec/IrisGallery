# Iris Gallery v6.4 — Universal Download Manager

- Removed v6.3 Pinterest/X source and share-link storage integration.
- Added generic Android share target for HTTP/HTTPS download URLs.
- Added Library > Downloads with direct URL input, queue/status/progress and cancel.
- External downloads use Android's persistent DownloadManager and save to Downloads/Iris.
- Existing Hitomi/Ggoorr download paths and the proven Iris video player are left untouched.

## Scope note
This is the stable universal-download foundation. It does not yet claim 1DM-style segmented multi-connection, manual pause/resume, or arbitrary webpage stream extraction. Those require a dedicated transfer engine rather than pretending platform DownloadManager provides them.
