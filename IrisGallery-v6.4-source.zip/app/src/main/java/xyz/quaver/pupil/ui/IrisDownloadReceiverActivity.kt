package xyz.quaver.pupil.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import xyz.quaver.pupil.util.IrisUniversalDownloader

class IrisDownloadReceiverActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = when (intent.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            Intent.ACTION_VIEW -> intent.dataString.orEmpty()
            else -> ""
        }
        val url = IrisUniversalDownloader.firstUrl(text)
        if (url == null) {
            AlertDialog.Builder(this).setTitle("Iris Download").setMessage("다운로드할 HTTP/HTTPS 링크를 찾지 못했어요.")
                .setPositiveButton("확인") { _, _ -> finish() }.setOnCancelListener { finish() }.show()
            return
        }
        AlertDialog.Builder(this).setTitle("Iris로 다운로드").setMessage(url)
            .setNegativeButton("취소") { _, _ -> finish() }
            .setPositiveButton("다운로드") { _, _ ->
                runCatching { IrisUniversalDownloader.enqueue(this, url) }
                    .onFailure { e -> AlertDialog.Builder(this).setMessage(e.message ?: "다운로드 등록 실패").setPositiveButton("확인") { _, _ -> finish() }.show() }
                    .onSuccess { finish() }
            }.setOnCancelListener { finish() }.show()
    }
}
