package xyz.quaver.pupil.ui.compose

import android.app.DownloadManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import xyz.quaver.pupil.util.IrisUniversalDownloader

enum class IrisLibrarySource { ALL, HITOMI, GGOORR, DOWNLOADS, GALLERY }

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var source by remember { mutableStateOf(IrisLibrarySource.ALL) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(top = 12.dp, bottom = 8.dp)) {
            Text("Library", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(horizontal = 16.dp))
            Text("Your personal visual library", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(8.dp))
            val sources = listOf(IrisLibrarySource.ALL to "All", IrisLibrarySource.HITOMI to "Hitomi", IrisLibrarySource.GGOORR to "Ggoorr", IrisLibrarySource.DOWNLOADS to "Downloads", IrisLibrarySource.GALLERY to "Gallery")
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sources) { (value, label) -> FilterChip(source == value, { source = value }, { Text(label) }) }
            }
        }
        when (source) {
            IrisLibrarySource.GALLERY -> IrisGallerySection(Modifier.weight(1f))
            IrisLibrarySource.DOWNLOADS -> IrisUniversalDownloads(Modifier.weight(1f))
            else -> {
                TabRow(selectedTabIndex = tab) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("Saved") })
                    Tab(tab == 1, { tab = 1 }, text = { Text("History") })
                    Tab(tab == 2, { tab = 2 }, text = { Text("Offline") })
                }
                IrisLibraryPage(tab, source, onGalleryClick, onShowDetail, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun IrisLibraryPage(tab: Int, source: IrisLibrarySource, onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit, modifier: Modifier) {
    val irisFilter = when (tab) { 0 -> IrisLibraryFilter.SAVED; 1 -> IrisLibraryFilter.HISTORY; else -> IrisLibraryFilter.DOWNLOADED }
    Column(modifier) {
        if (source != IrisLibrarySource.GGOORR) {
            Text("Hitomi", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp))
            when (tab) {
                0 -> FavoritesScreen(Modifier.weight(1f), onGalleryClick, onShowDetail, includeIris = false)
                1 -> HistoryScreen(Modifier.weight(1f), onGalleryClick, onShowDetail, includeIris = false)
                else -> DownloadsScreen(Modifier.weight(1f), onGalleryClick, onShowDetail, includeIris = false)
            }
        }
        if (source != IrisLibrarySource.HITOMI) IrisLibrarySection(irisFilter, Modifier.weight(1f), sourceId = "ggoorr", showHeader = true)
    }
}

@Composable
private fun IrisUniversalDownloads(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    var nonce by remember { mutableIntStateOf(0) }
    val rows = remember(nonce) { runCatching { IrisUniversalDownloader.list(context) }.getOrDefault(emptyList()) }
    Column(modifier.padding(horizontal = 16.dp)) {
        Text("Downloads", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 12.dp))
        Text("웹/다른 앱의 직접 다운로드 링크를 Iris에서 관리", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(url, { url = it }, label = { Text("HTTP/HTTPS URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { runCatching { IrisUniversalDownloader.enqueue(context, url) }; url = ""; nonce++ }, enabled = url.isNotBlank()) { Text("Download") }
            OutlinedButton(onClick = { nonce++ }) { Text("Refresh") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows, key = { it.id }) { item ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(item.title.ifBlank { "Download #${item.id}" }, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                    val state = when (item.status) { DownloadManager.STATUS_SUCCESSFUL -> "Complete"; DownloadManager.STATUS_FAILED -> "Failed"; DownloadManager.STATUS_RUNNING -> "Downloading"; DownloadManager.STATUS_PAUSED -> "Paused"; else -> "Queued" }
                    val pct = if (item.total > 0) ((item.downloaded * 100L) / item.total).coerceIn(0,100) else 0
                    Text("$state · $pct%", style = MaterialTheme.typography.bodySmall)
                    if (item.total > 0) LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                    if (item.status != DownloadManager.STATUS_SUCCESSFUL) TextButton(onClick = { IrisUniversalDownloader.cancel(context, item.id); nonce++ }) { Text("Cancel") }
                }}
            }
        }
    }
}
