package xyz.quaver.pupil.util

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.URLUtil

data class IrisDownloadItem(val id: Long, val title: String, val status: Int, val downloaded: Long, val total: Long)

object IrisUniversalDownloader {
    fun firstUrl(text: String): String? = Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ')', ']', '}')

    fun enqueue(context: Context, rawUrl: String): Long {
        val url = firstUrl(rawUrl) ?: rawUrl.trim()
        require(url.startsWith("http://") || url.startsWith("https://")) { "HTTP/HTTPS URL only" }
        val name = URLUtil.guessFileName(url, null, null).ifBlank { "iris_${System.currentTimeMillis()}" }
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(name)
            .setDescription("Iris Gallery")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Iris/$name")
        return (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    }

    fun list(context: Context): List<IrisDownloadItem> {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val out = mutableListOf<IrisDownloadItem>()
        dm.query(DownloadManager.Query()).use { c ->
            val idCol = c.getColumnIndex(DownloadManager.COLUMN_ID)
            val titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val gotCol = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val totalCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            while (c.moveToNext()) out += IrisDownloadItem(c.getLong(idCol), c.getString(titleCol).orEmpty(), c.getInt(statusCol), c.getLong(gotCol), c.getLong(totalCol))
        }
        return out.sortedByDescending { it.id }
    }

    fun cancel(context: Context, id: Long) {
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id)
    }
}
