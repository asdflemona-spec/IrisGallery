# Iris Gallery v6.5 — Stability & Identity Baseline

- Removed the v6.4 universal/external download experiment and its share receiver.
- Kept the original Hitomi offline/cache pipeline required by the reader; this is not the removed experimental downloader.
- Replaced legacy Pupil launcher artwork with a new Iris eye/lens identity across launcher density resources.
- Removed the experimental Downloads source from Iris Library; Library is now All / Hitomi / Ggoorr / Gallery.
- Preserved the v5.2-based video playback path and v6.2 fit/contain media behavior.
- Preserved GPLv3 attribution and internal package names to avoid a risky package-wide refactor.
- Cleaned user-facing biometric branding where legacy Pupil wording remained.

Baseline rule: future features should be added on top of this stable branch without changing the proven video core unless required.
