# Iris Gallery v6.6 — Local Language Coach

- Adds a separate Language tab; Gallery behavior remains unchanged.
- Imports a user-selected Qwen3-4B-Q4_K_M GGUF into private app storage.
- Runs local CPU inference through a JNI bridge backed by llama.cpp b10964 (v0.4.1-era release).
- Initial learning UX: target language, CEFR level, free conversation / role-play / correction modes.
- Prompt policy favors natural native-style continuation plus concise corrections instead of constant lectures.
- ARM64 only for the first inference build. Model is never bundled in the APK.
- Existing v5.2-derived video player is untouched.

Build note: CMake FetchContent downloads the pinned llama.cpp source while Gradle builds the native library. The GitHub Actions runner therefore needs GitHub network access during the build.
