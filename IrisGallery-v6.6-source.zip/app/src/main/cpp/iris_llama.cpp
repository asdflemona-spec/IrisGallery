#include <jni.h>
#include <string>
#include <vector>
#include "llama.h"
#include "ggml-backend.h"

extern "C" JNIEXPORT jstring JNICALL
Java_xyz_quaver_pupil_ui_IrisLocalLlm_generate(JNIEnv *env, jobject, jstring jpath, jstring jprompt, jint max_tokens) {
    const char *path_c = env->GetStringUTFChars(jpath, nullptr);
    const char *prompt_c = env->GetStringUTFChars(jprompt, nullptr);
    std::string path(path_c), prompt(prompt_c);
    env->ReleaseStringUTFChars(jpath, path_c); env->ReleaseStringUTFChars(jprompt, prompt_c);
    ggml_backend_load_all();
    llama_model_params mp = llama_model_default_params(); mp.n_gpu_layers = 0;
    llama_model *model = llama_model_load_from_file(path.c_str(), mp);
    if (!model) return env->NewStringUTF("Unable to load GGUF model");
    const llama_vocab *vocab = llama_model_get_vocab(model);
    int n_prompt = -llama_tokenize(vocab, prompt.c_str(), prompt.size(), nullptr, 0, true, true);
    if (n_prompt <= 0) { llama_model_free(model); return env->NewStringUTF("Tokenization failed"); }
    std::vector<llama_token> tokens(n_prompt);
    if (llama_tokenize(vocab, prompt.c_str(), prompt.size(), tokens.data(), tokens.size(), true, true) < 0) { llama_model_free(model); return env->NewStringUTF("Tokenization failed"); }
    llama_context_params cp = llama_context_default_params(); cp.n_ctx = std::max(2048, n_prompt + (int)max_tokens + 16); cp.n_batch = std::min(512, n_prompt); cp.n_threads = 4; cp.n_threads_batch = 4;
    llama_context *ctx = llama_init_from_model(model, cp);
    if (!ctx) { llama_model_free(model); return env->NewStringUTF("Unable to create model context"); }
    auto sp = llama_sampler_chain_default_params(); llama_sampler *smpl = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f)); llama_sampler_chain_add(smpl, llama_sampler_init_dist(42));
    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
    std::string out; int pos = 0;
    for (int i=0; i<max_tokens; ++i) {
        if (llama_decode(ctx, batch) != 0) break; pos += batch.n_tokens;
        llama_token id = llama_sampler_sample(smpl, ctx, -1); if (llama_vocab_is_eog(vocab, id)) break;
        char buf[512]; int n = llama_token_to_piece(vocab, id, buf, sizeof(buf), 0, true); if (n > 0) out.append(buf, n);
        batch = llama_batch_get_one(&id, 1);
    }
    llama_sampler_free(smpl); llama_free(ctx); llama_model_free(model);
    return env->NewStringUTF(out.c_str());
}
