package xyz.quaver.pupil.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class CoachMessage(val role: String, val text: String)

private object IrisLocalLlm {
    init { System.loadLibrary("iris_llama") }
    external fun generate(modelPath: String, prompt: String, maxTokens: Int): String
}

@Composable
fun IrisLanguageScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("iris_language", Context.MODE_PRIVATE) }
    var modelPath by remember { mutableStateOf(prefs.getString("model_path", null)) }
    var targetLanguage by remember { mutableStateOf(prefs.getString("target", "Japanese") ?: "Japanese") }
    var level by remember { mutableStateOf(prefs.getString("level", "A2") ?: "A2") }
    var mode by remember { mutableStateOf("Free conversation") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf<CoachMessage>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true; status = "Importing GGUF…"
            runCatching {
                val dir = File(context.filesDir, "models").apply { mkdirs() }
                val out = File(dir, "qwen3-4b-q4_k_m.gguf")
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri).use { src ->
                        requireNotNull(src) { "Cannot open selected model" }
                        out.outputStream().use { dst -> src.copyTo(dst, 1024 * 1024) }
                    }
                }
                require(out.length() > 1024L * 1024L * 1024L) { "Selected file is too small for the expected 4B GGUF" }
                modelPath = out.absolutePath
                prefs.edit().putString("model_path", out.absolutePath).apply()
                status = "Model ready · ${out.length() / 1024 / 1024} MB"
            }.onFailure { status = "Import failed: ${it.message}" }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("Language Coach", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
        Text("Private, on-device conversation practice", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Japanese", "English", "Spanish").forEach { lang ->
                FilterChip(selected = targetLanguage == lang, onClick = { targetLanguage = lang; prefs.edit().putString("target", lang).apply() }, label = { Text(lang) })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("A1", "A2", "B1", "B2").forEach { v ->
                FilterChip(selected = level == v, onClick = { level = v; prefs.edit().putString("level", v).apply() }, label = { Text(v) })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Free conversation", "Role-play", "Correction").forEach { v ->
                FilterChip(selected = mode == v, onClick = { mode = v }, label = { Text(v) })
            }
        }

        if (modelPath == null) {
            Card(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Qwen3 model required", style = MaterialTheme.typography.titleMedium)
                    Text("Select your Qwen3-4B-Q4_K_M.gguf. Iris copies it to private app storage; the model is not bundled in the APK.", modifier = Modifier.padding(vertical = 8.dp))
                    Button(enabled = !busy, onClick = { picker.launch(arrayOf("application/octet-stream", "*/*")) }) { Text("Select GGUF") }
                }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Text("Qwen3 local · ready", modifier = Modifier.weight(1f))
                TextButton(enabled = !busy, onClick = { picker.launch(arrayOf("application/octet-stream", "*/*")) }) { Text("Change") }
            }
        }
        status?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            if (messages.isEmpty()) item { Text("Start naturally. Iris will keep the conversation flowing and correct you without turning every message into a lesson.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(messages) { msg ->
                Surface(tonalElevation = if (msg.role == "user") 3.dp else 1.dp, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth(if (msg.role == "user") .88f else 1f)) {
                    Column(Modifier.padding(12.dp)) { Text(if (msg.role == "user") "You" else "Coach", style = MaterialTheme.typography.labelMedium); Text(msg.text) }
                }
            }
            if (busy && modelPath != null) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, enabled = !busy && modelPath != null, placeholder = { Text("Say something…") }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(enabled = input.isNotBlank() && !busy && modelPath != null, onClick = {
                val user = input.trim(); input = ""; messages += CoachMessage("user", user); busy = true
                scope.launch {
                    val history = messages.takeLast(10).joinToString("\n") { "${it.role}: ${it.text}" }
                    val prompt = """<|im_start|>system
You are Iris Language Coach. Target language: $targetLanguage. CEFR level: $level. Mode: $mode.
Act like a friendly native speaker. Continue primarily in the target language. Do not lecture unless needed. If the learner's phrase is unnatural, first reply naturally, then add one short line beginning 'Natural:' with a more native alternative. Explain nuance briefly in Korean only when useful. Never pretend there is only one correct native expression.<|im_end|>
<|im_start|>user
Conversation so far:
$history
Reply to the latest learner message.<|im_end|>
<|im_start|>assistant
"""
                    val result = runCatching { withContext(Dispatchers.Default) { IrisLocalLlm.generate(modelPath!!, prompt, 256) } }
                    messages += CoachMessage("assistant", result.getOrElse { "Local model error: ${it.message}" })
                    busy = false
                }
            }) { Text("Send") }
        }
    }
}
