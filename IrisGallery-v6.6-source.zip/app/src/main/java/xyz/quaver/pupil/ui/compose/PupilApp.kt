/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.union
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import xyz.quaver.pupil.R
import xyz.quaver.pupil.hitomi.SearchQuery
import xyz.quaver.pupil.ui.viewmodel.DownloadsViewModel
import xyz.quaver.pupil.ui.viewmodel.FavoritesViewModel
import xyz.quaver.pupil.ui.viewmodel.GalleryListViewModel
import xyz.quaver.pupil.ui.viewmodel.HistoryViewModel
import xyz.quaver.pupil.ui.viewmodel.LocalGalleryListViewModel
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel
import xyz.quaver.pupil.watchlist

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PupilApp(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
    initialQuery: SearchQuery? = null,
    onInitialQueryConsumed: () -> Unit = {},
    onGalleryClick: (Int) -> Unit = {},
    onGalleryPageClick: (galleryID: Int, page: Int) -> Unit = { galleryID, _ -> onGalleryClick(galleryID) },
    onSettingsClick: () -> Unit = {},
) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    // Held here, and not in SearchScreen, so the detail page covers the
    // navigation bar the way the dialog it replaced did.
    val searchViewModel: SearchViewModel = viewModel()
    val detailStack = rememberSaveable(saver = detailStackSaver) { mutableStateListOf<Int>() }

    val snackbarHostState = remember { SnackbarHostState() }
    val searchAll = { query: SearchQuery ->
        // The detail is drawn over the whole app rather than inside the screen it
        // was opened from, so it outlives a move to another one. It covers the
        // search this is navigating to, and the screen it leaves behind registers
        // its back and volume keys after the detail did -- taking them from it.
        detailStack.clear()

        searchViewModel.onQueryChange(query)
        navController.navigateToTopLevel(Destination.Search)
    }

    LaunchedEffect(initialQuery) {
        if (initialQuery == null) return@LaunchedEffect

        watchlist.markSeen(initialQuery)
        searchAll(initialQuery)
        onInitialQueryConsumed()
    }

    val irisViewerActive = remember { androidx.compose.runtime.mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            // Screens draw behind the transparent status bar and keep the top inset
            // off themselves; the bottom bar gets its own from innerPadding. Only
            // the sides, where landscape puts the navigation bar and the cutout,
            // are applied here.
            contentWindowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!irisViewerActive.value) NavigationBar(
                    windowInsets = NavigationBarDefaults.windowInsets
                        .union(WindowInsets.displayCutout.only(WindowInsetsSides.Horizontal)),
                ) {
                    Destination.entries.forEach { destination ->
                        NavigationBarItem(
                            selected = currentRoute == destination.route,
                            onClick = {
                                if (destination == Destination.Settings) {
                                    onSettingsClick()
                                    return@NavigationBarItem
                                }

                                if (currentRoute == destination.route) {
                                    if (destination == Destination.Search) searchViewModel.reset()
                                    return@NavigationBarItem
                                }

                                navController.navigateToTopLevel(destination)
                            },
                            icon = {
                                Icon(
                                    painter = painterResource(destination.iconRes),
                                    contentDescription = null,
                                )
                            },
                            label = { Text(stringResource(destination.labelRes)) },
                        )
                    }
                }
            },
        ) { innerPadding ->
            // The detail page covers these, and a screen that is covered owns
            // neither key: see LocalScreenCovered for why being composed first
            // is not enough to settle that.
            CompositionLocalProvider(
                LocalScreenCovered provides detailStack.isNotEmpty(),
            ) {
                NavHost(
                    navController = navController,
                    startDestination = Destination.Search.route,
                    // Consume as well as apply: otherwise imePadding() further in would
                    // add insets Scaffold has already accounted for, stacking the bottom
                    // bar's height on top of the keyboard inset.
                    modifier = Modifier
                        .padding(innerPadding)
                        .consumeWindowInsets(innerPadding),
                ) {
                    composable(Destination.Search.route) {
                        IrisHomeScreen(
                            onGalleryClick = onGalleryClick,
                            onShowDetail = { detailStack.add(it) },
                            searchViewModel = searchViewModel,
                            onViewerActiveChanged = { irisViewerActive.value = it },
                        )
                    }

                    composable(Destination.Language.route) {
                        IrisLanguageScreen()
                    }

                    composable(Destination.Favorites.route) {
                        val viewModel: FavoritesViewModel = viewModel()
                        OfferSearchAll(viewModel, snackbarHostState, searchAll)

                        IrisLibraryHub(
                            onGalleryClick = onGalleryClick,
                            onShowDetail = { detailStack.add(it) },
                        )
                    }

                }
            }
        }

        // Keyed, so a detail opened from a detail starts at its own top instead
        // of inheriting the scroll position of the one underneath it.
        detailStack.lastOrNull()?.let { galleryID ->
            val listViewModel = listViewModelFor(currentRoute, backStackEntry, searchViewModel)

            key(galleryID) {
                GalleryDetailPage(
                    galleryID = galleryID,
                    onDismiss = { detailStack.removeAt(detailStack.lastIndex) },
                    onOpen = onGalleryClick,
                    onOpenPage = { page -> onGalleryPageClick(galleryID, page) },
                    onTagClick = { tag ->
                        listViewModel.onQueryChange(tag)
                        detailStack.clear()
                    },
                    onShowRelatedDetail = { detailStack.add(it) },
                )
            }
        }
    }
}

/**
 * Offers to run a query narrowing one of the app's own lists against every
 * gallery instead, for as long as that query stands and its list is on screen.
 */
@Composable
private fun OfferSearchAll(
    viewModel: LocalGalleryListViewModel,
    snackbarHostState: SnackbarHostState,
    onSearchAll: (SearchQuery) -> Unit,
) {
    val message = stringResource(R.string.search_all)
    val actionLabel = stringResource(android.R.string.ok)

    LaunchedEffect(viewModel, snackbarHostState) {
        snapshotFlow { viewModel.query }
            .drop(1)
            .collectLatest { query ->
                if (query == null) return@collectLatest

                val result = snackbarHostState.showSnackbar(message, actionLabel)
                if (result == SnackbarResult.ActionPerformed) onSearchAll(query)
            }
    }
}

private fun NavHostController.navigateToTopLevel(destination: Destination) =
    navigate(destination.route) {
        popUpTo(Destination.Search.route) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

/**
 * The list under the detail overlay, so a tag picked there searches the
 * destination it was picked from rather than sending the reader home.
 *
 * Looked up on the destination's own entry, and only while a detail is open, so
 * a list is still not built until its tab is visited.
 */
@Composable
private fun listViewModelFor(
    route: String?,
    entry: NavBackStackEntry?,
    searchViewModel: SearchViewModel,
): GalleryListViewModel = when {
    entry == null -> searchViewModel
    route == Destination.Favorites.route -> viewModel<FavoritesViewModel>(entry)
    else -> searchViewModel
}

private val detailStackSaver = listSaver<SnapshotStateList<Int>, Int>(
    save = { it.toList() },
    restore = { it.toMutableStateList() },
)
