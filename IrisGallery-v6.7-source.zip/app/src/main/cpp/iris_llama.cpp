#include <jni.h>
#include <algorithm>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "llama.h"
#include "ggml-backend.h"

namespace {
std::mutex g_mutex;
llama_model *g_model = nullptr;
std::string g_model_path;

void unload_locked() {
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    g_model_path.clear();
}

bool load_locked(const std::string &path) {
    if (g_model && g_model_path == path) return true;
    unload_locked();
    ggml_backend_load_all();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) return false;
    g_model_path = path;
    return true;
}
}

extern "C" JNIEXPORT jboolean JNICALL
Java_xyz_quaver_pupil_ui_IrisLocalLlm_loadModel(JNIEnv *env, jobject, jstring jpath) {
    const char *p = env->GetStringUTFChars(jpath, nullptr);
    std::string path(p);
    env->ReleaseStringUTFChars(jpath, p);
    std::lock_guard<std::mutex> lock(g_mutex);
    return load_locked(path) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_xyz_quaver_pupil_ui_IrisLocalLlm_unloadModel(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();
}

extern "C" JNIEXPORT jstring JNICALL
Java_xyz_quaver_pupil_ui_IrisLocalLlm_generate(JNIEnv *env, jobject, jstring jpath, jstring jprompt, jint max_tokens, jobject callback) {
    const char *path_c = env->GetStringUTFChars(jpath, nullptr);
    const char *prompt_c = env->GetStringUTFChars(jprompt, nullptr);
    std::string path(path_c), prompt(prompt_c);
    env->ReleaseStringUTFChars(jpath, path_c);
    env->ReleaseStringUTFChars(jprompt, prompt_c);

    std::lock_guard<std::mutex> lock(g_mutex);
    if (!load_locked(path)) return env->NewStringUTF("Unable to load GGUF model");

    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    int n_prompt = -llama_tokenize(vocab, prompt.c_str(), prompt.size(), nullptr, 0, true, true);
    if (n_prompt <= 0) return env->NewStringUTF("Tokenization failed");
    std::vector<llama_token> tokens(n_prompt);
    if (llama_tokenize(vocab, prompt.c_str(), prompt.size(), tokens.data(), tokens.size(), true, true) < 0)
        return env->NewStringUTF("Tokenization failed");

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 4096;
    cp.n_batch = std::min(512, std::max(32, n_prompt));
    unsigned hc = std::thread::hardware_concurrency();
    int threads = std::max(2, std::min(6, hc > 1 ? (int)hc - 1 : 2));
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    llama_context *ctx = llama_init_from_model(g_model, cp);
    if (!ctx) return env->NewStringUTF("Unable to create model context");

    auto sp = llama_sampler_chain_default_params();
    llama_sampler *smpl = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    jclass cbClass = callback ? env->GetObjectClass(callback) : nullptr;
    jmethodID onToken = cbClass ? env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)V") : nullptr;

    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
    std::string out;
    for (int i = 0; i < max_tokens; ++i) {
        if (llama_decode(ctx, batch) != 0) break;
        llama_token id = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) break;
        char buf[512];
        int n = llama_token_to_piece(vocab, id, buf, sizeof(buf), 0, true);
        if (n > 0) {
            std::string piece(buf, n);
            out += piece;
            if (onToken) {
                jstring jp = env->NewStringUTF(piece.c_str());
                if (jp) { env->CallVoidMethod(callback, onToken, jp); env->DeleteLocalRef(jp); }
                if (env->ExceptionCheck()) env->ExceptionClear();
            }
        }
        batch = llama_batch_get_one(&id, 1);
    }
    if (cbClass) env->DeleteLocalRef(cbClass);
    llama_sampler_free(smpl);
    llama_free(ctx);
    return env->NewStringUTF(out.c_str());
}
