#include <jni.h>
#include <algorithm>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "llama.h"
#include "ggml-backend.h"

namespace {
std::mutex g_mutex;
llama_model *g_model = nullptr;
std::string g_model_path;

void unload_locked() {
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_model_path.clear();
}

bool load_locked(const std::string &path) {
    if (g_model && g_model_path == path) return true;
    unload_locked();
    ggml_backend_load_all();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) return false;
    g_model_path = path;
    return true;
}

jstring error_result(JNIEnv *env, const std::string &msg) {
    return env->NewStringUTF(("ERROR: " + msg).c_str());
}

std::string apply_chat_template(const std::string &system, const std::string &user) {
    const char *tmpl = llama_model_chat_template(g_model, nullptr);
    if (!tmpl) return {};
    llama_chat_message chat[2] = {{"system", system.c_str()}, {"user", user.c_str()}};
    int32_t needed = llama_chat_apply_template(tmpl, chat, 2, true, nullptr, 0);
    if (needed < 0) return {};
    std::vector<char> buf((size_t) needed + 1);
    int32_t written = llama_chat_apply_template(tmpl, chat, 2, true, buf.data(), (int32_t)buf.size());
    if (written < 0 || written > (int32_t)buf.size()) return {};
    return std::string(buf.data(), (size_t) written);
}
}

extern "C" JNIEXPORT jboolean JNICALL
Java_xyz_quaver_pupil_ui_IrisLocalLlm_loadModel(JNIEnv *env, jobject, jstring jpath) {
    const char *p = env->GetStringUTFChars(jpath, nullptr);
    std::string path(p); env->ReleaseStringUTFChars(jpath, p);
    std::lock_guard<std::mutex> lock(g_mutex);
    return load_locked(path) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_xyz_quaver_pupil_ui_IrisLocalLlm_unloadModel(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex); unload_locked();
}

extern "C" JNIEXPORT jstring JNICALL
Java_xyz_quaver_pupil_ui_IrisLocalLlm_generate(JNIEnv *env, jobject, jstring jpath, jstring jprompt, jint max_tokens, jobject callback) {
    const char *path_c = env->GetStringUTFChars(jpath, nullptr);
    const char *prompt_c = env->GetStringUTFChars(jprompt, nullptr);
    std::string path(path_c), user_content(prompt_c);
    env->ReleaseStringUTFChars(jpath, path_c); env->ReleaseStringUTFChars(jprompt, prompt_c);

    std::lock_guard<std::mutex> lock(g_mutex);
    if (!load_locked(path)) return error_result(env, "model load failed");

    const std::string system = "You are Iris Language Coach. Follow the learner settings and answer naturally and concisely.";
    std::string prompt = apply_chat_template(system, user_content);
    if (prompt.empty()) return error_result(env, "model chat template is missing or unsupported");

    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    int n_prompt = -llama_tokenize(vocab, prompt.c_str(), prompt.size(), nullptr, 0, true, true);
    if (n_prompt <= 0) return error_result(env, "tokenization size failed");
    if (n_prompt >= 3968) return error_result(env, "prompt exceeds 4096-token context");
    std::vector<llama_token> tokens((size_t)n_prompt);
    int tokenized = llama_tokenize(vocab, prompt.c_str(), prompt.size(), tokens.data(), (int32_t)tokens.size(), true, true);
    if (tokenized < 0) return error_result(env, "tokenization failed");

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 4096;
    cp.n_batch = std::min(512, std::max(32, n_prompt));
    unsigned hc = std::thread::hardware_concurrency();
    int threads = std::max(2, std::min(6, hc > 1 ? (int)hc - 1 : 2));
    cp.n_threads = threads; cp.n_threads_batch = threads;
    llama_context *ctx = llama_init_from_model(g_model, cp);
    if (!ctx) return error_result(env, "context creation failed");

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_min_p(0.05f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    jclass cbClass = callback ? env->GetObjectClass(callback) : nullptr;
    jmethodID onToken = cbClass ? env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)V") : nullptr;

    std::string out;
    std::string failure;
    llama_batch batch = llama_batch_get_one(tokens.data(), (int32_t)tokens.size());
    for (int i = 0; i < max_tokens; ++i) {
        int decode_rc = llama_decode(ctx, batch);
        if (decode_rc != 0) { failure = "llama_decode failed (code " + std::to_string(decode_rc) + ")"; break; }
        llama_token id = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) {
            if (out.empty()) failure = "model returned EOG before producing text";
            break;
        }
        char buf[1024];
        int n = llama_token_to_piece(vocab, id, buf, sizeof(buf), 0, true);
        if (n < 0) { failure = "token_to_piece failed"; break; }
        if (n > 0) {
            std::string piece(buf, (size_t)n); out += piece;
            if (onToken) {
                jstring jp = env->NewStringUTF(piece.c_str());
                if (jp) { env->CallVoidMethod(callback, onToken, jp); env->DeleteLocalRef(jp); }
                if (env->ExceptionCheck()) { env->ExceptionClear(); failure = "Kotlin token callback failed"; break; }
            }
        }
        batch = llama_batch_get_one(&id, 1);
    }

    if (cbClass) env->DeleteLocalRef(cbClass);
    llama_sampler_free(smpl); llama_free(ctx);
    if (!failure.empty()) return error_result(env, failure);
    if (out.empty()) return error_result(env, "generation produced zero text tokens");
    return env->NewStringUTF(out.c_str());
}
