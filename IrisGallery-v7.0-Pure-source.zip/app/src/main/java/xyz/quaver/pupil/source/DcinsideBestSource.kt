package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI

/** Read-only adapter for DCInside Real-time Best. Only posts whose title contains "ㅇㅎ" are exposed. */
class DcinsideBestSource : ContentSource {
    override val id = "dcinside"
    override val displayName = "DCInside ㅇㅎ"
    override val maturity = SourceMaturity.ADULT
    override val availability = SourceAvailability.READY
    override val capabilities = setOf(SourceCapability.BROWSE, SourceCapability.DETAIL, SourceCapability.MULTI_IMAGE)

    private val baseUrl = "https://gall.dcinside.com"
    private val listUrl = "$baseUrl/board/lists/?id=dcbest"
    val requestHeaders = mapOf(
        "Referer" to listUrl,
        "User-Agent" to "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
    )

    private suspend fun document(url: String): Document {
        val response = client.get(url) { requestHeaders.forEach { (k, v) -> header(k, v) } }
        if (!response.status.isSuccess()) throw IOException("DCInside HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }

    override suspend fun search(query: String, page: Int): SourcePage {
        val pageNo = page + 1
        val doc = document("$listUrl&page=$pageNo")
        val seen = hashSetOf<String>()
        val items = doc.select("tr.ub-content, tr.us-post, .gall_list tr").mapNotNull { row ->
            val link = row.selectFirst("a[href*='id=dcbest'][href*='no=']") ?: return@mapNotNull null
            val title = link.text().trim()
            if (!title.contains("ㅇㅎ") || (query.isNotBlank() && !title.contains(query, ignoreCase = true))) return@mapNotNull null
            val href = link.absUrl("href").ifBlank { absolute(link.attr("href")) ?: return@mapNotNull null }
            val remoteId = Regex("(?:[?&])no=(\\d+)").find(href)?.groupValues?.get(1) ?: return@mapNotNull null
            if (!seen.add(remoteId)) return@mapNotNull null
            SourceItem(id, remoteId, title, null, "$baseUrl/board/view/?id=dcbest&no=$remoteId", tags = listOf("ㅇㅎ"))
        }
        return SourcePage(items, page + 1)
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        val url = "$baseUrl/board/view/?id=dcbest&no=$remoteId"
        val doc = document(url)
        val title = doc.selectFirst(".title_subject, .gall_tit, h3, h1")?.text()?.trim()?.takeIf { it.isNotBlank() } ?: doc.title()
        if (!title.contains("ㅇㅎ")) throw IOException("Filtered DCInside post")
        val scope = doc.selectFirst(".write_div, .writing_view_box, .view_content_wrap, .gallview_contents") ?: doc.body()
        val media = linkedSetOf<String>()
        scope.select("img").forEach { img -> imageCandidates(img).forEach(media::add) }
        scope.select("a[href]").forEach { a ->
            absolute(a.attr("href"))?.takeIf(::looksLikeImage)?.let(media::add)
        }
        val filtered = media.filterNot { u -> listOf("icon", "logo", "avatar", "dccon", "emoticon").any { u.contains(it, true) } }
        return SourceDetail(SourceItem(id, remoteId, title, filtered.firstOrNull(), url, listOf("ㅇㅎ")), filtered)
    }

    private fun imageCandidates(img: Element): List<String> {
        val out = linkedSetOf<String>()
        listOf("data-original", "data-src", "data-url", "src").forEach { k -> absolute(img.attr(k))?.let(out::add) }
        return out.filter(::looksLikeImage)
    }

    private fun absolute(raw0: String): String? {
        val raw = raw0.trim().replace("&amp;", "&")
        if (raw.isBlank() || raw.startsWith("data:") || raw.startsWith("javascript:")) return null
        return try { if (raw.startsWith("//")) "https:$raw" else URI(baseUrl).resolve(raw).toString() } catch (_: Exception) { null }
    }

    private fun looksLikeImage(url: String): Boolean {
        val clean = url.substringBefore('?').lowercase()
        return listOf(".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif").any(clean::endsWith)
    }
}
