# Iris Gallery v6.6.2

Native build compatibility patch for the local Language Coach.

- Keeps the app minSdk at 21.
- Keeps llama.cpp pinned to b10964.
- On Android API targets below 23, maps `posix_madvise` / `POSIX_MADV_*` to the equivalent Bionic `madvise` / `MADV_*` API during native compilation.
- No Gallery or v5.2 video-player changes.

This patch addresses the GitHub Actions failure in `llama-mmap.cpp` while preserving the existing Android compatibility target.
