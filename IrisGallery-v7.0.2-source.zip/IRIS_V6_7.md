# Iris Gallery v6.7 — mobile LLM performance patch

- Keeps the selected GGUF model loaded across messages instead of reloading it for every send.
- Streams generated token pieces into the chat UI.
- Uses a 4096-token context and a device-aware CPU thread count (2–6).
- Caps normal replies at 128 generated tokens and adds Qwen `/no_think` for low-latency conversation.
- Accepts small compatible GGUF models such as Qwen3-0.6B; removes the old >1 GB / 4B-only import assumption.
- Validates the GGUF magic header on import.
- Model/context KV-cache reuse is intentionally deferred; v6.7 persists the model while creating a fresh context per request.
