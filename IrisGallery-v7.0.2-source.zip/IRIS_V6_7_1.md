# Iris Gallery v6.7.1

Language inference diagnostic/fix release.

- Uses the GGUF model's own llama.cpp chat template instead of hand-written ChatML markers.
- Moves `/no_think` into the user content.
- Surfaces native model/decode/tokenization/zero-output failures in the chat UI.
- Treats immediate EOG and zero generated text as errors instead of silent empty replies.
- Uses min-p + temperature + distribution sampler chain.
- Keeps the persistent loaded model behavior from v6.7.
- Does not modify gallery/video code.
