# Iris Gallery v6.7.2

Inference reliability patch based directly on llama.cpp b10964 `examples/simple-chat/simple-chat.cpp`.

- Context reduced to 2048 for the minimal mobile test path.
- `n_batch = n_ctx`, matching the official simple-chat example.
- Sampler uses min-p 0.05 + temperature 0.8 + dist, matching the example.
- Output capped at 96 tokens for the first-response test.
- JNI token callback streaming is temporarily disabled; the native synchronous result is shown after generation. This isolates inference from callback/coroutine issues.
- Model remains loaded between sends.
- No Gallery/video code changed.

Test target: Qwen3-0.6B GGUF, English/A1, message `hi`.
