# Iris Gallery v7.0 Pure

- Removed Language Coach / llama.cpp / JNI / GGUF integration completely.
- Removed the arm64-only ABI restriction introduced for local LLM experiments.
- Restored Iris to a media-first gallery application.
- Added a read-only DCInside Real-time Best source.
- DCInside adapter only exposes dcbest posts whose title contains the literal string `ㅇㅎ`.
- Post detail extracts image media and uses the existing Iris viewer/library actions.
- Hitomi and Ggoorr remain intact.
- v5.2 video player path was not modified.
