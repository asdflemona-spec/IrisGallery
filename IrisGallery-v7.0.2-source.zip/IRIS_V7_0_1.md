# Iris v7.0.1 — DCInside source fix

- Fix empty DCInside `ㅇㅎ` source when the first real-time-best page contains no matching title.
- Prefer DCInside subject/body search for `ㅇㅎ`; first-load fallback scans up to 12 live dcbest pages.
- Use the real subject-cell link selector instead of a broad first matching anchor.
- Accept DCInside `viewimage.php` attachment URLs that have no image extension.
- Add Korean Accept-Language header.
- No Language/LLM code restored. v5.2 media player remains untouched.
