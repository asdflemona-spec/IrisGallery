# Iris Gallery v7.0.2

- DCInside source now uses Real-time Best (`dcbest`) built-in title search for `ㅇㅎ` only.
- Removed the multi-page fallback crawler entirely.
- Pagination advances only through DCInside search-result pages.
- Keeps the title `ㅇㅎ` check as a defensive filter.
- No Language/LLM code. Media/video pipeline unchanged.
