package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI
import java.net.URLEncoder

/** Read-only DCInside Real-time Best adapter. Exposes only posts whose title contains "ㅇㅎ". */
class DcinsideBestSource : ContentSource {
    override val id = "dcinside"
    override val displayName = "DCInside ㅇㅎ"
    override val maturity = SourceMaturity.ADULT
    override val availability = SourceAvailability.READY
    override val capabilities = setOf(SourceCapability.BROWSE, SourceCapability.DETAIL, SourceCapability.MULTI_IMAGE)

    private val baseUrl = "https://gall.dcinside.com"
    private val listUrl = "$baseUrl/board/lists/?id=dcbest"
    private val keyword = "ㅇㅎ"
    private val encodedKeyword = URLEncoder.encode(keyword, Charsets.UTF_8.name())

    val requestHeaders = mapOf(
        "Referer" to listUrl,
        "User-Agent" to "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36",
        "Accept-Language" to "ko-KR,ko;q=0.9,en;q=0.7",
    )

    private suspend fun document(url: String): Document {
        val response = client.get(url) { requestHeaders.forEach { (k, v) -> header(k, v) } }
        if (!response.status.isSuccess()) throw IOException("DCInside HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }

    override suspend fun search(query: String, page: Int): SourcePage {
        // Use DCInside's own Real-time Best title search directly. Do not crawl normal
        // dcbest pages: pagination here is pagination of the search result itself.
        val dcPage = page + 1
        val searchUrl = "$listUrl&page=$dcPage&s_type=search_subject&s_keyword=$encodedKeyword"
        val found = parseList(document(searchUrl), query)
        return SourcePage(found, page + 1)
    }

    private fun parseList(doc: Document, query: String): List<SourceItem> {
        val seen = hashSetOf<String>()
        return doc.select("tr.ub-content, tr.us-post, .gall_list tr").mapNotNull { row ->
            // gall_tit is the actual subject cell. Avoid picking comment/profile links first.
            val link = row.selectFirst(".gall_tit a[href*='no='], a[href*='/board/view/'][href*='no='], a[href*='id=dcbest'][href*='no=']")
                ?: return@mapNotNull null
            val title = link.text().trim().ifBlank { row.selectFirst(".gall_tit")?.text()?.trim().orEmpty() }
            if (!title.contains(keyword) || (query.isNotBlank() && !title.contains(query, ignoreCase = true))) return@mapNotNull null
            val href = link.absUrl("href").ifBlank { absolute(link.attr("href")) ?: return@mapNotNull null }
            val remoteId = Regex("(?:[?&])no=(\\d+)").find(href)?.groupValues?.get(1) ?: return@mapNotNull null
            if (!seen.add(remoteId)) return@mapNotNull null
            SourceItem(id, remoteId, title, null, "$baseUrl/board/view/?id=dcbest&no=$remoteId", tags = listOf(keyword))
        }
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        val url = "$baseUrl/board/view/?id=dcbest&no=$remoteId"
        val doc = document(url)
        val title = doc.selectFirst(".title_subject, .gall_tit, h3, h1")?.text()?.trim()?.takeIf { it.isNotBlank() } ?: doc.title()
        if (!title.contains(keyword)) throw IOException("Filtered DCInside post")

        val scope = doc.selectFirst(".write_div, .writing_view_box, .view_content_wrap, .gallview_contents") ?: doc.body()
        val media = linkedSetOf<String>()
        scope.select("img").forEach { img -> imageCandidates(img).forEach(media::add) }
        scope.select("a[href]").forEach { a -> absolute(a.attr("href"))?.takeIf(::looksLikeMedia)?.let(media::add) }

        val filtered = media.filterNot { u ->
            listOf("icon", "logo", "avatar", "dccon", "emoticon", "gallog").any { u.contains(it, true) }
        }
        if (filtered.isEmpty()) throw IOException("DCInside post has no extractable media")
        return SourceDetail(SourceItem(id, remoteId, title, filtered.first(), url, listOf(keyword)), filtered)
    }

    private fun imageCandidates(img: Element): List<String> {
        val out = linkedSetOf<String>()
        listOf("data-original", "data-src", "data-url", "data-lazy-src", "src").forEach { k ->
            absolute(img.attr(k))?.let(out::add)
        }
        return out.filter(::looksLikeMedia)
    }

    private fun absolute(raw0: String): String? {
        val raw = raw0.trim().replace("&amp;", "&")
        if (raw.isBlank() || raw.startsWith("data:") || raw.startsWith("javascript:")) return null
        return try { if (raw.startsWith("//")) "https:$raw" else URI(baseUrl).resolve(raw).toString() } catch (_: Exception) { null }
    }

    private fun looksLikeMedia(url: String): Boolean {
        val lower = url.lowercase()
        val clean = lower.substringBefore('?')
        if (listOf(".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif").any(clean::endsWith)) return true
        // DCInside commonly serves original attachments through viewimage.php URLs with
        // no filename extension. v7.0 incorrectly discarded these.
        return "viewimage.php" in lower || "image.dcinside.com" in lower
    }
}
