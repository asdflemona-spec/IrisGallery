# Iris Gallery v7.1 — Pure Performance

## Scope
- Removed the experimental DCInside / dcbest source completely.
- Search sources are again Hitomi + Ggoorr only.
- Removed DCInside from SourceRegistry, Search source chips, and Library filters.
- Kept the proven v5.2 local video playback path unchanged.
- Kept the app free of the removed Language/LLM/JNI stack.

## Performance direction
This release intentionally avoids another large feature. The existing Iris presentation surfaces continue to share the same media/library core. Existing stable lazy-list keys and incremental Ggoorr paging are preserved rather than adding a second crawler or parallel media pipeline.

Future performance work should be measured in release builds before changing the proven viewer path: image decode sizing/cache reuse, bounded prefetch, and recomposition profiling are the next candidates.
